/**
 * WSUREDMSInterfaceServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf111019.19 v52610232443
 */

package us.pa.state.dot.ecms.webservices;

public class WSUREDMSInterfaceServiceLocator extends com.ibm.ws.webservices.multiprotocol.AgnosticService implements com.ibm.ws.webservices.multiprotocol.GeneratedService, us.pa.state.dot.ecms.webservices.WSUREDMSInterfaceService {

    public WSUREDMSInterfaceServiceLocator() {
        super(com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
           "http://webservices.ecms.dot.state.pa.us",
           "WSUREDMSInterfaceService"));

        context.setLocatorName("us.pa.state.dot.ecms.webservices.WSUREDMSInterfaceServiceLocator");
    }

    public WSUREDMSInterfaceServiceLocator(com.ibm.ws.webservices.multiprotocol.ServiceContext ctx) {
        super(ctx);
        context.setLocatorName("us.pa.state.dot.ecms.webservices.WSUREDMSInterfaceServiceLocator");
    }

    // Use to get a proxy class for WSUREDMSInterface
    private final java.lang.String WSUREDMSInterface_address = "http://localhost:9080/ECMSWebService/services/WSUREDMSInterface";

    public java.lang.String getWSUREDMSInterfaceAddress() {
        if (context.getOverriddingEndpointURIs() == null) {
            return WSUREDMSInterface_address;
        }
        String overriddingEndpoint = (String) context.getOverriddingEndpointURIs().get("WSUREDMSInterface");
        if (overriddingEndpoint != null) {
            return overriddingEndpoint;
        }
        else {
            return WSUREDMSInterface_address;
        }
    }

    private java.lang.String WSUREDMSInterfacePortName = "WSUREDMSInterface";

    // The WSDD port name defaults to the port name.
    private java.lang.String WSUREDMSInterfaceWSDDPortName = "WSUREDMSInterface";

    public java.lang.String getWSUREDMSInterfaceWSDDPortName() {
        return WSUREDMSInterfaceWSDDPortName;
    }

    public void setWSUREDMSInterfaceWSDDPortName(java.lang.String name) {
        WSUREDMSInterfaceWSDDPortName = name;
    }

    public us.pa.state.dot.ecms.webservices.WSUREDMSInterface getWSUREDMSInterface() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(getWSUREDMSInterfaceAddress());
        }
        catch (java.net.MalformedURLException e) {
            return null; // unlikely as URL was validated in WSDL2Java
        }
        return getWSUREDMSInterface(endpoint);
    }

    public us.pa.state.dot.ecms.webservices.WSUREDMSInterface getWSUREDMSInterface(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        us.pa.state.dot.ecms.webservices.WSUREDMSInterface _stub =
            (us.pa.state.dot.ecms.webservices.WSUREDMSInterface) getStub(
                WSUREDMSInterfacePortName,
                (String) getPort2NamespaceMap().get(WSUREDMSInterfacePortName),
                us.pa.state.dot.ecms.webservices.WSUREDMSInterface.class,
                "us.pa.state.dot.ecms.webservices.WSUREDMSInterfaceSoapBindingStub",
                portAddress.toString());
        if (_stub instanceof com.ibm.ws.webservices.engine.client.Stub) {
            ((com.ibm.ws.webservices.engine.client.Stub) _stub).setPortName(WSUREDMSInterfaceWSDDPortName);
        }
        return _stub;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (us.pa.state.dot.ecms.webservices.WSUREDMSInterface.class.isAssignableFrom(serviceEndpointInterface)) {
                return getWSUREDMSInterface();
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("WSWS3273E: Error: There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        String inputPortName = portName.getLocalPart();
        if ("WSUREDMSInterface".equals(inputPortName)) {
            return getWSUREDMSInterface();
        }
        else  {
            throw new javax.xml.rpc.ServiceException();
        }
    }

    public void setPortNamePrefix(java.lang.String prefix) {
        WSUREDMSInterfaceWSDDPortName = prefix + "/" + WSUREDMSInterfacePortName;
    }

    public javax.xml.namespace.QName getServiceName() {
        return com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "WSUREDMSInterfaceService");
    }

    private java.util.Map port2NamespaceMap = null;

    protected synchronized java.util.Map getPort2NamespaceMap() {
        if (port2NamespaceMap == null) {
            port2NamespaceMap = new java.util.HashMap();
            port2NamespaceMap.put(
               "WSUREDMSInterface",
               "http://schemas.xmlsoap.org/wsdl/soap/");
        }
        return port2NamespaceMap;
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            String serviceNamespace = getServiceName().getNamespaceURI();
            for (java.util.Iterator i = getPort2NamespaceMap().keySet().iterator(); i.hasNext(); ) {
                ports.add(
                    com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                        serviceNamespace,
                        (String) i.next()));
            }
        }
        return ports.iterator();
    }

    public javax.xml.rpc.Call[] getCalls(javax.xml.namespace.QName portName) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            throw new javax.xml.rpc.ServiceException("WSWS3062E: Error: portName should not be null.");
        }
        if  (portName.getLocalPart().equals("WSUREDMSInterface")) {
            return new javax.xml.rpc.Call[] {
                createCall(portName, "updateUREDMSChecklistItem", "updateUREDMSChecklistItemRequest"),
            };
        }
        else {
            throw new javax.xml.rpc.ServiceException("WSWS3062E: Error: portName should not be null.");
        }
    }
}
