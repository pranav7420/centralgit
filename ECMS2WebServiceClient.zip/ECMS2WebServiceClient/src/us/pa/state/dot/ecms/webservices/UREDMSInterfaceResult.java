/**
 * UREDMSInterfaceResult.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf150632.18 v81506105401
 */

package us.pa.state.dot.ecms.webservices;

public class UREDMSInterfaceResult  {
    private java.lang.String errorMessage;
    private boolean itemQueued;
    private java.lang.String result;

    public UREDMSInterfaceResult() {
    }

    public java.lang.String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(java.lang.String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public boolean isItemQueued() {
        return itemQueued;
    }

    public void setItemQueued(boolean itemQueued) {
        this.itemQueued = itemQueued;
    }

    public java.lang.String getResult() {
        return result;
    }

    public void setResult(java.lang.String result) {
        this.result = result;
    }

}
