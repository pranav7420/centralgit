package us.pa.state.dot.ecms.webservices;

public class WSCEESInterfaceProxy implements us.pa.state.dot.ecms.webservices.WSCEESInterface {
  private boolean _useJNDI = true;
  private String _endpoint = null;
  private us.pa.state.dot.ecms.webservices.WSCEESInterface __wSCEESInterface = null;
  
  public WSCEESInterfaceProxy() {
    _initWSCEESInterfaceProxy();
  }
  
  private void _initWSCEESInterfaceProxy() {
  
  if (_useJNDI) {
    try{
      javax.naming.InitialContext ctx = new javax.naming.InitialContext();
      __wSCEESInterface = ((us.pa.state.dot.ecms.webservices.WSCEESInterfaceService)ctx.lookup("java:comp/env/service/WSCEESInterfaceService")).getWSCEESInterface();
      }
    catch (javax.naming.NamingException namingException) {}
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  if (__wSCEESInterface == null) {
    try{
      __wSCEESInterface = (new us.pa.state.dot.ecms.webservices.WSCEESInterfaceServiceLocator()).getWSCEESInterface();
      }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  if (__wSCEESInterface != null) {
    if (_endpoint != null)
      ((javax.xml.rpc.Stub)__wSCEESInterface)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    else
      _endpoint = (String)((javax.xml.rpc.Stub)__wSCEESInterface)._getProperty("javax.xml.rpc.service.endpoint.address");
  }
  
}


public void useJNDI(boolean useJNDI) {
  _useJNDI = useJNDI;
  __wSCEESInterface = null;
  
}

public String getEndpoint() {
  return _endpoint;
}

public void setEndpoint(String endpoint) {
  _endpoint = endpoint;
  if (__wSCEESInterface != null)
    ((javax.xml.rpc.Stub)__wSCEESInterface)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
  
}

public us.pa.state.dot.ecms.webservices.WSCEESInterface getWSCEESInterface() {
  if (__wSCEESInterface == null)
    _initWSCEESInterfaceProxy();
  return __wSCEESInterface;
}

public us.pa.state.dot.ecms.webservices.CEESInterfaceResult updateCEEChecklistItem(java.lang.String userId, java.lang.String password, int ecmsProjectNum, java.lang.String ceeItemNumber, java.lang.String clItemNumber, java.lang.String actionDate, java.lang.String clApprBy, java.lang.String ceeDocLink) throws java.rmi.RemoteException{
  if (__wSCEESInterface == null)
    _initWSCEESInterfaceProxy();
  return __wSCEESInterface.updateCEEChecklistItem(userId, password, ecmsProjectNum, ceeItemNumber, clItemNumber, actionDate, clApprBy, ceeDocLink);
}

public void init(java.lang.Object c) throws java.rmi.RemoteException{
  if (__wSCEESInterface == null)
    _initWSCEESInterfaceProxy();
  __wSCEESInterface.init(c);
}

public void destroy() throws java.rmi.RemoteException{
  if (__wSCEESInterface == null)
    _initWSCEESInterfaceProxy();
  __wSCEESInterface.destroy();
}


}