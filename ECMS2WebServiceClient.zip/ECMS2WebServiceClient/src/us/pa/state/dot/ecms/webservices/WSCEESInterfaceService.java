/**
 * WSCEESInterfaceService.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf111019.19 v52610232443
 */

package us.pa.state.dot.ecms.webservices;

public interface WSCEESInterfaceService extends javax.xml.rpc.Service {
    public us.pa.state.dot.ecms.webservices.WSCEESInterface getWSCEESInterface() throws javax.xml.rpc.ServiceException;

    public java.lang.String getWSCEESInterfaceAddress();

    public us.pa.state.dot.ecms.webservices.WSCEESInterface getWSCEESInterface(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
