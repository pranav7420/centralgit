package us.pa.state.dot.ecms.webservices;

public class WSUREDMSInterfaceProxy implements us.pa.state.dot.ecms.webservices.WSUREDMSInterface {
  private boolean _useJNDI = true;
  private String _endpoint = null;
  private us.pa.state.dot.ecms.webservices.WSUREDMSInterface __wSUREDMSInterface = null;
  
  public WSUREDMSInterfaceProxy() {
    _initWSUREDMSInterfaceProxy();
  }
  
  private void _initWSUREDMSInterfaceProxy() {
  
  if (_useJNDI) {
    try{
      javax.naming.InitialContext ctx = new javax.naming.InitialContext();
      __wSUREDMSInterface = ((us.pa.state.dot.ecms.webservices.WSUREDMSInterfaceService)ctx.lookup("java:comp/env/service/WSUREDMSInterfaceService")).getWSUREDMSInterface();
      }
    catch (javax.naming.NamingException namingException) {}
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  if (__wSUREDMSInterface == null) {
    try{
      __wSUREDMSInterface = (new us.pa.state.dot.ecms.webservices.WSUREDMSInterfaceServiceLocator()).getWSUREDMSInterface();
      }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  if (__wSUREDMSInterface != null) {
    if (_endpoint != null)
      ((javax.xml.rpc.Stub)__wSUREDMSInterface)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    else
      _endpoint = (String)((javax.xml.rpc.Stub)__wSUREDMSInterface)._getProperty("javax.xml.rpc.service.endpoint.address");
  }
  
}


public void useJNDI(boolean useJNDI) {
  _useJNDI = useJNDI;
  __wSUREDMSInterface = null;
  
}

public String getEndpoint() {
  return _endpoint;
}

public void setEndpoint(String endpoint) {
  _endpoint = endpoint;
  if (__wSUREDMSInterface != null)
    ((javax.xml.rpc.Stub)__wSUREDMSInterface)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
  
}

public us.pa.state.dot.ecms.webservices.WSUREDMSInterface getWSUREDMSInterface() {
  if (__wSUREDMSInterface == null)
    _initWSUREDMSInterfaceProxy();
  return __wSUREDMSInterface;
}

public us.pa.state.dot.ecms.webservices.UREDMSInterfaceResult updateUREDMSChecklistItem(java.lang.String userId, java.lang.String password, int ecmsProjectNum, java.lang.String clItemNumber, java.lang.String actionDate, java.lang.String fhwaDate, java.lang.String clApprBy, java.lang.String edmsDocLink, java.lang.String edmsDocName) throws java.rmi.RemoteException{
  if (__wSUREDMSInterface == null)
    _initWSUREDMSInterfaceProxy();
  return __wSUREDMSInterface.updateUREDMSChecklistItem(userId, password, ecmsProjectNum, clItemNumber, actionDate, fhwaDate, clApprBy, edmsDocLink, edmsDocName);
}


}