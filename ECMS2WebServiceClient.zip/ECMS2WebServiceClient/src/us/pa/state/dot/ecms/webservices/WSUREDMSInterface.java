/**
 * WSUREDMSInterface.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf150632.18 v81506105401
 */

package us.pa.state.dot.ecms.webservices;

public interface WSUREDMSInterface extends java.rmi.Remote {
    public us.pa.state.dot.ecms.webservices.UREDMSInterfaceResult updateUREDMSChecklistItem(java.lang.String userId, java.lang.String password, int ecmsProjectNum, java.lang.String clItemNumber, java.lang.String actionDate, java.lang.String fhwaDate, java.lang.String clApprBy, java.lang.String edmsDocLink, java.lang.String edmsDocName) throws java.rmi.RemoteException;
}
