/**
 * WSUREDMSInterfaceServiceInformation.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf111019.19 v52610232443
 */

package us.pa.state.dot.ecms.webservices;

public class WSUREDMSInterfaceServiceInformation implements com.ibm.ws.webservices.multiprotocol.ServiceInformation {

    private static java.util.Map operationDescriptions;
    private static java.util.Map typeMappings;

    static {
         initOperationDescriptions();
         initTypeMappings();
    }

    private static void initOperationDescriptions() { 
        operationDescriptions = new java.util.HashMap();

        java.util.Map inner0 = new java.util.HashMap();

        java.util.List list0 = new java.util.ArrayList();
        inner0.put("updateUREDMSChecklistItem", list0);

        com.ibm.ws.webservices.engine.description.OperationDesc updateUREDMSChecklistItem0Op = _updateUREDMSChecklistItem0Op();
        list0.add(updateUREDMSChecklistItem0Op);

        operationDescriptions.put("WSUREDMSInterface",inner0);
        operationDescriptions = java.util.Collections.unmodifiableMap(operationDescriptions);
    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _updateUREDMSChecklistItem0Op() {
        com.ibm.ws.webservices.engine.description.OperationDesc updateUREDMSChecklistItem0Op = null;
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params0 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "userId"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false, false, false, true, false), 
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "password"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false, false, false, true, false), 
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "ecmsProjectNum"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false, false, false, true, false), 
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "clItemNumber"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false, false, false, true, false), 
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "actionDate"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false, false, false, true, false), 
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "fhwaDate"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false, false, false, true, false), 
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "clApprBy"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false, false, false, true, false), 
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "edmsDocLink"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false, false, false, true, false), 
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "edmsDocName"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false, false, false, true, false), 
          };
        _params0[0].setOption("inputPosition","0");
        _params0[0].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}string");
        _params0[0].setOption("partName","string");
        _params0[1].setOption("inputPosition","1");
        _params0[1].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}string");
        _params0[1].setOption("partName","string");
        _params0[2].setOption("inputPosition","2");
        _params0[2].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}int");
        _params0[2].setOption("partName","int");
        _params0[3].setOption("inputPosition","3");
        _params0[3].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}string");
        _params0[3].setOption("partName","string");
        _params0[4].setOption("inputPosition","4");
        _params0[4].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}string");
        _params0[4].setOption("partName","string");
        _params0[5].setOption("inputPosition","5");
        _params0[5].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}string");
        _params0[5].setOption("partName","string");
        _params0[6].setOption("inputPosition","6");
        _params0[6].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}string");
        _params0[6].setOption("partName","string");
        _params0[7].setOption("inputPosition","7");
        _params0[7].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}string");
        _params0[7].setOption("partName","string");
        _params0[8].setOption("inputPosition","8");
        _params0[8].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}string");
        _params0[8].setOption("partName","string");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc0 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "updateUREDMSChecklistItemReturn"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "UREDMSInterfaceResult"), us.pa.state.dot.ecms.webservices.UREDMSInterfaceResult.class, true, false, false, false, true, false); 
        _returnDesc0.setOption("outputPosition","0");
        _returnDesc0.setOption("partQNameString","{http://webservices.ecms.dot.state.pa.us}UREDMSInterfaceResult");
        _returnDesc0.setOption("partName","UREDMSInterfaceResult");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults0 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
          };
        updateUREDMSChecklistItem0Op = new com.ibm.ws.webservices.engine.description.OperationDesc("updateUREDMSChecklistItem", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "updateUREDMSChecklistItem"), _params0, _returnDesc0, _faults0, null);
        updateUREDMSChecklistItem0Op.setOption("inoutOrderingReq","false");
        updateUREDMSChecklistItem0Op.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "WSUREDMSInterface"));
        updateUREDMSChecklistItem0Op.setOption("inputName","updateUREDMSChecklistItemRequest");
        updateUREDMSChecklistItem0Op.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "updateUREDMSChecklistItemResponse"));
        updateUREDMSChecklistItem0Op.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "WSUREDMSInterfaceService"));
        updateUREDMSChecklistItem0Op.setOption("buildNum","cf111019.19");
        updateUREDMSChecklistItem0Op.setOption("ResponseNamespace","http://webservices.ecms.dot.state.pa.us");
        updateUREDMSChecklistItem0Op.setOption("targetNamespace","http://webservices.ecms.dot.state.pa.us");
        updateUREDMSChecklistItem0Op.setOption("outputName","updateUREDMSChecklistItemResponse");
        updateUREDMSChecklistItem0Op.setOption("ResponseLocalPart","updateUREDMSChecklistItemResponse");
        updateUREDMSChecklistItem0Op.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "updateUREDMSChecklistItemRequest"));
        updateUREDMSChecklistItem0Op.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.WRAPPED);
        return updateUREDMSChecklistItem0Op;

    }


    private static void initTypeMappings() {
        typeMappings = new java.util.HashMap();
        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "UREDMSInterfaceResult"),
                         us.pa.state.dot.ecms.webservices.UREDMSInterfaceResult.class);

        typeMappings = java.util.Collections.unmodifiableMap(typeMappings);
    }

    public java.util.Map getTypeMappings() {
        return typeMappings;
    }

    public Class getJavaType(javax.xml.namespace.QName xmlName) {
        return (Class) typeMappings.get(xmlName);
    }

    public java.util.Map getOperationDescriptions(String portName) {
        return (java.util.Map) operationDescriptions.get(portName);
    }

    public java.util.List getOperationDescriptions(String portName, String operationName) {
        java.util.Map map = (java.util.Map) operationDescriptions.get(portName);
        if (map != null) {
            return (java.util.List) map.get(operationName);
        }
        return null;
    }

}
