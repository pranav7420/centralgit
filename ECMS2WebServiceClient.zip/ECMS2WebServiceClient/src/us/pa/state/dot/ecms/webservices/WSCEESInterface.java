/**
 * WSCEESInterface.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf150632.18 v81506105401
 */

package us.pa.state.dot.ecms.webservices;

public interface WSCEESInterface extends java.rmi.Remote {
    public us.pa.state.dot.ecms.webservices.CEESInterfaceResult updateCEEChecklistItem(java.lang.String userId, java.lang.String password, int ecmsProjectNum, java.lang.String ceeItemNumber, java.lang.String clItemNumber, java.lang.String actionDate, java.lang.String clApprBy, java.lang.String ceeDocLink) throws java.rmi.RemoteException;
    public void init(java.lang.Object c) throws java.rmi.RemoteException;
    public void destroy() throws java.rmi.RemoteException;
}
