/**
 * WSCEESInterfaceServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf111019.19 v52610232443
 */

package us.pa.state.dot.ecms.webservices;

public class WSCEESInterfaceServiceLocator extends com.ibm.ws.webservices.multiprotocol.AgnosticService implements com.ibm.ws.webservices.multiprotocol.GeneratedService, us.pa.state.dot.ecms.webservices.WSCEESInterfaceService {

    public WSCEESInterfaceServiceLocator() {
        super(com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
           "http://webservices.ecms.dot.state.pa.us",
           "WSCEESInterfaceService"));

        context.setLocatorName("us.pa.state.dot.ecms.webservices.WSCEESInterfaceServiceLocator");
    }

    public WSCEESInterfaceServiceLocator(com.ibm.ws.webservices.multiprotocol.ServiceContext ctx) {
        super(ctx);
        context.setLocatorName("us.pa.state.dot.ecms.webservices.WSCEESInterfaceServiceLocator");
    }

    // Use to get a proxy class for WSCEESInterface
    private final java.lang.String WSCEESInterface_address = "http://localhost:9080/ECMSWebService/services/WSCEESInterface";

    public java.lang.String getWSCEESInterfaceAddress() {
        if (context.getOverriddingEndpointURIs() == null) {
            return WSCEESInterface_address;
        }
        String overriddingEndpoint = (String) context.getOverriddingEndpointURIs().get("WSCEESInterface");
        if (overriddingEndpoint != null) {
            return overriddingEndpoint;
        }
        else {
            return WSCEESInterface_address;
        }
    }

    private java.lang.String WSCEESInterfacePortName = "WSCEESInterface";

    // The WSDD port name defaults to the port name.
    private java.lang.String WSCEESInterfaceWSDDPortName = "WSCEESInterface";

    public java.lang.String getWSCEESInterfaceWSDDPortName() {
        return WSCEESInterfaceWSDDPortName;
    }

    public void setWSCEESInterfaceWSDDPortName(java.lang.String name) {
        WSCEESInterfaceWSDDPortName = name;
    }

    public us.pa.state.dot.ecms.webservices.WSCEESInterface getWSCEESInterface() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(getWSCEESInterfaceAddress());
        }
        catch (java.net.MalformedURLException e) {
            return null; // unlikely as URL was validated in WSDL2Java
        }
        return getWSCEESInterface(endpoint);
    }

    public us.pa.state.dot.ecms.webservices.WSCEESInterface getWSCEESInterface(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        us.pa.state.dot.ecms.webservices.WSCEESInterface _stub =
            (us.pa.state.dot.ecms.webservices.WSCEESInterface) getStub(
                WSCEESInterfacePortName,
                (String) getPort2NamespaceMap().get(WSCEESInterfacePortName),
                us.pa.state.dot.ecms.webservices.WSCEESInterface.class,
                "us.pa.state.dot.ecms.webservices.WSCEESInterfaceSoapBindingStub",
                portAddress.toString());
        if (_stub instanceof com.ibm.ws.webservices.engine.client.Stub) {
            ((com.ibm.ws.webservices.engine.client.Stub) _stub).setPortName(WSCEESInterfaceWSDDPortName);
        }
        return _stub;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (us.pa.state.dot.ecms.webservices.WSCEESInterface.class.isAssignableFrom(serviceEndpointInterface)) {
                return getWSCEESInterface();
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("WSWS3273E: Error: There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        String inputPortName = portName.getLocalPart();
        if ("WSCEESInterface".equals(inputPortName)) {
            return getWSCEESInterface();
        }
        else  {
            throw new javax.xml.rpc.ServiceException();
        }
    }

    public void setPortNamePrefix(java.lang.String prefix) {
        WSCEESInterfaceWSDDPortName = prefix + "/" + WSCEESInterfacePortName;
    }

    public javax.xml.namespace.QName getServiceName() {
        return com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "WSCEESInterfaceService");
    }

    private java.util.Map port2NamespaceMap = null;

    protected synchronized java.util.Map getPort2NamespaceMap() {
        if (port2NamespaceMap == null) {
            port2NamespaceMap = new java.util.HashMap();
            port2NamespaceMap.put(
               "WSCEESInterface",
               "http://schemas.xmlsoap.org/wsdl/soap/");
        }
        return port2NamespaceMap;
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            String serviceNamespace = getServiceName().getNamespaceURI();
            for (java.util.Iterator i = getPort2NamespaceMap().keySet().iterator(); i.hasNext(); ) {
                ports.add(
                    com.ibm.ws.webservices.engine.utils.QNameTable.createQName(
                        serviceNamespace,
                        (String) i.next()));
            }
        }
        return ports.iterator();
    }

    public javax.xml.rpc.Call[] getCalls(javax.xml.namespace.QName portName) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            throw new javax.xml.rpc.ServiceException("WSWS3062E: Error: portName should not be null.");
        }
        if  (portName.getLocalPart().equals("WSCEESInterface")) {
            return new javax.xml.rpc.Call[] {
                createCall(portName, "updateCEEChecklistItem", "updateCEEChecklistItemRequest"),
                createCall(portName, "init", "initRequest"),
                createCall(portName, "destroy", "destroyRequest"),
            };
        }
        else {
            throw new javax.xml.rpc.ServiceException("WSWS3062E: Error: portName should not be null.");
        }
    }
}
