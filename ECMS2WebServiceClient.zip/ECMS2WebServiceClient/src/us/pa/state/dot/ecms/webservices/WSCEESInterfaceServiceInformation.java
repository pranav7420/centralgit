/**
 * WSCEESInterfaceServiceInformation.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf111019.19 v52610232443
 */

package us.pa.state.dot.ecms.webservices;

public class WSCEESInterfaceServiceInformation implements com.ibm.ws.webservices.multiprotocol.ServiceInformation {

    private static java.util.Map operationDescriptions;
    private static java.util.Map typeMappings;

    static {
         initOperationDescriptions();
         initTypeMappings();
    }

    private static void initOperationDescriptions() { 
        operationDescriptions = new java.util.HashMap();

        java.util.Map inner0 = new java.util.HashMap();

        java.util.List list0 = new java.util.ArrayList();
        inner0.put("destroy", list0);

        com.ibm.ws.webservices.engine.description.OperationDesc destroy0Op = _destroy0Op();
        list0.add(destroy0Op);

        java.util.List list1 = new java.util.ArrayList();
        inner0.put("init", list1);

        com.ibm.ws.webservices.engine.description.OperationDesc init1Op = _init1Op();
        list1.add(init1Op);

        java.util.List list2 = new java.util.ArrayList();
        inner0.put("updateCEEChecklistItem", list2);

        com.ibm.ws.webservices.engine.description.OperationDesc updateCEEChecklistItem2Op = _updateCEEChecklistItem2Op();
        list2.add(updateCEEChecklistItem2Op);

        operationDescriptions.put("WSCEESInterface",inner0);
        operationDescriptions = java.util.Collections.unmodifiableMap(operationDescriptions);
    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _destroy0Op() {
        com.ibm.ws.webservices.engine.description.OperationDesc destroy0Op = null;
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params0 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
          };
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc0 = new com.ibm.ws.webservices.engine.description.ParameterDesc(null, com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://websphere.ibm.com/webservices/", "Void"), void.class, true, false, false, false, true, true); 
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults0 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
          };
        destroy0Op = new com.ibm.ws.webservices.engine.description.OperationDesc("destroy", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "destroy"), _params0, _returnDesc0, _faults0, null);
        destroy0Op.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "WSCEESInterface"));
        destroy0Op.setOption("inputName","destroyRequest");
        destroy0Op.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "destroyResponse"));
        destroy0Op.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "WSCEESInterfaceService"));
        destroy0Op.setOption("buildNum","cf111019.19");
        destroy0Op.setOption("ResponseNamespace","http://webservices.ecms.dot.state.pa.us");
        destroy0Op.setOption("targetNamespace","http://webservices.ecms.dot.state.pa.us");
        destroy0Op.setOption("outputName","destroyResponse");
        destroy0Op.setOption("ResponseLocalPart","destroyResponse");
        destroy0Op.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "destroyRequest"));
        destroy0Op.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.WRAPPED);
        return destroy0Op;

    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _init1Op() {
        com.ibm.ws.webservices.engine.description.OperationDesc init1Op = null;
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params0 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "c"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "anyType"), java.lang.Object.class, false, false, false, false, true, false), 
          };
        _params0[0].setOption("inputPosition","0");
        _params0[0].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}anyType");
        _params0[0].setOption("partName","anyType");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc0 = new com.ibm.ws.webservices.engine.description.ParameterDesc(null, com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://websphere.ibm.com/webservices/", "Void"), void.class, true, false, false, false, true, true); 
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults0 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
          };
        init1Op = new com.ibm.ws.webservices.engine.description.OperationDesc("init", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "init"), _params0, _returnDesc0, _faults0, null);
        init1Op.setOption("inoutOrderingReq","false");
        init1Op.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "WSCEESInterface"));
        init1Op.setOption("inputName","initRequest");
        init1Op.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "initResponse"));
        init1Op.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "WSCEESInterfaceService"));
        init1Op.setOption("buildNum","cf111019.19");
        init1Op.setOption("ResponseNamespace","http://webservices.ecms.dot.state.pa.us");
        init1Op.setOption("targetNamespace","http://webservices.ecms.dot.state.pa.us");
        init1Op.setOption("outputName","initResponse");
        init1Op.setOption("ResponseLocalPart","initResponse");
        init1Op.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "initRequest"));
        init1Op.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.WRAPPED);
        return init1Op;

    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _updateCEEChecklistItem2Op() {
        com.ibm.ws.webservices.engine.description.OperationDesc updateCEEChecklistItem2Op = null;
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params0 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "userId"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false, false, false, true, false), 
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "password"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false, false, false, true, false), 
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "ecmsProjectNum"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false, false, false, true, false), 
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "ceeItemNumber"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false, false, false, true, false), 
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "clItemNumber"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false, false, false, true, false), 
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "actionDate"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false, false, false, true, false), 
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "clApprBy"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false, false, false, true, false), 
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "ceeDocLink"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false, false, false, true, false), 
          };
        _params0[0].setOption("inputPosition","0");
        _params0[0].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}string");
        _params0[0].setOption("partName","string");
        _params0[1].setOption("inputPosition","1");
        _params0[1].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}string");
        _params0[1].setOption("partName","string");
        _params0[2].setOption("inputPosition","2");
        _params0[2].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}int");
        _params0[2].setOption("partName","int");
        _params0[3].setOption("inputPosition","3");
        _params0[3].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}string");
        _params0[3].setOption("partName","string");
        _params0[4].setOption("inputPosition","4");
        _params0[4].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}string");
        _params0[4].setOption("partName","string");
        _params0[5].setOption("inputPosition","5");
        _params0[5].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}string");
        _params0[5].setOption("partName","string");
        _params0[6].setOption("inputPosition","6");
        _params0[6].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}string");
        _params0[6].setOption("partName","string");
        _params0[7].setOption("inputPosition","7");
        _params0[7].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}string");
        _params0[7].setOption("partName","string");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc0 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "updateCEEChecklistItemReturn"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "CEESInterfaceResult"), us.pa.state.dot.ecms.webservices.CEESInterfaceResult.class, true, false, false, false, true, false); 
        _returnDesc0.setOption("outputPosition","0");
        _returnDesc0.setOption("partQNameString","{http://webservices.ecms.dot.state.pa.us}CEESInterfaceResult");
        _returnDesc0.setOption("partName","CEESInterfaceResult");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults0 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
          };
        updateCEEChecklistItem2Op = new com.ibm.ws.webservices.engine.description.OperationDesc("updateCEEChecklistItem", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "updateCEEChecklistItem"), _params0, _returnDesc0, _faults0, null);
        updateCEEChecklistItem2Op.setOption("inoutOrderingReq","false");
        updateCEEChecklistItem2Op.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "WSCEESInterface"));
        updateCEEChecklistItem2Op.setOption("inputName","updateCEEChecklistItemRequest");
        updateCEEChecklistItem2Op.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "updateCEEChecklistItemResponse"));
        updateCEEChecklistItem2Op.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "WSCEESInterfaceService"));
        updateCEEChecklistItem2Op.setOption("buildNum","cf111019.19");
        updateCEEChecklistItem2Op.setOption("ResponseNamespace","http://webservices.ecms.dot.state.pa.us");
        updateCEEChecklistItem2Op.setOption("targetNamespace","http://webservices.ecms.dot.state.pa.us");
        updateCEEChecklistItem2Op.setOption("outputName","updateCEEChecklistItemResponse");
        updateCEEChecklistItem2Op.setOption("ResponseLocalPart","updateCEEChecklistItemResponse");
        updateCEEChecklistItem2Op.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "updateCEEChecklistItemRequest"));
        updateCEEChecklistItem2Op.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.WRAPPED);
        return updateCEEChecklistItem2Op;

    }


    private static void initTypeMappings() {
        typeMappings = new java.util.HashMap();
        typeMappings.put(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "CEESInterfaceResult"),
                         us.pa.state.dot.ecms.webservices.CEESInterfaceResult.class);

        typeMappings = java.util.Collections.unmodifiableMap(typeMappings);
    }

    public java.util.Map getTypeMappings() {
        return typeMappings;
    }

    public Class getJavaType(javax.xml.namespace.QName xmlName) {
        return (Class) typeMappings.get(xmlName);
    }

    public java.util.Map getOperationDescriptions(String portName) {
        return (java.util.Map) operationDescriptions.get(portName);
    }

    public java.util.List getOperationDescriptions(String portName, String operationName) {
        java.util.Map map = (java.util.Map) operationDescriptions.get(portName);
        if (map != null) {
            return (java.util.List) map.get(operationName);
        }
        return null;
    }

}
