/**
 * WSCEESInterfaceSoapBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * cf111019.19 v52610232443
 */

package us.pa.state.dot.ecms.webservices;

public class WSCEESInterfaceSoapBindingStub extends com.ibm.ws.webservices.engine.client.Stub implements us.pa.state.dot.ecms.webservices.WSCEESInterface {
    public WSCEESInterfaceSoapBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws com.ibm.ws.webservices.engine.WebServicesFault {
        if (service == null) {
            super.service = new com.ibm.ws.webservices.engine.client.Service();
        }
        else {
            super.service = service;
        }
        super.engine = ((com.ibm.ws.webservices.engine.client.Service) super.service).getEngine();
        super.messageContexts = new com.ibm.ws.webservices.engine.MessageContext[3];
        java.lang.String theOption = (java.lang.String)super._getProperty("lastStubMapping");
        if (theOption == null || !theOption.equals("us.pa.state.dot.ecms.webservices.WSCEESInterfaceSoapBinding")) {
                initTypeMapping();
                super._setProperty("lastStubMapping","us.pa.state.dot.ecms.webservices.WSCEESInterfaceSoapBinding");
        }
        super.cachedEndpoint = endpointURL;
        super.connection = ((com.ibm.ws.webservices.engine.client.Service) super.service).getConnection(endpointURL);
    }

    private void initTypeMapping() {
        javax.xml.rpc.encoding.TypeMapping tm = super.getTypeMapping(com.ibm.ws.webservices.engine.Constants.URI_LITERAL_ENC);
        java.lang.Class javaType = null;
        javax.xml.namespace.QName xmlType = null;
        javax.xml.namespace.QName compQName = null;
        javax.xml.namespace.QName compTypeQName = null;
        com.ibm.ws.webservices.engine.encoding.SerializerFactory sf = null;
        com.ibm.ws.webservices.engine.encoding.DeserializerFactory df = null;
        javaType = us.pa.state.dot.ecms.webservices.CEESInterfaceResult.class;
        xmlType = com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "CEESInterfaceResult");
        sf = com.ibm.ws.webservices.engine.encoding.ser.BaseSerializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanSerializerFactory.class, javaType, xmlType);
        df = com.ibm.ws.webservices.engine.encoding.ser.BaseDeserializerFactory.createFactory(com.ibm.ws.webservices.engine.encoding.ser.BeanDeserializerFactory.class, javaType, xmlType);
        if (sf != null || df != null) {
            tm.register(javaType, xmlType, sf, df);
        }

    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _updateCEEChecklistItemOperation0 = null;
    private static com.ibm.ws.webservices.engine.description.OperationDesc _getupdateCEEChecklistItemOperation0() {
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params0 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "userId"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false, false, false, true, false), 
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "password"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false, false, false, true, false), 
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "ecmsProjectNum"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false, false, false, true, false), 
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "ceeItemNumber"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false, false, false, true, false), 
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "clItemNumber"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false, false, false, true, false), 
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "actionDate"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false, false, false, true, false), 
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "clApprBy"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false, false, false, true, false), 
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "ceeDocLink"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false, false, false, true, false), 
          };
        _params0[0].setOption("inputPosition","0");
        _params0[0].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}string");
        _params0[0].setOption("partName","string");
        _params0[1].setOption("inputPosition","1");
        _params0[1].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}string");
        _params0[1].setOption("partName","string");
        _params0[2].setOption("inputPosition","2");
        _params0[2].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}int");
        _params0[2].setOption("partName","int");
        _params0[3].setOption("inputPosition","3");
        _params0[3].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}string");
        _params0[3].setOption("partName","string");
        _params0[4].setOption("inputPosition","4");
        _params0[4].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}string");
        _params0[4].setOption("partName","string");
        _params0[5].setOption("inputPosition","5");
        _params0[5].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}string");
        _params0[5].setOption("partName","string");
        _params0[6].setOption("inputPosition","6");
        _params0[6].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}string");
        _params0[6].setOption("partName","string");
        _params0[7].setOption("inputPosition","7");
        _params0[7].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}string");
        _params0[7].setOption("partName","string");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc0 = new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "updateCEEChecklistItemReturn"), com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "CEESInterfaceResult"), us.pa.state.dot.ecms.webservices.CEESInterfaceResult.class, true, false, false, false, true, false); 
        _returnDesc0.setOption("outputPosition","0");
        _returnDesc0.setOption("partQNameString","{http://webservices.ecms.dot.state.pa.us}CEESInterfaceResult");
        _returnDesc0.setOption("partName","CEESInterfaceResult");
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults0 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
          };
        _updateCEEChecklistItemOperation0 = new com.ibm.ws.webservices.engine.description.OperationDesc("updateCEEChecklistItem", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "updateCEEChecklistItem"), _params0, _returnDesc0, _faults0, "updateCEEChecklistItem");
        _updateCEEChecklistItemOperation0.setOption("inoutOrderingReq","false");
        _updateCEEChecklistItemOperation0.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "WSCEESInterface"));
        _updateCEEChecklistItemOperation0.setOption("inputName","updateCEEChecklistItemRequest");
        _updateCEEChecklistItemOperation0.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "updateCEEChecklistItemResponse"));
        _updateCEEChecklistItemOperation0.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "WSCEESInterfaceService"));
        _updateCEEChecklistItemOperation0.setOption("buildNum","cf111019.19");
        _updateCEEChecklistItemOperation0.setOption("ResponseNamespace","http://webservices.ecms.dot.state.pa.us");
        _updateCEEChecklistItemOperation0.setOption("targetNamespace","http://webservices.ecms.dot.state.pa.us");
        _updateCEEChecklistItemOperation0.setOption("outputName","updateCEEChecklistItemResponse");
        _updateCEEChecklistItemOperation0.setOption("ResponseLocalPart","updateCEEChecklistItemResponse");
        _updateCEEChecklistItemOperation0.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "updateCEEChecklistItemRequest"));
        _updateCEEChecklistItemOperation0.setUse(com.ibm.ws.webservices.engine.enumtype.Use.LITERAL);
        _updateCEEChecklistItemOperation0.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.WRAPPED);
        return _updateCEEChecklistItemOperation0;

    }

    private int _updateCEEChecklistItemIndex0 = 0;
    private synchronized com.ibm.ws.webservices.engine.client.Stub.Invoke _getupdateCEEChecklistItemInvoke0(Object[] parameters) throws com.ibm.ws.webservices.engine.WebServicesFault  {
        com.ibm.ws.webservices.engine.MessageContext mc = super.messageContexts[_updateCEEChecklistItemIndex0];
        if (mc == null) {
            mc = new com.ibm.ws.webservices.engine.MessageContext(super.engine);
            mc.setOperation(WSCEESInterfaceSoapBindingStub._updateCEEChecklistItemOperation0);
            mc.setUseSOAPAction(true);
            mc.setSOAPActionURI("updateCEEChecklistItem");
            mc.setEncodingStyle(com.ibm.ws.webservices.engine.Constants.URI_LITERAL_ENC);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.SEND_TYPE_ATTR_PROPERTY, Boolean.FALSE);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.ENGINE_DO_MULTI_REFS_PROPERTY, Boolean.FALSE);
            super.primeMessageContext(mc);
            super.messageContexts[_updateCEEChecklistItemIndex0] = mc;
        }
        try {
            mc = (com.ibm.ws.webservices.engine.MessageContext) mc.clone();
        }
        catch (CloneNotSupportedException cnse) {
            throw com.ibm.ws.webservices.engine.WebServicesFault.makeFault(cnse);
        }
        return new com.ibm.ws.webservices.engine.client.Stub.Invoke(connection, mc, parameters);
    }

    public us.pa.state.dot.ecms.webservices.CEESInterfaceResult updateCEEChecklistItem(java.lang.String userId, java.lang.String password, int ecmsProjectNum, java.lang.String ceeItemNumber, java.lang.String clItemNumber, java.lang.String actionDate, java.lang.String clApprBy, java.lang.String ceeDocLink) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new com.ibm.ws.webservices.engine.NoEndPointException();
        }
        java.util.Vector _resp = null;
        try {
            _resp = _getupdateCEEChecklistItemInvoke0(new java.lang.Object[] {userId, password, new java.lang.Integer(ecmsProjectNum), ceeItemNumber, clItemNumber, actionDate, clApprBy, ceeDocLink}).invoke();

        } catch (com.ibm.ws.webservices.engine.WebServicesFault wsf) {
            Exception e = wsf.getUserException();
            throw wsf;
        } 
        try {
            return (us.pa.state.dot.ecms.webservices.CEESInterfaceResult) ((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue();
        } catch (java.lang.Exception _exception) {
            return (us.pa.state.dot.ecms.webservices.CEESInterfaceResult) super.convert(((com.ibm.ws.webservices.engine.xmlsoap.ext.ParamValue) _resp.get(0)).getValue(), us.pa.state.dot.ecms.webservices.CEESInterfaceResult.class);
        }
    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _initOperation1 = null;
    private static com.ibm.ws.webservices.engine.description.OperationDesc _getinitOperation1() {
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params1 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
         new com.ibm.ws.webservices.engine.description.ParameterDesc(com.ibm.ws.webservices.engine.utils.QNameTable.createQName("", "c"), com.ibm.ws.webservices.engine.description.ParameterDesc.IN, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://www.w3.org/2001/XMLSchema", "anyType"), java.lang.Object.class, false, false, false, false, true, false), 
          };
        _params1[0].setOption("inputPosition","0");
        _params1[0].setOption("partQNameString","{http://www.w3.org/2001/XMLSchema}anyType");
        _params1[0].setOption("partName","anyType");
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc1 = new com.ibm.ws.webservices.engine.description.ParameterDesc(null, com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://websphere.ibm.com/webservices/", "Void"), void.class, true, false, false, false, true, true); 
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults1 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
          };
        _initOperation1 = new com.ibm.ws.webservices.engine.description.OperationDesc("init", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "init"), _params1, _returnDesc1, _faults1, "init");
        _initOperation1.setOption("inoutOrderingReq","false");
        _initOperation1.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "WSCEESInterface"));
        _initOperation1.setOption("inputName","initRequest");
        _initOperation1.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "initResponse"));
        _initOperation1.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "WSCEESInterfaceService"));
        _initOperation1.setOption("buildNum","cf111019.19");
        _initOperation1.setOption("ResponseNamespace","http://webservices.ecms.dot.state.pa.us");
        _initOperation1.setOption("targetNamespace","http://webservices.ecms.dot.state.pa.us");
        _initOperation1.setOption("outputName","initResponse");
        _initOperation1.setOption("ResponseLocalPart","initResponse");
        _initOperation1.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "initRequest"));
        _initOperation1.setUse(com.ibm.ws.webservices.engine.enumtype.Use.LITERAL);
        _initOperation1.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.WRAPPED);
        return _initOperation1;

    }

    private int _initIndex1 = 1;
    private synchronized com.ibm.ws.webservices.engine.client.Stub.Invoke _getinitInvoke1(Object[] parameters) throws com.ibm.ws.webservices.engine.WebServicesFault  {
        com.ibm.ws.webservices.engine.MessageContext mc = super.messageContexts[_initIndex1];
        if (mc == null) {
            mc = new com.ibm.ws.webservices.engine.MessageContext(super.engine);
            mc.setOperation(WSCEESInterfaceSoapBindingStub._initOperation1);
            mc.setUseSOAPAction(true);
            mc.setSOAPActionURI("init");
            mc.setEncodingStyle(com.ibm.ws.webservices.engine.Constants.URI_LITERAL_ENC);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.SEND_TYPE_ATTR_PROPERTY, Boolean.FALSE);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.ENGINE_DO_MULTI_REFS_PROPERTY, Boolean.FALSE);
            super.primeMessageContext(mc);
            super.messageContexts[_initIndex1] = mc;
        }
        try {
            mc = (com.ibm.ws.webservices.engine.MessageContext) mc.clone();
        }
        catch (CloneNotSupportedException cnse) {
            throw com.ibm.ws.webservices.engine.WebServicesFault.makeFault(cnse);
        }
        return new com.ibm.ws.webservices.engine.client.Stub.Invoke(connection, mc, parameters);
    }

    public void init(java.lang.Object c) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new com.ibm.ws.webservices.engine.NoEndPointException();
        }
        try {
            _getinitInvoke1(new java.lang.Object[] {c}).invoke();

        } catch (com.ibm.ws.webservices.engine.WebServicesFault wsf) {
            Exception e = wsf.getUserException();
            throw wsf;
        } 
    }

    private static com.ibm.ws.webservices.engine.description.OperationDesc _destroyOperation2 = null;
    private static com.ibm.ws.webservices.engine.description.OperationDesc _getdestroyOperation2() {
        com.ibm.ws.webservices.engine.description.ParameterDesc[]  _params2 = new com.ibm.ws.webservices.engine.description.ParameterDesc[] {
          };
        com.ibm.ws.webservices.engine.description.ParameterDesc  _returnDesc2 = new com.ibm.ws.webservices.engine.description.ParameterDesc(null, com.ibm.ws.webservices.engine.description.ParameterDesc.OUT, com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://websphere.ibm.com/webservices/", "Void"), void.class, true, false, false, false, true, true); 
        com.ibm.ws.webservices.engine.description.FaultDesc[]  _faults2 = new com.ibm.ws.webservices.engine.description.FaultDesc[] {
          };
        _destroyOperation2 = new com.ibm.ws.webservices.engine.description.OperationDesc("destroy", com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "destroy"), _params2, _returnDesc2, _faults2, "destroy");
        _destroyOperation2.setOption("portTypeQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "WSCEESInterface"));
        _destroyOperation2.setOption("inputName","destroyRequest");
        _destroyOperation2.setOption("outputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "destroyResponse"));
        _destroyOperation2.setOption("ServiceQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "WSCEESInterfaceService"));
        _destroyOperation2.setOption("buildNum","cf111019.19");
        _destroyOperation2.setOption("ResponseNamespace","http://webservices.ecms.dot.state.pa.us");
        _destroyOperation2.setOption("targetNamespace","http://webservices.ecms.dot.state.pa.us");
        _destroyOperation2.setOption("outputName","destroyResponse");
        _destroyOperation2.setOption("ResponseLocalPart","destroyResponse");
        _destroyOperation2.setOption("inputMessageQName",com.ibm.ws.webservices.engine.utils.QNameTable.createQName("http://webservices.ecms.dot.state.pa.us", "destroyRequest"));
        _destroyOperation2.setUse(com.ibm.ws.webservices.engine.enumtype.Use.LITERAL);
        _destroyOperation2.setStyle(com.ibm.ws.webservices.engine.enumtype.Style.WRAPPED);
        return _destroyOperation2;

    }

    private int _destroyIndex2 = 2;
    private synchronized com.ibm.ws.webservices.engine.client.Stub.Invoke _getdestroyInvoke2(Object[] parameters) throws com.ibm.ws.webservices.engine.WebServicesFault  {
        com.ibm.ws.webservices.engine.MessageContext mc = super.messageContexts[_destroyIndex2];
        if (mc == null) {
            mc = new com.ibm.ws.webservices.engine.MessageContext(super.engine);
            mc.setOperation(WSCEESInterfaceSoapBindingStub._destroyOperation2);
            mc.setUseSOAPAction(true);
            mc.setSOAPActionURI("destroy");
            mc.setEncodingStyle(com.ibm.ws.webservices.engine.Constants.URI_LITERAL_ENC);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.SEND_TYPE_ATTR_PROPERTY, Boolean.FALSE);
            mc.setProperty(com.ibm.wsspi.webservices.Constants.ENGINE_DO_MULTI_REFS_PROPERTY, Boolean.FALSE);
            super.primeMessageContext(mc);
            super.messageContexts[_destroyIndex2] = mc;
        }
        try {
            mc = (com.ibm.ws.webservices.engine.MessageContext) mc.clone();
        }
        catch (CloneNotSupportedException cnse) {
            throw com.ibm.ws.webservices.engine.WebServicesFault.makeFault(cnse);
        }
        return new com.ibm.ws.webservices.engine.client.Stub.Invoke(connection, mc, parameters);
    }

    public void destroy() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new com.ibm.ws.webservices.engine.NoEndPointException();
        }
        try {
            _getdestroyInvoke2(new java.lang.Object[] {}).invoke();

        } catch (com.ibm.ws.webservices.engine.WebServicesFault wsf) {
            Exception e = wsf.getUserException();
            throw wsf;
        } 
    }

    private static void _staticInit() {
        _destroyOperation2 = _getdestroyOperation2();
        _updateCEEChecklistItemOperation0 = _getupdateCEEChecklistItemOperation0();
        _initOperation1 = _getinitOperation1();
    }

    static {
       _staticInit();
    }
}
