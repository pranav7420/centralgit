<%@page contentType="text/html;charset=UTF-8"%>
<% request.setCharacterEncoding("UTF-8"); %>
<HTML>
<HEAD>
<TITLE>Result</TITLE>
</HEAD>
<BODY>
<H1>Result</H1>

<jsp:useBean id="sampleWSCEESInterfaceProxyid" scope="session" class="us.pa.state.dot.ecms.webservices.WSCEESInterfaceProxy" />
<%
if (request.getParameter("endpoint") != null && request.getParameter("endpoint").length() > 0)
sampleWSCEESInterfaceProxyid.setEndpoint(request.getParameter("endpoint"));
%>

<%
String method = request.getParameter("method");
int methodID = 0;
if (method == null) methodID = -1;

if(methodID != -1) methodID = Integer.parseInt(method);
boolean gotMethod = false;

try {
switch (methodID){ 
case 2:
        gotMethod = true;
        String userId_0id=  request.getParameter("userId11");
        java.lang.String userId_0idTemp  = userId_0id;
        String password_1id=  request.getParameter("password13");
        java.lang.String password_1idTemp  = password_1id;
        String ecmsProjectNum_2id=  request.getParameter("ecmsProjectNum15");
        int ecmsProjectNum_2idTemp  = Integer.parseInt(ecmsProjectNum_2id);
        String ceeItemNumber_3id=  request.getParameter("ceeItemNumber17");
        java.lang.String ceeItemNumber_3idTemp  = ceeItemNumber_3id;
        String clItemNumber_4id=  request.getParameter("clItemNumber19");
        java.lang.String clItemNumber_4idTemp  = clItemNumber_4id;
        String actionDate_5id=  request.getParameter("actionDate21");
        java.lang.String actionDate_5idTemp  = actionDate_5id;
        String clApprBy_6id=  request.getParameter("clApprBy23");
        java.lang.String clApprBy_6idTemp  = clApprBy_6id;
        String ceeDocLink_7id=  request.getParameter("ceeDocLink25");
        java.lang.String ceeDocLink_7idTemp  = ceeDocLink_7id;
        us.pa.state.dot.ecms.webservices.CEESInterfaceResult updateCEEChecklistItem2mtemp = sampleWSCEESInterfaceProxyid.updateCEEChecklistItem(userId_0idTemp,password_1idTemp,ecmsProjectNum_2idTemp,ceeItemNumber_3idTemp,clItemNumber_4idTemp,actionDate_5idTemp,clApprBy_6idTemp,ceeDocLink_7idTemp);
if(updateCEEChecklistItem2mtemp == null){
%>
<%=updateCEEChecklistItem2mtemp %>
<%
}else{
%>
<TABLE>
<TR>
<TD COLSPAN="3" ALIGN="LEFT">returnp:</TD>
<TR>
<TD WIDTH="5%"></TD>
<TD COLSPAN="2" ALIGN="LEFT">result:</TD>
<TD>
<%
if(updateCEEChecklistItem2mtemp != null){
java.lang.String typeresult5 = updateCEEChecklistItem2mtemp.getResult();
        String tempResultresult5 = org.eclipse.jst.ws.util.JspUtils.markup(String.valueOf(typeresult5));
        %>
        <%= tempResultresult5 %>
        <%
}%>
</TD>
<TR>
<TD WIDTH="5%"></TD>
<TD COLSPAN="2" ALIGN="LEFT">ceeItemQueued:</TD>
<TD>
<%
if(updateCEEChecklistItem2mtemp != null){
%>
<%=updateCEEChecklistItem2mtemp.isCeeItemQueued()
%><%}%>
</TD>
<TR>
<TD WIDTH="5%"></TD>
<TD COLSPAN="2" ALIGN="LEFT">errorMessage:</TD>
<TD>
<%
if(updateCEEChecklistItem2mtemp != null){
java.lang.String typeerrorMessage9 = updateCEEChecklistItem2mtemp.getErrorMessage();
        String tempResulterrorMessage9 = org.eclipse.jst.ws.util.JspUtils.markup(String.valueOf(typeerrorMessage9));
        %>
        <%= tempResulterrorMessage9 %>
        <%
}%>
</TD>
</TABLE>
<%
}
break;
}
} catch (Exception e) { 
%>
exception: <%= e %>
<%
return;
}
if(!gotMethod){
%>
result: N/A
<%
}
%>
</BODY>
</HTML>