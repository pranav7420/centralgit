<%@page contentType="text/html;charset=UTF-8"%>
<% request.setCharacterEncoding("UTF-8"); %>
<HTML>
<HEAD>
<TITLE>Result</TITLE>
</HEAD>
<BODY>
<H1>Result</H1>

<jsp:useBean id="sampleWSUREDMSInterfaceProxyid" scope="session" class="us.pa.state.dot.ecms.webservices.WSUREDMSInterfaceProxy" />
<%
if (request.getParameter("endpoint") != null && request.getParameter("endpoint").length() > 0)
sampleWSUREDMSInterfaceProxyid.setEndpoint(request.getParameter("endpoint"));
%>

<%
String method = request.getParameter("method");
int methodID = 0;
if (method == null) methodID = -1;

if(methodID != -1) methodID = Integer.parseInt(method);
boolean gotMethod = false;

try {
switch (methodID){ 
case 2:
        gotMethod = true;
        String userId_0id=  request.getParameter("userId11");
        java.lang.String userId_0idTemp  = userId_0id;
        String password_1id=  request.getParameter("password13");
        java.lang.String password_1idTemp  = password_1id;
        String ecmsProjectNum_2id=  request.getParameter("ecmsProjectNum15");
        int ecmsProjectNum_2idTemp  = Integer.parseInt(ecmsProjectNum_2id);
        String clItemNumber_3id=  request.getParameter("clItemNumber17");
        java.lang.String clItemNumber_3idTemp  = clItemNumber_3id;
        String actionDate_4id=  request.getParameter("actionDate19");
        java.lang.String actionDate_4idTemp  = actionDate_4id;
        String fhwaDate_5id=  request.getParameter("fhwaDate21");
        java.lang.String fhwaDate_5idTemp  = fhwaDate_5id;
        String clApprBy_6id=  request.getParameter("clApprBy23");
        java.lang.String clApprBy_6idTemp  = clApprBy_6id;
        String edmsDocLink_7id=  request.getParameter("edmsDocLink25");
        java.lang.String edmsDocLink_7idTemp  = edmsDocLink_7id;
        String edmsDocName_8id=  request.getParameter("edmsDocName27");
        java.lang.String edmsDocName_8idTemp  = edmsDocName_8id;
        us.pa.state.dot.ecms.webservices.UREDMSInterfaceResult updateUREDMSChecklistItem2mtemp = sampleWSUREDMSInterfaceProxyid.updateUREDMSChecklistItem(userId_0idTemp,password_1idTemp,ecmsProjectNum_2idTemp,clItemNumber_3idTemp,actionDate_4idTemp,fhwaDate_5idTemp,clApprBy_6idTemp,edmsDocLink_7idTemp,edmsDocName_8idTemp);
if(updateUREDMSChecklistItem2mtemp == null){
%>
<%=updateUREDMSChecklistItem2mtemp %>
<%
}else{
%>
<TABLE>
<TR>
<TD COLSPAN="3" ALIGN="LEFT">returnp:</TD>
<TR>
<TD WIDTH="5%"></TD>
<TD COLSPAN="2" ALIGN="LEFT">result:</TD>
<TD>
<%
if(updateUREDMSChecklistItem2mtemp != null){
java.lang.String typeresult5 = updateUREDMSChecklistItem2mtemp.getResult();
        String tempResultresult5 = org.eclipse.jst.ws.util.JspUtils.markup(String.valueOf(typeresult5));
        %>
        <%= tempResultresult5 %>
        <%
}%>
</TD>
<TR>
<TD WIDTH="5%"></TD>
<TD COLSPAN="2" ALIGN="LEFT">errorMessage:</TD>
<TD>
<%
if(updateUREDMSChecklistItem2mtemp != null){
java.lang.String typeerrorMessage7 = updateUREDMSChecklistItem2mtemp.getErrorMessage();
        String tempResulterrorMessage7 = org.eclipse.jst.ws.util.JspUtils.markup(String.valueOf(typeerrorMessage7));
        %>
        <%= tempResulterrorMessage7 %>
        <%
}%>
</TD>
<TR>
<TD WIDTH="5%"></TD>
<TD COLSPAN="2" ALIGN="LEFT">itemQueued:</TD>
<TD>
<%
if(updateUREDMSChecklistItem2mtemp != null){
%>
<%=updateUREDMSChecklistItem2mtemp.isItemQueued()
%><%}%>
</TD>
</TABLE>
<%
}
break;
}
} catch (Exception e) { 
%>
exception: <%= e %>
<%
return;
}
if(!gotMethod){
%>
result: N/A
<%
}
%>
</BODY>
</HTML>