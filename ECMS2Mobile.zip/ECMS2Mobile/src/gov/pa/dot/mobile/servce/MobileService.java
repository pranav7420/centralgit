package gov.pa.dot.mobile.servce;

import gov.pa.dot.mobile.domain.PDCcheckListDetailRequest;
import gov.pa.dot.mobile.domain.PDCcheckListDetailResponse;
import gov.pa.dot.mobile.domain.PDCcheckListResponse;

import javax.servlet.ServletContext;

public interface MobileService
{
	public PDCcheckListResponse getPDC(PDCcheckListDetailRequest request, ServletContext context);

	public PDCcheckListDetailResponse getPDCDetails(PDCcheckListDetailRequest request, ServletContext context);
}
