/**
 * 
 */
package gov.pa.dot.mobile.servce;

import javax.servlet.ServletContext;

import gov.pa.dot.mobile.domain.BaseDomain;
import gov.pa.dot.mobile.domain.UserProfile;
import gov.pa.dot.mobile.exception.MobileServiceException;
import us.pa.state.dot.ecms.dataobject.DOCOMUser;
import us.pa.state.dot.ecms.dataobject.DOCOMUserGroupList;
import us.pa.state.dot.framework.data.DOHAUserPassword;
import us.pa.state.dot.framework.data.PDDataObjectList;
import us.pa.state.dot.framework.exception.HAUserException;

/**
 * @author c-stumugan
 *
 */
public interface AuthenticationService
{

	public  void checkUserPassword(String userId,  DOHAUserPassword doUserPassword, String serverName, String pathName,PDDataObjectList authControlList) throws HAUserException, Exception;
	public UserProfile  getUserProfile(DOCOMUser dOCOMUser,DOCOMUserGroupList doUserGroupList) throws MobileServiceException;
	public BaseDomain validateUser(String userId, ServletContext context);
}
