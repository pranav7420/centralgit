/**
 * 
 */
package gov.pa.dot.mobile.listener;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.UUID;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.slf4j.MDC;

/**
 * @author c-stumugan
 * 
 */
public class StartupUtilityListener implements ServletContextListener
{

	public void contextDestroyed(ServletContextEvent event)
	{

	}

	public void contextInitialized(ServletContextEvent event)
	{

		MDC.put("UUID", "<uid: " + UUID.randomUUID().toString().replace("-", "") + ">");
		try
		{

			System.setProperty("DOCS_LOG_PATH", "////" + InetAddress.getLocalHost().getHostName() + "//");

		}
		catch (UnknownHostException e)
		{

		}

	}

}
