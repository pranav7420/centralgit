/**
 * 
 */
package gov.pa.dot.mobile.controller;

import gov.pa.dot.mobile.interceptor.PropertiesManager;
import gov.pa.dot.mobile.utilities.ApplicationProperties;
import gov.pa.dot.mobile.utilities.ECMSConstants;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @author c-stumugan
 *
 */
@Controller
public class AdminController
{

	@Autowired
	ApplicationProperties applicationProperties;
	
	@RequestMapping(value = ECMSConstants.END_POINT_ECMS_DOCS_STATUS, method = RequestMethod.GET)
	public ResponseEntity<String> docsStatus(HttpServletRequest request)
	{
		String ipAdd = "";
		String remoteAddr = request.getRemoteAddr();
		if (request.getHeader("X-Forwarded-For") != null)
		{
			//If it has IP Address, Proxy1,Proxy2
			int idx = (request.getHeader("X-Forwarded-For")).indexOf(',');
			if (idx > -1)
			{
				ipAdd = (request.getHeader("X-Forwarded-For")).substring(0, idx);
			}
		}
		else if (request.getHeader("Proxy-client-IP") != null)
		{
			ipAdd = request.getHeader("Proxy-client-IP");
		}
		else if (request.getHeader("WL-Proxy-client-IP") != null)
		{
			ipAdd = request.getHeader("WL-Proxy-client-IP");
		}
		else if (request.getHeader("HTTP_CLIENT_IP") != null)
		{
			ipAdd = request.getHeader("HTTP_CLIENT_IP");
		}
		else
		{
			ipAdd = remoteAddr;
		}
		//moved outside if condition
		StringBuilder sb = new StringBuilder("");
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type", "text/html");
		headers.add("RESTServiceAppVersion", PropertiesManager.getProperty("app.version.long"));
		headers.add("RESTServerName", request.getServerName());
		headers.add("RESTLocalName", request.getLocalName());
		headers.add("DeviceVersion", PropertiesManager.getProperty("device.version"));
		sb.append("<html><head><title>DOCS REST Service Status</title>");
		sb.append("<style type='text/css'>");
		sb.append("table.table1{font-family:'Trebuchet MS',sans-serif;font-size: 16px;font-weight: bold;line-height:1.4em;font-style: normal;border-collapse:separate;}");
		sb.append(".table1 th{padding:2px;color:#000;text-align:left;text-shadow:1px 1px 1px #568F23;border:1px solid #93CE37;border-bottom:3px solid #9ED929;background-color:#9DD929;background:-webkit-gradient(linear,left bottom,left top,color-stop(0.02,rgb(123,192,67)),color-stop(0.51, rgb(139,198,66)),color-stop(0.87, rgb(158,217,41)));background: -moz-linear-gradient(center bottom,rgb(123,192,67) 2%,rgb(139,198,66) 51%,rgb(158,217,41) 87% );-webkit-border-top-left-radius:5px;-webkit-border-top-right-radius:5px;-moz-border-radius:5px 5px 0px 0px;border-top-left-radius:5px;border-top-right-radius:5px; } ");
		sb.append(".table1 thead th:empty{background:transparent;border:none;} ");
		sb.append(".table1 tbody td{padding:2px;padding-left:10px;text-align:left;background-color:#DEF3CA;border: 2px solid #E7EFE0;-moz-border-radius:2px;-webkit-border-radius:2px;border-radius:2px;   color:#666;text-shadow:1px 1px 1px #fff; } ");
		sb.append("</style></head><body><span style='font-size:18px;color:#000;font-weight:bold;'>DOCS REST Service Status</span><table class='table1'><tbody>");
		sb.append("<tr><th scope='row'>Server App Version</th><td>" + PropertiesManager.getProperty("app.version.long") + "</td></tr>");
		sb.append("<tr><th scope='row'>Mobile App Version</th><td>" + PropertiesManager.getProperty("device.version") + "</td></tr>");
		sb.append("<tr><th scope='row'>Mobile App Status</th><td>" + " RUNNING " + "</td></tr>");

		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		sb.append("<tr><th scope='row'>App Server Time</th><td>" + dateFormat.format(cal.getTime()) + "</td></tr>");
		sb.append("<br><br>");
		sb.append("</tbody></table></body></html>");
		ResponseEntity<String> res = new ResponseEntity<String>(sb.toString(), headers, HttpStatus.OK);
		return res;
	}

	@RequestMapping(value = ECMSConstants.END_POINT_ECMS_RELOAD_APP_PROPERTIES , method = RequestMethod.GET)
	public ResponseEntity<String> reloadAppProperties()
	{
		StringBuilder sb = new StringBuilder("");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.TEXT_HTML);
		try
		{
			applicationProperties.init();
			sb.append("<html><head><title>DLT REST Service Details</title>");
			sb.append("<style type='text/css'>");
			sb.append("table.table1{font-family:'Trebuchet MS',sans-serif;font-size: 16px;font-weight: bold;line-height:1.4em;font-style: normal;border-collapse:separate;}");
			sb.append(".table1 th{padding:2px;color:#000;text-align:left;text-shadow:1px 1px 1px #568F23;border:1px solid #93CE37;border-bottom:3px solid #9ED929;background-color:#9DD929;background:-webkit-gradient(linear,left bottom,left top,color-stop(0.02,rgb(123,192,67)),color-stop(0.51, rgb(139,198,66)),color-stop(0.87, rgb(158,217,41)));background: -moz-linear-gradient(center bottom,rgb(123,192,67) 2%,rgb(139,198,66) 51%,rgb(158,217,41) 87% );-webkit-border-top-left-radius:5px;-webkit-border-top-right-radius:5px;-moz-border-radius:5px 5px 0px 0px;border-top-left-radius:5px;border-top-right-radius:5px; } ");
			sb.append(".table1 thead th:empty{background:transparent;border:none;} ");
			sb.append(".table1 tbody td{padding:2px;padding-left:10px;text-align:left;background-color:#DEF3CA;border: 2px solid #E7EFE0;-moz-border-radius:2px;-webkit-border-radius:2px;border-radius:2px;   color:#666;text-shadow:1px 1px 1px #fff; } ");
			sb.append("</style></head><body>");
			sb.append("<div id=\"left\" style=\"left; width:75%;\">");
			sb.append("<span style='font-size:18px;color:#000;font-weight:bold;'>Application Properties</span>");
			sb.append("<br><br>");
			sb.append("<table class='table1'><tbody>");

			Map<String, String> propertiesMap = applicationProperties.getApplicationProperties();

			for (Entry<String, String> entry : propertiesMap.entrySet())
			{
				sb.append("<tr><th scope='row'>" + entry.getKey() + " </th><td>" + entry.getValue() + "</td></tr>");
			}

			sb.append("</tbody></table>");
			sb.append("</div>");
			sb.append("</body></html>");
		}
		catch (Exception e)
		{
			sb.append(e.getLocalizedMessage());
		}

		return new ResponseEntity<String>(sb.toString(), headers, HttpStatus.OK);
	}
}
