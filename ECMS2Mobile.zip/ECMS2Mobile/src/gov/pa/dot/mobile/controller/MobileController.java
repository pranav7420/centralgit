/**
 * 
 */
package gov.pa.dot.mobile.controller;

import static gov.pa.dot.mobile.utilities.MobileSessionUtils.BOCOM_BUSINESS_FUNCTION_ALL;
import static gov.pa.dot.mobile.utilities.MobileSessionUtils.BOCOM_BUSINESS_FUNCTION_CONTRACTOR;
import static gov.pa.dot.mobile.utilities.MobileSessionUtils.USER_MOBILE_SESSION_DOUSER;
import static gov.pa.dot.mobile.utilities.MobileSessionUtils.USER_MOBILE_SESSION_USER_LIST;

import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.ServletContext;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import gov.pa.dot.mobile.domain.ActiveSOLDetailRequest;
import gov.pa.dot.mobile.domain.Document;
import gov.pa.dot.mobile.domain.DocumentMetadataRequest;
import gov.pa.dot.mobile.domain.DocumentMetadataResponse;
import gov.pa.dot.mobile.domain.GetPdfResponse;
import gov.pa.dot.mobile.domain.GetProjectResponse;
import gov.pa.dot.mobile.domain.GetProjectsRequest;
import gov.pa.dot.mobile.domain.PDCcheckList;
import gov.pa.dot.mobile.domain.PDCcheckListDetailRequest;
import gov.pa.dot.mobile.domain.PDCcheckListDetailResponse;
import gov.pa.dot.mobile.domain.PDCcheckListResponse;
import gov.pa.dot.mobile.domain.PDFRetrieveRequest;
import gov.pa.dot.mobile.domain.ProjectObject;
import gov.pa.dot.mobile.domain.ProjectRequest;
import gov.pa.dot.mobile.domain.ProjectResponseObject;
import gov.pa.dot.mobile.domain.SOLDocumentList;
import gov.pa.dot.mobile.domain.SOLResponseList;
import gov.pa.dot.mobile.domain.SOLResult;
import gov.pa.dot.mobile.exception.MobilePersistenceException;
import gov.pa.dot.mobile.persistence.DocsMapper;
import gov.pa.dot.mobile.servce.MobileService;
import gov.pa.dot.mobile.utilities.AppUtil;
import gov.pa.dot.mobile.utilities.ApplicationProperties;
import gov.pa.dot.mobile.utilities.ECMSConstants;
import gov.pa.dot.mobile.utilities.JSONUtil;
import gov.pa.dot.mobile.utilities.MessageCodeEnum;
import gov.pa.dot.mobile.utilities.MobileSessionUtils;
import us.pa.state.dot.ecms.business.BOBSLBidPackage;
import us.pa.state.dot.ecms.business.BOCABContract;
import us.pa.state.dot.ecms.business.BOCOMDocHandler;
import us.pa.state.dot.ecms.business.BOCOMDocumentQueueManager;
import us.pa.state.dot.ecms.business.BOCOMSOL;
import us.pa.state.dot.ecms.business.BOCOMSOLSearch;
import us.pa.state.dot.ecms.business.BOPDCItemList;
import us.pa.state.dot.ecms.database.DBCOMSOL;
import us.pa.state.dot.ecms.database.DBCOMSOLSearch;
import us.pa.state.dot.ecms.dataobject.DOBidPackage;
import us.pa.state.dot.ecms.dataobject.DOCOMDocument;
import us.pa.state.dot.ecms.dataobject.DOCOMDocumentList;
import us.pa.state.dot.ecms.dataobject.DOCOMSOL;
import us.pa.state.dot.ecms.dataobject.DOCOMSOLList;
import us.pa.state.dot.ecms.dataobject.DOCOMSOLSearchCriteria;
import us.pa.state.dot.ecms.dataobject.DOCOMUser;
import us.pa.state.dot.ecms.dataobject.DOCOMUserGroup;
import us.pa.state.dot.ecms.dataobject.DOCOMUserGroupList;
import us.pa.state.dot.ecms.dataobject.DOPDCItem;
import us.pa.state.dot.ecms.dataobject.DOPDCList;
import us.pa.state.dot.ecms.exception.EXBSLException;
import us.pa.state.dot.ecms.exception.EXCABException;
import us.pa.state.dot.framework.data.PDDataObject;
import us.pa.state.dot.framework.environment.PDWebServiceEnvironment;
import us.pa.state.dot.framework.util.PDDate;
import us.pa.state.dot.framework.util.PDNumber;

/**
 * @author stumugan
 * 
 */
@Controller
public class MobileController
{
	public static Logger logger = LoggerFactory.getLogger(MobileController.class);

	public static Logger reqresLogger = LoggerFactory.getLogger(ECMSConstants.REQRESlOG);

	@Autowired
	private DocsMapper docsMapper;

	@Autowired
	private ServletContext context;

	@Autowired
	MobileService mobileService;

	@Autowired
	ApplicationProperties applicationProperties;

	@RequestMapping(value = ECMSConstants.END_POINT_ECMS_GET_PROJECTS_LIST, method = RequestMethod.POST)
	public @ResponseBody ProjectResponseObject getProjects(@RequestBody GetProjectsRequest request) throws Exception
	{

		reqresLogger.debug(ECMSConstants.END_POINT_ECMS_GET_PROJECTS_LIST + " --> " + request.getUserId() + " --> " + JSONUtil.getJsonString(request));
		String userId = request.getUserId().toLowerCase();

		ProjectResponseObject projResObj = new ProjectResponseObject();
		try
		{

			ProjectRequest projectRequest = buildRequest(userId, ProjectRequest.BOOLEAN_INT_FALSE, request);

			if (projectRequest != null)
			{
				if (projectRequest.getUserGroupList().contains(ECMSConstants.ECMS_MOBILE_READONLY))
				{
					if (applicationProperties.getAllProjectsQuery().equalsIgnoreCase(ECMSConstants.CODE_OPTIMISED))
					{
						projResObj.setActiveProjList(docsMapper.getAllProjectsForState(projectRequest));
					}
					else
					{
						projResObj.setActiveProjList(docsMapper.getOldAllProjectsForState(projectRequest));
					}
				}
				else
				{
					if (applicationProperties.getTeamMemberListQuery().equalsIgnoreCase(ECMSConstants.CODE_OPTIMISED))
					{

						projResObj.setUserProjList(docsMapper.getTeamMemberProjectList(projectRequest));
					}
					else
					{
						projResObj.setUserProjList(docsMapper.getTeamMemberOldProjectList(projectRequest));
					}

					if (projectRequest.getDistrictView() != null
							&& projectRequest.getDistrictView().equals(ProjectRequest.BOOLEAN_INT_TRUE))
					{
						if (applicationProperties.getDistrictProjectList().equalsIgnoreCase(ECMSConstants.CODE_OPTIMISED))
						{

							projResObj.setActiveProjList(docsMapper.getDistrictProjectList(projectRequest));
						}
						else
						{
							projResObj.setActiveProjList(docsMapper.getOldDistrictProjectList(projectRequest));
						}
					}
					if (projectRequest.getIsFacilityManagement() != null
							&& projectRequest.getIsFacilityManagement().equals(ProjectRequest.BOOLEAN_INT_TRUE))
					{
						projResObj.setActiveProjList(docsMapper.getFacilitiesManagementProjectList(projectRequest));
					}

					if (projectRequest.getIsBusinessPartner() != null
							&& projectRequest.getIsBusinessPartner().equals(ProjectRequest.BOOLEAN_INT_TRUE))
					{
						projResObj.setActiveProjList(docsMapper.getBusinessPartnerProjectList(projectRequest));
					}
					/*
									if (projectList != null && projectList.size() > 0)
									{
					
										Map<Integer, ProjectObject> projMap = new HashMap<Integer, ProjectObject>();
										for (ProjectObject project : projectList)
										{
											Object obj = projMap.get(project.getEcmsProjectNum());
											if (obj == null)
											{
												projMap.put(project.getEcmsProjectNum(), project);
											}
										}
										projectList.clear();
										projectList = new ArrayList<ProjectObject>(projMap.values());
					
										for (ProjectObject proj : projectList)
										{
											if (proj.getProjListType().equals(ECMSConstants.USER))
											{
												projResObj.getUserProjList().add(proj);
											}
											else
											{
												projResObj.getActiveProjList().add(proj);
											}
										}
									}*/
				}
			}

			logger.debug("number of Active proj -->" + projResObj.getActiveProjList().size());
			logger.debug("number of User proj -->" + projResObj.getUserProjList().size());
		}
		catch (MobilePersistenceException pe)
		{
			logger.error(ECMSConstants.ERROR + "-->", pe);
			AppUtil.setErrorMessageToResponse(projResObj, MessageCodeEnum.ERROR, AppUtil.getRootExceptionMessage(pe));
			USER_MOBILE_SESSION_DOUSER.remove(userId);
			USER_MOBILE_SESSION_USER_LIST.remove(userId);
		}
		catch (Exception e)
		{
			logger.error(ECMSConstants.ERROR + "-->", e);
			AppUtil.setErrorMessageToResponse(projResObj, MessageCodeEnum.ERROR, AppUtil.getRootExceptionMessage(e));
			USER_MOBILE_SESSION_DOUSER.remove(userId);
			USER_MOBILE_SESSION_USER_LIST.remove(userId);
		}
		return projResObj;
	}

	private ProjectRequest buildRequest(String userId, int allProjectsInd, GetProjectsRequest getProjectsRequest) throws MobilePersistenceException, Exception
	{

		ProjectRequest request = getUserDetailsForProjectRequest(userId);
		request.setProjStatusCodeList(Arrays.asList(applicationProperties.getProjStatusCodes().split("\\|")));
		if (request.getBusPartnerId() != null)
		{
			getProjectsRequest.setIsFacilityManagement(null);

			if (request == null || !request.getUserRole().equals(ECMSConstants.USER))
			{
				return null;
			}

			if (StringUtils.hasText(request.getOrganizationCode()) &&
					ProjectRequest.workUnitCodeList.contains(request.getOrganizationCode()))
			{

				request.setDistrictCode(request.getOrganizationCode().substring(0, 2));

				request.setDistrictView(ProjectRequest.BOOLEAN_INT_TRUE);

				if (Arrays.asList(applicationProperties.getOrgCodes().split("\\|")).contains(request.getOrganizationCode()))
				{
					request.setIsFacilityManagement(ProjectRequest.BOOLEAN_INT_TRUE);
				}

				request.setIsBusinessPartner(null);
				request.setBusPartnerId("");

			}
			else if (StringUtils.hasText(request.getBusPartnerId()) &&
					docsMapper.validateBusPartnerId(request.getBusPartnerId()) > 0)
			{
				request.setDistrictCode("");
				request.setDistrictView(null);

				request.setIsBusinessPartner(ProjectRequest.BOOLEAN_INT_TRUE);

			}
			else
			{// Only Team member List 
				request.setDistrictCode("");
				request.setDistrictView(null);
				request.setIsBusinessPartner(null);
				request.setBusPartnerId("");
			}
		}

		return request;
	}

	private ProjectRequest getUserDetailsForProjectRequest(String userId) throws Exception
	{
		PDWebServiceEnvironment pdWSEnv = MobileSessionUtils.getPDEnvironment(userId, context);
		ProjectRequest response = new ProjectRequest();

		List<String> userGroupList = new ArrayList<String>();
		DOCOMUser dOCOMUser = (DOCOMUser) pdWSEnv.getPersistentObject(ECMSConstants.DOCOMUSER);
		if (dOCOMUser != null)
		{
			response.setBusPartnerId(dOCOMUser.getString(DOCOMUser.FIRM_ID));
			response.setDominoFullName(dOCOMUser.getString(DOCOMUser.DOMINO_FULL_NAME));
			response.setUserId(dOCOMUser.getString(DOCOMUser.USER_ID));
			response.setOrganizationCode(dOCOMUser.getString(DOCOMUser.ORGANIZATION));
			response.setUserRole(ECMSConstants.USER);
			DOCOMUserGroupList doUserGroupList = (DOCOMUserGroupList) pdWSEnv.getPersistentObject("DOCOMUserGroupList");
			Enumeration<?> e = doUserGroupList.getDataObjects();
			while (e.hasMoreElements())
			{
				PDDataObject dataObj = (PDDataObject) e.nextElement();
				userGroupList.add(dataObj.getString(DOCOMUserGroup.GROUP_NAME));

			}
			response.setUserGroupList(userGroupList);

		}

		return response;
	}

	@RequestMapping(value = ECMSConstants.END_POINT_ECMS_GET_PDC_CHECKLIST, method = RequestMethod.POST)
	public @ResponseBody PDCcheckListResponse getPdcChecklist(@RequestBody PDCcheckListDetailRequest request)
	{
		reqresLogger.debug(ECMSConstants.END_POINT_ECMS_GET_PDC_CHECKLIST + " --> " + request.getUserId() + " --> " + JSONUtil.getJsonString(request));
		String userId = request.getUserId().toLowerCase();
		String sendingSource = "";
		PDNumber addendumNum = null;
		PDCcheckListResponse pDCcheckListResponse = new PDCcheckListResponse();
		List<PDCcheckList> pDCcheckList = new ArrayList<PDCcheckList>();
		try
		{
			PDWebServiceEnvironment pdWSEnv = MobileSessionUtils.getPDEnvironment(userId, context);

			PDNumber ecmsProjectNum = new PDNumber(request.getEcmsProjNumber());

			if (request.getVersion() == null || request.getVersion().equals(""))
			{
				request.setVersion(ECMSConstants.PDC_VIEW_CURRENT);
			}

			if (request.getVersion().equalsIgnoreCase(ECMSConstants.PDC_VIEW_CURRENT) || request.getVersion().equalsIgnoreCase(ECMSConstants.PDC_VIEW_ORIGINAL)
					|| request.getVersion().equalsIgnoreCase(ECMSConstants.PDC_VIEW_CONTRACT))
			{
				addendumNum = new PDNumber(0);
			}
			else
			{
				int a = Integer.parseInt(request.getVersion());
				addendumNum = new PDNumber(a);
			}

			if (addendumNum != null && addendumNum.intValue() != 0)
			{
				new BOPDCItemList(pdWSEnv, ecmsProjectNum, addendumNum, sendingSource, true);
			}
			else
			{
				new BOPDCItemList(pdWSEnv, ecmsProjectNum, request.getVersion(), sendingSource, true);
			}

			//doPDClist = dbPDC.readPDCCurrent(ecmsProjectNumber, sendingSource, true);
			DOPDCList doPDClist = (DOPDCList) pdWSEnv.getPersistentObject(ECMSConstants.DOPDCLIST);
			if (doPDClist != null)
			{
				Enumeration<?> e = doPDClist.getDataObjects();
				while (e.hasMoreElements())
				{
					PDDataObject dataObj = (PDDataObject) e.nextElement();
					PDCcheckList pDCcheckListRes = new PDCcheckList();
					setPdc(dataObj, pDCcheckListRes);

					pDCcheckList.add(pDCcheckListRes);
				}
				pDCcheckListResponse.setPdcCheckLsit(pDCcheckList);
			}
			else
			{
				pDCcheckListResponse.setMessageCode(MessageCodeEnum.LIST_EMPTY.getCode());
				pDCcheckListResponse.setStatusMessage(MessageCodeEnum.LIST_EMPTY.getMessage());
			}
		}
		catch (Exception e)
		{
			logger.error(ECMSConstants.ERROR + "--->", e);
			AppUtil.setErrorMessageToResponse(pDCcheckListResponse, MessageCodeEnum.ERROR, AppUtil.getRootExceptionMessage(e));
			USER_MOBILE_SESSION_DOUSER.remove(userId);
			USER_MOBILE_SESSION_USER_LIST.remove(userId);
		}
		return pDCcheckListResponse;
	}

	@RequestMapping(value = ECMSConstants.END_POINT_ECMS_GET_DOCUMENT_METADATA, method = RequestMethod.POST)
	public @ResponseBody DocumentMetadataResponse getDocumentMetadata(@RequestBody DocumentMetadataRequest request)
	{
		reqresLogger.debug(ECMSConstants.END_POINT_ECMS_GET_DOCUMENT_METADATA + " --> " + request.getUserId() + " --> " + JSONUtil.getJsonString(request));
		String userId = request.getUserId().toLowerCase();
		DocumentMetadataResponse metadataResponse = new DocumentMetadataResponse();

		try
		{
			//DocsMobile Code for Contract Documents
			if (request.getCategoryId().equalsIgnoreCase("CONSTECMS1101"))
			{
				metadataResponse.setEcmsDocuments(getContracts(request.getUserId(), request.getEcmsProjNumber()));
			}
			//DocsMobile Code for PDC Reports
			else if (request.getCategoryId().equalsIgnoreCase("CONSTECMS1102"))
			{
				metadataResponse.setEcmsDocuments(getBidPackageReport(request.getUserId(), request.getEcmsProjNumber()));
			}
			else
			{
				AppUtil.setErrorMessageToResponse(metadataResponse, MessageCodeEnum.ERROR, null);
			}
		}
		catch (Exception e)
		{
			logger.error(ECMSConstants.ERROR + "--->", e);
			AppUtil.setErrorMessageToResponse(metadataResponse, MessageCodeEnum.ERROR, AppUtil.getRootExceptionMessage(e));
			USER_MOBILE_SESSION_DOUSER.remove(userId);
			USER_MOBILE_SESSION_USER_LIST.remove(userId);
		}

		return metadataResponse;
	}

	List<Document> getContracts(String userId, int projectNumber) throws Exception
	{
		List<Document> documents = new ArrayList<Document>();

		PDWebServiceEnvironment pdWSEnv = MobileSessionUtils.getPDEnvironment(userId, context);

		PDNumber ecmsProjectNum = new PDNumber(projectNumber);

		BOCABContract contract = new BOCABContract(pdWSEnv, ecmsProjectNum, true);

		DOCOMDocumentList doCOMContractList;
		try
		{
			//Fetch Contract documents
			contract.getURL(ecmsProjectNum, BOCOMDocumentQueueManager.DOC_TYPE_CONTRACT);
			doCOMContractList = (DOCOMDocumentList) pdWSEnv.getPersistentObject(BOCOMDocHandler.DOCUMENT_LIST_SESSION_KEY_NAME);
			if (doCOMContractList != null)
			{
				Enumeration<?> e = doCOMContractList.getDataObjects();
				while (e.hasMoreElements())
				{
					PDDataObject dataObj = (PDDataObject) e.nextElement();
					setDocuments(documents, dataObj);
				}
			}
		}
		catch (EXCABException e1)
		{
			logger.debug("Skipping document not found exception");
		}

		try
		{
			//Fetch Contract attachments
			contract.getURL(ecmsProjectNum, BOCOMDocumentQueueManager.DOC_TYPE_CONTRACT_ATTACHMENT);
			doCOMContractList = (DOCOMDocumentList) pdWSEnv.getPersistentObject(BOCOMDocHandler.DOCUMENT_LIST_SESSION_KEY_NAME);
			if (doCOMContractList != null)
			{
				Enumeration<?> e = doCOMContractList.getDataObjects();
				while (e.hasMoreElements())
				{
					PDDataObject dataObj = (PDDataObject) e.nextElement();
					setDocuments(documents, dataObj);
				}
			}
		}
		catch (EXCABException e)
		{
			logger.debug("Skipping document not found exception");
		}
		return documents;
	}

	List<Document> getBidPackageReport(String userId, int projectNumber) throws Exception
	{
		List<Document> documents = new ArrayList<Document>();
		PDWebServiceEnvironment pdWSEnv = MobileSessionUtils.getPDEnvironment(userId, context);

		PDNumber ecmsProjectNum = new PDNumber(projectNumber);

		BOBSLBidPackage bidPackage = new BOBSLBidPackage(pdWSEnv, ecmsProjectNum, null, true);

		DOBidPackage dOBidPackage;
		//Fetch Bid Package
		dOBidPackage = (DOBidPackage) pdWSEnv.getPersistentObject("doBidPackage");
		if (dOBidPackage != null)
		{
			PDNumber bidPackageNumber = (PDNumber) dOBidPackage.getFields().get(DOBidPackage.BID_PACKAGE_NUM);
			try
			{
				bidPackage.getURLForProposalReport(ecmsProjectNum, bidPackageNumber, true);

				DOCOMDocumentList documentList = (DOCOMDocumentList) pdWSEnv.getPersistentObject(BOCOMDocHandler.DOCUMENT_LIST_SESSION_KEY_NAME);
				if (documentList != null)
				{
					Enumeration<?> e = documentList.getDataObjects();
					while (e.hasMoreElements())
					{
						PDDataObject dataObj = (PDDataObject) e.nextElement();
						setDocuments(documents, dataObj);
					}
				}
			}

			catch (EXBSLException ex)
			{
				logger.debug("Skipping document not found exception");
			}
		}
		return documents;
	}

	@RequestMapping(value = ECMSConstants.END_POINT_ECMS_GET_PDC_DETAIL_LIST, method = RequestMethod.POST)
	public @ResponseBody PDCcheckListDetailResponse getPDCDetailslist(@RequestBody PDCcheckListDetailRequest request)
	{
		reqresLogger.debug(ECMSConstants.END_POINT_ECMS_GET_PDC_DETAIL_LIST + " --> " + request.getUserId() + " --> " + JSONUtil.getJsonString(request));
		PDCcheckListDetailResponse pDCcheckListDetailResponse = mobileService.getPDCDetails(request, context);
		return pDCcheckListDetailResponse;
	}

	/**
	 * 
	 */
	@RequestMapping(value = ECMSConstants.END_POINT_ECMS_GET_ACTIVE_SOL, method = RequestMethod.POST)
	public @ResponseBody SOLResponseList activeSOL(@RequestHeader(value = ECMSConstants.USERID) String userId) throws Exception
	{
		List<SOLResult> solList = new ArrayList<SOLResult>();
		SOLResponseList sOLResponseList = new SOLResponseList();
		PDWebServiceEnvironment pdWSEnv = null;
		try
		{
			if (!userId.isEmpty())
			{
				pdWSEnv = MobileSessionUtils.getPDEnvironment(userId, context);
				BOCOMSOLSearch boCOMSOLSearch = new BOCOMSOLSearch(pdWSEnv, true);
				boCOMSOLSearch.searchActive();
				DOCOMSOLList dOCOMSOLList = (DOCOMSOLList) pdWSEnv.getPersistentObject("doCOMSOLSearchResultsList");
				if (dOCOMSOLList != null)
				{
					Enumeration<?> e = dOCOMSOLList.getDataObjects();
					while (e.hasMoreElements())
					{
						PDDataObject dataObj = (PDDataObject) e.nextElement();
						SOLResult solResponse = new SOLResult();
						setSOLResponse(dataObj, solResponse);
						solList.add(solResponse);
					}
				}
			}
			else
			{

				pdWSEnv = MobileSessionUtils.getPDEnvironment(context);
				DBCOMSOLSearch dBCOMSOLSearch = new DBCOMSOLSearch(pdWSEnv);
				DOCOMSOLSearchCriteria doCOMSOLSearchCriteria = this.setSearchCriteria();
				DOCOMSOLList doCOMSOLSearchResultsList = dBCOMSOLSearch.readAdvancedSearch(doCOMSOLSearchCriteria);
				Enumeration<?> e = doCOMSOLSearchResultsList.getDataObjects();

				while (e.hasMoreElements())
				{
					PDDataObject dataObj = (PDDataObject) e.nextElement();
					SOLResult solResponse = new SOLResult();
					setSOLResponse(dataObj, solResponse);
					solList.add(solResponse);
				}
			}
			sOLResponseList.setSolResponseList(solList);

		}
		catch (Exception e)
		{
			logger.error(ECMSConstants.ERROR + "--->", e);
			AppUtil.setErrorMessageToResponse(sOLResponseList, MessageCodeEnum.ERROR, AppUtil.getRootExceptionMessage(e));
		}
		return sOLResponseList;
	}

	private DOCOMSOLSearchCriteria setSearchCriteria()
	{
		DOCOMSOLSearchCriteria doCOMSOLSearchCriteria = new DOCOMSOLSearchCriteria();

		doCOMSOLSearchCriteria.setValue(DOCOMSOLSearchCriteria.SOL_CURRENT_STATUS_IND, ECMSConstants.ACTIVE_IND);
		doCOMSOLSearchCriteria.setValue(DOCOMSOLSearchCriteria.VIEWABLE_BY_BP_IND, "Y");
		return doCOMSOLSearchCriteria;
	}

	@RequestMapping(value = ECMSConstants.END_POINT_ECMS_GET_ACTIVE_SOL_DETAILS, method = RequestMethod.POST)
	public @ResponseBody SOLDocumentList activeSOLDetails(@RequestBody ActiveSOLDetailRequest soLrequest) throws Exception
	{
		reqresLogger.debug(ECMSConstants.END_POINT_ECMS_GET_ACTIVE_SOL_DETAILS + " --> " + JSONUtil.getJsonString(soLrequest));
		SOLDocumentList sOLDocumentList = new SOLDocumentList();
		try
		{
			PDWebServiceEnvironment pdWSEnv = MobileSessionUtils.getPDEnvironment(context);
			DBCOMSOL dbCOMSOL = new DBCOMSOL(pdWSEnv);
			DateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy");
			Date issueDate = simpleDateFormat.parse(soLrequest.getSolIssueDate());
			List<Document> documentList = new ArrayList<Document>();

			DOCOMSOL doCOMSOL = dbCOMSOL.readCOMSOL(soLrequest.getOrgCode(), new PDDate(issueDate), new PDNumber(Integer.parseInt(soLrequest.getLetterNum())), true);
			if (doCOMSOL != null)
			{
				// read the document list
				BOCOMDocHandler boDocHandler = new BOCOMDocHandler(pdWSEnv);
				DOCOMDocumentList selectedList = boDocHandler.retrieveDocumentList(ECMSConstants.COMSOL_DOCUMENT_TYPE_CODE, 1, doCOMSOL.getPDNumber(DOCOMSOL.DOCUMENT_ID));
				Enumeration<?> e = selectedList.getDataObjects();
				while (e.hasMoreElements())
				{
					PDDataObject dataObj = (PDDataObject) e.nextElement();
					setDocuments(documentList, dataObj);
				}
				sOLDocumentList.setDocumentsList(documentList);
			}
		}
		catch (Exception e)
		{
			logger.error(ECMSConstants.ERROR + "--->", e);
			AppUtil.setErrorMessageToResponse(sOLDocumentList, MessageCodeEnum.ERROR, AppUtil.getRootExceptionMessage(e));
		}
		return sOLDocumentList;
	}

	@RequestMapping(value = ECMSConstants.END_POINT_ECMS_FETCH_PDF, method = RequestMethod.POST)
	public @ResponseBody GetPdfResponse fetchPDF(@RequestBody PDFRetrieveRequest request) throws Exception
	{

		reqresLogger.debug(ECMSConstants.END_POINT_ECMS_FETCH_PDF + " --> " + request.getUserId() + " --> " + JSONUtil.getJsonString(request));
		BOCOMDocHandler aBOCOMDocHandler = null;
		GetPdfResponse response = new GetPdfResponse();
		PDWebServiceEnvironment pdWSEnv = null;
		try
		{
			if (StringUtils.isEmpty(request.getUserId()))
			{
				pdWSEnv = MobileSessionUtils.getPDEnvironment(context);
			}
			else
			{
				String userId = request.getUserId().toLowerCase();
				pdWSEnv = MobileSessionUtils.getPDEnvironment(userId, context);
			}
			aBOCOMDocHandler = new BOCOMDocHandler(pdWSEnv);
			logger.debug("fetchPDF Request " + JSONUtil.getJsonString(request));
			PDNumber docId = new PDNumber(Integer.parseInt(request.getDocId()));
			InputStream is = aBOCOMDocHandler.readDocumentStream(request.getDocTypeCode(), docId);
			response.setDocumentData(IOUtils.toByteArray(is));

		}
		catch (Exception e)
		{
			logger.error(ECMSConstants.ERROR + "--->", e);
			AppUtil.setErrorMessageToResponse(response, MessageCodeEnum.ERROR, AppUtil.getRootExceptionMessage(e));
		}
		return response;
	}

	@RequestMapping(value = ECMSConstants.END_POINT_ECMS_PURGE_USER_SESSION, method = RequestMethod.GET)
	public @ResponseBody ResponseEntity<String> purgeUserSession(@RequestHeader(value = ECMSConstants.USERID) String userId)
	{
		reqresLogger.debug(ECMSConstants.END_POINT_ECMS_PURGE_USER_SESSION + " --> " + userId);
		userId = userId.toLowerCase();
		HttpHeaders headers = new HttpHeaders();
		headers.add(ECMSConstants.CONTENT_TYPE, MediaType.TEXT_HTML_VALUE);
		String message;
		if (userId != null && USER_MOBILE_SESSION_DOUSER.containsKey(userId) && USER_MOBILE_SESSION_USER_LIST.containsKey(userId))
		{
			USER_MOBILE_SESSION_DOUSER.remove(userId);
			USER_MOBILE_SESSION_USER_LIST.remove(userId);
			message = ECMSConstants.USER + " " + userId + " is cleared from the session";
			logger.debug(ECMSConstants.USER + " " + userId + " is cleared from the session");
		}
		else
		{
			message = ECMSConstants.USER + " " + userId + " is not present in the session";
			logger.debug(ECMSConstants.USER + " " + userId + " is not present in the session");
		}
		ResponseEntity<String> res = new ResponseEntity<String>(message, HttpStatus.OK);
		return res;
	}

	@RequestMapping(value = ECMSConstants.END_POINT_ECMS_PURGE_SESSIONS, method = RequestMethod.GET)
	public @ResponseBody ResponseEntity<String> purgeSessions()
	{
		HttpHeaders headers = new HttpHeaders();
		headers.add(ECMSConstants.CONTENT_TYPE, MediaType.TEXT_HTML_VALUE);
		String message;

		USER_MOBILE_SESSION_DOUSER.clear();
		USER_MOBILE_SESSION_USER_LIST.clear();
		BOCOM_BUSINESS_FUNCTION_ALL = null;
		BOCOM_BUSINESS_FUNCTION_CONTRACTOR = null;
		message = "Session is cleared";
		logger.debug("ALL THE SESSIONS CLEARED");
		ResponseEntity<String> res = new ResponseEntity<String>(message, HttpStatus.OK);
		return res;
	}

	/**
	 * 
	 */
	@RequestMapping(value = ECMSConstants.END_POINT_ECMS_GET_SOL, method = RequestMethod.POST)
	public @ResponseBody SOLResponseList getSOL(@RequestBody PDCcheckListDetailRequest request) throws Exception
	{
		reqresLogger.debug(ECMSConstants.END_POINT_ECMS_GET_SOL + " --> " + request.getUserId() + " --> " + JSONUtil.getJsonString(request));
		List<SOLResult> solList = new ArrayList<SOLResult>();
		SOLResponseList sOLResponseList = new SOLResponseList();
		PDWebServiceEnvironment pdWSEnv = null;
		try
		{
			if (!StringUtils.isEmpty(request.getUserId()))
			{
				String userId = request.getUserId().toLowerCase();
				pdWSEnv = MobileSessionUtils.getPDEnvironment(userId, context);

				long startTimeECMS = System.currentTimeMillis();
				BOCOMSOLSearch boCOMSOLSearch = new BOCOMSOLSearch(pdWSEnv, true);
				boCOMSOLSearch.searchActive();
				logger.debug("END_TIME--Calling ECMS to get SOL with UserID--" + (System.currentTimeMillis() - startTimeECMS) + " ms");

				DOCOMSOLList dOCOMSOLList = (DOCOMSOLList) pdWSEnv.getPersistentObject("doCOMSOLSearchResultsList");
				if (dOCOMSOLList != null)
				{
					Enumeration<?> e = dOCOMSOLList.getDataObjects();
					while (e.hasMoreElements())
					{
						SOLResult solResponse = new SOLResult();
						List<Document> documentList = new ArrayList<Document>();
						PDDataObject dataObj = (PDDataObject) e.nextElement();
						setSOLResponse(dataObj, solResponse);

						DateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy");
						Date issueDate = simpleDateFormat.parse(solResponse.getSolIssueDate());
						long startTimeECMSSOLDetails = System.currentTimeMillis();
						new BOCOMSOL(pdWSEnv, solResponse.getOrgCode(), new PDDate(issueDate), new PDNumber(Integer.parseInt(solResponse.getLetterNum())), true);
						DOCOMSOL dOCOMSOL = (DOCOMSOL) pdWSEnv.getPersistentObject("doCOMSOL");
						logger.debug("END_TIME--Calling ECMS to get SOL Details with UserId--" + (System.currentTimeMillis() - startTimeECMSSOLDetails) + " ms");
						if (dOCOMSOL != null)
						{
							DOCOMDocumentList selectedList = (DOCOMDocumentList) dOCOMSOL.getValue("ATTACHMENT_LIST");
							Enumeration<?> en = selectedList.getDataObjects();
							while (en.hasMoreElements())
							{
								PDDataObject dataOb = (PDDataObject) en.nextElement();
								setDocuments(documentList, dataOb);
							}

							solResponse.setDocumentsList(documentList);
						}

						solList.add(solResponse);
					}

				}
			}
			else
			{

				pdWSEnv = MobileSessionUtils.getPDEnvironment(context);
				DBCOMSOLSearch dBCOMSOLSearch = new DBCOMSOLSearch(pdWSEnv);
				DOCOMSOLSearchCriteria doCOMSOLSearchCriteria = this.setSearchCriteria();
				long startTimeECMS = System.currentTimeMillis();
				DOCOMSOLList doCOMSOLSearchResultsList = dBCOMSOLSearch.readAdvancedSearch(doCOMSOLSearchCriteria);
				logger.debug("END_TIME--Calling ECMS to get SOL without UserID--" + (System.currentTimeMillis() - startTimeECMS) + " ms");

				Enumeration<?> e = doCOMSOLSearchResultsList.getDataObjects();

				while (e.hasMoreElements())
				{

					SOLResult solResponse = new SOLResult();
					List<Document> documentList = new ArrayList<Document>();
					PDDataObject dataObj = (PDDataObject) e.nextElement();
					setSOLResponse(dataObj, solResponse);

					DateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy");
					Date issueDate = simpleDateFormat.parse(solResponse.getSolIssueDate());
					long startTimeECMSSOLDetails = System.currentTimeMillis();
					new BOCOMSOL(pdWSEnv, solResponse.getOrgCode(), new PDDate(issueDate), new PDNumber(Integer.parseInt(solResponse.getLetterNum())), true);
					DOCOMSOL dOCOMSOL = (DOCOMSOL) pdWSEnv.getPersistentObject("doCOMSOL");
					logger.debug("END_TIME--Calling ECMS to get SOL Details without UserId--" + (System.currentTimeMillis() - startTimeECMSSOLDetails) + " ms");
					if (dOCOMSOL != null)
					{
						DOCOMDocumentList selectedList = (DOCOMDocumentList) dOCOMSOL.getValue("ATTACHMENT_LIST");
						Enumeration<?> en = selectedList.getDataObjects();
						while (en.hasMoreElements())
						{
							PDDataObject dataOb = (PDDataObject) en.nextElement();
							setDocuments(documentList, dataOb);
						}

						solResponse.setDocumentsList(documentList);
					}

					solList.add(solResponse);

				}
			}
			sOLResponseList.setSolResponseList(solList);

		}
		catch (Exception e)
		{
			logger.error(ECMSConstants.ERROR + "--->", e);
			AppUtil.setErrorMessageToResponse(sOLResponseList, MessageCodeEnum.ERROR, AppUtil.getRootExceptionMessage(e));
		}
		return sOLResponseList;
	}

	@RequestMapping(value = ECMSConstants.END_POINT_ECMS_GET_PDC, method = RequestMethod.POST)
	public @ResponseBody PDCcheckListResponse getPdc(@RequestBody PDCcheckListDetailRequest request)
	{
		reqresLogger.debug(ECMSConstants.END_POINT_ECMS_GET_PDC + " --> " + request.getUserId() + " --> " + JSONUtil.getJsonString(request));
		PDCcheckListResponse pDCcheckListResponse = mobileService.getPDC(request, context);
		return pDCcheckListResponse;
	}

	@RequestMapping(value = ECMSConstants.END_POINT_ECMS_GET_PROJECT_INFO, method = RequestMethod.POST)
	public @ResponseBody GetProjectResponse getProject(@RequestBody PDCcheckListDetailRequest request)
	{
		GetProjectResponse response = new GetProjectResponse();
		reqresLogger.debug(ECMSConstants.END_POINT_ECMS_GET_PROJECT_INFO + " --> " + request.getUserId() + " --> " + JSONUtil.getJsonString(request));
		try
		{
			ProjectObject projectObject = docsMapper.getProject(request.getEcmsProjNumber());
			response.setProject(projectObject);
		}
		catch (Exception e)
		{
			logger.error(ECMSConstants.ERROR + "--->", e);
			AppUtil.setErrorMessageToResponse(response, MessageCodeEnum.ERROR, AppUtil.getRootExceptionMessage(e));
		}

		return response;
	}

	private void setPdc(PDDataObject dataObj, PDCcheckList pDCcheckListRes)
	{
		pDCcheckListRes.setCreatedBy(dataObj.getString(DOPDCItem.CREATED_BY));
		pDCcheckListRes.setLastModifiedBy(dataObj.getString(DOPDCItem.LAST_MODIFIED_BY));
		pDCcheckListRes.setCreatedTs(dataObj.getPDDate(DOPDCItem.CREATED_BY_TS).toFormattedString());
		pDCcheckListRes.setLastModifiedTs(dataObj.getPDDate(DOPDCItem.LAST_MODIFIED_TS).toFormattedString());
		pDCcheckListRes.setFileCount(dataObj.getPDNumber(DOPDCItem.ATTACHMENT_COUNT).intValue());
		pDCcheckListRes.setClLineNum(dataObj.getPDNumber(DOPDCItem.CL_LINE_NUM).toFormattedString(ECMSConstants.FORMATSTRING));
		pDCcheckListRes.setClItemSecDesc(dataObj.getString(DOPDCItem.CL_ITEM_SEC_DESC));
		pDCcheckListRes.setDeleteInd(dataObj.getString(DOPDCItem.DELETE_IND));
		pDCcheckListRes.setAddendumPendInd(dataObj.getString(DOPDCItem.ADDENDA_PEND_IND));
		pDCcheckListRes.setBidPkgInd(dataObj.getString(DOPDCItem.BID_PKG_IND));
		pDCcheckListRes.setClItemComplInd(dataObj.getString(DOPDCItem.CL_ITEM_COMPL_IND));
		pDCcheckListRes.setOrigContInd(dataObj.getString(DOPDCItem.ORIG_CONT_IND));
		pDCcheckListRes.setEcmsProjNum(dataObj.getPDNumber(DOPDCItem.ECMS_PROJECT_NUM).toFormattedString(ECMSConstants.FORMATSTRING));
		pDCcheckListRes.setPdcBodCat(dataObj.getString(DOPDCItem.PDC_BOD_CAT));
		if (dataObj.getValue(DOPDCItem.ADDENDUM_NUM) != "")
		{
			String addendumNum = dataObj.getValue(DOPDCItem.ADDENDUM_NUM).toString();
			pDCcheckListRes.setAddendumNum(addendumNum);
			pDCcheckListRes.setClItemName(dataObj.getValue(DOPDCItem.CL_ITEM_NAME).toString() + "(Addendum:" + addendumNum + ")");
		}
		else
		{

			pDCcheckListRes.setClItemName(dataObj.getValue(DOPDCItem.CL_ITEM_NAME).toString());
		}
	}

	private void setSOLResponse(PDDataObject dataObj, SOLResult solResponse)
	{
		solResponse.setLetterNum(dataObj.getString(DOCOMSOL.LETTER_NUMBER));
		solResponse.setSolAbstract(dataObj.getString(DOCOMSOL.SOL_ABSTRACT));
		solResponse.setSolSignature(dataObj.getString(DOCOMSOL.SOL_SIGNATURE));
		solResponse.setSolIssueDate(dataObj.getPDDate(DOCOMSOL.SOL_ISSUE_DATE).toString());
		solResponse.setSolSubject(dataObj.getString(DOCOMSOL.SOL_SUBJECT));
		solResponse.setSolOriginator(dataObj.getString(DOCOMSOL.SOL_ORIGINATOR));
		solResponse.setOrgCode(dataObj.getString(DOCOMSOL.ORG_CODE));
		solResponse.setFormattedLetterNumber(dataObj.getString(DOCOMSOL.FORMATTED_LETTER_NUMBER));
		solResponse.setSolCurrentStatusInd(dataObj.getString(DOCOMSOL.SOL_CURRENT_STATUS_IND));
		solResponse.setOrgCodeDesc(dataObj.getString(DOCOMSOL.ORG_CODE_DESC));
		solResponse.setSolCurrentStatusDesc(dataObj.getString(DOCOMSOL.SOL_CURRENT_STATUS_DESC));
		solResponse.setSolSignatureDesc(dataObj.getString(DOCOMSOL.SOL_SIGNATURE_DESC));
	}

	private void setDocuments(List<Document> documentList, PDDataObject dataObj)
	{
		Document document = new Document();
		document.setDocumentTypeCode(dataObj.getString(DOCOMDocument.DOCUMENT_TYPE_CODE));
		document.setCreatedBy(dataObj.getString(DOCOMDocument.CREATED_BY));
		document.setEdmsTitleSubject(dataObj.getString(DOCOMDocument.EDMS_TITLE_SUBJECT));
		document.setDocumentId(dataObj.getPDNumber(DOCOMDocument.DOCUMENT_ID).toFormattedString(ECMSConstants.FORMATSTRING));
		document.setEdmsDocTypeCode(dataObj.getString(DOCOMDocument.EDMS_DOC_TYPE_CODE));
		document.setEdmsDocLink(dataObj.getString(DOCOMDocument.EDMS_DOC_LINK));
		document.setEdmsUrl(dataObj.getString(DOCOMDocument.EDMS_URL));
		document.setDocumentLength(dataObj.getValue(DOCOMDocument.DOCUMENT_LENGTH).toString());
		document.setDocumentContentType(dataObj.getString(DOCOMDocument.DOCUMENT_CONTENT_TYPE));
		document.setBpId(dataObj.getString(DOCOMDocument.BP_ID));
		if (dataObj.getValue(DOCOMDocument.EDMS_DOC_ID) != null)
		{
			document.setEdmsDocId(dataObj.getValue(DOCOMDocument.EDMS_DOC_ID).toString());
		}
		document.setCreatedByTs(dataObj.getPDTimeStamp(DOCOMDocument.CREATED_BY_TS).toString());
		document.setDocumentName(dataObj.getString(DOCOMDocument.DOCUMENT_NAME));
		document.setEdmsReadyToMoveInd(dataObj.getString(DOCOMDocument.EDMS_READY_TO_MOVE_IND));
		document.setEdmsDocumentTitle(dataObj.getString(DOCOMDocument.EDMS_DOCUMENT_TITLE));
		documentList.add(document);
	}

	@RequestMapping(value = ECMSConstants.END_POINT_ECMS_GET_PROJECTS_LIST_PARAMS, method = RequestMethod.POST)
	public @ResponseBody ProjectResponseObject getProjectList(@RequestBody GetProjectsRequest request) throws Exception
	{

		reqresLogger.debug(ECMSConstants.END_POINT_ECMS_GET_PROJECTS_LIST + " --> " + request.getUserId() + " --> " + JSONUtil.getJsonString(request));
		String userId = request.getUserId().toLowerCase();

		ProjectResponseObject projResObj = new ProjectResponseObject();
		try
		{

			ProjectRequest projectRequest = GetProjBuildRequest(userId, ProjectRequest.BOOLEAN_INT_FALSE, request);

			if (projectRequest != null)
			{
				if (projectRequest.getUserGroupList().contains(ECMSConstants.ECMS_MOBILE_READONLY))
				{
					if (applicationProperties.getAllProjectsQuery().equalsIgnoreCase(ECMSConstants.CODE_OPTIMISED))
					{
						projResObj.setActiveProjList(docsMapper.getAllProjectsForState(projectRequest));
					}
					else
					{
						projResObj.setActiveProjList(docsMapper.getOldAllProjectsForState(projectRequest));
					}
				}
				else
				{
					if (request.getGetUserProjects())
					{
						if (applicationProperties.getTeamMemberListQuery().equalsIgnoreCase(ECMSConstants.CODE_OPTIMISED))
						{

							projResObj.setUserProjList(docsMapper.getTeamMemberProjectList(projectRequest));
						}
						else
						{
							projResObj.setUserProjList(docsMapper.getTeamMemberOldProjectList(projectRequest));
						}

					}
					if (request.getGetActiveProjects())
					{

						if (projectRequest.getDistrictView() != null
								&& projectRequest.getDistrictView().equals(ProjectRequest.BOOLEAN_INT_TRUE))
						{
							if (applicationProperties.getDistrictProjectList().equalsIgnoreCase(ECMSConstants.CODE_OPTIMISED))
							{

								projResObj.setActiveProjList(docsMapper.getDistrictProjectList(projectRequest));
							}
							else
							{
								projResObj.setActiveProjList(docsMapper.getOldDistrictProjectList(projectRequest));
							}
						}
						if (projectRequest.getIsFacilityManagement() != null
								&& projectRequest.getIsFacilityManagement().equals(ProjectRequest.BOOLEAN_INT_TRUE))
						{
							projResObj.setActiveProjList(docsMapper.getFacilitiesManagementProjectList(projectRequest));
						}

						if (projectRequest.getIsBusinessPartner() != null
								&& projectRequest.getIsBusinessPartner().equals(ProjectRequest.BOOLEAN_INT_TRUE))
						{
							projResObj.setActiveProjList(docsMapper.getBusinessPartnerProjectList(projectRequest));
						}
					}

				}
			}

			logger.debug("number of Active proj -->" + projResObj.getActiveProjList().size());
			logger.debug("number of User proj -->" + projResObj.getUserProjList().size());
		}
		catch (MobilePersistenceException pe)
		{
			logger.error(ECMSConstants.ERROR + "-->", pe);
			AppUtil.setErrorMessageToResponse(projResObj, MessageCodeEnum.ERROR, AppUtil.getRootExceptionMessage(pe));
			USER_MOBILE_SESSION_DOUSER.remove(userId);
			USER_MOBILE_SESSION_USER_LIST.remove(userId);
		}
		catch (Exception e)
		{
			logger.error(ECMSConstants.ERROR + "-->", e);
			AppUtil.setErrorMessageToResponse(projResObj, MessageCodeEnum.ERROR, AppUtil.getRootExceptionMessage(e));
			USER_MOBILE_SESSION_DOUSER.remove(userId);
			USER_MOBILE_SESSION_USER_LIST.remove(userId);
		}
		return projResObj;
	}

	private ProjectRequest GetProjBuildRequest(String userId, int allProjectsInd, GetProjectsRequest getProjectsRequest) throws MobilePersistenceException, Exception
	{

		ProjectRequest request = getUserDetailsForProjectRequest(userId);
		request.setProjStatusCodeList(Arrays.asList(getProjectsRequest.getProjStatusCodes().split("\\|")));
		if (request.getBusPartnerId() != null)
		{
			getProjectsRequest.setIsFacilityManagement(null);

			if (request == null || !request.getUserRole().equals(ECMSConstants.USER))
			{
				return null;
			}

			if (StringUtils.hasText(request.getOrganizationCode()) &&
					ProjectRequest.workUnitCodeList.contains(request.getOrganizationCode()))
			{

				request.setDistrictCode(request.getOrganizationCode().substring(0, 2));

				request.setDistrictView(ProjectRequest.BOOLEAN_INT_TRUE);

				if (Arrays.asList(applicationProperties.getOrgCodes().split("\\|")).contains(request.getOrganizationCode()))
				{
					request.setIsFacilityManagement(ProjectRequest.BOOLEAN_INT_TRUE);
				}

				request.setIsBusinessPartner(null);
				request.setBusPartnerId("");

			}
			else if (StringUtils.hasText(request.getBusPartnerId()) &&
					docsMapper.validateBusPartnerId(request.getBusPartnerId()) > 0)
			{
				request.setDistrictCode("");
				request.setDistrictView(null);

				request.setIsBusinessPartner(ProjectRequest.BOOLEAN_INT_TRUE);

			}
			else
			{// Only Team member List 
				request.setDistrictCode("");
				request.setDistrictView(null);
				request.setIsBusinessPartner(null);
				request.setBusPartnerId("");
			}
		}

		return request;
	}

}
