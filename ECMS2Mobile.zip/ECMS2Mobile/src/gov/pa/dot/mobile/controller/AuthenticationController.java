/**
 * 
 */
package gov.pa.dot.mobile.controller;

import static gov.pa.dot.mobile.utilities.MobileSessionUtils.BOCOM_BUSINESS_FUNCTION_ALL;
import static gov.pa.dot.mobile.utilities.MobileSessionUtils.BOCOM_BUSINESS_FUNCTION_CONTRACTOR;
import static gov.pa.dot.mobile.utilities.MobileSessionUtils.USER_MOBILE_SESSION_DOUSER;
import static gov.pa.dot.mobile.utilities.MobileSessionUtils.USER_MOBILE_SESSION_USER_LIST;

import javax.servlet.ServletContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import gov.pa.dot.mobile.domain.BaseDomain;
import gov.pa.dot.mobile.domain.LoginResponse;
import gov.pa.dot.mobile.domain.UserProfile;
import gov.pa.dot.mobile.exception.MobileServiceException;
import gov.pa.dot.mobile.servce.AuthenticationService;
import gov.pa.dot.mobile.utilities.AppUtil;
import gov.pa.dot.mobile.utilities.ECMSConstants;
import gov.pa.dot.mobile.utilities.MessageCodeEnum;
import gov.pa.dot.mobile.utilities.MobileSessionUtils;
import us.pa.state.dot.ecms.business.BOCOMUser;
import us.pa.state.dot.ecms.business.BOPDCDetail;
import us.pa.state.dot.ecms.dataobject.DOCOMUser;
import us.pa.state.dot.ecms.dataobject.DOCOMUserGroupList;
import us.pa.state.dot.ecms.exception.ECMSUserLogonException;
import us.pa.state.dot.framework.environment.PDWebServiceEnvironment;
import us.pa.state.dot.framework.exception.PDConfigException;

/**
 * @author c-stumugan
 * 
 */
@Controller
public class AuthenticationController
{

	@Autowired
	private AuthenticationService authenticationService;

	public static Logger logger = LoggerFactory.getLogger(AuthenticationController.class);
	public static Logger reqresLogger = LoggerFactory.getLogger(ECMSConstants.REQRESlOG);
	private ServletContext context;
	public static final String USER_LOGGED_IN = "USER_LOGGED_IN";
	public static final String MESSAGE = "MESSAGE";

	@Autowired
	public void setContext(ServletContext context)
	{
		this.context = context;
	}

	@RequestMapping(value = ECMSConstants.END_POINT_ECMS_AUTHORIZE_ECMS, method = RequestMethod.POST)
	public @ResponseBody LoginResponse authorize(@RequestHeader(value = ECMSConstants.ECMSAUTHORIZATION) String auth, @RequestBody String versionId)
	{
		reqresLogger.debug(ECMSConstants.END_POINT_ECMS_AUTHORIZE_ECMS + " --> " + auth);

		LoginResponse response = new LoginResponse();
		String userId = null;
		try
		{
			PDWebServiceEnvironment pdWSEnv = new PDWebServiceEnvironment(context);
			BOCOMUser boUser = new BOCOMUser(pdWSEnv);
			userId = AppUtil.getUserId(auth);
			String password = AppUtil.getPassword(auth);
			boUser.initUser(userId.toLowerCase(), pdWSEnv.getParameter("anonymous", "false"));
			pdWSEnv.setUser(boUser);
			boUser.mobileLogOn(userId, password);
			boUser.getUser(userId);
			boUser.save();
			DOCOMUser dOCOMUser = (DOCOMUser) pdWSEnv.getPersistentObject(ECMSConstants.DOCOMUSER);
			DOCOMUserGroupList doUserGroupList = (DOCOMUserGroupList) pdWSEnv.getPersistentObject("DOCOMUserGroupList");
			if (dOCOMUser != null && doUserGroupList != null)
			{
				UserProfile userProfile = authenticationService.getUserProfile(dOCOMUser, doUserGroupList);
				response.setUser(userProfile);
			}

		}
		catch (ECMSUserLogonException ee)
		{
			AppUtil.setErrorMessageToResponse(response, MessageCodeEnum.ECMS_LOGIN_FAILURE, AppUtil.getRootExceptionMessage(ee));
			logger.error(ECMSConstants.ERROR + "--->", ee);
		}
		catch (PDConfigException pe)
		{
			AppUtil.setErrorMessageToResponse(response, MessageCodeEnum.ECMS_PD_CONFIGURATION_FAILURE, AppUtil.getRootExceptionMessage(pe));
			logger.error(ECMSConstants.ERROR + "--->", pe);

		}
		catch (MobileServiceException se)
		{
			AppUtil.setErrorMessageToResponse(response, MessageCodeEnum.ECMS_USER_OBJECTS_MAPPRING_FAILURE, AppUtil.getRootExceptionMessage(se));
			logger.error(ECMSConstants.ERROR + "--->", se);
		}
		catch (Exception e)
		{
			AppUtil.setErrorMessageToResponse(response, MessageCodeEnum.ERROR, AppUtil.getRootExceptionMessage(e));
			logger.error(ECMSConstants.ERROR + "--->", e);

		}
		return response;

	}

	@RequestMapping(value = ECMSConstants.END_POINT_ECMS_GET_USER_DETAILS, method = RequestMethod.POST)
	public @ResponseBody LoginResponse getUserDetails(@RequestHeader(value = ECMSConstants.USERID) String userId) throws Exception
	{
		reqresLogger.debug(ECMSConstants.END_POINT_ECMS_GET_USER_DETAILS + " --> " + userId);
		LoginResponse loginResponse = new LoginResponse();
		userId = userId.toLowerCase();
		try
		{
			PDWebServiceEnvironment pdWSEnv = MobileSessionUtils.getPDEnvironment(userId, context);

			DOCOMUser dOCOMUser = (DOCOMUser) pdWSEnv.getPersistentObject(ECMSConstants.DOCOMUSER);
			DOCOMUserGroupList doUserGroupList = (DOCOMUserGroupList) pdWSEnv.getPersistentObject("DOCOMUserGroupList");

			if (dOCOMUser != null && doUserGroupList != null)
			{
				UserProfile userProfile = authenticationService.getUserProfile(dOCOMUser, doUserGroupList);
				loginResponse.setUser(userProfile);
			}
		}

		catch (Exception e)
		{
			USER_MOBILE_SESSION_DOUSER.remove(userId);
			USER_MOBILE_SESSION_USER_LIST.remove(userId);
			logger.error(ECMSConstants.ERROR + "--->", e);
			AppUtil.setErrorMessageToResponse(loginResponse, MessageCodeEnum.ERROR, AppUtil.getRootExceptionMessage(e));
		}

		return loginResponse;
	}

	@RequestMapping(value = ECMSConstants.END_POINT_ECMS_IS_AUTHORIZED, method = RequestMethod.GET)
	public @ResponseBody BaseDomain isAuthorized(@RequestHeader String userId)
	{
		BaseDomain response = new BaseDomain();
		logger.debug("isAuthorized is called for the user " + userId);
		PDWebServiceEnvironment pdWSEnv = MobileSessionUtils.getPDEnvironment(userId, context);
		try
		{
			DOCOMUser user = (DOCOMUser) pdWSEnv.getPersistentObject("DOCOMUser");
			if (user.isContractor() && !user.isConsultant())
			{
				if (BOCOM_BUSINESS_FUNCTION_CONTRACTOR == null)
				{
					BOCOMUser bocomUser = new BOCOMUser(pdWSEnv);
					bocomUser.isAuthorized(BOPDCDetail.SEC_ACCESS_LIMITED);
					pdWSEnv.setUser(bocomUser);
					BOCOM_BUSINESS_FUNCTION_CONTRACTOR = ((BOCOMUser) pdWSEnv.getUser()).getBoCOMBusinessFunction();
				}
			}
			else
			{
				if (BOCOM_BUSINESS_FUNCTION_ALL == null)
				{
					BOCOMUser bocomUser = new BOCOMUser(pdWSEnv);
					bocomUser.isAuthorized(BOPDCDetail.SEC_ACCESS_LIMITED);
					pdWSEnv.setUser(bocomUser);
					BOCOM_BUSINESS_FUNCTION_ALL = ((BOCOMUser) pdWSEnv.getUser()).getBoCOMBusinessFunction();
				}
			}

		}
		catch (Exception e)
		{
			logger.error(ECMSConstants.ERROR + "--->", e);
			AppUtil.setErrorMessageToResponse(response, MessageCodeEnum.ERROR, AppUtil.getRootExceptionMessage(e));
		}
		return response;
	}

}
