/**
 * 
 */
package gov.pa.dot.mobile.exception;

/**
 * @author c-stumugan
 * 
 */
public class MobilePersistenceException extends Exception
{

	private static final long serialVersionUID = 6029129479928791921L;

	/**
	 * PersistenceException
	 */
	public MobilePersistenceException()
	{
		super();
	}

	/**
	 * @param message
	 */
	public MobilePersistenceException(String message)
	{
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public MobilePersistenceException(String message, Throwable cause)
	{
		super(message, cause);
	}

	/**
	 * @param cause
	 */
	public MobilePersistenceException(Throwable cause)
	{
		super(cause);
	}
}
