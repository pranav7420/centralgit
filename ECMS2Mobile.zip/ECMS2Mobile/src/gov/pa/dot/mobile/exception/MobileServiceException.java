/**
 * 
 */
package gov.pa.dot.mobile.exception;

import gov.pa.dot.mobile.utilities.MessageCodeEnum;

/**
 * @author c-stumugan
 * 
 */
public class MobileServiceException extends Exception
{

	private static final long serialVersionUID = 6029129479928791921L;

	private final Boolean businessException;
	private final MessageCodeEnum messageCode;

	/**
	 * @param businessException
	 * @param messageCode
	 */
	public MobileServiceException(Boolean businessException, MessageCodeEnum messageCode)
	{
		super();
		this.businessException = businessException;
		this.messageCode = messageCode;
	}

	/**
	 * @param message
	 * @param cause
	 * @param businessException
	 * @param messageCode
	 */
	public MobileServiceException(String message, Throwable cause, Boolean businessException, MessageCodeEnum messageCode)
	{
		super(message, cause);
		this.businessException = businessException;
		this.messageCode = messageCode;
	}

	/**
	 * @param message
	 * @param cause
	 */
	public MobileServiceException(String message, Throwable cause)
	{
		super(message, cause);
		this.businessException = Boolean.FALSE;
		this.messageCode = null;
	}

	/**
	 * @param exceptionMessage
	 * @param cause
	 */
	public MobileServiceException(String exceptionMessage)
	{
		super(exceptionMessage);
		this.businessException = Boolean.FALSE;
		this.messageCode = null;
	}

	public Boolean getBusinessException()
	{
		return businessException;
	}

	public MessageCodeEnum getMessageCode()
	{
		return messageCode;
	}
}
