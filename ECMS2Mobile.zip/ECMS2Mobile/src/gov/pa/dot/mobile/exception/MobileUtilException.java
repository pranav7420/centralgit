/**
 * 
 */
package gov.pa.dot.mobile.exception;

/**
 * @author c-stumugan
 * 
 */
public class MobileUtilException extends Exception
{

	private static final long serialVersionUID = 6029129479928791921L;

	/**
	 * PersistenceException
	 */
	public MobileUtilException()
	{
		super();
	}

	/**
	 * @param message
	 */
	public MobileUtilException(String message)
	{
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public MobileUtilException(String message, Throwable cause)
	{
		super(message, cause);
	}

	/**
	 * @param cause
	 */
	public MobileUtilException(Throwable cause)
	{
		super(cause);
	}
}
