/**
 * 
 */
package gov.pa.dot.mobile.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author c-sangulur
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class DocumentMetadataRequest
{

	private int ecmsProjNumber;
	private String userId;
	private String categoryId;
	
	/**
	 * @return the ecmsProjNumber
	 */
	public int getEcmsProjNumber()
	{
		return ecmsProjNumber;
	}
	/**
	 * @param ecmsProjNumber the ecmsProjNumber to set
	 */
	public void setEcmsProjNumber(int ecmsProjNumber)
	{
		this.ecmsProjNumber = ecmsProjNumber;
	}
	/**
	 * @return the userId
	 */
	public String getUserId()
	{
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId)
	{
		this.userId = userId;
	}
	
	public String getCategoryId() 
	{
		return categoryId;
	}
	
	public void setCategoryId(String categoryId) 
	{
		this.categoryId = categoryId;
	}
}
