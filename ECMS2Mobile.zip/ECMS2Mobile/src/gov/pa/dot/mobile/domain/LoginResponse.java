/**
 * 
 */
package gov.pa.dot.mobile.domain;


/**
 * @author c-stumugan
 * 
 */
public class LoginResponse extends BaseDomain
{
	private UserProfile user;

	/**
	 * @return the user
	 */
	public UserProfile getUser()
	{
		return user;
	}

	/**
	 * @param user
	 *            the user to set
	 */
	public void setUser(UserProfile user)
	{
		this.user = user;
	}

}
