/**
 * 
 */
package gov.pa.dot.mobile.domain;




/**
 * @author c-stumugan
 *
 */
public class SOLDetailResponse
{

	String documentId;
	Integer documentSourceId;
	String sourceDocumentKey;
	String parentName;
	String documentName;
	String documentExtension;
	String documentContentType;
	String relativePath;
	String documentVersion;
	Long documentSize;
	byte[] documentData;
	String createdBy;
	String createdTs;
	String lastModifiedBy;
	String lastModifiedTs;
	String absoluteWebPath;
	char isDirectory= 'N';
	Integer fileCount = 0;
	/**
	 * @return the documentId
	 */
	public String getDocumentId()
	{
		return documentId;
	}
	/**
	 * @param documentId the documentId to set
	 */
	public void setDocumentId(String documentId)
	{
		this.documentId = documentId;
	}
	/**
	 * @return the documentSourceId
	 */
	public Integer getDocumentSourceId()
	{
		return documentSourceId;
	}
	/**
	 * @param documentSourceId the documentSourceId to set
	 */
	public void setDocumentSourceId(Integer documentSourceId)
	{
		this.documentSourceId = documentSourceId;
	}
	/**
	 * @return the sourceDocumentKey
	 */
	public String getSourceDocumentKey()
	{
		return sourceDocumentKey;
	}
	/**
	 * @param sourceDocumentKey the sourceDocumentKey to set
	 */
	public void setSourceDocumentKey(String sourceDocumentKey)
	{
		this.sourceDocumentKey = sourceDocumentKey;
	}
	/**
	 * @return the parentName
	 */
	public String getParentName()
	{
		return parentName;
	}
	/**
	 * @param parentName the parentName to set
	 */
	public void setParentName(String parentName)
	{
		this.parentName = parentName;
	}
	/**
	 * @return the documentName
	 */
	public String getDocumentName()
	{
		return documentName;
	}
	/**
	 * @param documentName the documentName to set
	 */
	public void setDocumentName(String documentName)
	{
		this.documentName = documentName;
	}
	/**
	 * @return the documentExtension
	 */
	public String getDocumentExtension()
	{
		return documentExtension;
	}
	/**
	 * @param documentExtension the documentExtension to set
	 */
	public void setDocumentExtension(String documentExtension)
	{
		this.documentExtension = documentExtension;
	}
	/**
	 * @return the documentContentType
	 */
	public String getDocumentContentType()
	{
		return documentContentType;
	}
	/**
	 * @param documentContentType the documentContentType to set
	 */
	public void setDocumentContentType(String documentContentType)
	{
		this.documentContentType = documentContentType;
	}
	/**
	 * @return the relativePath
	 */
	public String getRelativePath()
	{
		return relativePath;
	}
	/**
	 * @param relativePath the relativePath to set
	 */
	public void setRelativePath(String relativePath)
	{
		this.relativePath = relativePath;
	}
	/**
	 * @return the documentVersion
	 */
	public String getDocumentVersion()
	{
		return documentVersion;
	}
	/**
	 * @param documentVersion the documentVersion to set
	 */
	public void setDocumentVersion(String documentVersion)
	{
		this.documentVersion = documentVersion;
	}
	/**
	 * @return the documentSize
	 */
	public Long getDocumentSize()
	{
		return documentSize;
	}
	/**
	 * @param documentSize the documentSize to set
	 */
	public void setDocumentSize(Long documentSize)
	{
		this.documentSize = documentSize;
	}
	/**
	 * @return the documentData
	 */
	public byte[] getDocumentData()
	{
		return documentData;
	}
	/**
	 * @param documentData the documentData to set
	 */
	public void setDocumentData(byte[] documentData)
	{
		this.documentData = documentData;
	}
	/**
	 * @return the createdBy
	 */
	public String getCreatedBy()
	{
		return createdBy;
	}
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy)
	{
		this.createdBy = createdBy;
	}
	/**
	 * @return the createdTs
	 */
	public String getCreatedTs()
	{
		return createdTs;
	}
	/**
	 * @param createdTs the createdTs to set
	 */
	public void setCreatedTs(String createdTs)
	{
		this.createdTs = createdTs;
	}
	/**
	 * @return the lastModifiedBy
	 */
	public String getLastModifiedBy()
	{
		return lastModifiedBy;
	}
	/**
	 * @param lastModifiedBy the lastModifiedBy to set
	 */
	public void setLastModifiedBy(String lastModifiedBy)
	{
		this.lastModifiedBy = lastModifiedBy;
	}
	/**
	 * @return the lastModifiedTs
	 */
	public String getLastModifiedTs()
	{
		return lastModifiedTs;
	}
	/**
	 * @param lastModifiedTs the lastModifiedTs to set
	 */
	public void setLastModifiedTs(String lastModifiedTs)
	{
		this.lastModifiedTs = lastModifiedTs;
	}
	/**
	 * @return the absoluteWebPath
	 */
	public String getAbsoluteWebPath()
	{
		return absoluteWebPath;
	}
	/**
	 * @param absoluteWebPath the absoluteWebPath to set
	 */
	public void setAbsoluteWebPath(String absoluteWebPath)
	{
		this.absoluteWebPath = absoluteWebPath;
	}
	/**
	 * @return the isDirectory
	 */
	public char getIsDirectory()
	{
		return isDirectory;
	}
	/**
	 * @param isDirectory the isDirectory to set
	 */
	public void setIsDirectory(char isDirectory)
	{
		this.isDirectory = isDirectory;
	}
	/**
	 * @return the fileCount
	 */
	public Integer getFileCount()
	{
		return fileCount;
	}
	/**
	 * @param fileCount the fileCount to set
	 */
	public void setFileCount(Integer fileCount)
	{
		this.fileCount = fileCount;
	} 
	
	
	
	
}

	