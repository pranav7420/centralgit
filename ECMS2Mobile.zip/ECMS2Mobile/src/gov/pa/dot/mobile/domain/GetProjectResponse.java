/**
 * 
 */
package gov.pa.dot.mobile.domain;

/**
 * @author c-stumugan
 *
 */
public class GetProjectResponse extends BaseDomain
{

	ProjectObject project;

	/**
	 * @return the project
	 */
	public ProjectObject getProject()
	{
		return project;
	}

	/**
	 * @param project the project to set
	 */
	public void setProject(ProjectObject project)
	{
		this.project = project;
	}
	
	
}
