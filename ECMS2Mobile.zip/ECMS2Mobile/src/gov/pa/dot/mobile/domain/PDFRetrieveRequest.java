/**
 * 
 */
package gov.pa.dot.mobile.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author c-stumugan
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PDFRetrieveRequest
{

	private String docTypeCode;
	private String docId;
	private String userId;

	/**
	 * @return the docTypeCode
	 */
	public String getDocTypeCode()
	{
		return docTypeCode;
	}

	/**
	 * @param docTypeCode
	 *            the docTypeCode to set
	 */
	public void setDocTypeCode(String docTypeCode)
	{
		this.docTypeCode = docTypeCode;
	}

	/**
	 * @return the docId
	 */
	public String getDocId()
	{
		return docId;
	}

	/**
	 * @param docId
	 *            the docId to set
	 */
	public void setDocId(String docId)
	{
		this.docId = docId;
	}

	/**
	 * @return the userId
	 */
	public String getUserId()
	{
		return userId;
	}

	/**
	 * @param userId
	 *            the userId to set
	 */
	public void setUserId(String userId)
	{
		this.userId = userId;
	}

}
