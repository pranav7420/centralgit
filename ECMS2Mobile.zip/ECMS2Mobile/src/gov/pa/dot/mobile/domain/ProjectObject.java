package gov.pa.dot.mobile.domain;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class ProjectObject implements Serializable {
	private static final long serialVersionUID = -6460067609084978092L;

	private Integer ecmsProjectNum;
	
	@SuppressWarnings("unused")	private String projNum;
	
	private String orgCode;
	private String districtCode;
	private String countyCode;
	private String stateRouteId;
	private String section;
	private String groupId;
	private String municipalityCode;
	private String s408Version;
	private String projectUserType;
	@JsonIgnore private String projListType;
	
	private String projShortDesc;
	private String projLongDesc;
	
	@SuppressWarnings("unused") private String shortDesc;
	@SuppressWarnings("unused") private String longDesc;
	
	private String letDate;
	private String projStatusCode;
	private String projectManager;
	
	
	public Integer getProjNum() {
		return ecmsProjectNum;
	}
	public void setEcmsProjectNum(Integer ecmsProjectNum) {
		this.ecmsProjectNum = ecmsProjectNum;
	}
	@JsonIgnore
	public Integer getEcmsProjectNum(){
		return this.ecmsProjectNum;
	}
	public String getOrgCode() {
		return orgCode;
	}
	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}
	public String getDistrictCode() {
		return districtCode;
	}
	public void setDistrictCode(String districtCode) {
		this.districtCode = districtCode;
	}
	public String getCountyCode() {
		return countyCode;
	}
	public void setCountyCode(String countyCode) {
		this.countyCode = countyCode;
	}
	public String getStateRouteId() {
		return stateRouteId;
	}
	public void setStateRouteId(String stateRouteId) {
		this.stateRouteId = stateRouteId;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getMunicipalityCode() {
		return municipalityCode;
	}
	public void setMunicipalityCode(String municipalityCode) {
		this.municipalityCode = municipalityCode;
	}
	public String getS408Version() {
		return s408Version;
	}
	public void setS408Version(String s408Version) {
		this.s408Version = s408Version;
	}
	public String getShortDesc() {
		return projShortDesc;
	}
	public void setProjShortDesc(String projShortDesc) {
		this.projShortDesc = projShortDesc;
	}
	public String getLongDesc() {
		return projLongDesc;
	}
	public void setProjLongDesc(String projLongDesc) {
		this.projLongDesc = projLongDesc;
	}
	public String getProjListType() {
		return projListType;
	}
	public void setProjListType(String projListType) {
		this.projListType = projListType;
	}
	public String getProjectUserType() {
		return projectUserType;
	}
	public void setProjectUserType(String projectUserType) {
		this.projectUserType = projectUserType;
	}
	/**
	 * @return the letDate
	 */
	public String getLetDate()
	{
		return letDate;
	}
	/**
	 * @param letDate the letDate to set
	 */
	public void setLetDate(String letDate)
	{
		this.letDate = letDate;
	}
	
	/**
	 * @return the projStatusCode
	 */
	public String getProjStatusCode()
	{
		return projStatusCode;
	}
	/**
	 * @param projStatusCode the projStatusCode to set
	 */
	public void setProjStatusCode(String projStatusCode)
	{
		this.projStatusCode = projStatusCode;
	}
	/**
	 * @param longDesc the longDesc to set
	 */
	public void setLongDesc(String longDesc)
	{
		this.longDesc = longDesc;
	}
	/**
	 * @return the projectManager
	 */
	public String getProjectManager()
	{
		return projectManager;
	}
	/**
	 * @param projectManager the projectManager to set
	 */
	public void setProjectManager(String projectManager)
	{
		this.projectManager = projectManager;
	}
	
	
	
}
