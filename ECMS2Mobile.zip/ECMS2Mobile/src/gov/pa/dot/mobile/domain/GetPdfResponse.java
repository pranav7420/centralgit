/**
 * 
 */
package gov.pa.dot.mobile.domain;

/**
 * @author c-stumugan
 *
 */
public class GetPdfResponse extends BaseDomain
{
	byte[] documentData;

	/**
	 * @return the documentData
	 */
	public byte[] getDocumentData()
	{
		return documentData;
	}

	/**
	 * @param documentData the documentData to set
	 */
	public void setDocumentData(byte[] documentData)
	{
		this.documentData = documentData;
	}
	
	
}
