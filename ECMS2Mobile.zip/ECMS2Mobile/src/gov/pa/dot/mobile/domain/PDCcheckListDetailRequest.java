/**
 * 
 */
package gov.pa.dot.mobile.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author c-stumugan
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class PDCcheckListDetailRequest
{

	private int ecmsProjNumber;
	private int cliLineNum;
	private String userId;
	private int addendumNum;
	private String Version="C";
	/**
	 * @return the ecmsProjNumber
	 */
	public int getEcmsProjNumber()
	{
		return ecmsProjNumber;
	}
	/**
	 * @param ecmsProjNumber the ecmsProjNumber to set
	 */
	public void setEcmsProjNumber(int ecmsProjNumber)
	{
		this.ecmsProjNumber = ecmsProjNumber;
	}
	/**
	 * @return the cliLineNum
	 */
	public int getCliLineNum()
	{
		return cliLineNum;
	}
	/**
	 * @param cliLineNum the cliLineNum to set
	 */
	public void setCliLineNum(int cliLineNum)
	{
		this.cliLineNum = cliLineNum;
	}
	/**
	 * @return the userId
	 */
	public String getUserId()
	{
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId)
	{
		this.userId = userId;
	}
	/**
	 * @return the addendumNum
	 */
	public int getAddendumNum()
	{
		return addendumNum;
	}
	/**
	 * @param addendumNum the addendumNum to set
	 */
	public void setAddendumNum(int addendumNum)
	{
		this.addendumNum = addendumNum;
	}
	/**
	 * @return the version
	 */
	public String getVersion()
	{
		return Version;
	}
	/**
	 * @param version the version to set
	 */
	public void setVersion(String version)
	{
		Version = version;
	}
	
	
	
	
}
