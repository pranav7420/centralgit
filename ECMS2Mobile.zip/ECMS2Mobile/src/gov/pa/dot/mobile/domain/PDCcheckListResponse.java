/**
 * 
 */
package gov.pa.dot.mobile.domain;


import java.util.List;

/**
 * @author c-stumugan
 *
 */
public class PDCcheckListResponse extends BaseDomain
{
	private List<PDCcheckList> pdcCheckLsit;

	/**
	 * @return the pdcCheckLsit
	 */
	public List<PDCcheckList> getPdcCheckLsit()
	{
		return pdcCheckLsit;
	}

	/**
	 * @param pdcCheckLsit the pdcCheckLsit to set
	 */
	public void setPdcCheckLsit(List<PDCcheckList> pdcCheckLsit)
	{
		this.pdcCheckLsit = pdcCheckLsit;
	}
	

	 
}
