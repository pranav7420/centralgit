/**
 * 
 */
package gov.pa.dot.mobile.domain;


import java.util.List;

/**
 * @author c-stumugan
 *
 */
public class PDCcheckListDetailResponse extends BaseDomain
{
	private String createdBy;
	private String createdTs;
	private String lastModifiedBy;
	private String lastModifiedTs;
	private String clItemComplInd;
	private String clItemNum;
	private String clItemName;
	private String pdcItemTypeCode;
	private String projStatusCode;
	private String clLineNum;
	private String genCodeValue;
	private String ecmsProjNum;
	private String editBidPkgInd;
	private String origContInd;
	List<Document> pdcDocumentList;
	/**
	 * @return the createdBy
	 */
	public String getCreatedBy()
	{
		return createdBy;
	}
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy)
	{
		this.createdBy = createdBy.trim();
	}
	/**
	 * @return the createdTs
	 */
	public String getCreatedTs()
	{
		return createdTs;
	}
	/**
	 * @param createdTs the createdTs to set
	 */
	public void setCreatedTs(String createdTs)
	{
		this.createdTs = createdTs;
	}
	/**
	 * @return the lastModifiedBy
	 */
	public String getLastModifiedBy()
	{
		return lastModifiedBy;
	}
	/**
	 * @param lastModifiedBy the lastModifiedBy to set
	 */
	public void setLastModifiedBy(String lastModifiedBy)
	{
		this.lastModifiedBy = lastModifiedBy.trim();
	}
	/**
	 * @return the lastModifiedTs
	 */
	public String getLastModifiedTs()
	{
		return lastModifiedTs;
	}
	/**
	 * @param lastModifiedTs the lastModifiedTs to set
	 */
	public void setLastModifiedTs(String lastModifiedTs)
	{
		this.lastModifiedTs = lastModifiedTs;
	}
	/**
	 * @return the clItemComplInd
	 */
	public String getClItemComplInd()
	{
		return clItemComplInd;
	}
	/**
	 * @param clItemComplInd the clItemComplInd to set
	 */
	public void setClItemComplInd(String clItemComplInd)
	{
		this.clItemComplInd = clItemComplInd;
	}
	/**
	 * @return the clItemNum
	 */
	public String getClItemNum()
	{
		return clItemNum;
	}
	/**
	 * @param clItemNum the clItemNum to set
	 */
	public void setClItemNum(String clItemNum)
	{
		this.clItemNum = clItemNum;
	}
	/**
	 * @return the clItemName
	 */
	public String getClItemName()
	{
		return clItemName;
	}
	/**
	 * @param clItemName the clItemName to set
	 */
	public void setClItemName(String clItemName)
	{
		this.clItemName = clItemName.trim();
	}
	/**
	 * @return the pdcItemTypeCode
	 */
	public String getPdcItemTypeCode()
	{
		return pdcItemTypeCode;
	}
	/**
	 * @param pdcItemTypeCode the pdcItemTypeCode to set
	 */
	public void setPdcItemTypeCode(String pdcItemTypeCode)
	{
		this.pdcItemTypeCode = pdcItemTypeCode;
	}
	/**
	 * @return the projStatusCode
	 */
	public String getProjStatusCode()
	{
		return projStatusCode;
	}
	/**
	 * @param projStatusCode the projStatusCode to set
	 */
	public void setProjStatusCode(String projStatusCode)
	{
		this.projStatusCode = projStatusCode;
	}
	/**
	 * @return the clLineNum
	 */
	public String getClLineNum()
	{
		return clLineNum;
	}
	/**
	 * @param clLineNum the clLineNum to set
	 */
	public void setClLineNum(String clLineNum)
	{
		this.clLineNum = clLineNum;
	}
	/**
	 * @return the genCodeValue
	 */
	public String getGenCodeValue()
	{
		return genCodeValue;
	}
	/**
	 * @param genCodeValue the genCodeValue to set
	 */
	public void setGenCodeValue(String genCodeValue)
	{
		this.genCodeValue = genCodeValue;
	}
	/**
	 * @return the ecmsProjNum
	 */
	public String getEcmsProjNum()
	{
		return ecmsProjNum;
	}
	/**
	 * @param ecmsProjNum the ecmsProjNum to set
	 */
	public void setEcmsProjNum(String ecmsProjNum)
	{
		this.ecmsProjNum = ecmsProjNum;
	}
	/**
	 * @return the editBidPkgInd
	 */
	public String getEditBidPkgInd()
	{
		return editBidPkgInd;
	}
	/**
	 * @param editBidPkgInd the editBidPkgInd to set
	 */
	public void setEditBidPkgInd(String editBidPkgInd)
	{
		this.editBidPkgInd = editBidPkgInd;
	}
	/**
	 * @return the origContInd
	 */
	public String getOrigContInd()
	{
		return origContInd;
	}
	/**
	 * @param origContInd the origContInd to set
	 */
	public void setOrigContInd(String origContInd)
	{
		this.origContInd = origContInd;
	}
	/**
	 * @return the pdcDocumentList
	 */
	public List<Document> getPdcDocumentList()
	{
		return pdcDocumentList;
	}
	/**
	 * @param pdcDocumentList the pdcDocumentList to set
	 */
	public void setPdcDocumentList(List<Document> pdcDocumentList)
	{
		this.pdcDocumentList = pdcDocumentList;
	}
	
	

}
