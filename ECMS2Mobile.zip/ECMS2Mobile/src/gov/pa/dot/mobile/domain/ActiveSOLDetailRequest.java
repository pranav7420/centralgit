/**
 * 
 */
package gov.pa.dot.mobile.domain;

/**
 * @author c-stumugan
 *
 */
public class ActiveSOLDetailRequest
{

	private String letterNum;
	private String solIssueDate;
	private String orgCode;
	/**
	 * @return the letterNum
	 */
	public String getLetterNum()
	{
		return letterNum;
	}
	/**
	 * @param letterNum the letterNum to set
	 */
	public void setLetterNum(String letterNum)
	{
		this.letterNum = letterNum;
	}
	/**
	 * @return the solIssueDate
	 */
	public String getSolIssueDate()
	{
		return solIssueDate;
	}
	/**
	 * @param solIssueDate the solIssueDate to set
	 */
	public void setSolIssueDate(String solIssueDate)
	{
		this.solIssueDate = solIssueDate;
	}
	/**
	 * @return the orgCode
	 */
	public String getOrgCode()
	{
		return orgCode;
	}
	/**
	 * @param orgCode the orgCode to set
	 */
	public void setOrgCode(String orgCode)
	{
		this.orgCode = orgCode;
	}
	
}
