/**
 * 
 */
package gov.pa.dot.mobile.domain;

import java.util.List;

/**
 * @author c-stumugan
 *
 */
public class SOLResponseList extends BaseDomain
{

	private List<SOLResult> SolResponseList;

	/**
	 * @return the solResponseList
	 */
	public List<SOLResult> getSolResponseList()
	{
		return SolResponseList;
	}

	/**
	 * @param solResponseList the solResponseList to set
	 */
	public void setSolResponseList(List<SOLResult> solResponseList)
	{
		SolResponseList = solResponseList;
	}
	
	
}
