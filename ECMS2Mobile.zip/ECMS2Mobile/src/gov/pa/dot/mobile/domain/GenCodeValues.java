/**
 * 
 */
package gov.pa.dot.mobile.domain;

/**
 * @author c-stumugan
 * 
 */
public class GenCodeValues
{

	private String genCodeValue;
	private String genCode;
	/**
	 * @return the genCodeValue
	 */
	public String getGenCodeValue()
	{
		return genCodeValue;
	}
	/**
	 * @param genCodeValue the genCodeValue to set
	 */
	public void setGenCodeValue(String genCodeValue)
	{
		this.genCodeValue = genCodeValue.trim();
	}
	/**
	 * @return the genCode
	 */
	public String getGenCode()
	{
		return genCode;
	}
	/**
	 * @param genCode the genCode to set
	 */
	public void setGenCode(String genCode)
	{
		this.genCode = genCode.trim();
	}

	
	
}
