package gov.pa.dot.mobile.domain;


import java.util.ArrayList;
import java.util.List;

public class ProjectResponseObject extends BaseDomain
{
	
	
	private List<ProjectObject> userProjList = new ArrayList<ProjectObject>();
	private List<ProjectObject> activeProjList = new ArrayList<ProjectObject>();
	
	public List<ProjectObject> getUserProjList() {
		return userProjList;
	}
	public void setUserProjList(List<ProjectObject> userProjList) {
		this.userProjList = userProjList;
	}
	public List<ProjectObject> getActiveProjList() {
		return activeProjList;
	}
	public void setActiveProjList(List<ProjectObject> activeProjList) {
		this.activeProjList = activeProjList;
	}
	
	
}
