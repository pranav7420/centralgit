/**
 * 
 */
package gov.pa.dot.mobile.domain;

import java.util.List;

/**
 * @author c-stumugan
 * 
 */
public class SOLDocumentList extends BaseDomain 
{
	List<Document> documentsList;

	/**
	 * @return the documentsList
	 */
	public List<Document> getDocumentsList()
	{
		return documentsList;
	}

	/**
	 * @param documentsList the documentsList to set
	 */
	public void setDocumentsList(List<Document> documentsList)
	{
		this.documentsList = documentsList;
	}

	
	
	
}
