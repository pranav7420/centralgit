/**
 * 
 */
package gov.pa.dot.mobile.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author c-stumugan
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetProjectsRequest
{

	private String organizationCode;
	private String userId;
	private String dominoFullName;
	private String busPartnerId;
	private String userRole;
	private String districtCode;
	private Integer isBusinessPartner;
	private Integer districtView;
	private Integer isFacilityManagement;
	private String projStatusCodes;
	private Boolean getActiveProjects = true;
	private Boolean getUserProjects = true;

	private String projectStatusCodes;

	/**
	 * @return the organizationCode
	 */
	public String getOrganizationCode()
	{
		return organizationCode;
	}

	/**
	 * @param organizationCode
	 *            the organizationCode to set
	 */
	public void setOrganizationCode(String organizationCode)
	{
		this.organizationCode = organizationCode;
	}

	/**
	 * @return the userId
	 */
	public String getUserId()
	{
		return userId;
	}

	/**
	 * @param userId
	 *            the userId to set
	 */
	public void setUserId(String userId)
	{
		this.userId = userId;
	}

	/**
	 * @return the dominoFullName
	 */
	public String getDominoFullName()
	{
		return dominoFullName;
	}

	/**
	 * @param dominoFullName
	 *            the dominoFullName to set
	 */
	public void setDominoFullName(String dominoFullName)
	{
		this.dominoFullName = dominoFullName;
	}

	/**
	 * @return the busPartnerId
	 */
	public String getBusPartnerId()
	{
		return busPartnerId;
	}

	/**
	 * @param busPartnerId
	 *            the busPartnerId to set
	 */
	public void setBusPartnerId(String busPartnerId)
	{
		this.busPartnerId = busPartnerId;
	}

	/**
	 * @return the userRole
	 */
	public String getUserRole()
	{
		return userRole;
	}

	/**
	 * @param userRole
	 *            the userRole to set
	 */
	public void setUserRole(String userRole)
	{
		this.userRole = userRole;
	}

	/**
	 * @return the districtCode
	 */
	public String getDistrictCode()
	{
		return districtCode;
	}

	/**
	 * @param districtCode
	 *            the districtCode to set
	 */
	public void setDistrictCode(String districtCode)
	{
		this.districtCode = districtCode;
	}

	/**
	 * @return the isBusinessPartner
	 */
	public Integer getIsBusinessPartner()
	{
		return isBusinessPartner;
	}

	/**
	 * @param isBusinessPartner
	 *            the isBusinessPartner to set
	 */
	public void setIsBusinessPartner(Integer isBusinessPartner)
	{
		this.isBusinessPartner = isBusinessPartner;
	}

	/**
	 * @return the districtView
	 */
	public Integer getDistrictView()
	{
		return districtView;
	}

	/**
	 * @param districtView
	 *            the districtView to set
	 */
	public void setDistrictView(Integer districtView)
	{
		this.districtView = districtView;
	}

	/**
	 * @return the isFacilityManagement
	 */
	public Integer getIsFacilityManagement()
	{
		return isFacilityManagement;
	}

	/**
	 * @param isFacilityManagement
	 *            the isFacilityManagement to set
	 */
	public void setIsFacilityManagement(Integer isFacilityManagement)
	{
		this.isFacilityManagement = isFacilityManagement;
	}

	/**
	 * @return the projStatusCodes
	 */
	public String getProjStatusCodes()
	{
		return projStatusCodes;
	}

	/**
	 * @param projStatusCodes
	 *            the projStatusCodes to set
	 */
	public void setProjStatusCodes(String projStatusCodes)
	{
		this.projStatusCodes = projStatusCodes;
	}

	public Boolean getGetActiveProjects()
	{
		return getActiveProjects;
	}

	public void setGetActiveProjects(Boolean getActiveProjects)
	{
		this.getActiveProjects = getActiveProjects;
	}

	public Boolean getGetUserProjects()
	{
		return getUserProjects;
	}

	public void setGetUserProjects(Boolean getUserProjects)
	{
		this.getUserProjects = getUserProjects;
	}

	public String getProjectStatusCodes()
	{
		return projectStatusCodes;
	}

	public void setProjectStatusCodes(String projectStatusCodes)
	{
		this.projectStatusCodes = projectStatusCodes;
	}

	
}
