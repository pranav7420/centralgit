package gov.pa.dot.mobile.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;


public class ProjectRequest {

	public static final Integer BOOLEAN_INT_TRUE = 1;
	public static final Integer BOOLEAN_INT_FALSE = 0;
	
	private String sourceApp;
	private String userId;
	private String 	dominoFullName;	
	private String busPartnerId;
	
	private String userRole;
	private String districtCode;
	private Integer isBusinessPartner;
	private Integer districtView;
	private Integer isFacilityManagement;
	private String 	organizationCode;
	private Set<String> userSecurityRoles;
	private List<String> userGroupList;
	
	public String getSourceApp() {return this.sourceApp;}
	public void setSourceApp(String sourceApp) {this.sourceApp = sourceApp;}
	
	public String getUserId() {return this.userId;}
	public void setUserId(String userId) {this.userId = userId;}
	
	public String getDominoFullName() {
		return dominoFullName;
	}
	public void setDominoFullName(String dominoFullName) {
		this.dominoFullName = dominoFullName;
	}
	public String getBusPartnerId() {return this.busPartnerId;}
	public void setBusPartnerId(String busPartnerId) {this.busPartnerId = busPartnerId;}
	
	public String getUserRole() {return this.userRole;}
	public void setUserRole(String userRole) {this.userRole = userRole;}
	
	public String getDistrictCode() {return this.districtCode;}
	public void setDistrictCode(String districtCode) {this.districtCode = districtCode;}
	
	public Integer getIsBusinessPartner() {return this.isBusinessPartner;}
	public void setIsBusinessPartner(Integer isBusinessPartner) {this.isBusinessPartner = isBusinessPartner;}
	public Integer getIsFacilityManagement() {return this.isFacilityManagement;}
	public void setIsFacilityManagement(Integer isFacilityManagement) {this.isFacilityManagement = isFacilityManagement;}
	public Integer getDistrictView() {return this.districtView;}
	public void setDistrictView(Integer districtView) {this.districtView = districtView;
	}
	
	public List<String> getProjDataSourceList() {return ProjectRequest.projDataSourceList;}
	public List<String> getProjFMOrgCodeList() {return ProjectRequest.projFMOrgCodeList;}
	
	
	
	
	/**
	 * @return the projStatusCodeList
	 */
	public List<String> getProjStatusCodeList()
	{
		return projStatusCodeList;
	}
	/**
	 * @param projStatusCodeList the projStatusCodeList to set
	 */
	public void setProjStatusCodeList(List<String> projStatusCodeList)
	{
		this.projStatusCodeList = projStatusCodeList;
	}
	public List<String> getUserGroupList()
	{
		return userGroupList;
	}
	public void setUserGroupList(List<String> userGroupList)
	{
		this.userGroupList = userGroupList;
	}
	public Set<String> getUserSecurityRoles() {
		return userSecurityRoles;
	}
	public void setUserSecurityRoles(Set<String> userSecurityRoles) {
		this.userSecurityRoles = userSecurityRoles;
	}
	public String getOrganizationCode() {return organizationCode;}
	public void setOrganizationCode(String organizationCode) {this.organizationCode = organizationCode;}

	/*public final static class UserObject extends ProjectRequest {
		
		private String 	organizationCode;
		
		public UserObject(String errorMessage){
			setUserRole(errorMessage);
		}
		
		public UserObject(AuthResult auth){
			setUserId(auth.getUsername());
			setDominoFullName(auth.getSecurityFullName());
			setBusPartnerId(auth.getFirmId());
			setOrganizationCode(auth.getOrganizationCode());
			setUserRole("USER");
			setUserSecurityRoles(new HashSet<String>(auth.getGroups().getString()));
		}
		
		public String getOrganizationCode() {return organizationCode;}
		public void setOrganizationCode(String organizationCode) {this.organizationCode = organizationCode;}

	}*/
	
	private  List<String> projStatusCodeList ;
	private final static List<String> projDataSourceList = new ArrayList<String>();
	private final static List<String> projFMOrgCodeList = new ArrayList<String>();
	public final static List<String> workUnitCodeList = new ArrayList<String>();
	static{
		projDataSourceList.add("ECMS");
		projDataSourceList.add("CDSN");
		projDataSourceList.add("CDS3");
		projFMOrgCodeList.add("3500");
		projFMOrgCodeList.add("4300");
		/*projStatusCodeList.add("10");
		projStatusCodeList.add("20");
		projStatusCodeList.add("30");
		projStatusCodeList.add("40");
		projStatusCodeList.add("50");
		projStatusCodeList.add("55");*/
		workUnitCodeList.add("0000");
		workUnitCodeList.add("0081");
		workUnitCodeList.add("0100");
		workUnitCodeList.add("0102");
		workUnitCodeList.add("0103");
		workUnitCodeList.add("0104");
		workUnitCodeList.add("0105");
		workUnitCodeList.add("0110");
		workUnitCodeList.add("0120");
		workUnitCodeList.add("0130");
		workUnitCodeList.add("0140");
		workUnitCodeList.add("0150");
		workUnitCodeList.add("0160");
		workUnitCodeList.add("0200");
		workUnitCodeList.add("0201");
		workUnitCodeList.add("0202");
		workUnitCodeList.add("0203");
		workUnitCodeList.add("0204");
		workUnitCodeList.add("0205");
		workUnitCodeList.add("0210");
		workUnitCodeList.add("0220");
		workUnitCodeList.add("0230");
		workUnitCodeList.add("0240");
		workUnitCodeList.add("0250");
		workUnitCodeList.add("0260");
		workUnitCodeList.add("0270");
		workUnitCodeList.add("0280");
		workUnitCodeList.add("0290");
		workUnitCodeList.add("0300");
		workUnitCodeList.add("0302");
		workUnitCodeList.add("0303");
		workUnitCodeList.add("0304");
		workUnitCodeList.add("0305");
		workUnitCodeList.add("0310");
		workUnitCodeList.add("0320");
		workUnitCodeList.add("0330");
		workUnitCodeList.add("0340");
		workUnitCodeList.add("0350");
		workUnitCodeList.add("0360");
		workUnitCodeList.add("0370");
		workUnitCodeList.add("0380");
		workUnitCodeList.add("0390");
		workUnitCodeList.add("0400");
		workUnitCodeList.add("0402");
		workUnitCodeList.add("0403");
		workUnitCodeList.add("0404");
		workUnitCodeList.add("0405");
		workUnitCodeList.add("0420");
		workUnitCodeList.add("0430");
		workUnitCodeList.add("0440");
		workUnitCodeList.add("0450");
		workUnitCodeList.add("0460");
		workUnitCodeList.add("0470");
		workUnitCodeList.add("0500");
		workUnitCodeList.add("0502");
		workUnitCodeList.add("0503");
		workUnitCodeList.add("0504");
		workUnitCodeList.add("0505");
		workUnitCodeList.add("0510");
		workUnitCodeList.add("0520");
		workUnitCodeList.add("0530");
		workUnitCodeList.add("0540");
		workUnitCodeList.add("0550");
		workUnitCodeList.add("0560");
		workUnitCodeList.add("0600");
		workUnitCodeList.add("0602");
		workUnitCodeList.add("0603");
		workUnitCodeList.add("0604");
		workUnitCodeList.add("0605");
		workUnitCodeList.add("0610");
		workUnitCodeList.add("0620");
		workUnitCodeList.add("0630");
		workUnitCodeList.add("0640");
		workUnitCodeList.add("0650");
		workUnitCodeList.add("0800");
		workUnitCodeList.add("0802");
		workUnitCodeList.add("0803");
		workUnitCodeList.add("0804");
		workUnitCodeList.add("0805");
		workUnitCodeList.add("081");
		workUnitCodeList.add("0810");
		workUnitCodeList.add("0820");
		workUnitCodeList.add("0830");
		workUnitCodeList.add("0840");
		workUnitCodeList.add("0850");
		workUnitCodeList.add("0870");
		workUnitCodeList.add("0880");
		workUnitCodeList.add("0890");
		workUnitCodeList.add("0900");
		workUnitCodeList.add("0902");
		workUnitCodeList.add("0903");
		workUnitCodeList.add("0904");
		workUnitCodeList.add("0905");
		workUnitCodeList.add("0910");
		workUnitCodeList.add("0920");
		workUnitCodeList.add("0930");
		workUnitCodeList.add("0940");
		workUnitCodeList.add("0950");
		workUnitCodeList.add("0970");
		workUnitCodeList.add("1000");
		workUnitCodeList.add("1002");
		workUnitCodeList.add("1003");
		workUnitCodeList.add("1004");
		workUnitCodeList.add("1005");
		workUnitCodeList.add("1010");
		workUnitCodeList.add("1020");
		workUnitCodeList.add("1030");
		workUnitCodeList.add("1040");
		workUnitCodeList.add("1050");
		workUnitCodeList.add("1100");
		workUnitCodeList.add("1102");
		workUnitCodeList.add("1103");
		workUnitCodeList.add("1104");
		workUnitCodeList.add("1105");
		workUnitCodeList.add("1110");
		workUnitCodeList.add("1120");
		workUnitCodeList.add("1130");
		workUnitCodeList.add("1140");
		workUnitCodeList.add("1200");
		workUnitCodeList.add("1202");
		workUnitCodeList.add("1203");
		workUnitCodeList.add("1204");
		workUnitCodeList.add("1205");
		workUnitCodeList.add("1210");
		workUnitCodeList.add("1220");
		workUnitCodeList.add("1240");
		workUnitCodeList.add("1250");
		workUnitCodeList.add("1308");
		workUnitCodeList.add("2000");
		workUnitCodeList.add("2010");
		workUnitCodeList.add("2100");
		workUnitCodeList.add("2200");
		workUnitCodeList.add("2401");
		workUnitCodeList.add("2700");
		workUnitCodeList.add("2800");
		workUnitCodeList.add("3000");
		workUnitCodeList.add("3300");
		workUnitCodeList.add("3400");
		workUnitCodeList.add("3500");
		workUnitCodeList.add("3600");
		workUnitCodeList.add("3700");
		workUnitCodeList.add("3800");
		workUnitCodeList.add("4000");
		workUnitCodeList.add("4100");
		workUnitCodeList.add("4200");
		workUnitCodeList.add("4210");
		workUnitCodeList.add("4220");
		workUnitCodeList.add("4230");
		workUnitCodeList.add("4240");
		workUnitCodeList.add("4250");
		workUnitCodeList.add("4300");
		workUnitCodeList.add("4310");
		workUnitCodeList.add("4320");
		workUnitCodeList.add("4330");
		workUnitCodeList.add("4340");
		workUnitCodeList.add("4350");
		workUnitCodeList.add("4360");
		workUnitCodeList.add("4370");
		workUnitCodeList.add("4380");
		workUnitCodeList.add("4390");
		workUnitCodeList.add("4400");
		workUnitCodeList.add("4600");
		workUnitCodeList.add("4610");
		workUnitCodeList.add("4620");
		workUnitCodeList.add("4630");
		workUnitCodeList.add("4650");
		workUnitCodeList.add("4700");
		workUnitCodeList.add("4800");
		workUnitCodeList.add("4811");
		workUnitCodeList.add("4812");
		workUnitCodeList.add("4813");
		workUnitCodeList.add("4814");
		workUnitCodeList.add("4815");
		workUnitCodeList.add("4816");
		workUnitCodeList.add("4817");
		workUnitCodeList.add("4820");
		workUnitCodeList.add("4822");
		workUnitCodeList.add("4823");
		workUnitCodeList.add("4824");
		workUnitCodeList.add("4825");
		workUnitCodeList.add("4830");
		workUnitCodeList.add("4832");
		workUnitCodeList.add("4833");
		workUnitCodeList.add("4834");
		workUnitCodeList.add("4835");
		workUnitCodeList.add("4900");
		workUnitCodeList.add("4901");
		workUnitCodeList.add("4910");
		workUnitCodeList.add("4920");
		workUnitCodeList.add("4930");
		workUnitCodeList.add("4935");
		workUnitCodeList.add("4936");
		workUnitCodeList.add("4940");
		workUnitCodeList.add("4950");
		workUnitCodeList.add("5000");
		workUnitCodeList.add("5100");
		workUnitCodeList.add("5200");
		workUnitCodeList.add("6000");
		workUnitCodeList.add("6200");
		workUnitCodeList.add("6300");
		workUnitCodeList.add("6400");
		workUnitCodeList.add("7000");
		workUnitCodeList.add("8140");
		workUnitCodeList.add("8200");
	}
	
}
