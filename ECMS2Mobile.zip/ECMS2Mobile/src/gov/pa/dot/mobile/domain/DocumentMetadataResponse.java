/**
 * 
 */
package gov.pa.dot.mobile.domain;

import java.util.List;

/**
 * @author c-sangulur
 *
 */
public class DocumentMetadataResponse extends BaseDomain 
{

	List<Document> ecmsDocuments;

	public List<Document> getEcmsDocuments() 
	{
		return ecmsDocuments;
	}

	public void setEcmsDocuments(List<Document> ecmsDocuments) 
	{
		this.ecmsDocuments = ecmsDocuments;
	}

}
