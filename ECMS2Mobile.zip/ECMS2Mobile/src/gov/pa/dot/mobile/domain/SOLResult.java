/**
 * 
 */
package gov.pa.dot.mobile.domain;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author c-stumugan
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class SOLResult
{
	private String letterNum;
	private String solAbstract;
	private String solSignature;	
	private String solIssueDate;
	private String solSubject;
	private String solOriginator;
	private String orgCode;
	private String formattedLetterNumber;
	private String solCurrentStatusInd;
	private String orgCodeDesc;
	private String solCurrentStatusDesc;
	private String solSignatureDesc;
	List<Document> documentsList;
	/**
	 * @return the letterNum
	 */
	public String getLetterNum()
	{
		return letterNum;
	}
	/**
	 * @param letterNum the letterNum to set
	 */
	public void setLetterNum(String letterNum)
	{
		this.letterNum = letterNum;
	}
	/**
	 * @return the solAbstract
	 */
	public String getSolAbstract()
	{
		return solAbstract;
	}
	/**
	 * @param solAbstract the solAbstract to set
	 */
	public void setSolAbstract(String solAbstract)
	{
		this.solAbstract = solAbstract;
	}
	/**
	 * @return the solSignature
	 */
	public String getSolSignature()
	{
		return solSignature;
	}
	/**
	 * @param solSignature the solSignature to set
	 */
	public void setSolSignature(String solSignature)
	{
		this.solSignature = solSignature;
	}
	/**
	 * @return the solIssueDate
	 */
	public String getSolIssueDate()
	{
		return solIssueDate;
	}
	/**
	 * @param solIssueDate the solIssueDate to set
	 */
	public void setSolIssueDate(String solIssueDate)
	{
		this.solIssueDate = solIssueDate;
	}
	/**
	 * @return the solSubject
	 */
	public String getSolSubject()
	{
		return solSubject;
	}
	/**
	 * @param solSubject the solSubject to set
	 */
	public void setSolSubject(String solSubject)
	{
		this.solSubject = solSubject;
	}
	/**
	 * @return the solOriginator
	 */
	public String getSolOriginator()
	{
		return solOriginator;
	}
	/**
	 * @param solOriginator the solOriginator to set
	 */
	public void setSolOriginator(String solOriginator)
	{
		this.solOriginator = solOriginator;
	}
	/**
	 * @return the orgCode
	 */
	public String getOrgCode()
	{
		return orgCode;
	}
	/**
	 * @param orgCode the orgCode to set
	 */
	public void setOrgCode(String orgCode)
	{
		this.orgCode = orgCode;
	}
	/**
	 * @return the formattedLetterNumber
	 */
	public String getFormattedLetterNumber()
	{
		return formattedLetterNumber;
	}
	/**
	 * @param formattedLetterNumber the formattedLetterNumber to set
	 */
	public void setFormattedLetterNumber(String formattedLetterNumber)
	{
		this.formattedLetterNumber = formattedLetterNumber;
	}
	/**
	 * @return the solCurrentStatusInd
	 */
	public String getSolCurrentStatusInd()
	{
		return solCurrentStatusInd;
	}
	/**
	 * @param solCurrentStatusInd the solCurrentStatusInd to set
	 */
	public void setSolCurrentStatusInd(String solCurrentStatusInd)
	{
		this.solCurrentStatusInd = solCurrentStatusInd;
	}
	/**
	 * @return the orgCodeDesc
	 */
	public String getOrgCodeDesc()
	{
		return orgCodeDesc;
	}
	/**
	 * @param orgCodeDesc the orgCodeDesc to set
	 */
	public void setOrgCodeDesc(String orgCodeDesc)
	{
		this.orgCodeDesc = orgCodeDesc;
	}
	/**
	 * @return the solCurrentStatusDesc
	 */
	public String getSolCurrentStatusDesc()
	{
		return solCurrentStatusDesc;
	}
	/**
	 * @param solCurrentStatusDesc the solCurrentStatusDesc to set
	 */
	public void setSolCurrentStatusDesc(String solCurrentStatusDesc)
	{
		this.solCurrentStatusDesc = solCurrentStatusDesc;
	}
	/**
	 * @return the solSignatureDesc
	 */
	public String getSolSignatureDesc()
	{
		return solSignatureDesc;
	}
	/**
	 * @param solSignatureDesc the solSignatureDesc to set
	 */
	public void setSolSignatureDesc(String solSignatureDesc)
	{
		this.solSignatureDesc = solSignatureDesc;
	}
	/**
	 * @return the documentsList
	 */
	public List<Document> getDocumentsList()
	{
		return documentsList;
	}
	/**
	 * @param documentsList the documentsList to set
	 */
	public void setDocumentsList(List<Document> documentsList)
	{
		this.documentsList = documentsList;
	}
	
	
	
	
	
}
