/**
 * 
 */
package gov.pa.dot.mobile.domain;

/**
 * @author c-stumugan
 *
 */
public class Document
{
		private String documentTypeCode;
		private String createdBy;
		private String edmsTitleSubject;
		private String documentId;
		private String edmsDocTypeCode;
		private String edmsDocLink;
		private String edmsUrl;
		private String documentLength;
		private String documentContentType;
		private String bpId;
		private String edmsDocId;
		private String createdByTs;
		private String documentName;
		private String edmsReadyToMoveInd;
		private String edmsDocumentTitle;
		/**
		 * @return the documentTypeCode
		 */
		public String getDocumentTypeCode()
		{
			return documentTypeCode;
		}
		/**
		 * @param documentTypeCode the documentTypeCode to set
		 */
		public void setDocumentTypeCode(String documentTypeCode)
		{
			this.documentTypeCode = documentTypeCode;
		}
		
		/**
		 * @return the createdBy
		 */
		public String getCreatedBy()
		{
			return createdBy;
		}
		/**
		 * @param createdBy the createdBy to set
		 */
		public void setCreatedBy(String createdBy)
		{
			this.createdBy = createdBy.trim();
		}
		/**
		 * @return the edmsTitleSubject
		 */
		public String getEdmsTitleSubject()
		{
			return edmsTitleSubject;
		}
		/**
		 * @param edmsTitleSubject the edmsTitleSubject to set
		 */
		public void setEdmsTitleSubject(String edmsTitleSubject)
		{
			this.edmsTitleSubject = edmsTitleSubject;
		}
		/**
		 * @return the documentId
		 */
		public String getDocumentId()
		{
			return documentId;
		}
		/**
		 * @param documentId the documentId to set
		 */
		public void setDocumentId(String documentId)
		{
			this.documentId = documentId;
		}
		/**
		 * @return the edmsDocTypeCode
		 */
		public String getEdmsDocTypeCode()
		{
			return edmsDocTypeCode;
		}
		/**
		 * @param edmsDocTypeCode the edmsDocTypeCode to set
		 */
		public void setEdmsDocTypeCode(String edmsDocTypeCode)
		{
			this.edmsDocTypeCode = edmsDocTypeCode;
		}
		/**
		 * @return the edmsDocLink
		 */
		public String getEdmsDocLink()
		{
			return edmsDocLink;
		}
		/**
		 * @param edmsDocLink the edmsDocLink to set
		 */
		public void setEdmsDocLink(String edmsDocLink)
		{
			this.edmsDocLink = edmsDocLink;
		}
		/**
		 * @return the edmsUrl
		 */
		public String getEdmsUrl()
		{
			return edmsUrl;
		}
		/**
		 * @param edmsUrl the edmsUrl to set
		 */
		public void setEdmsUrl(String edmsUrl)
		{
			this.edmsUrl = edmsUrl;
		}
		/**
		 * @return the documentLength
		 */
		public String getDocumentLength()
		{
			return documentLength;
		}
		/**
		 * @param documentLength the documentLength to set
		 */
		public void setDocumentLength(String documentLength)
		{
			this.documentLength = documentLength;
		}
		/**
		 * @return the documentContentType
		 */
		public String getDocumentContentType()
		{
			return documentContentType;
		}
		/**
		 * @param documentContentType the documentContentType to set
		 */
		public void setDocumentContentType(String documentContentType)
		{
			this.documentContentType = documentContentType;
		}
		/**
		 * @return the bpId
		 */
		public String getBpId()
		{
			return bpId;
		}
		/**
		 * @param bpId the bpId to set
		 */
		public void setBpId(String bpId)
		{
			this.bpId = bpId;
		}
		/**
		 * @return the edmsDocId
		 */
		public String getEdmsDocId()
		{
			return edmsDocId;
		}
		/**
		 * @param edmsDocId the edmsDocId to set
		 */
		public void setEdmsDocId(String edmsDocId)
		{
			this.edmsDocId = edmsDocId;
		}
		/**
		 * @return the createdByTs
		 */
		public String getCreatedByTs()
		{
			return createdByTs;
		}
		/**
		 * @param createdByTs the createdByTs to set
		 */
		public void setCreatedByTs(String createdByTs)
		{
			this.createdByTs = createdByTs;
		}
		/**
		 * @return the documentName
		 */
		public String getDocumentName()
		{
			return documentName;
		}
		/**
		 * @param documentName the documentName to set
		 */
		public void setDocumentName(String documentName)
		{
			this.documentName = documentName;
		}
		/**
		 * @return the edmsReadyToMoveInd
		 */
		public String getEdmsReadyToMoveInd()
		{
			return edmsReadyToMoveInd;
		}
		/**
		 * @param edmsReadyToMoveInd the edmsReadyToMoveInd to set
		 */
		public void setEdmsReadyToMoveInd(String edmsReadyToMoveInd)
		{
			this.edmsReadyToMoveInd = edmsReadyToMoveInd;
		}
		/**
		 * @return the edmsDocumentTitle
		 */
		public String getEdmsDocumentTitle()
		{
			return edmsDocumentTitle;
		}
		/**
		 * @param edmsDocumentTitle the edmsDocumentTitle to set
		 */
		public void setEdmsDocumentTitle(String edmsDocumentTitle)
		{
			this.edmsDocumentTitle = edmsDocumentTitle;
		}
		
		
		
	
	

}
