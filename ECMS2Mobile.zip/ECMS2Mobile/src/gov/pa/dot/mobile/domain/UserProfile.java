/**
 * 
 */
package gov.pa.dot.mobile.domain;

import java.util.List;

/**
 * @author c-stumugan
 *
 */
public class UserProfile
{
 	private    Boolean 		isContractorUser;
	private    String  		busPartnerName;
	private    String  		faxExchange;
	private    String  		organization;
	private    String  		securityDominoFullName;
	private    Boolean 		isPenndotUser;
	private    String  		firstName;
	private    String  		userId;
	private    String  		lastUpdateTs;
	private    String  		displayFaxNumber;
	private    Boolean 		isTurnpikeUser;
	private    String  		changePasswordLink;
	private    String  		busPartnerFid;
	private    String  		phoneNumber;
	private    Boolean 		isFhwaUser;
	private    String  		nameSuffix;
	private    String  		firmId;
	private    String  		phoneExtension;
	private    String  		phoneExchange;
	private    Boolean 		isBondingAgencyUser;
	private    String  		faxAreaCode;
	private    Boolean 		isAnonymousUser;
	private    String  		fullName;
	private    String  		requestPenndotAccessLink;
	private    Boolean 		isMunicipalityUser;
	private    String  		emailAddress;
	private    Boolean 		isBusinessPartnerUser;
	private    String  		displayPhoneNumber;
	private    String  		lastName;
	private    String  		workUnitType;
	private    Boolean 		isDebuggerUser;
	private    String  		middleInitial;
	private    String  		dominoFullName;
	private    String  		workUnitCode;
	private    String  		sortableFullName;
	private    Boolean 		isSuretyUser;
	private    Boolean 		isConsultantUser;
	private    String  		faxNumber;
	private    String  		phoneAreaCode;
	private    String  		workUnitName;
	
	private List<UserGroup> userGroupList;
	/**
	 * @return the isContractorUser
	 */
	public Boolean getIsContractorUser()
	{
		return isContractorUser;
	}
	/**
	 * @param isContractorUser the isContractorUser to set
	 */
	public void setIsContractorUser(Boolean isContractorUser)
	{
		this.isContractorUser = isContractorUser;
	}
	/**
	 * @return the busPartnerName
	 */
	public String getBusPartnerName()
	{
		return busPartnerName;
	}
	/**
	 * @param busPartnerName the busPartnerName to set
	 */
	public void setBusPartnerName(String busPartnerName)
	{
		this.busPartnerName = busPartnerName;
	}
	/**
	 * @return the faxExchange
	 */
	public String getFaxExchange()
	{
		return faxExchange;
	}
	/**
	 * @param faxExchange the faxExchange to set
	 */
	public void setFaxExchange(String faxExchange)
	{
		this.faxExchange = faxExchange;
	}
	/**
	 * @return the organization
	 */
	public String getOrganization()
	{
		return organization;
	}
	/**
	 * @param organization the organization to set
	 */
	public void setOrganization(String organization)
	{
		this.organization = organization;
	}
	/**
	 * @return the securityDominoFullName
	 */
	public String getSecurityDominoFullName()
	{
		return securityDominoFullName;
	}
	/**
	 * @param securityDominoFullName the securityDominoFullName to set
	 */
	public void setSecurityDominoFullName(String securityDominoFullName)
	{
		this.securityDominoFullName = securityDominoFullName;
	}
	/**
	 * @return the isPenndotUser
	 */
	public Boolean getIsPenndotUser()
	{
		return isPenndotUser;
	}
	/**
	 * @param isPenndotUser the isPenndotUser to set
	 */
	public void setIsPenndotUser(Boolean isPenndotUser)
	{
		this.isPenndotUser = isPenndotUser;
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName()
	{
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}
	/**
	 * @return the userId
	 */
	public String getUserId()
	{
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId)
	{
		this.userId = userId;
	}
	/**
	 * @return the lastUpdateTs
	 */
	public String getLastUpdateTs()
	{
		return lastUpdateTs;
	}
	/**
	 * @param lastUpdateTs the lastUpdateTs to set
	 */
	public void setLastUpdateTs(String lastUpdateTs)
	{
		this.lastUpdateTs = lastUpdateTs;
	}
	/**
	 * @return the displayFaxNumber
	 */
	public String getDisplayFaxNumber()
	{
		return displayFaxNumber;
	}
	/**
	 * @param displayFaxNumber the displayFaxNumber to set
	 */
	public void setDisplayFaxNumber(String displayFaxNumber)
	{
		this.displayFaxNumber = displayFaxNumber;
	}
	/**
	 * @return the isTurnpikeUser
	 */
	public Boolean getIsTurnpikeUser()
	{
		return isTurnpikeUser;
	}
	/**
	 * @param isTurnpikeUser the isTurnpikeUser to set
	 */
	public void setIsTurnpikeUser(Boolean isTurnpikeUser)
	{
		this.isTurnpikeUser = isTurnpikeUser;
	}
	/**
	 * @return the changePasswordLink
	 */
	public String getChangePasswordLink()
	{
		return changePasswordLink;
	}
	/**
	 * @param changePasswordLink the changePasswordLink to set
	 */
	public void setChangePasswordLink(String changePasswordLink)
	{
		this.changePasswordLink = changePasswordLink;
	}
	/**
	 * @return the busPartnerFid
	 */
	public String getBusPartnerFid()
	{
		return busPartnerFid;
	}
	/**
	 * @param busPartnerFid the busPartnerFid to set
	 */
	public void setBusPartnerFid(String busPartnerFid)
	{
		this.busPartnerFid = busPartnerFid;
	}
	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber()
	{
		return phoneNumber;
	}
	/**
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber)
	{
		this.phoneNumber = phoneNumber;
	}
	/**
	 * @return the isFhwaUser
	 */
	public Boolean getIsFhwaUser()
	{
		return isFhwaUser;
	}
	/**
	 * @param isFhwaUser the isFhwaUser to set
	 */
	public void setIsFhwaUser(Boolean isFhwaUser)
	{
		this.isFhwaUser = isFhwaUser;
	}
	/**
	 * @return the nameSuffix
	 */
	public String getNameSuffix()
	{
		return nameSuffix;
	}
	/**
	 * @param nameSuffix the nameSuffix to set
	 */
	public void setNameSuffix(String nameSuffix)
	{
		this.nameSuffix = nameSuffix;
	}
	/**
	 * @return the firmId
	 */
	public String getFirmId()
	{
		return firmId;
	}
	/**
	 * @param firmId the firmId to set
	 */
	public void setFirmId(String firmId)
	{
		this.firmId = firmId;
	}
	/**
	 * @return the phoneExtension
	 */
	public String getPhoneExtension()
	{
		return phoneExtension;
	}
	/**
	 * @param phoneExtension the phoneExtension to set
	 */
	public void setPhoneExtension(String phoneExtension)
	{
		this.phoneExtension = phoneExtension;
	}
	/**
	 * @return the phoneExchange
	 */
	public String getPhoneExchange()
	{
		return phoneExchange;
	}
	/**
	 * @param phoneExchange the phoneExchange to set
	 */
	public void setPhoneExchange(String phoneExchange)
	{
		this.phoneExchange = phoneExchange;
	}
	/**
	 * @return the isBondingAgencyUser
	 */
	public Boolean getIsBondingAgencyUser()
	{
		return isBondingAgencyUser;
	}
	/**
	 * @param isBondingAgencyUser the isBondingAgencyUser to set
	 */
	public void setIsBondingAgencyUser(Boolean isBondingAgencyUser)
	{
		this.isBondingAgencyUser = isBondingAgencyUser;
	}
	/**
	 * @return the faxAreaCode
	 */
	public String getFaxAreaCode()
	{
		return faxAreaCode;
	}
	/**
	 * @param faxAreaCode the faxAreaCode to set
	 */
	public void setFaxAreaCode(String faxAreaCode)
	{
		this.faxAreaCode = faxAreaCode;
	}
	/**
	 * @return the isAnonymousUser
	 */
	public Boolean getIsAnonymousUser()
	{
		return isAnonymousUser;
	}
	/**
	 * @param isAnonymousUser the isAnonymousUser to set
	 */
	public void setIsAnonymousUser(Boolean isAnonymousUser)
	{
		this.isAnonymousUser = isAnonymousUser;
	}
	/**
	 * @return the fullName
	 */
	public String getFullName()
	{
		return fullName;
	}
	/**
	 * @param fullName the fullName to set
	 */
	public void setFullName(String fullName)
	{
		this.fullName = fullName;
	}
	/**
	 * @return the requestPenndotAccessLink
	 */
	public String getRequestPenndotAccessLink()
	{
		return requestPenndotAccessLink;
	}
	/**
	 * @param requestPenndotAccessLink the requestPenndotAccessLink to set
	 */
	public void setRequestPenndotAccessLink(String requestPenndotAccessLink)
	{
		this.requestPenndotAccessLink = requestPenndotAccessLink;
	}
	/**
	 * @return the isMunicipalityUser
	 */
	public Boolean getIsMunicipalityUser()
	{
		return isMunicipalityUser;
	}
	/**
	 * @param isMunicipalityUser the isMunicipalityUser to set
	 */
	public void setIsMunicipalityUser(Boolean isMunicipalityUser)
	{
		this.isMunicipalityUser = isMunicipalityUser;
	}
	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress()
	{
		return emailAddress;
	}
	/**
	 * @param emailAddress the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress)
	{
		this.emailAddress = emailAddress;
	}
	/**
	 * @return the isBusinessPartnerUser
	 */
	public Boolean getIsBusinessPartnerUser()
	{
		return isBusinessPartnerUser;
	}
	/**
	 * @param isBusinessPartnerUser the isBusinessPartnerUser to set
	 */
	public void setIsBusinessPartnerUser(Boolean isBusinessPartnerUser)
	{
		this.isBusinessPartnerUser = isBusinessPartnerUser;
	}
	/**
	 * @return the displayPhoneNumber
	 */
	public String getDisplayPhoneNumber()
	{
		return displayPhoneNumber;
	}
	/**
	 * @param displayPhoneNumber the displayPhoneNumber to set
	 */
	public void setDisplayPhoneNumber(String displayPhoneNumber)
	{
		this.displayPhoneNumber = displayPhoneNumber;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName()
	{
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}
	/**
	 * @return the workUnitType
	 */
	public String getWorkUnitType()
	{
		return workUnitType;
	}
	/**
	 * @param workUnitType the workUnitType to set
	 */
	public void setWorkUnitType(String workUnitType)
	{
		this.workUnitType = workUnitType;
	}
	/**
	 * @return the isDebuggerUser
	 */
	public Boolean getIsDebuggerUser()
	{
		return isDebuggerUser;
	}
	/**
	 * @param isDebuggerUser the isDebuggerUser to set
	 */
	public void setIsDebuggerUser(Boolean isDebuggerUser)
	{
		this.isDebuggerUser = isDebuggerUser;
	}
	/**
	 * @return the middleInitial
	 */
	public String getMiddleInitial()
	{
		return middleInitial;
	}
	/**
	 * @param middleInitial the middleInitial to set
	 */
	public void setMiddleInitial(String middleInitial)
	{
		this.middleInitial = middleInitial;
	}
	/**
	 * @return the dominoFullName
	 */
	public String getDominoFullName()
	{
		return dominoFullName;
	}
	/**
	 * @param dominoFullName the dominoFullName to set
	 */
	public void setDominoFullName(String dominoFullName)
	{
		this.dominoFullName = dominoFullName;
	}
	/**
	 * @return the workUnitCode
	 */
	public String getWorkUnitCode()
	{
		return workUnitCode;
	}
	/**
	 * @param workUnitCode the workUnitCode to set
	 */
	public void setWorkUnitCode(String workUnitCode)
	{
		this.workUnitCode = workUnitCode;
	}
	/**
	 * @return the sortableFullName
	 */
	public String getSortableFullName()
	{
		return sortableFullName;
	}
	/**
	 * @param sortableFullName the sortableFullName to set
	 */
	public void setSortableFullName(String sortableFullName)
	{
		this.sortableFullName = sortableFullName;
	}
	/**
	 * @return the isSuretyUser
	 */
	public Boolean getIsSuretyUser()
	{
		return isSuretyUser;
	}
	/**
	 * @param isSuretyUser the isSuretyUser to set
	 */
	public void setIsSuretyUser(Boolean isSuretyUser)
	{
		this.isSuretyUser = isSuretyUser;
	}
	/**
	 * @return the isConsultantUser
	 */
	public Boolean getIsConsultantUser()
	{
		return isConsultantUser;
	}
	/**
	 * @param isConsultantUser the isConsultantUser to set
	 */
	public void setIsConsultantUser(Boolean isConsultantUser)
	{
		this.isConsultantUser = isConsultantUser;
	}
	/**
	 * @return the faxNumber
	 */
	public String getFaxNumber()
	{
		return faxNumber;
	}
	/**
	 * @param faxNumber the faxNumber to set
	 */
	public void setFaxNumber(String faxNumber)
	{
		this.faxNumber = faxNumber;
	}
	/**
	 * @return the phoneAreaCode
	 */
	public String getPhoneAreaCode()
	{
		return phoneAreaCode;
	}
	/**
	 * @param phoneAreaCode the phoneAreaCode to set
	 */
	public void setPhoneAreaCode(String phoneAreaCode)
	{
		this.phoneAreaCode = phoneAreaCode;
	}
	/**
	 * @return the workUnitName
	 */
	public String getWorkUnitName()
	{
		return workUnitName;
	}
	/**
	 * @param workUnitName the workUnitName to set
	 */
	public void setWorkUnitName(String workUnitName)
	{
		this.workUnitName = workUnitName;
	}
	/**
	 * @return the userGroupList
	 */
	public List<UserGroup> getUserGroupList()
	{
		return userGroupList;
	}
	/**
	 * @param userGroupList the userGroupList to set
	 */
	public void setUserGroupList(List<UserGroup> userGroupList)
	{
		this.userGroupList = userGroupList;
	}
	
}
