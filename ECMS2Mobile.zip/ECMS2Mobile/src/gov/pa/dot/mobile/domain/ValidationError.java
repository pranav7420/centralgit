/**
 * 
 */
package gov.pa.dot.mobile.domain;

/**
 * @author c-stumugan
 * 
 */
public class ValidationError
{
	String objectId;
	String attributeName;
	String errorMessage;
	String additionalInfo;

	/**
	 * @return the objectId
	 */
	public String getObjectId()
	{
		return objectId;
	}

	/**
	 * @param objectId
	 *            the objectId to set
	 */
	public void setObjectId(String objectId)
	{
		this.objectId = objectId;
	}

	/**
	 * @return the attributeName
	 */
	public String getAttributeName()
	{
		return attributeName;
	}

	/**
	 * @param attributeName
	 *            the attributeName to set
	 */
	public void setAttributeName(String attributeName)
	{
		this.attributeName = attributeName;
	}

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage()
	{
		return errorMessage;
	}

	/**
	 * @param errorMessage
	 *            the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage)
	{
		this.errorMessage = errorMessage;
	}

	/**
	 * @return the additionalInfo
	 */
	public String getAdditionalInfo()
	{
		return additionalInfo;
	}

	/**
	 * @param additionalInfo
	 *            the additionalInfo to set
	 */
	public void setAdditionalInfo(String additionalInfo)
	{
		this.additionalInfo = additionalInfo;
	}

}
