/**
 * 
 */
package gov.pa.dot.mobile.domain;

import java.util.List;

/**
 * @author c-stumugan
 * 
 */
public class PDCcheckList
{

	private String createdBy;
	private String createdTs;
	private String lastModifiedBy;
	private String lastModifiedTs;
	private Integer fileCount = 0;
	private String clLineNum;
	private String clItemSecDesc;
	private String clItemName;
	private String deleteInd;
	private String addendumPendInd;
	private String bidPkgInd;
	private String clItemComplInd;
	private String origContInd;
	private String ecmsProjNum;
	private String PdcBodCat;
	private String addendumNum;
	List<Document> pdcDocumentList;
	/**
	 * @return the createdBy
	 */
	public String getCreatedBy()
	{
		return createdBy;
	}
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy)
	{
		this.createdBy = createdBy.trim();
	}
	/**
	 * @return the createdTs
	 */
	public String getCreatedTs()
	{
		return createdTs;
	}
	/**
	 * @param createdTs the createdTs to set
	 */
	public void setCreatedTs(String createdTs)
	{
		this.createdTs = createdTs;
	}
	/**
	 * @return the lastModifiedBy
	 */
	public String getLastModifiedBy()
	{
		return lastModifiedBy;
	}
	/**
	 * @param lastModifiedBy the lastModifiedBy to set
	 */
	public void setLastModifiedBy(String lastModifiedBy)
	{
		this.lastModifiedBy = lastModifiedBy.trim();
	}
	/**
	 * @return the lastModifiedTs
	 */
	public String getLastModifiedTs()
	{
		return lastModifiedTs;
	}
	/**
	 * @param lastModifiedTs the lastModifiedTs to set
	 */
	public void setLastModifiedTs(String lastModifiedTs)
	{
		this.lastModifiedTs = lastModifiedTs;
	}
	/**
	 * @return the fileCount
	 */
	public Integer getFileCount()
	{
		return fileCount;
	}
	/**
	 * @param fileCount the fileCount to set
	 */
	public void setFileCount(Integer fileCount)
	{
		this.fileCount = fileCount;
	}
	/**
	 * @return the clLineNum
	 */
	public String getClLineNum()
	{
		return clLineNum;
	}
	/**
	 * @param clLineNum the clLineNum to set
	 */
	public void setClLineNum(String clLineNum)
	{
		this.clLineNum = clLineNum;
	}
	/**
	 * @return the clItemSecDesc
	 */
	public String getClItemSecDesc()
	{
		return clItemSecDesc;
	}
	/**
	 * @param clItemSecDesc the clItemSecDesc to set
	 */
	public void setClItemSecDesc(String clItemSecDesc)
	{
		this.clItemSecDesc = clItemSecDesc;
	}
	/**
	 * @return the clItemName
	 */
	public String getClItemName()
	{
		return clItemName;
	}
	/**
	 * @param clItemName the clItemName to set
	 */
	public void setClItemName(String clItemName)
	{
		this.clItemName = clItemName;
	}
	/**
	 * @return the deleteInd
	 */
	public String getDeleteInd()
	{
		return deleteInd;
	}
	/**
	 * @param deleteInd the deleteInd to set
	 */
	public void setDeleteInd(String deleteInd)
	{
		this.deleteInd = deleteInd;
	}
	/**
	 * @return the addendumPendInd
	 */
	public String getAddendumPendInd()
	{
		return addendumPendInd;
	}
	/**
	 * @param addendumPendInd the addendumPendInd to set
	 */
	public void setAddendumPendInd(String addendumPendInd)
	{
		this.addendumPendInd = addendumPendInd;
	}
	/**
	 * @return the bidPkgInd
	 */
	public String getBidPkgInd()
	{
		return bidPkgInd;
	}
	/**
	 * @param bidPkgInd the bidPkgInd to set
	 */
	public void setBidPkgInd(String bidPkgInd)
	{
		this.bidPkgInd = bidPkgInd;
	}
	/**
	 * @return the clItemComplInd
	 */
	public String getClItemComplInd()
	{
		return clItemComplInd;
	}
	/**
	 * @param clItemComplInd the clItemComplInd to set
	 */
	public void setClItemComplInd(String clItemComplInd)
	{
		this.clItemComplInd = clItemComplInd;
	}
	/**
	 * @return the origContInd
	 */
	public String getOrigContInd()
	{
		return origContInd;
	}
	/**
	 * @param origContInd the origContInd to set
	 */
	public void setOrigContInd(String origContInd)
	{
		this.origContInd = origContInd;
	}
	/**
	 * @return the ecmsProjNum
	 */
	public String getEcmsProjNum()
	{
		return ecmsProjNum;
	}
	/**
	 * @param ecmsProjNum the ecmsProjNum to set
	 */
	public void setEcmsProjNum(String ecmsProjNum)
	{
		this.ecmsProjNum = ecmsProjNum;
	}
	/**
	 * @return the pdcBodCat
	 */
	public String getPdcBodCat()
	{
		return PdcBodCat;
	}
	/**
	 * @param pdcBodCat the pdcBodCat to set
	 */
	public void setPdcBodCat(String pdcBodCat)
	{
		PdcBodCat = pdcBodCat;
	}
	/**
	 * @return the addendumNum
	 */
	public String getAddendumNum()
	{
		return addendumNum;
	}
	/**
	 * @param addendumNum the addendumNum to set
	 */
	public void setAddendumNum(String addendumNum)
	{
		this.addendumNum = addendumNum;
	}
	/**
	 * @return the pdcDocumentList
	 */
	public List<Document> getPdcDocumentList()
	{
		return pdcDocumentList;
	}
	/**
	 * @param pdcDocumentList the pdcDocumentList to set
	 */
	public void setPdcDocumentList(List<Document> pdcDocumentList)
	{
		this.pdcDocumentList = pdcDocumentList;
	}
	
	
}
