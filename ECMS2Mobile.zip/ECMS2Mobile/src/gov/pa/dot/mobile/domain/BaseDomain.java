/**
 * 
 */
package gov.pa.dot.mobile.domain;

import java.util.List;

import gov.pa.dot.mobile.utilities.ECMSConstants;
import gov.pa.dot.mobile.utilities.MessageCodeEnum;

public class BaseDomain
{

	String statusCode = ECMSConstants.CODE_SUCCESS;
	String statusMessage = MessageCodeEnum.SUCCESS.getMessage();
	Integer messageCode = MessageCodeEnum.SUCCESS.getCode();
	String errorType;
	String developerMessage;

	List<ValidationError> validationErrors;

	/**
	 * @return the statusCode
	 */
	public String getStatusCode()
	{
		return statusCode;
	}

	/**
	 * @param statusCode
	 *            the statusCode to set
	 */
	public void setStatusCode(String statusCode)
	{
		this.statusCode = statusCode;
	}

	/**
	 * @return the statusMessage
	 */
	public String getStatusMessage()
	{
		return statusMessage;
	}

	/**
	 * @param statusMessage
	 *            the statusMessage to set
	 */
	public void setStatusMessage(String statusMessage)
	{
		this.statusMessage = statusMessage;
	}

	/**
	 * @return the messageCode
	 */
	public Integer getMessageCode()
	{
		return messageCode;
	}

	/**
	 * @param messageCode
	 *            the messageCode to set
	 */
	public void setMessageCode(Integer messageCode)
	{
		this.messageCode = messageCode;
	}

	/**
	 * @return the errorType
	 */
	public String getErrorType()
	{
		return errorType;
	}

	/**
	 * @param errorType
	 *            the errorType to set
	 */
	public void setErrorType(String errorType)
	{
		this.errorType = errorType;
	}

	/**
	 * @return the developerMessage
	 */
	public String getDeveloperMessage()
	{
		return developerMessage;
	}

	/**
	 * @param developerMessage
	 *            the developerMessage to set
	 */
	public void setDeveloperMessage(String developerMessage)
	{
		this.developerMessage = developerMessage;
	}

	/**
	 * @return the validationErrors
	 */
	public List<ValidationError> getValidationErrors()
	{
		return validationErrors;
	}

	/**
	 * @param validationErrors
	 *            the validationErrors to set
	 */
	public void setValidationErrors(List<ValidationError> validationErrors)
	{
		this.validationErrors = validationErrors;
	}

}
