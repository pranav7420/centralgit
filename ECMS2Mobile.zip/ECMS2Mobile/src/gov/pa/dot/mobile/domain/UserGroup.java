/**
 * 
 */
package gov.pa.dot.mobile.domain;

/**
 * @author c-stumugan
 *
 */
public class UserGroup
{
	private String groupName;
	private String genericGroupName;
	/**
	 * @return the groupName
	 */
	public String getGroupName()
	{
		return groupName;
	}
	/**
	 * @param groupName the groupName to set
	 */
	public void setGroupName(String groupName)
	{
		this.groupName = groupName;
	}
	/**
	 * @return the genericGroupName
	 */
	public String getGenericGroupName()
	{
		return genericGroupName;
	}
	/**
	 * @param genericGroupName the genericGroupName to set
	 */
	public void setGenericGroupName(String genericGroupName)
	{
		this.genericGroupName = genericGroupName;
	}

	
}
