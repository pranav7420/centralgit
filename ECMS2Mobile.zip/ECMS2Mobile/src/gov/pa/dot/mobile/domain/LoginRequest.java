/**
 * 
 */
package gov.pa.dot.mobile.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author c-stumugan
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class LoginRequest
{

	private String userId;
	private String password;
	/**
	 * @return the userId
	 */
	public String getUserId()
	{
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId)
	{
		this.userId = userId;
	}
	/**
	 * @return the password
	 */
	public String getPassword()
	{
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password)
	{
		this.password = password;
	}
	
	
}
