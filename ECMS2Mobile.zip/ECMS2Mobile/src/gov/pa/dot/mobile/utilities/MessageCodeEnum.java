/**
 * 
 */
package gov.pa.dot.mobile.utilities;

/**
 * @author c-sangulur, c-stumugan
 * 
 */
public enum MessageCodeEnum
{

	SUCCESS(200, "Success"),
	VALIDATIONS(400, "Error(s) Occurred During Validation"),
	LIST_EMPTY(701, "List is Empty"),

	ERROR(500, "Error Occurred In Processing Request"),
	GEN_CODE_MAPPER_EXCEPTION(521, "General code mapping exception failure"),

	ECMS_LOGIN_FAILURE(522, "ECMS authentication Failed, Please Check your username and password and try again."),
	ECMS_PD_CONFIGURATION_FAILURE(523, "PD Configuration exception occured"),
	ECMS_HA_USER_FAILURE(620, "There is an issue when validating your ECMS account.  Please contact the ECMS Help Desk for assistance."),
	ECMS_USER_OBJECTS_MAPPRING_FAILURE(525, "Mapping ecms user objects to mobile domain objects failed "),

	LOGGED_OUT(450, "Session Timeout"),
	
	 INVALID_USER_ID(2, "Encountered an issue while validating your Account in ECMS. Please Visit ECMS and verify your Login."),
	 PASSWORD_RESET_INDICATOR(6, "Your ECMS Account password was reset by a Security Administrator. Please Visit ECMS and verify your Login."),
	 INACTIVE_USER (5, "Your ECMS Account has not been active for a while. Please Visit ECMS and verify your Login."),
	 PASSWORD_EXPIRED (4, "Your ECMS Account Password has expired. Please Visit ECMS and verify your Login."),
	 MULTIPLE_FAILED_ATTEMPTS (3, "Your ECMS Account Password has expired. Please Visit ECMS and verify your Login.");

	Integer code;
	String message;

	/**
	 * @param code
	 * @param message
	 */
	private MessageCodeEnum(Integer code, String message)
	{
		this.code = code;
		this.message = message;
	}

	public Integer getCode()
	{
		return code;
	}

	public String getMessage()
	{
		return message;
	}

	/**
	 * @param code
	 * @return
	 */
	public static MessageCodeEnum getByCode(Integer code)
	{
		for (MessageCodeEnum e : values())
		{
			if (e.code.equals(code))
				return e;
		}

		return ERROR;
	}

	/**
	 * @param value
	 * @return
	 */
	public static MessageCodeEnum getByValue(String value)
	{
		for (MessageCodeEnum e : values())
		{
			if (e.message.equals(value))
				return e;
		}

		return null;
	}

}
