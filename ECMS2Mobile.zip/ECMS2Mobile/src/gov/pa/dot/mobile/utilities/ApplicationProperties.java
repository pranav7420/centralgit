package gov.pa.dot.mobile.utilities;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import gov.pa.dot.mobile.persistence.GenCodeMapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ApplicationProperties
{
	public static final Logger logger = LoggerFactory.getLogger(ApplicationProperties.class);

	@Autowired
	GenCodeMapper genCodeMappers;

	private String projStatusCodes;
	
	private String allProjectsQuery;
	
	private String teamMemberListQuery;
	
	private String districtProjectList;
	
	private String userLoginValue;
	
	private String orgCodes;
	


	/**
	 * @return the projStatusCodes
	 */
	public String getProjStatusCodes()
	{
		return projStatusCodes;
	}

	/**
	 * @param projStatusCodes the projStatusCodes to set
	 */
	public void setProjStatusCodes(String projStatusCodes)
	{
		this.projStatusCodes = projStatusCodes;
	}

	/**
	 * @return the allProjectsQuery
	 */
	public String getAllProjectsQuery()
	{
		return allProjectsQuery;
	}

	/**
	 * @param allProjectsQuery the allProjectsQuery to set
	 */
	public void setAllProjectsQuery(String allProjectsQuery)
	{
		this.allProjectsQuery = allProjectsQuery;
	}

	/**
	 * @return the teamMemberListQuery
	 */
	public String getTeamMemberListQuery()
	{
		return teamMemberListQuery;
	}

	/**
	 * @param teamMemberListQuery the teamMemberListQuery to set
	 */
	public void setTeamMemberListQuery(String teamMemberListQuery)
	{
		this.teamMemberListQuery = teamMemberListQuery;
	}

	/**
	 * @return the districtProjectList
	 */
	public String getDistrictProjectList()
	{
		return districtProjectList;
	}

	/**
	 * @param districtProjectList the districtProjectList to set
	 */
	public void setDistrictProjectList(String districtProjectList)
	{
		this.districtProjectList = districtProjectList;
	}

	/**
	 * @return the userLoginValue
	 */
	public String getUserLoginValue()
	{
		return userLoginValue;
	}

	/**
	 * @param userLoginValue the userLoginValue to set
	 */
	public void setUserLoginValue(String userLoginValue)
	{
		this.userLoginValue = userLoginValue;
	}
	

	/**
	 * @return the orgCodes
	 */
	public String getOrgCodes()
	{
		return orgCodes;
	}

	/**
	 * @param orgCodes the orgCodes to set
	 */
	public void setOrgCodes(String orgCodes)
	{
		this.orgCodes = orgCodes;
	}

	@PostConstruct
	public void init()
	{
		loadValues();
	}

	protected void loadValues()
	{
		this.projStatusCodes = getPropValue(ECMSConstants.GC_CODE_PROJECT_STATUS_CODES);
		this.allProjectsQuery=getPropValue(ECMSConstants.GC_CODE_GET_ALL_PROJECTS);
		this.districtProjectList=getPropValue(ECMSConstants.GC_CODE_GET_DISTRICT_PROJECTS);
		this.teamMemberListQuery=getPropValue(ECMSConstants.GC_CODE_GET_TEAM_MEMBER_PROJECTS);
		this.userLoginValue=getPropValue(ECMSConstants.GC_CODE_USER_LOGIN);
		this.orgCodes= getPropValue(ECMSConstants.GC_CODE_ORG_CODES);
	}

	private String getPropValue(String code)
	{
		String val = "";

		try
		{
			val = genCodeMappers.getGeneralCodeValue(ECMSConstants.SOURCE_APP, ECMSConstants.GC_CODE_TYPE, code);
		}
		catch (Exception e)
		{
			logger.error("Unable to get property value from DB: " + code + "--", e);
		}

		return val;
	}

	public Map<String, String> getApplicationProperties()
	{
		Map<String, String> propertiesMap = new HashMap<String, String>();

		for (Field field : this.getClass().getDeclaredFields())
		{

			for (Method method : this.getClass().getMethods())
			{
				if ((method.getName().startsWith("get")) && (method.getName().length() == (field.getName().length() + 3)) && method.getName().toLowerCase().endsWith(field.getName().toLowerCase()))
				{
					// MZ: Method found, run it
					try
					{
						propertiesMap.put(field.getName(), String.valueOf(method.invoke(this)));
					}
					catch (Exception e)
					{
						//Skipping this entry
					}
				}
			}
		}

		return propertiesMap;
	}

}
