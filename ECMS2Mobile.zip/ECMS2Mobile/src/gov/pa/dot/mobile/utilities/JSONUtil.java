
package gov.pa.dot.mobile.utilities;

import org.codehaus.jackson.map.ObjectMapper;


public class JSONUtil {
	
	public static String getJsonString(Object object) {
		
		ObjectMapper mapper = new ObjectMapper();
		
		String result = "";
		
		try {
			
			result = mapper.writeValueAsString(object);
	 
		} catch (Exception e) {
			result = "";
		} 
		return result;
	}
}
