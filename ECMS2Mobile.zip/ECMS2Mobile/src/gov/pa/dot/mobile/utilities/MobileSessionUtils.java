/**
 * 
 */
package gov.pa.dot.mobile.utilities;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.ServletContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import us.pa.state.dot.ecms.business.BOCOMBusinessFunction;
import us.pa.state.dot.ecms.business.BOCOMUser;
import us.pa.state.dot.ecms.dataobject.DOCOMUser;
import us.pa.state.dot.ecms.dataobject.DOCOMUserGroupList;
import us.pa.state.dot.ecms.exception.ECMSUserLogonException;
import us.pa.state.dot.framework.environment.PDWebServiceEnvironment;
import us.pa.state.dot.framework.exception.PDConfigException;

/**
 * @author c-stumugan
 * 
 */
public class MobileSessionUtils
{
	public static Logger logger = LoggerFactory.getLogger(MobileSessionUtils.class);
	public static Map<String, DOCOMUser> USER_MOBILE_SESSION_DOUSER = new ConcurrentHashMap<>();
	public static Map<String, DOCOMUserGroupList> USER_MOBILE_SESSION_USER_LIST = new ConcurrentHashMap<>();
	public static BOCOMBusinessFunction BOCOM_BUSINESS_FUNCTION_ALL = null;
	public static BOCOMBusinessFunction BOCOM_BUSINESS_FUNCTION_CONTRACTOR = null;
	public static final String USER_LOGGED_IN = "USER_LOGGED_IN";
	public static final String MESSAGE = "MESSAGE";

	public static PDWebServiceEnvironment getPDEnvironment(String userID, ServletContext context)

	{
		long startTime = System.currentTimeMillis();
		PDWebServiceEnvironment pdWSEnv = null;

		DOCOMUser docomUser = USER_MOBILE_SESSION_DOUSER.get(userID);

		if (docomUser != null)
		{
			logger.debug("User Already in the Session", userID);
			try
			{
				pdWSEnv = new PDWebServiceEnvironment(context);
				DOCOMUser user = USER_MOBILE_SESSION_DOUSER.get(userID);
				pdWSEnv.savePersistentObject("DOCOMUser", user);
				pdWSEnv.savePersistentObject("DOCOMUserGroupList", USER_MOBILE_SESSION_USER_LIST.get(userID));
				BOCOMUser boUser;
				boUser = new BOCOMUser(pdWSEnv);
				
				if (user.isContractor())
				{
					boUser.setBoCOMBusinessFunction(BOCOM_BUSINESS_FUNCTION_CONTRACTOR);
				}
				else if (user.isConsultant() || user.isPennDot())
				{
					boUser.setBoCOMBusinessFunction(BOCOM_BUSINESS_FUNCTION_ALL);
				}
				else
				{
					
					logger.debug("Different  User - "+userID);
					boUser.setBoCOMBusinessFunction(null);
				}
				pdWSEnv.setUser(boUser);
			}
			catch (Exception e)
			{
				logger.error(ECMSConstants.ERROR + userID);
				USER_MOBILE_SESSION_DOUSER.remove(userID);
				USER_MOBILE_SESSION_USER_LIST.remove(userID);
			}
			return pdWSEnv;
		}
		else
		{
			Boolean loginFlag = true;
			String message = null;
			BOCOMUser boUser = null;

			// create a new PDWebServiceEnvironment can throw a PDConfigException
			try
			{
				pdWSEnv = new PDWebServiceEnvironment(context);
				boUser = new BOCOMUser(pdWSEnv);
				// validate the user login id and password.
				// boUser.validateLogin(userID, pwd, "");
			}
			catch (ECMSUserLogonException e)
			{
				loginFlag = false;
				logger.error(ECMSConstants.ERROR + userID);
				USER_MOBILE_SESSION_DOUSER.remove(userID);
				USER_MOBILE_SESSION_USER_LIST.remove(userID);
			}
			catch (PDConfigException e)
			{
				message = "Config Error occured";
				loginFlag = false;
				logger.error(ECMSConstants.ERROR + userID + " " + message);
				USER_MOBILE_SESSION_DOUSER.remove(userID);
				USER_MOBILE_SESSION_USER_LIST.remove(userID);
			}
			catch (Exception e)
			{
				message = ECMSConstants.MSG_UNKNOWN_ERROR;
				loginFlag = false;
				logger.error(ECMSConstants.ERROR + userID + " " + message + " exception");
				USER_MOBILE_SESSION_DOUSER.remove(userID);
				USER_MOBILE_SESSION_USER_LIST.remove(userID);
			}

			if (loginFlag)
			{
				// initialize the user
				boUser.initUser(userID.toLowerCase(), pdWSEnv.getParameter("anonymous", "false"));

				// set user into the environment
				pdWSEnv.setUser(boUser);

				try
				{
					boUser.getUser(userID);
					boUser.save();
					message = ECMSConstants.MSG_AUTH_SUCC_LOGIN;
					USER_MOBILE_SESSION_DOUSER.put(userID, (DOCOMUser) pdWSEnv.getPersistentObject("DOCOMUser"));
					USER_MOBILE_SESSION_USER_LIST.put(userID,
							(DOCOMUserGroupList) pdWSEnv.getPersistentObject("DOCOMUserGroupList"));
				}
				catch (ECMSUserLogonException e)
				{
					loginFlag = false;
					logger.error(ECMSConstants.ERROR + userID);
					USER_MOBILE_SESSION_DOUSER.remove(userID);
					USER_MOBILE_SESSION_USER_LIST.remove(userID);
				}
				catch (PDConfigException e)
				{
					loginFlag = false;
					logger.error(ECMSConstants.ERROR + userID + " " + message + " config");
					USER_MOBILE_SESSION_DOUSER.remove(userID);
					USER_MOBILE_SESSION_USER_LIST.remove(userID);
				}
				catch (Exception e)
				{
					message = ECMSConstants.MSG_UNKNOWN_ERROR;
					loginFlag = false;
					logger.error(ECMSConstants.ERROR + userID + " " + message + " exception");
					USER_MOBILE_SESSION_DOUSER.remove(userID);
					USER_MOBILE_SESSION_USER_LIST.remove(userID);
				}
			}
			pdWSEnv.savePersistentObject(MobileSessionUtils.MESSAGE, message);
			pdWSEnv.savePersistentObject(MobileSessionUtils.USER_LOGGED_IN, loginFlag);
		}
		logger.debug("END_TIME--method--" + (System.currentTimeMillis() - startTime) + " ms");
		logger.debug("create user Session end ", userID);
		return pdWSEnv;
	}

	/*
	 * This method is called to get the create a session for the anonymous user
	 * 
	 */
	public static PDWebServiceEnvironment getPDEnvironment(ServletContext context)
	{

		PDWebServiceEnvironment pdWSEnv = null;
		Boolean loginFlag = true;
		String message = null;
		BOCOMUser boUser = null;

		// create a new PDWebServiceEnvironment can throw a PDConfigException
		try
		{
			pdWSEnv = new PDWebServiceEnvironment(context);
			boUser = new BOCOMUser(pdWSEnv);
		}
		catch (ECMSUserLogonException e)
		{
			loginFlag = false;
			logger.error(ECMSConstants.ERROR + " ");
		}
		catch (PDConfigException e)
		{
			loginFlag = false;
			logger.error(ECMSConstants.ERROR + " " + "Config Error occured");
		}
		catch (Exception e)
		{
			loginFlag = false;
			logger.error(ECMSConstants.ERROR + " " + ECMSConstants.MSG_UNKNOWN_ERROR + " exception");
		}

		if (loginFlag)
		{
			// initialize the user
			boUser.initUser(null, "true");
			// set user into the environment
			pdWSEnv.setUser(boUser);

			message = ECMSConstants.MSG_AUTH_SUCC_LOGIN;
		}
		pdWSEnv.savePersistentObject(MobileSessionUtils.MESSAGE, message);
		pdWSEnv.savePersistentObject(MobileSessionUtils.USER_LOGGED_IN, loginFlag);
		return pdWSEnv;
	}

}
