/**
 * 
 */
package gov.pa.dot.mobile.utilities;

import static org.springframework.util.StringUtils.isEmpty;
import gov.pa.dot.mobile.domain.BaseDomain;
import gov.pa.dot.mobile.domain.ValidationError;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.DatatypeConverter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;

/**
 * @author c-stumugan
 * 
 */
public class AppUtil
{

	public static final Logger logger = LoggerFactory.getLogger(AppUtil.class);

	private AppUtil()
	{
		throw new AssertionError();
	}

	/**
	 * @param t
	 * @return
	 */
	public static String getRootExceptionMessage(Throwable t)
	{
		Throwable result = t;

		String exceptionMessage;

		while (result.getCause() != null)
		{
			result = result.getCause();
		}

		if (!StringUtils.isEmpty(result.getMessage()))
		{
			exceptionMessage = result.toString();
		}
		else
		{
			exceptionMessage = result.getCause() + " - Stacktrace: " + result.toString();
		}

		return exceptionMessage;
	}

	/**
	 * @param domain
	 * @param messagecode
	 * @param developerMessage
	 */
	public static void setErrorMessageToResponse(BaseDomain domain, MessageCodeEnum messagecode, String developerMessage)
	{
		domain.setStatusCode(ECMSConstants.CODE_FAILURE);

		domain.setMessageCode(messagecode.getCode());
		domain.setStatusMessage(messagecode.getMessage());

		if (!isEmpty(developerMessage))
		{
			domain.setDeveloperMessage(developerMessage);
		}
		else
		{
			domain.setDeveloperMessage(messagecode.getMessage());
		}
	}

	/**
	 * @param authorization
	 * @return
	 */
	public static String getUserId(String authorization)
	{
		String userID = "";

		byte[] authBytes = DatatypeConverter.parseBase64Binary(authorization.substring(6));
		String auth = new String(authBytes);

		if (auth.length() > 0)
		{
			userID = auth.substring(0, auth.indexOf(':'));
			logger.debug("userId---->" + userID);
		}

		return userID;
	}

	/**
	 * @param authorization
	 * @return
	 */
	public static String getPassword(String authorization)
	{

		String password = "";
		byte[] authBytes = DatatypeConverter.parseBase64Binary(authorization.substring(6));
		String auth = new String(authBytes);
		if (auth.length() > 0)
		{
			password = auth.substring(auth.indexOf(':') + 1, auth.length());
		}
		return password;
	}

	public static List<ValidationError> buildValidationErrorObject(List<ObjectError> errors)
	{
		List<ValidationError> errorList = new ArrayList<ValidationError>();

		for (ObjectError objectError : errors)
		{
			FieldError fieldError = (FieldError) objectError;

			ValidationError validationError = new ValidationError();

			validationError.setAttributeName(fieldError.getField());
			validationError.setErrorMessage(fieldError.getDefaultMessage());
			validationError.setAdditionalInfo(objectError.toString());

			errorList.add(validationError);
		}
		return errorList;
	}
}
