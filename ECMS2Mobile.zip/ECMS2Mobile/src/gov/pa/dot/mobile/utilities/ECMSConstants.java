/**
 * 
 */
package gov.pa.dot.mobile.utilities;

/**
 * @author c-stumugan
 * This interface contains all constants for the  Mobile Applications
 * 
 */
public interface ECMSConstants {

	public static final  String SCHEMA_NAME = "MOBLXADM";
	public static final  String SOURCE_APP = "ECMSM";
	public static final  String ERROR="ERROR :";
	public static final  String MSGLOG="MESSAGE :";
	public static final  String USERID="userId";
	public static final  String ECMSAUTHORIZATION="ECMSAuthorization";
	public static final  String REQRESlOG="reqresLogger";
	
	public static final  String GC_CODE_TYPE = "SYS";
	public static final  String GC_CODE_PROJECT_STATUS_CODES = "EMPSC";
	public static final  String GC_CODE_USER_LOGIN = "GVUSR";
	public static final  String GC_CODE_GET_ALL_PROJECTS = "GAPRO";
	public static final  String GC_CODE_GET_DISTRICT_PROJECTS = "GDPRO";
	public static final  String GC_CODE_GET_TEAM_MEMBER_PROJECTS = "GTPRO";
	public static final  String GC_CODE_ORG_CODES = "ORCDS";
	

	public static final  String CODE_DATEFORMAT = "yyyy-MM-dd";
	public static final  String CODE_TIMEZONE = "EST";
	public static final  String ACTIVE_IND = "Y";
	public static final  String INACTIVE_IND="N";
	public static final  String FORMATSTRING="#";
	public static final String CONTENT_TYPE="Content-Type";


	

	//COMMON FOR ALL SERVICES
	public static final  String MSG_LOGIN_DB_CONNECTION_ERR = "Database connection error. Please try later. If the problem persists contact PennDOT helpdesk";
	public static final  String MSG_LOGIN_UNK_ERROR = "Unknown error. Contact PennDOT helpdesk";

	public static final  String CODE_SUCCESSFUL = "200";
	public static final  String CODE_LOGIN_DB_CONNECTION_ERR = "298";

	public static final  String MSG_UNKNOWN_ERROR = "Unknown Error Occured";
	public static final  String CODE_UNKNOWN_ERROR = "299";
	
	


	public static final  String MSG_LOGIN_SUCCESSFUL = "Authentication Success.";
	public static final  String MSG_LOGIN_FAILED = "Authentication Failed.";
	
	public static final  String CODE_NO_RECORDS="908";
	public static final  String CODE_RETRIEVE_INS_LOG_STATUS_SUCCESS="909";
	public static final  String CODE_RETRIEVE_INS_LOG_STATUS_FAIL="910";
	public static final  String CODE_INVALID_CHARACTERS="911";
	public static final  String CODE_VALIDATION_ERROR = "912";
	public static final  String CODE_DATA_NOT_AVAILABLE = "913";
	public static final  String CODE_MSG_COMMIT_FAILED = "914";

	public static final  String MSG_VALIDATION_ERROR = "Validation Error";
	public static final  String MSG_AUTH_FAIL_LOGIN = "Login Failed";
	public static final  String MSG_RETRIEVAL_SUCCESS = "Retrieval Success";
	public static final  String MSG_RETRIEVAL_FAILED = "Retrieve from Database failed,Please try again";
	public static final  String MSG_SUCCESSFUL_SAVED = "Succesfully Saved";
	public static final  String MSG_FAILED_TO_SAVE = "Insertion failed";
	public static final  String MSG_SEARCH_FAILED = "Search failed";
	public static final  String REQUEST_IS_NULL = "Request is empty";
	public static final  String LIST_IS_NULL = " Record is empty";
	public static final  String MSG_AUTH_SUCC_LOGIN = "Successful Login";


	public static final int STATUS_FAILURE = 0;
	public static final int STATUS_SUCCESS = 1;
	public static final String CODE_SUCCESS = "Y";
	public static final String CODE_FAILURE = "N";
	public static final String CODE_OPTIMISED = "1";

	public static final String MSG_CODE_RESPONSE_GENERAL_SUCCESS = "0001";
	public static final String MSG_DESC_RESPONSE_GENERAL_SUCCESS = "Success";

	public static final String MSG_CODE_RESPONSE_GENERAL_FAILURE = "0000";
	public static final String MSG_DESC_RESPONSE_GENERAL_FAILURE = "Failure";

	public static final String MSG_CODE_REQUEST_FAILURE_GENERIC = "0006";
	public static final String MSG_DESC_REQUEST_FAILURE_GENERIC = "Error in processing the request";

	public static final String MSG_DESC_RESPONSE_ECMS_LOGIN_FAILURE = "ECMS authentication Falied, Please Check your username and password and try again.";
	
	//DOCS
	
	public static final String PDC_VIEW_CURRENT = "C";
	public static final String PDC_VIEW_ORIGINAL = "O";
	public static final String PDC_VIEW_CONTRACT = "K";
	public static final String VERSION_ID = "C";
	public static final String DOCOMUSER ="DOCOMUser";
	public static final String DOCOMUSERGROUPLIST ="DOCOMUserGroupList";
	public static final String DOPDCLIST ="doPDClist";
	public static final String DOPDCDETAILS ="doPDCDetail";
	public static final String DOPDCITEM ="doPDCItem";
	public static final String USER ="USER";
	public static final String COMSOL_DOCUMENT_TYPE_CODE = "45";
	
	
	
	
	
	//ECMS ROLES
	public static final String ECMS_MOBILE_READONLY="$ECMS MOBILE READONLY";
	
	
	
	
	//HAUSER
	
	public static String INVALID_UID_PSWD_CODE = "03";
	public static String FAILED_PSWD_ATTMPTS_EXCEEDED_CODE = "08";
	public static String PASSWORD_EXPIRED_CODE = "01";
	public static String USER_ID_DEACTIVATED_CODE = "02";
	public static String MUST_CHANGE_PSWD_CODE = "05";
	public static String PASSWORD_WILL_EXPIRE_ON_CODE = "06";
	public static String SINGLE_LOGIN_FAILED_ATTEMPTS_CODE = "07";
	public static String MULTIPLE_LOGIN_FAILED_ATTEMPTS_CODE = "04";
	
	public static String DAYS_UNTIL_PASSWORD_DEACTIVATED_CODE = "00";
	public static String DAYS_UNTIL_PASSWORD_EXPIRE_WARNING_CODE = "04";
	public static String NUM_ALLOWED_FAILED_PASSWORD_ATTEMPTS_CODE = "01";
	public static String DAYS_UNTIL_PASSWORD_EXIPRES_CODE = "02";
	

	
	//EndPoints
	
	public static final String END_POINT_ECMS_AUTHORIZE_ECMS="/authorizeECMS.json";
	public static final String END_POINT_ECMS_GET_USER_DETAILS="/getUserDetails.json";
	public static final String END_POINT_ECMS_GET_PROJECTS_LIST="/getProjectList.json";
	public static final String END_POINT_ECMS_GET_PROJECTS_LIST_PARAMS="/getProjectListWithParams.json";
	public static final String END_POINT_ECMS_GET_PROJECT_INFO="/getProjectInfo.json";
	public static final String END_POINT_ECMS_GET_PDC_CHECKLIST="/getPdcChecklist.json";
	
	public static final String END_POINT_ECMS_GET_DOCUMENT_METADATA="/getDocumentMetadata.json";
	
	public static final String END_POINT_ECMS_GET_PDC="/getPdc.json";
	public static final String END_POINT_ECMS_GET_PDC_DETAIL_LIST="/getPDCDetailslist.json";
	public static final String END_POINT_ECMS_GET_ACTIVE_SOL="/getActiveSOL.json";
	public static final String END_POINT_ECMS_GET_SOL="/getSOL.json";
	public static final String END_POINT_ECMS_GET_ACTIVE_SOL_DETAILS="/getActiveSOLDetails.json";
	public static final String END_POINT_ECMS_PURGE_SESSIONS="/purgeSessions.json";
	public static final String END_POINT_ECMS_PURGE_USER_SESSION="/purgeUserSession.json";
	public static final String END_POINT_ECMS_FETCH_PDF="/fetchPDF.json";
	public static final String END_POINT_ECMS_DOCS_STATUS="/docsStatus.json";
	public static final String END_POINT_ECMS_RELOAD_APP_PROPERTIES = "/reloadAppProperties.json";
	public static final String END_POINT_ECMS_IS_AUTHORIZED = "/isAuthorized.json";
}
