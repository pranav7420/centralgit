/**
 * 
 */
package gov.pa.dot.mobile.service.impl;

import static gov.pa.dot.mobile.utilities.MobileSessionUtils.USER_MOBILE_SESSION_DOUSER;
import static gov.pa.dot.mobile.utilities.MobileSessionUtils.USER_MOBILE_SESSION_USER_LIST;
import static gov.pa.dot.mobile.utilities.MobileSessionUtils.BOCOM_BUSINESS_FUNCTION_ALL;
import static gov.pa.dot.mobile.utilities.MobileSessionUtils.BOCOM_BUSINESS_FUNCTION_CONTRACTOR;

import gov.pa.dot.mobile.domain.Document;
import gov.pa.dot.mobile.domain.PDCcheckList;
import gov.pa.dot.mobile.domain.PDCcheckListDetailRequest;
import gov.pa.dot.mobile.domain.PDCcheckListDetailResponse;
import gov.pa.dot.mobile.domain.PDCcheckListResponse;
import gov.pa.dot.mobile.servce.MobileService;
import gov.pa.dot.mobile.utilities.AppUtil;
import gov.pa.dot.mobile.utilities.ECMSConstants;
import gov.pa.dot.mobile.utilities.MessageCodeEnum;
import gov.pa.dot.mobile.utilities.MobileSessionUtils;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.ServletContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import us.pa.state.dot.ecms.business.BOCOMUser;
import us.pa.state.dot.ecms.business.BOPDCDetail;
import us.pa.state.dot.ecms.business.BOPDCItemList;
import us.pa.state.dot.ecms.dataobject.DOCOMDocument;
import us.pa.state.dot.ecms.dataobject.DOCOMUser;
import us.pa.state.dot.ecms.dataobject.DOPDCDetail;
import us.pa.state.dot.ecms.dataobject.DOPDCItem;
import us.pa.state.dot.ecms.dataobject.DOPDCList;
import us.pa.state.dot.framework.data.PDDataObject;
import us.pa.state.dot.framework.data.PDDataObjectList;
import us.pa.state.dot.framework.environment.PDWebServiceEnvironment;
import us.pa.state.dot.framework.util.PDNumber;

/**
 * @author c-stumugan
 * 
 */
@Service
public class MobileServiceImpl implements MobileService
{
	public static Logger logger = LoggerFactory.getLogger(MobileServiceImpl.class);

	public PDCcheckListResponse getPDC(PDCcheckListDetailRequest request, ServletContext context)
	{
		String userId = request.getUserId().toLowerCase();
		String sendingSource = "";
		PDNumber addendumNum = null;
		PDCcheckListResponse pDCcheckListResponse = new PDCcheckListResponse();
		List<PDCcheckList> pDCcheckList = new ArrayList<PDCcheckList>();
		PDWebServiceEnvironment pdWSEnv = MobileSessionUtils.getPDEnvironment(userId, context);
		try
		{

			PDNumber ecmsProjectNum = new PDNumber(request.getEcmsProjNumber());

			if (request.getVersion() == null || request.getVersion().equals(""))
			{
				request.setVersion(ECMSConstants.PDC_VIEW_CURRENT);
			}

			if (request.getVersion().equalsIgnoreCase(ECMSConstants.PDC_VIEW_CURRENT) || request.getVersion().equalsIgnoreCase(ECMSConstants.PDC_VIEW_ORIGINAL)
					|| request.getVersion().equalsIgnoreCase(ECMSConstants.PDC_VIEW_CONTRACT))
			{
				addendumNum = new PDNumber(0);
			}
			else
			{
				int a = Integer.parseInt(request.getVersion());
				addendumNum = new PDNumber(a);
			}
			long startTimePDC = System.currentTimeMillis();
			if (addendumNum != null && addendumNum.intValue() != 0)
			{
				new BOPDCItemList(pdWSEnv, ecmsProjectNum, addendumNum, sendingSource, true);
			}
			else
			{
				new BOPDCItemList(pdWSEnv, ecmsProjectNum, request.getVersion(), sendingSource, true);
			}
			logger.debug("END_TIME--Calling ECMS Method to Get PDC--" + (System.currentTimeMillis() - startTimePDC) + " ms");

			DOPDCList doPDClist = (DOPDCList) pdWSEnv.getPersistentObject(ECMSConstants.DOPDCLIST);
			if (doPDClist != null)
			{
				Enumeration<?> e = doPDClist.getDataObjects();
				while (e.hasMoreElements())
				{
					PDDataObject dataObj = (PDDataObject) e.nextElement();
					PDCcheckList pDCcheckListRes = new PDCcheckList();
					List<Document> pdcDocumentList = new ArrayList<Document>();
					setPdc(dataObj, pDCcheckListRes);

					PDNumber ecmsProjectNumber = new PDNumber(request.getEcmsProjNumber());
					PDNumber cliLineNum = new PDNumber(Integer.parseInt(pDCcheckListRes.getClLineNum()));
					long startTimePDCDetails = System.currentTimeMillis();
					new BOPDCDetail(pdWSEnv, ecmsProjectNumber, cliLineNum, true);
					logger.debug("END_TIME--Calling ECMS Method to Get PDCDetails--" + (System.currentTimeMillis() - startTimePDCDetails) + " ms");
					DOPDCItem doPDCItem = (DOPDCItem) pdWSEnv.getPersistentObject(ECMSConstants.DOPDCITEM);
					PDDataObjectList dataObjList = doPDCItem.getPDDataObjectList("EDMS_ATTACHMENT_LIST");
					if (dataObjList != null)
					{

						Enumeration<?> en = dataObjList.getDataObjects();
						while (en.hasMoreElements())
						{

							PDDataObject dataObjs = (PDDataObject) en.nextElement();
							setPDCDocMetaData(pdcDocumentList, dataObjs);
							pDCcheckListRes.setPdcDocumentList(pdcDocumentList);
						}
					}

					pDCcheckList.add(pDCcheckListRes);
				}
				pDCcheckListResponse.setPdcCheckLsit(pDCcheckList);
			}
			else
			{
				pDCcheckListResponse.setMessageCode(MessageCodeEnum.LIST_EMPTY.getCode());
				pDCcheckListResponse.setStatusMessage(MessageCodeEnum.LIST_EMPTY.getMessage());
			}
		}
		catch (Exception e)
		{
			logger.error(ECMSConstants.ERROR + "--->", e);
			AppUtil.setErrorMessageToResponse(pDCcheckListResponse, MessageCodeEnum.ERROR, AppUtil.getRootExceptionMessage(e));
			USER_MOBILE_SESSION_DOUSER.remove(userId);
			USER_MOBILE_SESSION_USER_LIST.remove(userId);
		}
		DOCOMUser user = (DOCOMUser) pdWSEnv.getPersistentObject("DOCOMUser");

		if (user.isContractor())
		{
			if(BOCOM_BUSINESS_FUNCTION_CONTRACTOR==null)
				BOCOM_BUSINESS_FUNCTION_CONTRACTOR = ((BOCOMUser) pdWSEnv.getUser()).getBoCOMBusinessFunction();
		}
		else if ((user.isConsultant() || user.isPennDot()))
		{
			if(BOCOM_BUSINESS_FUNCTION_ALL==null)
				
				BOCOM_BUSINESS_FUNCTION_ALL = ((BOCOMUser) pdWSEnv.getUser()).getBoCOMBusinessFunction();
		}
		return pDCcheckListResponse;
	}

	public PDCcheckListDetailResponse getPDCDetails(PDCcheckListDetailRequest request, ServletContext context)
	{
		String userId = request.getUserId().toLowerCase();
		List<Document> pdcDocumentList = new ArrayList<Document>();
		PDWebServiceEnvironment pdWSEnv = MobileSessionUtils.getPDEnvironment(userId, context);
		PDCcheckListDetailResponse pDCcheckListDetailResponse = new PDCcheckListDetailResponse();
		PDNumber ecmsProjectNumber = new PDNumber(request.getEcmsProjNumber());
		PDNumber cliLineNum = new PDNumber(request.getCliLineNum());

		try
		{

			new BOPDCDetail(pdWSEnv, ecmsProjectNumber, cliLineNum, true);
			DOPDCDetail dOPDCDetail = (DOPDCDetail) pdWSEnv.getPersistentObject(ECMSConstants.DOPDCDETAILS);

			if (dOPDCDetail != null)
			{
				pDCcheckListDetailResponse.setCreatedBy(dOPDCDetail.getString(DOPDCDetail.CREATED_BY));
				pDCcheckListDetailResponse.setLastModifiedBy(dOPDCDetail.getString(DOPDCDetail.LAST_MODIFIED_BY));
				pDCcheckListDetailResponse.setCreatedTs(dOPDCDetail.getPDDate(DOPDCDetail.CREATED_BY_TS).toFormattedString());
				pDCcheckListDetailResponse.setLastModifiedTs(dOPDCDetail.getPDDate(DOPDCDetail.CREATED_BY_TS).toFormattedString());
				pDCcheckListDetailResponse.setClItemComplInd(dOPDCDetail.getString(DOPDCDetail.CL_ITEM_COMPL_IND));
				pDCcheckListDetailResponse.setClItemName(dOPDCDetail.getString(DOPDCDetail.CL_ITEM_NAME));
				pDCcheckListDetailResponse.setClItemNum(dOPDCDetail.getPDNumber(DOPDCDetail.CL_ITEM_NUM).toFormattedString(ECMSConstants.FORMATSTRING));
				pDCcheckListDetailResponse.setClLineNum(dOPDCDetail.getPDNumber(DOPDCDetail.CL_LINE_NUM).toFormattedString(ECMSConstants.FORMATSTRING));
				pDCcheckListDetailResponse.setEcmsProjNum(dOPDCDetail.getPDNumber(DOPDCDetail.ECMS_PROJECT_NUM).toFormattedString(ECMSConstants.FORMATSTRING));
				pDCcheckListDetailResponse.setEditBidPkgInd(dOPDCDetail.getString(DOPDCDetail.EDIT_BID_PKG_IND));
				pDCcheckListDetailResponse.setGenCodeValue(dOPDCDetail.getString(DOPDCDetail.GEN_CODE_VALUE));
				pDCcheckListDetailResponse.setOrigContInd(dOPDCDetail.getString(DOPDCDetail.ORIG_CONT_IND));
				pDCcheckListDetailResponse.setPdcItemTypeCode(dOPDCDetail.getString(DOPDCDetail.PDC_ITEM_TYPE_CODE));
				pDCcheckListDetailResponse.setProjStatusCode(dOPDCDetail.getValue(DOPDCDetail.PROJ_STATUS_CODE).toString());
				DOPDCItem doPDCItem = (DOPDCItem) pdWSEnv.getPersistentObject(ECMSConstants.DOPDCITEM);
				PDDataObjectList dataObjList = doPDCItem.getPDDataObjectList("EDMS_ATTACHMENT_LIST");
				if (dataObjList != null)
				{

					Enumeration<?> e = dataObjList.getDataObjects();
					while (e.hasMoreElements())
					{

						PDDataObject dataObj = (PDDataObject) e.nextElement();
						setPDCDocMetaData(pdcDocumentList, dataObj);
						pDCcheckListDetailResponse.setPdcDocumentList(pdcDocumentList);
					}
				}
				else
				{
					pDCcheckListDetailResponse.setMessageCode(MessageCodeEnum.LIST_EMPTY.getCode());
					pDCcheckListDetailResponse.setStatusMessage(MessageCodeEnum.LIST_EMPTY.getMessage());
				}
			}
			else
			{
				pDCcheckListDetailResponse.setMessageCode(MessageCodeEnum.LIST_EMPTY.getCode());
				pDCcheckListDetailResponse.setStatusMessage(MessageCodeEnum.LIST_EMPTY.getMessage());

			}
		}
		catch (Exception e)
		{
			logger.error(ECMSConstants.ERROR + "--->", e);
			AppUtil.setErrorMessageToResponse(pDCcheckListDetailResponse, MessageCodeEnum.ERROR, AppUtil.getRootExceptionMessage(e));
			USER_MOBILE_SESSION_DOUSER.remove(userId);
			USER_MOBILE_SESSION_USER_LIST.remove(userId);
		}
		return pDCcheckListDetailResponse;
	}

	private void setPDCDocMetaData(List<Document> pdcDocumentList, PDDataObject dataObj)
	{
		Document pdcDocument = new Document();
		pdcDocument.setDocumentTypeCode(dataObj.getString(DOCOMDocument.DOCUMENT_TYPE_CODE));
		pdcDocument.setCreatedBy(dataObj.getString(DOCOMDocument.CREATED_BY));
		pdcDocument.setCreatedByTs(dataObj.getPDTimeStamp(DOCOMDocument.CREATED_BY_TS).toFormattedString());
		pdcDocument.setEdmsTitleSubject(dataObj.getString(DOCOMDocument.EDMS_TITLE_SUBJECT));
		pdcDocument.setDocumentId(dataObj.getPDNumber(DOCOMDocument.DOCUMENT_ID).toFormattedString(ECMSConstants.FORMATSTRING));
		pdcDocument.setEdmsDocTypeCode(dataObj.getString(DOCOMDocument.EDMS_DOC_TYPE_CODE));
		pdcDocument.setEdmsDocLink(dataObj.getString(DOCOMDocument.EDMS_DOC_LINK));
		pdcDocument.setEdmsUrl(dataObj.getString(DOCOMDocument.EDMS_URL));
		pdcDocument.setDocumentLength(dataObj.getPDNumber(DOCOMDocument.DOCUMENT_LENGTH).toFormattedString(ECMSConstants.FORMATSTRING));
		pdcDocument.setDocumentContentType(dataObj.getString(DOCOMDocument.DOCUMENT_CONTENT_TYPE));
		pdcDocument.setBpId(dataObj.getString(DOCOMDocument.BP_ID));
		pdcDocument.setEdmsDocId(dataObj.getValue(DOCOMDocument.EDMS_DOC_ID).toString());
		pdcDocument.setDocumentName(dataObj.getString(DOCOMDocument.DOCUMENT_NAME));
		pdcDocument.setEdmsReadyToMoveInd(dataObj.getString(DOCOMDocument.EDMS_READY_TO_MOVE_IND));
		pdcDocument.setEdmsDocumentTitle(dataObj.getString(DOCOMDocument.EDMS_DOCUMENT_TITLE));

		pdcDocumentList.add(pdcDocument);
	}

	private void setPdc(PDDataObject dataObj, PDCcheckList pDCcheckListRes)
	{
		pDCcheckListRes.setCreatedBy(dataObj.getString(DOPDCItem.CREATED_BY));
		pDCcheckListRes.setLastModifiedBy(dataObj.getString(DOPDCItem.LAST_MODIFIED_BY));
		pDCcheckListRes.setCreatedTs(dataObj.getPDDate(DOPDCItem.CREATED_BY_TS).toFormattedString());
		pDCcheckListRes.setLastModifiedTs(dataObj.getPDDate(DOPDCItem.LAST_MODIFIED_TS).toFormattedString());
		pDCcheckListRes.setFileCount(dataObj.getPDNumber(DOPDCItem.ATTACHMENT_COUNT).intValue());
		pDCcheckListRes.setClLineNum(dataObj.getPDNumber(DOPDCItem.CL_LINE_NUM).toFormattedString(ECMSConstants.FORMATSTRING));
		pDCcheckListRes.setClItemSecDesc(dataObj.getString(DOPDCItem.CL_ITEM_SEC_DESC));
		pDCcheckListRes.setDeleteInd(dataObj.getString(DOPDCItem.DELETE_IND));
		pDCcheckListRes.setAddendumPendInd(dataObj.getString(DOPDCItem.ADDENDA_PEND_IND));
		pDCcheckListRes.setBidPkgInd(dataObj.getString(DOPDCItem.BID_PKG_IND));
		pDCcheckListRes.setClItemComplInd(dataObj.getString(DOPDCItem.CL_ITEM_COMPL_IND));
		pDCcheckListRes.setOrigContInd(dataObj.getString(DOPDCItem.ORIG_CONT_IND));
		pDCcheckListRes.setEcmsProjNum(dataObj.getPDNumber(DOPDCItem.ECMS_PROJECT_NUM).toFormattedString(ECMSConstants.FORMATSTRING));
		pDCcheckListRes.setPdcBodCat(dataObj.getString(DOPDCItem.PDC_BOD_CAT));
		if (dataObj.getValue(DOPDCItem.ADDENDUM_NUM) != "")
		{
			String addendumNum = dataObj.getValue(DOPDCItem.ADDENDUM_NUM).toString();
			pDCcheckListRes.setAddendumNum(addendumNum);
			pDCcheckListRes.setClItemName(dataObj.getValue(DOPDCItem.CL_ITEM_NAME).toString() + "(Addendum:" + addendumNum + ")");
		}
		else
		{

			pDCcheckListRes.setClItemName(dataObj.getValue(DOPDCItem.CL_ITEM_NAME).toString());
		}
	}

}
