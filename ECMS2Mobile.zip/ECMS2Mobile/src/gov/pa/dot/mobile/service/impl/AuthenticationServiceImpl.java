/**
 * 
 */
package gov.pa.dot.mobile.service.impl;

import gov.pa.dot.mobile.domain.BaseDomain;
import static gov.pa.dot.mobile.utilities.MobileSessionUtils.USER_MOBILE_SESSION_DOUSER;
import static gov.pa.dot.mobile.utilities.MobileSessionUtils.USER_MOBILE_SESSION_USER_LIST;

import gov.pa.dot.mobile.domain.GenCodeValues;
import gov.pa.dot.mobile.domain.UserGroup;
import gov.pa.dot.mobile.domain.UserProfile;
import gov.pa.dot.mobile.exception.MobileServiceException;
import gov.pa.dot.mobile.persistence.GenCodeMapper;
import gov.pa.dot.mobile.servce.AuthenticationService;
import gov.pa.dot.mobile.utilities.AppUtil;
import gov.pa.dot.mobile.utilities.ApplicationProperties;
import gov.pa.dot.mobile.utilities.ECMSConstants;
import gov.pa.dot.mobile.utilities.MessageCodeEnum;
import gov.pa.dot.mobile.utilities.MobileSessionUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.ServletContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import us.pa.state.dot.ecms.dataobject.DOCOMUser;
import us.pa.state.dot.ecms.dataobject.DOCOMUserGroup;
import us.pa.state.dot.ecms.dataobject.DOCOMUserGroupList;
import us.pa.state.dot.framework.data.DOHAUserPassword;
import us.pa.state.dot.framework.data.PDDataObject;
import us.pa.state.dot.framework.data.PDDataObjectList;
import us.pa.state.dot.framework.database.DBHAUser;
import us.pa.state.dot.framework.environment.PDWebServiceEnvironment;
import us.pa.state.dot.framework.exception.HAUserException;
import us.pa.state.dot.framework.service.PDConfigService;
import us.pa.state.dot.framework.util.PDDate;
import us.pa.state.dot.framework.util.PDUtil;

/**
 * @author c-stumugan
 * 
 */
@Service
public class AuthenticationServiceImpl implements AuthenticationService
{
	public static Logger logger = LoggerFactory.getLogger(AuthenticationServiceImpl.class);

	
	List<GenCodeValues> genCodesList = new ArrayList<GenCodeValues>();
	private PDDataObjectList authControlList = null;

	@Autowired
	private GenCodeMapper genCodeMapper;
	
	@Autowired
	ApplicationProperties applicationProperties;


	public void checkUserPassword(String userId, DOHAUserPassword doUserPassword, String serverName, String pathName, PDDataObjectList authControlList) throws HAUserException, Exception
	{
		Date today = new Date();
		try
		{
			genCodesList = genCodeMapper.getGencodeValuesforUserLogin(applicationProperties.getUserLoginValue());
		}
		catch (Exception e)
		{
			throw new MobileServiceException(Boolean.TRUE, MessageCodeEnum.GEN_CODE_MAPPER_EXCEPTION);
		}
		//If no data was found, it means that the user id is invalid
		if (doUserPassword == null)
		{
			throw new HAUserException(HAUserException.INVALIDUSERIDORPASSWORD, getMessage(ECMSConstants.INVALID_UID_PSWD_CODE), "");
		}

		// If the password reset indicator is "Y", force to reset password
		String ind = (String) doUserPassword.getValue(DOHAUserPassword.PWDRESETIND);
		if (ind.equalsIgnoreCase(ECMSConstants.CODE_SUCCESS))
		{
			// get the link for password reset web site
			throw new HAUserException(HAUserException.MUSTCHANGEPSWD, getMessage(ECMSConstants.MUST_CHANGE_PSWD_CODE), serverName.concat(pathName).concat(userId));
		}

		PDDate lastLoginDate = doUserPassword.getPDTimeStamp(DOHAUserPassword.LASTLOGINTS).getPDDate();
		long daysPassed = PDUtil.dateDiff(lastLoginDate.getDate(), today);

		// If days since last login exceeds limit, user will become inactive 
		if (daysPassed > getAuthControl(ECMSConstants.DAYS_UNTIL_PASSWORD_DEACTIVATED_CODE, authControlList))
		{
			throw new HAUserException(HAUserException.USERDEACTIVATED, getMessage(ECMSConstants.USER_ID_DEACTIVATED_CODE), "");
		}

		// Check password expiration
		PDDate lastPswdChgDate = doUserPassword.getPDDate(DOHAUserPassword.PWDCHANGEDATE);
		daysPassed = PDUtil.dateDiff(lastPswdChgDate.getDate(), today);

		int daysUtilPswdExpired = getAuthControl(ECMSConstants.DAYS_UNTIL_PASSWORD_EXIPRES_CODE, authControlList);
		if (daysPassed > daysUtilPswdExpired)
		{
			throw new HAUserException(HAUserException.PASSWORDEXPIRED, getMessage(ECMSConstants.PASSWORD_EXPIRED_CODE), serverName.concat(pathName).concat(userId));
		}

		// Set the failed login count
		int loginFailedCount;
		if (doUserPassword.getValue(DOHAUserPassword.FAILEDPWDCOUNT) == null)
		{
			loginFailedCount = 0;
		}
		else
		{
			loginFailedCount = doUserPassword.getPDNumber(DOHAUserPassword.FAILEDPWDCOUNT).intValue();
		}

		// If they have already attempted to login too many times unsuccessfully, let the user know.
		if (loginFailedCount > getAuthControl(ECMSConstants.NUM_ALLOWED_FAILED_PASSWORD_ATTEMPTS_CODE, authControlList))
		{
			throw new HAUserException(HAUserException.EXCEEDEDLOGINATTEMPTCOUNT, getMessage(ECMSConstants.FAILED_PSWD_ATTMPTS_EXCEEDED_CODE), "");
		}
	}

	public UserProfile getUserProfile(DOCOMUser dOCOMUser, DOCOMUserGroupList doUserGroupList) throws MobileServiceException
	{
		UserProfile userProfile = new UserProfile();
		List<UserGroup> userGroupList = new ArrayList<UserGroup>();

		userProfile.setIsContractorUser(dOCOMUser.getBoolean(DOCOMUser.IS_CONTRACTOR_USER));
		userProfile.setBusPartnerName(dOCOMUser.getString(DOCOMUser.BUS_PARTNER_NAME));
		userProfile.setFaxExchange(dOCOMUser.getString(DOCOMUser.FAX_EXCHANGE));
		userProfile.setOrganization(dOCOMUser.getString(DOCOMUser.ORGANIZATION));
		userProfile.setSecurityDominoFullName(dOCOMUser.getString(DOCOMUser.SECURITY_DOMINO_FULL_NAME));
		userProfile.setIsPenndotUser(dOCOMUser.getBoolean(DOCOMUser.IS_PENNDOT_USER));
		userProfile.setFirstName(dOCOMUser.getString(DOCOMUser.FIRST_NAME));
		userProfile.setUserId(dOCOMUser.getString(DOCOMUser.USER_ID));
		userProfile.setLastUpdateTs(dOCOMUser.getPDTimeStamp(DOCOMUser.LAST_UPDATE_TS).toString());
		userProfile.setDisplayFaxNumber(dOCOMUser.getString(DOCOMUser.DISPLAY_FAX_NUMBER));
		userProfile.setIsTurnpikeUser(dOCOMUser.getBoolean(DOCOMUser.IS_TURNPIKE_USER));
		userProfile.setBusPartnerFid(dOCOMUser.getString(DOCOMUser.BUS_PARTNER_FID));
		userProfile.setPhoneNumber(dOCOMUser.getString(DOCOMUser.PHONE_NUMBER));
		userProfile.setIsFhwaUser(dOCOMUser.getBoolean(DOCOMUser.IS_FHWA_USER));
		userProfile.setNameSuffix(dOCOMUser.getString(DOCOMUser.NAME_SUFFIX));
		userProfile.setFirmId(dOCOMUser.getString(DOCOMUser.FIRM_ID));
		userProfile.setPhoneExtension(dOCOMUser.getString(DOCOMUser.PHONE_EXTENSION));
		userProfile.setPhoneExchange(dOCOMUser.getString(DOCOMUser.PHONE_EXCHANGE));
		userProfile.setIsBondingAgencyUser(dOCOMUser.getBoolean(DOCOMUser.IS_BONDING_AGENCY_USER));
		userProfile.setFaxAreaCode(dOCOMUser.getString(DOCOMUser.FAX_AREA_CODE));
		userProfile.setIsAnonymousUser(dOCOMUser.getBoolean(DOCOMUser.IS_ANONYMOUS_USER));
		userProfile.setFullName(dOCOMUser.getString(DOCOMUser.FULL_NAME));
		userProfile.setIsMunicipalityUser(dOCOMUser.getBoolean(DOCOMUser.IS_MUNICIPALITY_USER));
		userProfile.setEmailAddress(dOCOMUser.getString(DOCOMUser.EMAIL_ADDRESS));
		userProfile.setIsBusinessPartnerUser(dOCOMUser.getBoolean(DOCOMUser.IS_BUSINESS_PARTNER_USER));
		userProfile.setDisplayPhoneNumber(dOCOMUser.getString(DOCOMUser.DISPLAY_PHONE_NUMBER));
		userProfile.setLastName(dOCOMUser.getString(DOCOMUser.LAST_NAME));
		userProfile.setWorkUnitType(dOCOMUser.getString(DOCOMUser.WORK_UNIT_TYPE));
		userProfile.setIsDebuggerUser(dOCOMUser.getBoolean(DOCOMUser.IS_DEBUGGER_USER));
		userProfile.setMiddleInitial(dOCOMUser.getString(DOCOMUser.MIDDLE_INITIAL));
		userProfile.setDominoFullName(dOCOMUser.getString(DOCOMUser.DOMINO_FULL_NAME));
		userProfile.setWorkUnitCode(dOCOMUser.getString(DOCOMUser.WORK_UNIT_CODE));
		userProfile.setSortableFullName(dOCOMUser.getString(DOCOMUser.SORTABLE_FULL_NAME));
		userProfile.setIsSuretyUser(dOCOMUser.getBoolean(DOCOMUser.IS_SURETY_USER));
		userProfile.setIsConsultantUser(dOCOMUser.getBoolean(DOCOMUser.IS_CONSULTANT_USER));
		userProfile.setFaxNumber(dOCOMUser.getString(DOCOMUser.FAX_NUMBER));
		userProfile.setPhoneAreaCode(dOCOMUser.getString(DOCOMUser.PHONE_AREA_CODE));
		userProfile.setWorkUnitName(dOCOMUser.getString(DOCOMUser.WORK_UNIT_NAME));

		Enumeration<?> e = doUserGroupList.getDataObjects();
		while (e.hasMoreElements())
		{

			UserGroup group = new UserGroup();
			PDDataObject dataObj = (PDDataObject) e.nextElement();
			group.setGroupName(dataObj.getString(DOCOMUserGroup.GROUP_NAME));
			group.setGenericGroupName(dataObj.getString(DOCOMUserGroup.GENERIC_GROUP_NAME));
			userGroupList.add(group);

		}
		userProfile.setUserGroupList(userGroupList);
		return userProfile;
	}

	private String getMessage(String msgCode) throws MobileServiceException
	{
		return getGenCodeValue(genCodesList, msgCode);
	}

	/**
	 * This method will get the authentication control value for the
	 * authentication control code passed from the authentication control list
	 */
	private int getAuthControl(String authControlCode, PDDataObjectList authControlList) throws MobileServiceException
	{
		return Integer.parseInt(getGPCValue(authControlList, authControlCode));
	}

	/**
	 * This method will loop through the GPC list and return the GPC value for
	 * the GPC code passed.
	 */
	private String getGenCodeValue(List<GenCodeValues> gpcList, String genCode) throws MobileServiceException
	{
		for (GenCodeValues genCodeValues : gpcList)
		{

			if (genCodeValues.getGenCode() != null && !genCodeValues.getGenCode().isEmpty() && genCodeValues.getGenCode().equalsIgnoreCase(genCode))
			{
				return genCodeValues.getGenCodeValue();
			}
		}

		return "";

	}

	private String getGPCValue(PDDataObjectList gpcList, String genCode) throws MobileServiceException
	{
		Enumeration<?> e = gpcList.getDataObjects();
		while (e.hasMoreElements())
		{
			PDDataObject gpc = (PDDataObject) e.nextElement();
			if (gpc.getString(DBHAUser.GPC_GEN_CODE).equals(genCode))
			{
				return gpc.getString(DBHAUser.GPC_GEN_CODE_VALUE);
			}
		}
		return "";
	}

	public BaseDomain validateUser(String userId, ServletContext context)
	{
		userId = userId.toLowerCase();
		BaseDomain response = new BaseDomain();
		DOHAUserPassword doUserPassword = new DOHAUserPassword();

		try
		{
			PDWebServiceEnvironment pdWSEnv = MobileSessionUtils.getPDEnvironment(userId, context);
			String serverName = pdWSEnv.getConfigService().getProperty(PDConfigService.ECMS_DOMINO_MAIN_URL, "");
			String pathName = pdWSEnv.getConfigService().getProperty(PDConfigService.ECMS_DOMINO_CHANGE_PASSWORD_PATH, "");

			DBHAUser dbUser = new DBHAUser(pdWSEnv);
			//Get the password info for this user
			doUserPassword = dbUser.readUserPassword(userId);

			authControlList = dbUser.readGPCAuthenticationControlList();
			long startTime = System.currentTimeMillis();
			checkUserPassword(userId, doUserPassword, serverName, pathName, authControlList);
			logger.debug("END_TIME--ChecKPassword--"+ (System.currentTimeMillis() - startTime)+" ms");

		}
		catch (HAUserException ha)
        {
			USER_MOBILE_SESSION_DOUSER.remove(userId);
			USER_MOBILE_SESSION_USER_LIST.remove(userId);
              logger.error(ECMSConstants.ERROR + "--->", ha);
              AppUtil.setErrorMessageToResponse(response, MessageCodeEnum.ECMS_HA_USER_FAILURE, AppUtil.getRootExceptionMessage(ha));
        }
        catch (MobileServiceException se)
        {
        	USER_MOBILE_SESSION_DOUSER.remove(userId);
			USER_MOBILE_SESSION_USER_LIST.remove(userId);
              logger.error(ECMSConstants.ERROR + "--->", se);
              AppUtil.setErrorMessageToResponse(response, se.getMessageCode(), AppUtil.getRootExceptionMessage(se));
        }
        catch (Exception e)
        {
        	USER_MOBILE_SESSION_DOUSER.remove(userId);
			USER_MOBILE_SESSION_USER_LIST.remove(userId);
              logger.error(ECMSConstants.ERROR + "--->", e);
              AppUtil.setErrorMessageToResponse(response, MessageCodeEnum.ERROR, AppUtil.getRootExceptionMessage(e));
        }

		return response;

	}
}
