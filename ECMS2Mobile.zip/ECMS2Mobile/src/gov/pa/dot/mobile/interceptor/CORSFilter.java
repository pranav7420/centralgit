/**
 * 
 */
package gov.pa.dot.mobile.interceptor;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author c-stumugan
 *
 */
public class CORSFilter implements Filter {


	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
		HttpServletResponse response = (HttpServletResponse) servletResponse;
		HttpServletRequest reqeust =  (HttpServletRequest) servletRequest;

		if(reqeust.getHeader("Access-Control-Request-Method") != null || "OPTIONS".equals(reqeust.getMethod()) || "POST".equals(reqeust.getMethod()) || "GET".equals(reqeust.getMethod()))
		{	    
			response.setHeader("Access-Control-Allow-Origin", "*");
			response.setHeader("Access-Control-Allow-Credentials", "true");
			response.setHeader("Access-Control-Allow-Methods", "POST, GET, HEAD, OPTIONS");
			response.setHeader("Access-Control-Allow-Headers", "Origin,Authorization, apiKey, reauthorize, Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers");
		}
		filterChain.doFilter(servletRequest, servletResponse);
	}

	@Override
	public void destroy() {

	}
}
