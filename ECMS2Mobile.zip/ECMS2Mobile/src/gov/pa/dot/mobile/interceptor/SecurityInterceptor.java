package gov.pa.dot.mobile.interceptor;

import gov.pa.dot.mobile.domain.BaseDomain;
import gov.pa.dot.mobile.servce.AuthenticationService;
import gov.pa.dot.mobile.utilities.ECMSConstants;
import gov.pa.dot.mobile.utilities.JSONUtil;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class SecurityInterceptor extends HandlerInterceptorAdapter
{

	@Autowired
	AuthenticationService authenticationService;

	public static Logger logger = LoggerFactory.getLogger(SecurityInterceptor.class);
	public static List<String> handleRequestPath = new ArrayList<String>();

	static
	{
		handleRequestPath.add(ECMSConstants.END_POINT_ECMS_AUTHORIZE_ECMS);
		handleRequestPath.add(ECMSConstants.END_POINT_ECMS_DOCS_STATUS);
		handleRequestPath.add(ECMSConstants.END_POINT_ECMS_PURGE_SESSIONS);
		handleRequestPath.add(ECMSConstants.END_POINT_ECMS_PURGE_USER_SESSION);
		handleRequestPath.add(ECMSConstants.END_POINT_ECMS_GET_ACTIVE_SOL_DETAILS);
		handleRequestPath.add(ECMSConstants.END_POINT_ECMS_GET_ACTIVE_SOL);
		handleRequestPath.add(ECMSConstants.END_POINT_ECMS_GET_SOL);
		handleRequestPath.add(ECMSConstants.END_POINT_ECMS_FETCH_PDF);
		handleRequestPath.add(ECMSConstants.END_POINT_ECMS_GET_PROJECT_INFO);
		handleRequestPath.add(ECMSConstants.END_POINT_ECMS_RELOAD_APP_PROPERTIES);

	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception
	{
		request.setAttribute("START_TIME", System.currentTimeMillis());
		String userId = null;
		BaseDomain baseResponse = new BaseDomain();
		MDC.put("UUID", "<uid: " + UUID.randomUUID().toString().replace("-", "") + ">");
		String requestPath = request.getServletPath();
		if (handleRequestPath.contains(requestPath) && (request.getHeader(ECMSConstants.USERID) == null || request.getHeader(ECMSConstants.USERID).isEmpty()))
		{
			return true;
		}
		else if (requestPath.equalsIgnoreCase(ECMSConstants.END_POINT_ECMS_PURGE_USER_SESSION))
        {
              return true;
        }
		else if (request.getHeader(ECMSConstants.USERID) != null && !request.getHeader(ECMSConstants.USERID).isEmpty())
		{
			userId = request.getHeader(ECMSConstants.USERID);
		}
		else
		{
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			response.setContentType(MediaType.TEXT_HTML_VALUE);
			OutputStream o = response.getOutputStream();
			o.write(("Please enter the userId in the header").getBytes());
			return false;
		}

		logger.debug(ECMSConstants.MSGLOG + " PRE REQUEST_PATH->" + requestPath + " USERID->" + userId);

		if ("OPTIONS".equals(request.getMethod()))
			return true;

		baseResponse = authenticationService.validateUser(userId, request.getSession().getServletContext());
		if (baseResponse.getStatusCode().equalsIgnoreCase(ECMSConstants.CODE_FAILURE))
		{
			String message = JSONUtil.getJsonString(baseResponse);
			response.setStatus(HttpServletResponse.SC_OK);
			response.setContentType(MediaType.APPLICATION_JSON_VALUE);
			OutputStream o = response.getOutputStream();
			o.write((message).getBytes());

			return false;
		}
		return true;

	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception
	{

		String requestPath = request.getServletPath();
		String userName = request.getHeader(ECMSConstants.USERID);
		logger.debug(ECMSConstants.MSGLOG + " POST REQUEST_PATH->" + requestPath + " USERID->" + userName);
		Long startTime = (Long) request.getAttribute("START_TIME");
		logger.debug("PostHandle Request {} Elapsed Time: {} ms", request.getRequestURI(), (System.currentTimeMillis() - startTime));
	}

}
