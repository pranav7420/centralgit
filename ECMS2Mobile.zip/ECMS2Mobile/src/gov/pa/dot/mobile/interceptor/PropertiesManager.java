/**
 * 
 */
package gov.pa.dot.mobile.interceptor;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * @author c-stumugan
 *
 */
public class PropertiesManager {

	/**
	 * 
	 * Gets the property specified by the property parameter received.
	 * 
	 * 
	 * 
	 * @param property
	 *            - Property's values to look for in the file
	 * 
	 * @return value - Value returned from the file, empty string if
	 * 
	 *         file is not there or not readable or null if key is not found.
	 */

	public static String getProperty(String property) {

		String value = null;

		Properties prop = new Properties();

		try {

			InputStream is = PropertiesManager.class
					.getResourceAsStream("DocsStatus.properties");

			prop.load(is);

			value = prop.getProperty(property);

		} catch (FileNotFoundException fnfEx) {

			value = "";

		} catch (IOException ioEX) {

			value = "";

		}

		return value;

	}
}
