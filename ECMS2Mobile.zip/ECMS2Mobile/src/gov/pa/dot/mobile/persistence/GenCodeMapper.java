/**
 * 
 */
package gov.pa.dot.mobile.persistence;

import gov.pa.dot.mobile.domain.GenCodeValues;
import gov.pa.dot.mobile.exception.MobilePersistenceException;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

/**
 * @author c-stumugan
 *
 */
@Component
public interface GenCodeMapper
{

	List<GenCodeValues> getGencodeValuesforUserLogin(String genCodeType)throws MobilePersistenceException;
	public String getGeneralCodeValue(@Param("sourceApp") String sourceApp,@Param("codeType") String codeType,@Param("code") String code);
}
