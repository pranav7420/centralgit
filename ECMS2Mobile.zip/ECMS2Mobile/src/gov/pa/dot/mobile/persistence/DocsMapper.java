package gov.pa.dot.mobile.persistence;

import gov.pa.dot.mobile.domain.ProjectObject;
import gov.pa.dot.mobile.domain.ProjectRequest;
import gov.pa.dot.mobile.exception.MobilePersistenceException;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

/**
 * @author c-stumugan
 */

@Component
public interface DocsMapper
{

	public List<ProjectObject> getTeamMemberProjectList(ProjectRequest projectRequest) throws MobilePersistenceException;

	public List<ProjectObject> getFacilitiesManagementProjectList(ProjectRequest projectRequest) throws MobilePersistenceException;

	public List<ProjectObject> getDistrictProjectList(ProjectRequest projectRequest) throws MobilePersistenceException;

	public List<ProjectObject> getBusinessPartnerProjectList(ProjectRequest projectRequest) throws MobilePersistenceException;

	public int validateBusPartnerId(@Param("busPartnerId") String busPartnerId) throws MobilePersistenceException;

	public List<ProjectObject> getAllProjectsForState(ProjectRequest projectRequest)throws MobilePersistenceException;

	public ProjectObject getProject(int ecmsProjectNum)throws MobilePersistenceException;
	
	public List<ProjectObject> getTeamMemberOldProjectList(ProjectRequest projectRequest) throws MobilePersistenceException;

	public List<ProjectObject> getOldDistrictProjectList(ProjectRequest projectRequest) throws MobilePersistenceException;

	public List<ProjectObject> getOldAllProjectsForState(ProjectRequest projectRequest)throws MobilePersistenceException;
}

