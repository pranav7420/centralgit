package gov.pa.dot;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MobileAspect
{
private static final Logger logger = LoggerFactory.getLogger("metrics");
	
	public Object logExecutionTime(ProceedingJoinPoint joinPoint) throws Throwable {

		long startTimeMillis = System.currentTimeMillis();
		boolean isExceptionThrown = false;
		Object proceed;
		try
		{
			 proceed = joinPoint.proceed();
		}
		catch(Exception e)
		{
			isExceptionThrown = true;
			throw e;
		}
		finally
		{
		    long executionTime = (System.currentTimeMillis() - startTimeMillis);
		    Signature signature = joinPoint.getSignature();
		    logger.debug("{}, timeTaken: {} msecs, isExceptionThrown: {}",signature,executionTime,isExceptionThrown);
		}
		return proceed;
	}
}
