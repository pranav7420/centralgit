package us.pa.state.dot.ecms.webservices;

public class CEESInterfaceResult {

	private String result = "";
	private String errorMessage = "";
	private boolean ceeItemQueued = false;
	
	public CEESInterfaceResult() {
		
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String message) {
		this.errorMessage = message;
	}

	public boolean getCeeItemQueued() {
		return ceeItemQueued;
	}

	public void setCeeItemQueued(boolean found) {
		this.ceeItemQueued = found;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

}
