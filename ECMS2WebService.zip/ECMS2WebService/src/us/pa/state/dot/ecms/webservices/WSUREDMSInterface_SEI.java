package us.pa.state.dot.ecms.webservices;


public interface WSUREDMSInterface_SEI extends java.rmi.Remote
{
  public us.pa.state.dot.ecms.webservices.UREDMSInterfaceResult updateUREDMSChecklistItem(java.lang.String userId,java.lang.String password,int ecmsProjectNum,java.lang.String clItemNumber,java.lang.String actionDate,java.lang.String fhwaDate,java.lang.String clApprBy,java.lang.String edmsDocLink,java.lang.String edmsDocName) throws java.lang.Exception;
}