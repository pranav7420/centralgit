package us.pa.state.dot.ecms.webservices;


public interface WSCEESInterface_SEI extends java.rmi.Remote
{
  public us.pa.state.dot.ecms.webservices.CEESInterfaceResult updateCEEChecklistItem(java.lang.String userId,java.lang.String password,int ecmsProjectNum,java.lang.String ceeItemNumber,java.lang.String clItemNumber,java.lang.String actionDate,java.lang.String clApprBy,java.lang.String ceeDocLink) throws java.lang.Exception;
  public void init(java.lang.Object c) throws javax.xml.rpc.ServiceException;
  public void destroy();
}