package us.pa.state.dot.ecms.webservices;



import us.pa.state.dot.ecms.business.BOCOMCodeReference;
import us.pa.state.dot.ecms.business.BOPDCItemList;
import us.pa.state.dot.ecms.exception.EXCOMSecurityException;
import us.pa.state.dot.ecms.exception.EXPDCException;
import us.pa.state.dot.framework.environment.PDEnvironment;
import us.pa.state.dot.framework.exception.PDConfigException;
import us.pa.state.dot.framework.util.PDDate;
import us.pa.state.dot.framework.util.PDNumber;
import us.pa.state.dot.framework.util.PDUtil;

public class WSCEESInterface extends ECMSWebService {
	
	//Constants
	private static final String PDC_GENERAL_SYSTEM_CODE			= "926";
	private static final String PDC_CEE_USERID_GPC_CODE			= "03";
	private static final String PDC_CEE_PASSWORD_GPC_CODE		= "04";
	private static final String PDC_CEE_CHECKLIST_ITEM_CODE		= "697";
	
	
	//Business Objects
	private BOCOMCodeReference boCOMCodeReference = null;
	
	public WSCEESInterface() throws Exception {
		
		super();		
		
	}
	
	public WSCEESInterface(PDEnvironment pdEnv) throws Exception {
		
		super();		
		
	}
	
	/**
	 * Method to insert/update CEE checklist item doclinks into PDC table
	 * @param userId String
	 * @param password String
	 * @return String
	 * @throws PDConfigException
	 */
	public CEESInterfaceResult updateCEEChecklistItem(String userId, String password, int ecmsProjectNum, String ceeItemNumber,
			String clItemNumber, String actionDate, String clApprBy, String ceeDocLink)  
			throws Exception {		
		
        CEESInterfaceResult result = new CEESInterfaceResult();
		
		if (pdEnv == null) {
			try {
				pdEnv = this.getEnvironment(); 
			}  catch (Exception e) {
				terminateEnvironment(pdEnv, false); 
				result.setResult("FAILED");
				result.setErrorMessage(e.getMessage());
				return result;
			}			
		}
		
		try  {
			setDefaultUser(pdEnv);
			validateCEEUser(userId, password);
			
			boolean b = processCEEUpdate(userId, ecmsProjectNum, ceeItemNumber, clItemNumber, getDate(actionDate), clApprBy, ceeDocLink).booleanValue();
			result.setCeeItemQueued(b);
			result.setResult("SUCCESS");
			terminateEnvironment(pdEnv, true); //commit DB2 data

		} catch (EXCOMSecurityException e) {
			terminateEnvironment(pdEnv, false); //close DB2 connections - no commit
			result.setResult("ERROR");
			result.setErrorMessage(e.getMessage());

		} catch (EXPDCException e) {			
			terminateEnvironment(pdEnv, false); //close DB2 connections - no commit
			result.setResult("ERROR");
			result.setErrorMessage(e.getMessage());

		} catch (Exception e) {
			terminateEnvironment(pdEnv, false); //close DB2 connections - no commit
			result.setResult("FAILED");
			result.setErrorMessage(e.getMessage());
		}
		return result;
	
	}// end method
	
	/**
	 * Returns the passed string as a PDDate.
	 * 
	 * @throws EXPDCException when the date string is invalid
	 */
	private PDDate getDate(String date) throws EXPDCException {
		try {
			return new PDDate(PDUtil.getParameterDate(date, "yyyy/MM/dd"), "yyyy/MM/dd");
		} catch (Exception e) {
			throw new EXPDCException(e.getMessage());
		}
	}
	/**
	 * Validates that user passes security. Compares userid to userid on GPC table
	 * @param userId
	 * @param password
	 * @throws Exception
	 * @throws EXCOMSecurityException
	 */
	private void validateCEEUser(String userId, String password) throws Exception, EXCOMSecurityException {
						
		if (boCOMCodeReference == null) {
			
			boCOMCodeReference = new BOCOMCodeReference(pdEnv);
			
		}		
		
		String validUserId = boCOMCodeReference.getGPCValue(PDC_CEE_USERID_GPC_CODE, PDC_GENERAL_SYSTEM_CODE);		
		String validPassword = boCOMCodeReference.getGPCValue(PDC_CEE_PASSWORD_GPC_CODE, PDC_GENERAL_SYSTEM_CODE);
				
		if (userId.equals(validUserId) && password.equals(validPassword)) {			
			//continue			
		} else {
			throw new EXCOMSecurityException(" Invalid userId or password ");			
		}
		
	} //end method
	
	/**
	 * Calls BOPDCItemList to process the CEE Item record update/insert
	 * 
	 * @param userId
	 * @param ecmsProjectNum
	 * @param ceeItemNumber
	 * @param clItemNumber
	 * @param actionDate
	 * @param clApprBy
	 * @param ceeDocLink
	 * @param action
	 * @throws Exception
	 * @throws EXPDCException
	 */
	private Boolean processCEEUpdate(String userId,int ecmsProjectNum, String ceeItemNumber,
			String clItemNumber, PDDate actionDate, String clApprBy, String ceeDocLink) throws Exception,
								EXPDCException {
		
		PDNumber clItemNumberPD = null;		
		
		if (boCOMCodeReference == null) {			
			boCOMCodeReference = new BOCOMCodeReference(pdEnv);			
		}		
		
		String gpcItemNumber = boCOMCodeReference.getGPCValue(clItemNumber, PDC_CEE_CHECKLIST_ITEM_CODE);	
		
		if (gpcItemNumber == null) {
			throw new EXPDCException(" Invalid CL Item Number ");	
		} else {
			Integer intClItemNumber = new Integer(gpcItemNumber);
			clItemNumberPD = new PDNumber(intClItemNumber.intValue());
		}		
		
		PDNumber ecmsProjectNumPD = new PDNumber(ecmsProjectNum);
		BOPDCItemList boPDCItemList = new BOPDCItemList(pdEnv);
		
		return boPDCItemList.processCEES(ecmsProjectNumPD, clItemNumberPD, ceeItemNumber, actionDate, clApprBy, ceeDocLink);
		
	} //end method
	
	

} // end class

