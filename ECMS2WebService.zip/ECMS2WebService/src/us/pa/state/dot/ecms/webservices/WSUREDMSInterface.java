package us.pa.state.dot.ecms.webservices;



import java.sql.Date;
import java.util.Calendar;

import us.pa.state.dot.ecms.business.BOCOMCodeReference;
import us.pa.state.dot.ecms.business.BOPDCItemList;
import us.pa.state.dot.ecms.exception.EXCOMSecurityException;
import us.pa.state.dot.ecms.exception.EXPDCException;
import us.pa.state.dot.framework.environment.PDEnvironment;
import us.pa.state.dot.framework.exception.PDConfigException;
import us.pa.state.dot.framework.util.PDDate;
import us.pa.state.dot.framework.util.PDNumber;
import us.pa.state.dot.framework.util.PDUtil;

public class WSUREDMSInterface extends ECMSWebService {
	
	//Constants
	private static final String PDC_GENERAL_SYSTEM_CODE					= "926";
	private static final String PDC_UREDMS_USERID_GPC_CODE				= "05";
	private static final String PDC_UREDMS_PASSWORD_GPC_CODE			= "06";
	private static final String PDC_UREDMS_CHECKLIST_ITEM_CODE			= "717"; 
	
	
	//Business Objects
	private BOCOMCodeReference boCOMCodeReference = null;
	
	public WSUREDMSInterface() throws Exception {
		
		super();		
		
	}
	
	public WSUREDMSInterface(PDEnvironment pdEnv) throws Exception {
		
		super();		
		
	}
	
	/**
	 * Method to insert/update uredms checklist item doclinks into PDC table
	 * @param userId String
	 * @param password String
	 * @return String
	 * @throws PDConfigException
	 */
	public UREDMSInterfaceResult updateUREDMSChecklistItem(String userId, String password, int ecmsProjectNum,
			String clItemNumber, String actionDate, String fhwaDate, String clApprBy, String edmsDocLink, String edmsDocName)  
			throws Exception {		
		
        UREDMSInterfaceResult result = new UREDMSInterfaceResult();
		 
		if (pdEnv == null) {
			try {
				pdEnv = this.getEnvironment(); 
			}  catch (Exception e) {
				terminateEnvironment(pdEnv, false); 
				result.setResult("FAILED");
				result.setErrorMessage(e.getMessage());
				return result;
			}			
		}
		
		try  {
			setDefaultUser(pdEnv);
			validateUser(userId, password);
			
			processUREDMSUpdate(userId, ecmsProjectNum,clItemNumber, getDate(actionDate), getDate(fhwaDate),clApprBy, edmsDocLink, edmsDocName);
			
			result.setItemQueued(false);
			
			result.setResult("SUCCESS");
			terminateEnvironment(pdEnv, true); //commit DB2 data		

		} catch (EXCOMSecurityException e) {
			terminateEnvironment(pdEnv, false); //close DB2 connections - no commit
			result.setResult("ERROR");
			result.setErrorMessage(e.getMessage());

		} catch (EXPDCException e) {			
			terminateEnvironment(pdEnv, false); //close DB2 connections - no commit
			result.setResult("ERROR");
			result.setErrorMessage(e.getMessage());

		} catch (Exception e) {
			terminateEnvironment(pdEnv, false); //close DB2 connections - no commit
			result.setResult("FAILED");
			result.setErrorMessage(e.getMessage());
		}
		return result;
	
	}// end method
	
	/**
	 * Returns the passed string as a PDDate.
	 * 
	 * @throws EXPDCException when the date string is invalid
	 */
	private PDDate getDate(String date) throws EXPDCException {
		
		if (date == null || date.trim().equals("")) {
			
			PDDate returnDate = null;
			return returnDate;
			
		}
				
		try {
			return new PDDate(PDUtil.getParameterDate(date, "yyyy/MM/dd"), "yyyy/MM/dd");
		} catch (Exception e) {
			throw new EXPDCException(e.getMessage());
		}
	}
	/**
	 * Validates that user passes security. Compares userid to userid on GPC table 
	 * @param userId
	 * @param password
	 * @throws Exception
	 * @throws EXCOMSecurityException
	 */
	private void validateUser(String userId, String password) throws Exception, EXCOMSecurityException {
						
		if (boCOMCodeReference == null) {
			
			boCOMCodeReference = new BOCOMCodeReference(pdEnv);
			
		}		
		
		String validUserId = boCOMCodeReference.getGPCValue(PDC_UREDMS_USERID_GPC_CODE, PDC_GENERAL_SYSTEM_CODE);		
		String validPassword = boCOMCodeReference.getGPCValue(PDC_UREDMS_PASSWORD_GPC_CODE, PDC_GENERAL_SYSTEM_CODE);
				
		if (userId.equals(validUserId) && password.equals(validPassword)) {			
			//continue			
		} else {
			throw new EXCOMSecurityException(" Invalid userId or password ");			
		}
		
	} //end method
	
	
	/**
	 * Processes the logic to update UREDMS PDC checklist item
	 * @param userId
	 * @param ecmsProjectNum
	 * @param clItemNumber
	 * @param actionDate
	 * @param fhwaDate
	 * @param clApprBy
	 * @param edmsDocLink
	 * @param edmsDocName
	 * @throws Exception
	 * @throws EXPDCException
	 */
	private void processUREDMSUpdate(String userId,int ecmsProjectNum, 
			String clItemNumber, PDDate actionDate, PDDate fhwaDate, String clApprBy, String edmsDocLink, String edmsDocName) throws Exception,
								EXPDCException {
		
		PDNumber clItemNumberPD = null;		
		
		if (boCOMCodeReference == null) {			
			boCOMCodeReference = new BOCOMCodeReference(pdEnv);			
		}		
		
		String gpcItemNumber = boCOMCodeReference.getGPCValue(clItemNumber, PDC_UREDMS_CHECKLIST_ITEM_CODE);	
		
		if (gpcItemNumber == null) {
			throw new EXPDCException(" Invalid CL Item Number ");	
		} else {
			Integer intClItemNumber = new Integer(gpcItemNumber);
			clItemNumberPD = new PDNumber(intClItemNumber.intValue());
		}		
		
		PDNumber ecmsProjectNumPD = new PDNumber(ecmsProjectNum);
		BOPDCItemList boPDCItemList = new BOPDCItemList(pdEnv);
		
	
		boPDCItemList.processUREDMS(ecmsProjectNumPD, clItemNumberPD, actionDate, fhwaDate, clApprBy, edmsDocLink, edmsDocName);
		
		
		
	} //end method
	
	

} // end class

