package us.pa.state.dot.ecms.webservices;

public class UREDMSInterfaceResult {

	private String result = "";
	private String errorMessage = "";
	private boolean itemQueued = false;
	
	public UREDMSInterfaceResult() {
		
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String message) {
		this.errorMessage = message;
	}

	public boolean getItemQueued() {
		return itemQueued;
	}

	public void setItemQueued(boolean found) {
		this.itemQueued = found;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

}
