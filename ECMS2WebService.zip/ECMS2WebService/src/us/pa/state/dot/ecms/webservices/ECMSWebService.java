package us.pa.state.dot.ecms.webservices;


import us.pa.state.dot.ecms.business.BOCOMUser;
import us.pa.state.dot.framework.environment.PDEnvironment;
import us.pa.state.dot.framework.environment.PDWebServiceEnvironment;
import us.pa.state.dot.framework.webservice.PDWebServiceObject;

public abstract class ECMSWebService extends PDWebServiceObject {
	
	protected PDWebServiceEnvironment pdEnv = null;	
	
	public ECMSWebService() throws Exception {
		
		super();		
		
	}
	
	public ECMSWebService(PDEnvironment pdEnv) throws Exception {
		
		super();		
		
	}
	
	/**
	 * Sets default user in PDEnv
	 * 
	 * @param pdEnv
	 * @throws Exception
	 */
	protected void setDefaultUser(PDWebServiceEnvironment pdEnv) throws Exception {
		//Instantiate a new user 
		BOCOMUser boUser = new BOCOMUser(pdEnv);
		//initialize the user
		boUser.getBatchUser();
		//set user into the environment
		pdEnv.setUser(boUser);
	}
	

} // end class

