CREATE PROCEDURE ECMSXADM.SPSAP05A (IN IN_ECMS_TRANSACTION_ID INTEGER)

	RESULT SETS 1
	LANGUAGE SQL
	QUALIFIER ECMSXADM
	ISOLATION LEVEL CS
	VALIDATE BIND
	PACKAGE OWNER HWYDEV
	WLM ENVIRONMENT FOR DEBUG MODE DSNDWLM2
	ASUTIME LIMIT 5000
	ALLOW DEBUG MODE
	
	
	P1: BEGIN

/************************************/
/* SQL VARIABLE DECLARATIONS        */
/************************************/

 DECLARE SQLSTATE       CHAR(5) DEFAULT '00000';
 DECLARE SQLCODE        INT DEFAULT 0;
 DECLARE ERRLOC         CHAR(4);
 DECLARE ERRCODE        INTEGER;
 DECLARE TRANS_AGR      CHAR(6);
 DECLARE TRANS_INV_ID   INTEGER;
 DECLARE TRANS_PAYMENT_AMT DEC(15, 2);

 DECLARE INVLOOP_AGR    CHAR(6);
 DECLARE INVLOOP_INV_ID INTEGER;
 DECLARE INVLOOP_LEVEL  INTEGER;
 DECLARE INVLOOP_PART_ID SMALLINT;
 DECLARE INVLOOP_HIGHEST_SUPPL_ID SMALLINT;
 DECLARE INVLOOP_ASSOC_HIERARCHY_ID INTEGER;
 DECLARE INVLOOP_INV_TOTAL_OTHER_COSTS_AMT DEC(13,2);
 DECLARE INVLOOP_OVERHEAD_DOLLARS_ADJUST_AMT DEC(13,2);
 DECLARE INVLOOP_AUDIT_DIRECT_PAYROLL_AMT DEC(13,2);

 DECLARE PAYRLOOP_TASK_ID      SMALLINT;
 DECLARE PAYRLOOP_INV_LINE_TOTAL_AMT DEC(13,2);
 DECLARE PAYRLOOP_INTERNAL_ORDER  CHAR(5);
 DECLARE PAYRLOOP_INTERNAL_ORDER_FUNDING_ID INTEGER;

 DECLARE PERCLOOP_TASK_ID      SMALLINT;
 DECLARE PERCLOOP_INV_LINE_TOTAL_AMT DEC(13,2);
 DECLARE PERCLOOP_INTERNAL_ORDER  CHAR(5);
 DECLARE PERCLOOP_INTERNAL_ORDER_FUNDING_ID INTEGER;
 
 DECLARE BGTCOSTLOOP_INV_TOTAL DEC(17,2);
 DECLARE BGTCOSTLOOP_PHASE_ID CHAR(2);
 DECLARE BGTCOSTLOOP_INTERNAL_ORDER_FUNDING_ID INTEGER;
 DECLARE BGTCOSTLOOP_INTERNAL_ORDER  CHAR(5);
 DECLARE OUT_GEN_CODE_VALUE_BGT      CHAR(3);

 DECLARE UOWTASKLOOP_TASK_ID    SMALLINT;
 DECLARE UOWTASKLOOP_LABOR_TASK_SUM DEC(13,2);
 DECLARE UOWTASKLOOP_TASK_AMOUNT    DEC(13,2);
 DECLARE UOWTASKLOOP_INTERNAL_ORDER  CHAR(5);
 DECLARE UOWTASKLOOP_INTERNAL_ORDER_FUNDING_ID INTEGER;

 DECLARE UOWLOOP_UNIT_OF_WORK_NBR    SMALLINT;
 DECLARE UOWLOOP_UNITS_CLAIMED       DEC(7, 2);
 DECLARE UOWLOOP_INV_LINE_TOTAL_AMT  DEC(13, 2);
 DECLARE TOTAL_LABOR_UOW_AMOUNT     DEC(13, 2);
 DECLARE RECL_TOTAL_PAYMENT         DEC(13,2);
 DECLARE MIN_FUNDING_AMT            DEC(13,2);
 DECLARE  MIN_INTERNAL_ORDER_FUNDING_ID INTEGER;
 DECLARE OVERAGE_AMT                DEC(13,2);

 DECLARE OUT_GEN_CODE_VALUE_OTH      CHAR(5);
 DECLARE OUT_GEN_CODE_VALUE_OVH      CHAR(5);
 DECLARE OUT_GEN_CODE_VALUE_AUD      CHAR(5);
 DECLARE OUT_INTERNAL_ORDER_FUNDING_ID INTEGER;

/************************************************/
/* INITIALIZE                                   */
/************************************************/

  -- Declare return cursor
    DECLARE SINGLE_PARM_CURSOR CURSOR WITH RETURN
       FOR
     SELECT SQLCODE,
            SQLSTATE,
            ERRLOC,
            ERRCODE
       FROM SYSIBM.SYSDUMMY1;

   -- Declare outer Loop Cursor to fetch each 
   --Invoice that is associated with the primes invoice

   DECLARE INV_OUTER_LOOP CURSOR WITH RETURN
     FOR
      WITH RPL
       ( LEVEL,
         AGR,
         INV_ID ) AS
       ( SELECT 0,
            ROOT.AGR,
            ROOT.INV_ID
     FROM INV_HIERARCHY ROOT
     WHERE AGR = TRANS_AGR
      AND INV_ID = TRANS_INV_ID
   UNION ALL
     SELECT PARENT.LEVEL + 1,
            CHILD.AGR,
            CHILD.INV_ID
     FROM RPL PARENT, INV_HIERARCHY CHILD
     WHERE PARENT.AGR = CHILD.PARENT_AGR
       AND PARENT.INV_ID = CHILD.PARENT_INV_ID
       AND PARENT.LEVEL < 5)
  SELECT LEVEL,
         AGR,
         INV_ID
  FROM RPL  ;

   -- Declare Cursor used for Payroll items... 
   --This is used in the first Inner Loop PAYRLOOP
 DECLARE PAYROLL_LEVEL2_LOOP CURSOR WITH RETURN
     FOR
   SELECT TASK_ID, SUM(INV_LINE_TOTAL_AMT)
     FROM INV_EMPLOYEE_DETAIL
    WHERE AGR = TRANS_AGR
      AND INV_ID = INVLOOP_INV_ID
    GROUP BY TASK_ID;

   -- Declare Cursor used for Percent Complete items... 
   --This is used in the third Inner Loop PERCLOOP
 DECLARE PERC_COMPL_LEVEL2_LOOP CURSOR WITH RETURN
     FOR
   SELECT TASK_ID, SUM(INV_LINE_TOTAL_AMT)
     FROM INV_PERCENT_COMPLETE_DETAIL
    WHERE AGR = TRANS_AGR
      AND INV_ID = INVLOOP_INV_ID
    GROUP BY TASK_ID;
    
   -- Declare Cursor used for Budget Phases... 
   --This is used in the third Inner Loop PERCLOOP
 DECLARE BGT_COST_LEVEL2_LOOP CURSOR WITH RETURN
     FOR
   SELECT INV_TOTAL, PHASE_ID
     FROM INV_BGT_PHASE
    WHERE AGR = TRANS_AGR
      AND INV_ID = INVLOOP_INV_ID;

    -- Declare Cursor used for Unit of Work items... 
    --This is used in the third Inner Loop UOWLOOP
 DECLARE UNIT_OF_WORK_LEVEL2_LOOP CURSOR WITH RETURN
     FOR
   SELECT UNIT_OF_WORK_NBR, UNITS_CLAIMED, INV_LINE_TOTAL_AMT
     FROM INV_COST_PER_UNIT_DETAIL
    WHERE AGR = TRANS_AGR
      AND INV_ID = INVLOOP_INV_ID;

    -- Declare lower level (Level 3) Cursor used for Unit of Work items... 
    --This is used inside the third Inner Loop UOWLOOP
    -- For each Unit of Work Number retrieved in the UOWLOOP, 
    --have a lower level loop that gets each task id for the given UOW#
  DECLARE UOW_TASK_INNER_LOOP CURSOR WITH RETURN
     FOR
    SELECT DISTINCT CST.TASK_ID
      FROM CST_LABOR_TASK_UNITS_OF_WORK CST,
           CST_COST_ESTIMATE COS,
           SOW_DETAIL SOW
     WHERE CST.AGR = SOW.AGR
       AND CST.AGR = COS.AGR
       AND CST.AGR = TRANS_AGR
       AND COS.SOW_ID = CST.SOW_ID
       AND COS.CST_EST_ID = CST.CST_EST_ID
       AND CST.SOW_ID = SOW.SOW_ID
       AND CST.SOW_DETAIL_ID = SOW.SOW_DETAIL_ID
       AND COS.ASSOC_HIERARCHY_ID = INVLOOP_ASSOC_HIERARCHY_ID
       AND (COALESCE(SOW.PART_ID,0) = INVLOOP_PART_ID) 
       AND COALESCE(SOW.SUPPL_ID,0) <= INVLOOP_HIGHEST_SUPPL_ID
       AND COALESCE(SOW.AMEND_ID,0) <= INVLOOP_HIGHEST_SUPPL_ID
       AND CST.VERSION_ID = 0
       AND CST.UNIT_OF_WORK_NBR = UOWLOOP_UNIT_OF_WORK_NBR
       FETCH FIRST 1 ROW ONLY;

       -- Initialize return values
   SET ERRCODE = -1;
   SET ERRLOC = '0001';
   SET RECL_TOTAL_PAYMENT = 0;
   SET OVERAGE_AMT = 0;
   
   
/************************************************/
/* GET INFO FROM ECMS Transaction               */
/************************************************/


 SELECT AGR,
        INV_ID,
        TOTAL_PAYMENT_AMT
   INTO TRANS_AGR,
        TRANS_INV_ID,
        TRANS_PAYMENT_AMT
   FROM SAP_ECMS_TRANSACTION
  WHERE ECMS_TRANSACTION_ID = IN_ECMS_TRANSACTION_ID ;


/************************************************/
/* DELETE FROM INTERNAL ORDER TABLE FOR THIS    */
/* AGR/INV ID                                    */
/************************************************/
   SET ERRLOC = '0002';

   DELETE FROM INV_INTERNAL_ORDER_FUNDING
     WHERE AGR = TRANS_AGR
       AND INV_ID = TRANS_INV_ID;
   

/***********************************************************/
/* Open Level 1 (Outer) Invoice cursor... gets all invoices*/
/*    related to the parent/prime invoice id               */
/***********************************************************/

 SET ERRLOC = '0003';

 OPEN INV_OUTER_LOOP;

 SET ERRLOC = '0004';

 INVLOOP: LOOP

   FETCH INV_OUTER_LOOP
       INTO INVLOOP_LEVEL,
            INVLOOP_AGR,
            INVLOOP_INV_ID;
   IF SQLCODE = 100 THEN LEAVE INVLOOP;
   END IF;
   SET ERRLOC = '0005';
   -- Get the other columns needed from INV_HIERARCHY
   SELECT  PART_ID,
           COALESCE(HIGHEST_SUPPL_ID, 0),
           ASSOC_HIERARCHY_ID,
           (COALESCE(INV_TOTAL_OTHER_COSTS_AMT,0) + 
           COALESCE(INV_TOTAL_PDA_AMT,0)),
           COALESCE(OVERHEAD_DOLLARS_ADJUST_AMT,0),
           COALESCE(AUDIT_DIRECT_PAYROLL_AMT,0)
      INTO INVLOOP_PART_ID,
           INVLOOP_HIGHEST_SUPPL_ID,
           INVLOOP_ASSOC_HIERARCHY_ID,
           INVLOOP_INV_TOTAL_OTHER_COSTS_AMT,
           INVLOOP_OVERHEAD_DOLLARS_ADJUST_AMT,
           INVLOOP_AUDIT_DIRECT_PAYROLL_AMT
      FROM INV_HIERARCHY
     WHERE AGR = INVLOOP_AGR
       AND INV_ID = INVLOOP_INV_ID;

   -- Get SOW_ID and SOW_DETAIL_ID from SOW_DETAIL table
   -- for either a part or a work order depending on which
   -- one the invoice is for

   SET ERRLOC = '0006';


   -- Get CST_EST_ID from CST_Cost_Estimate table
   -- for the business partner id we're dealing with

   SET ERRLOC = '0007';

/****************************************************/
/*  First Level 2 Loop ....This section gets internal*/
/*    orders related to payroll tasks for an invoice*/
/****************************************************/

  SET ERRLOC = '0008';

  OPEN PAYROLL_LEVEL2_LOOP;

   PAYRLOOP: LOOP

       SET ERRLOC = '0009';

       FETCH PAYROLL_LEVEL2_LOOP
        INTO PAYRLOOP_TASK_ID,
             PAYRLOOP_INV_LINE_TOTAL_AMT ;

       IF SQLCODE = 100 THEN LEAVE PAYRLOOP;
       END IF;

      -- Get Internal Order for this Task ID

       SET ERRLOC = '0010';

         SELECT DISTINCT INTERNAL_ORDER
           INTO PAYRLOOP_INTERNAL_ORDER
           FROM SOW_MAIN_TASK TSK, SOW_DETAIL DET
          WHERE TSK.AGR = TRANS_AGR
            AND TSK.AGR = DET.AGR
            AND TSK.SOW_ID = DET.SOW_ID
            AND TSK.SOW_DETAIL_ID = DET.SOW_DETAIL_ID
            AND DET.PART_ID = INVLOOP_PART_ID
            AND COALESCE(DET.SUPPL_ID,0) <= INVLOOP_HIGHEST_SUPPL_ID
            AND TASK_ID = PAYRLOOP_TASK_ID
            FETCH FIRST 1 ROW ONLY;


      -- Get Next available Internal Order Funding ID PK,
      -- and use it in the insert to Internal Order Funding
       SET ERRLOC = '0011';
       SELECT COALESCE(MAX(INTERNAL_ORDER_FUNDING_ID),0)+1
         INTO PAYRLOOP_INTERNAL_ORDER_FUNDING_ID
         FROM INV_INTERNAL_ORDER_FUNDING
         WHERE AGR = TRANS_AGR
           AND INV_ID = TRANS_INV_ID ;

      -- Increment the Total Amount for reconcilation
      SET ERRLOC = '012A';
      SET RECL_TOTAL_PAYMENT = RECL_TOTAL_PAYMENT + PAYRLOOP_INV_LINE_TOTAL_AMT;

      SET ERRLOC = '012B'  ;
      IF RECL_TOTAL_PAYMENT > TRANS_PAYMENT_AMT THEN
          SET OVERAGE_AMT = RECL_TOTAL_PAYMENT - TRANS_PAYMENT_AMT ;
          SET PAYRLOOP_INV_LINE_TOTAL_AMT = 
                                   PAYRLOOP_INV_LINE_TOTAL_AMT - OVERAGE_AMT ;
          SET RECL_TOTAL_PAYMENT = RECL_TOTAL_PAYMENT - OVERAGE_AMT;
      END IF;


      -- Insert Payroll Internal Order Info into INV_INTERNAL_ORDER_FUNDING
       SET ERRLOC = '0012';
       INSERT INTO INV_INTERNAL_ORDER_FUNDING
         (AGR,
          INV_ID,
          INTERNAL_ORDER_FUNDING_ID,
          TASK_ID,
          DETAIL_TASK_ID,
          INTERNAL_ORDER,
          FUNDING_AMT)
       VALUES
         (TRANS_AGR,
          TRANS_INV_ID,
          PAYRLOOP_INTERNAL_ORDER_FUNDING_ID,
          PAYRLOOP_TASK_ID,
          NULL,
          PAYRLOOP_INTERNAL_ORDER,
          PAYRLOOP_INV_LINE_TOTAL_AMT) ;


   END LOOP PAYRLOOP;

   SET ERRLOC = '0013';
   CLOSE PAYROLL_LEVEL2_LOOP;

/****************************************************/
/*  End of First Level 2 Loop                       */
/****************************************************/


/****************************************************************/
/*  Second Level 2 Loop....This section gets internal           */
/*    orders related to Units of Work tasks for an invoice      */
/****************************************************************/

   SET ERRLOC = '0014';

   OPEN UNIT_OF_WORK_LEVEL2_LOOP;

   UOWLOOP:  LOOP
       SET ERRLOC = '0015';

       FETCH UNIT_OF_WORK_LEVEL2_LOOP
         INTO UOWLOOP_UNIT_OF_WORK_NBR,
              UOWLOOP_UNITS_CLAIMED,
              UOWLOOP_INV_LINE_TOTAL_AMT;



       IF SQLCODE = 100 THEN LEAVE UOWLOOP;
       END IF;

       SET ERRLOC = '015B' ;
       SET TOTAL_LABOR_UOW_AMOUNT = 0;

/****************************************************************/
/*  Level 3 Inner Loop....This section gets task id's for each  */
/*    unit of work number fetched by the 2nd Level 2 Loop       */
/****************************************************************/
       SET ERRLOC = '0016';
       OPEN UOW_TASK_INNER_LOOP;


       UOWTASKLOOP:  LOOP

        -- Get Task ID from cross reference table
            SET ERRLOC = '0017';
            FETCH UOW_TASK_INNER_LOOP
             INTO UOWTASKLOOP_TASK_ID;

            IF SQLCODE = 100 THEN LEAVE UOWTASKLOOP;
            END IF;

       -- Calculate Task Amount
             SET ERRLOC = '0019';
             SET UOWTASKLOOP_TASK_AMOUNT = UOWLOOP_INV_LINE_TOTAL_AMT   ;



       -- Get Internal Order for this Task ID
             SET ERRLOC = '0020';

               SELECT DISTINCT INTERNAL_ORDER
                 INTO UOWTASKLOOP_INTERNAL_ORDER
                 FROM SOW_MAIN_TASK TSK, SOW_DETAIL DET
                WHERE TSK.AGR = TRANS_AGR
                  AND TSK.AGR = DET.AGR
                  AND TSK.SOW_ID = DET.SOW_ID
                  AND TSK.SOW_DETAIL_ID = DET.SOW_DETAIL_ID
                  AND DET.PART_ID = INVLOOP_PART_ID
                  AND COALESCE(DET.SUPPL_ID,0) <= INVLOOP_HIGHEST_SUPPL_ID
                  AND TASK_ID = UOWTASKLOOP_TASK_ID
                  FETCH FIRST 1 ROW ONLY;

      -- Get Next available Internal Order Funding ID PK,
      -- and use it in the insert to Internal Order Funding
             SET ERRLOC = '0021';
             SELECT COALESCE(MAX(INTERNAL_ORDER_FUNDING_ID),0)+1
               INTO UOWTASKLOOP_INTERNAL_ORDER_FUNDING_ID
               FROM INV_INTERNAL_ORDER_FUNDING
              WHERE AGR = TRANS_AGR
                AND INV_ID = TRANS_INV_ID ;

      -- Increment Total UOW Labor Amount
             SET ERRLOC = '021B';
             SET TOTAL_LABOR_UOW_AMOUNT = 
                                       TOTAL_LABOR_UOW_AMOUNT + 
                                                   UOWTASKLOOP_TASK_AMOUNT;

       -- Increment the Total Amount for reconcilation
            SET ERRLOC = '022A';
            SET RECL_TOTAL_PAYMENT = 
                               RECL_TOTAL_PAYMENT + UOWTASKLOOP_TASK_AMOUNT;

            SET ERRLOC = '022B'  ;
            IF RECL_TOTAL_PAYMENT > TRANS_PAYMENT_AMT THEN
               SET OVERAGE_AMT = RECL_TOTAL_PAYMENT - TRANS_PAYMENT_AMT ;
               SET UOWTASKLOOP_TASK_AMOUNT =
                                        UOWTASKLOOP_TASK_AMOUNT - OVERAGE_AMT ;
               SET RECL_TOTAL_PAYMENT = RECL_TOTAL_PAYMENT - OVERAGE_AMT;
            END IF;


      -- Insert Payroll Internal Order Info into INV_INTERNAL_ORDER_FUNDING
             SET ERRLOC = '0022';
             INSERT INTO INV_INTERNAL_ORDER_FUNDING
               (AGR,
                INV_ID,
                INTERNAL_ORDER_FUNDING_ID,
                TASK_ID,
                DETAIL_TASK_ID,
                INTERNAL_ORDER,
                FUNDING_AMT)
             VALUES
               (TRANS_AGR,
                TRANS_INV_ID,
                UOWTASKLOOP_INTERNAL_ORDER_FUNDING_ID,
                UOWTASKLOOP_TASK_ID,
                null,
                UOWTASKLOOP_INTERNAL_ORDER,
                UOWTASKLOOP_TASK_AMOUNT) ;

       END LOOP UOWTASKLOOP;
       SET ERRLOC = '0023';
       CLOSE UOW_TASK_INNER_LOOP;

/****************************************************/
/*  End of Inner Loop                               */
/****************************************************/


    -- Increment total other costs amount if there is
    -- UOW costs that are not applied to Labor
    SET ERRLOC = '023B';
    SET INVLOOP_INV_TOTAL_OTHER_COSTS_AMT = INVLOOP_INV_TOTAL_OTHER_COSTS_AMT + 
                         (UOWLOOP_INV_LINE_TOTAL_AMT - TOTAL_LABOR_UOW_AMOUNT);
   END LOOP UOWLOOP;
   SET ERRLOC = '0024';
   CLOSE UNIT_OF_WORK_LEVEL2_LOOP;

/****************************************************/
/*  End of Second Level 2 Loop                      */
/****************************************************/

/****************************************************************/
/*  Third Level 2 Loop....This section gets internal            */
/*    orders related to percentage complete tasks for an invoice*/
/****************************************************************/

   SET ERRLOC = '0025';

   OPEN PERC_COMPL_LEVEL2_LOOP;

   PERCLOOP: LOOP
       SET ERRLOC = '0026';
       FETCH PERC_COMPL_LEVEL2_LOOP
         INTO PERCLOOP_TASK_ID,
              PERCLOOP_INV_LINE_TOTAL_AMT ;

       IF SQLCODE = 100 THEN LEAVE PERCLOOP;
       END IF;

      -- Get Internal Order for this Task ID
       SET ERRLOC = '0027';

         SELECT DISTINCT INTERNAL_ORDER
           INTO PERCLOOP_INTERNAL_ORDER
           FROM SOW_MAIN_TASK TSK, SOW_DETAIL DET
          WHERE TSK.AGR = TRANS_AGR
            AND TSK.AGR = DET.AGR
            AND TSK.SOW_ID = DET.SOW_ID
            AND TSK.SOW_DETAIL_ID = DET.SOW_DETAIL_ID
            AND DET.PART_ID = INVLOOP_PART_ID
            AND COALESCE(DET.SUPPL_ID,0) <= INVLOOP_HIGHEST_SUPPL_ID
            AND TASK_ID = PERCLOOP_TASK_ID
            FETCH FIRST 1 ROW ONLY;

      -- Get Next available Internal Order Funding ID PK,
      -- and use it in the insert to Internal Order Funding
       SET ERRLOC = '0028';
       SELECT COALESCE(MAX(INTERNAL_ORDER_FUNDING_ID),0)+1
         INTO PERCLOOP_INTERNAL_ORDER_FUNDING_ID
         FROM INV_INTERNAL_ORDER_FUNDING
         WHERE AGR = TRANS_AGR
           AND INV_ID = TRANS_INV_ID ;


       -- Increment the Total Amount for reconcilation
        SET ERRLOC = '029A';
        SET RECL_TOTAL_PAYMENT =
                           RECL_TOTAL_PAYMENT + PERCLOOP_INV_LINE_TOTAL_AMT;

        SET ERRLOC = '029B'  ;
        IF RECL_TOTAL_PAYMENT > TRANS_PAYMENT_AMT THEN
           SET OVERAGE_AMT = RECL_TOTAL_PAYMENT - TRANS_PAYMENT_AMT ;
           SET PERCLOOP_INV_LINE_TOTAL_AMT = 
                                     PERCLOOP_INV_LINE_TOTAL_AMT - OVERAGE_AMT ;
           SET RECL_TOTAL_PAYMENT = RECL_TOTAL_PAYMENT - OVERAGE_AMT;
        END IF;


      -- Insert Payroll Internal Order Info into INV_INTERNAL_ORDER_FUNDING
       SET ERRLOC = '0029';
       INSERT INTO INV_INTERNAL_ORDER_FUNDING
         (AGR,
          INV_ID,
          INTERNAL_ORDER_FUNDING_ID,
          TASK_ID,
          DETAIL_TASK_ID,
          INTERNAL_ORDER,
          FUNDING_AMT)
       VALUES
         (TRANS_AGR,
          TRANS_INV_ID,
          PERCLOOP_INTERNAL_ORDER_FUNDING_ID,
          PERCLOOP_TASK_ID,
          NULL,
          PERCLOOP_INTERNAL_ORDER,
          PERCLOOP_INV_LINE_TOTAL_AMT) ;


   END LOOP PERCLOOP;
   SET ERRLOC = '0030';
   CLOSE PERC_COMPL_LEVEL2_LOOP;

   /****************************************************/
   /*  End of Third Level 2 Loop                       */
   /****************************************************/

/****************************************************************/
/*  Third Level 2 Loop....This section gets internal            */
/*       orders related to Budget Cost for an invoice          */
/****************************************************************/
 -- Get Internal Order for this Task ID
       SET ERRLOC = '0031'||', Budget Gen Code Value';

       SELECT LEFT(GEN_CODE_VALUE,3)
       INTO OUT_GEN_CODE_VALUE_BGT
       FROM COM_GENERAL_CODE
        WHERE GEN_CODE_TYPE = 906
        AND GEN_CODE = '05';
        
 SET ERRLOC = '0032';

   OPEN BGT_COST_LEVEL2_LOOP;

   BGTCOSTLOOP: LOOP
       SET ERRLOC = '0033';
       
       FETCH BGT_COST_LEVEL2_LOOP
         INTO BGTCOSTLOOP_INV_TOTAL,
             BGTCOSTLOOP_PHASE_ID ;

       IF SQLCODE = 100 THEN LEAVE BGTCOSTLOOP;
       END IF;

      -- Get Next available Internal Order Funding ID PK,
      -- and use it in the insert to Internal Order Funding
       SET ERRLOC = '0034';
       SELECT COALESCE(MAX(INTERNAL_ORDER_FUNDING_ID),0)+1
         INTO BGTCOSTLOOP_INTERNAL_ORDER_FUNDING_ID
         FROM INV_INTERNAL_ORDER_FUNDING
         WHERE AGR = TRANS_AGR
           AND INV_ID = TRANS_INV_ID ;


       -- Increment the Total Amount for reconcilation
        SET ERRLOC = '035A';
        SET RECL_TOTAL_PAYMENT = RECL_TOTAL_PAYMENT + BGTCOSTLOOP_INV_TOTAL;

        SET ERRLOC = '035B'  ;
        IF RECL_TOTAL_PAYMENT > TRANS_PAYMENT_AMT THEN
           SET OVERAGE_AMT = RECL_TOTAL_PAYMENT - TRANS_PAYMENT_AMT ;
           SET BGTCOSTLOOP_INV_TOTAL = BGTCOSTLOOP_INV_TOTAL - OVERAGE_AMT ;
           SET RECL_TOTAL_PAYMENT = RECL_TOTAL_PAYMENT - OVERAGE_AMT;
        END IF;

       SET BGTCOSTLOOP_INTERNAL_ORDER =
                   OUT_GEN_CODE_VALUE_BGT || CHAR(BGTCOSTLOOP_PHASE_ID);
      -- Insert Payroll Internal Order Info into INV_INTERNAL_ORDER_FUNDING
       SET ERRLOC = '0035';
       INSERT INTO INV_INTERNAL_ORDER_FUNDING
         (AGR,
          INV_ID,
          INTERNAL_ORDER_FUNDING_ID,
          TASK_ID,
          DETAIL_TASK_ID,
          INTERNAL_ORDER,
          FUNDING_AMT)
       VALUES
         (TRANS_AGR,
          TRANS_INV_ID,
          BGTCOSTLOOP_INTERNAL_ORDER_FUNDING_ID,
          NULL,
          NULL,
          BGTCOSTLOOP_INTERNAL_ORDER,
          BGTCOSTLOOP_INV_TOTAL) ;


   END LOOP BGTCOSTLOOP;
   SET ERRLOC = '0036';
   CLOSE BGT_COST_LEVEL2_LOOP;


   /****************************************************/
   /*  End of fourth Level 2 Loop                      */
   /****************************************************/

/****************************************************/
/*  Process non-task related Internal Order funding */
/*     one for Other Costs, one for Overhead Rate   */
/*     change and one for Audit                     */
/****************************************************/

 -- Get Internal Order numbers from GPC for Other Costs

 SET ERRLOC = '0037';

 SELECT LEFT(GEN_CODE_VALUE,5)
   INTO OUT_GEN_CODE_VALUE_OTH
   FROM COM_GENERAL_CODE
  WHERE GEN_CODE_TYPE = 906
    AND GEN_CODE = '01';

 -- Get Internal Order numbers from GPC for Overhead Rate Change

 SET ERRLOC = '0038';

 SELECT LEFT(GEN_CODE_VALUE,5)
   INTO OUT_GEN_CODE_VALUE_OVH
   FROM COM_GENERAL_CODE
  WHERE GEN_CODE_TYPE = 906
    AND GEN_CODE = '02';


 -- Get Internal Order numbers from GPC for Audit

 SET ERRLOC = '0039';

 SELECT LEFT(GEN_CODE_VALUE,5)
   INTO OUT_GEN_CODE_VALUE_AUD
   FROM COM_GENERAL_CODE
  WHERE GEN_CODE_TYPE = 906
    AND GEN_CODE = '03';


 -- Insert for Other Costs
 SET ERRLOC = '0040';
 SELECT COALESCE(MAX(INTERNAL_ORDER_FUNDING_ID),0)+1
   INTO OUT_INTERNAL_ORDER_FUNDING_ID
   FROM INV_INTERNAL_ORDER_FUNDING
  WHERE AGR = TRANS_AGR
    AND INV_ID = TRANS_INV_ID ;


  -- Increment the Total Amount for reconcilation
    SET ERRLOC = '041A';
    SET RECL_TOTAL_PAYMENT = 
                      RECL_TOTAL_PAYMENT + INVLOOP_INV_TOTAL_OTHER_COSTS_AMT;

    SET ERRLOC = '041B'  ;
    IF RECL_TOTAL_PAYMENT > TRANS_PAYMENT_AMT THEN
        SET OVERAGE_AMT = RECL_TOTAL_PAYMENT - TRANS_PAYMENT_AMT ;
        SET INVLOOP_INV_TOTAL_OTHER_COSTS_AMT =
                              INVLOOP_INV_TOTAL_OTHER_COSTS_AMT - OVERAGE_AMT ;
        SET RECL_TOTAL_PAYMENT = RECL_TOTAL_PAYMENT - OVERAGE_AMT;
    END IF;

 SET ERRLOC = '0041';
 IF INVLOOP_INV_TOTAL_OTHER_COSTS_AMT <> 0 THEN
     INSERT INTO INV_INTERNAL_ORDER_FUNDING
         (AGR,
          INV_ID,
          INTERNAL_ORDER_FUNDING_ID,
          TASK_ID,
          DETAIL_TASK_ID,
          INTERNAL_ORDER,
          FUNDING_AMT)
       VALUES
         (TRANS_AGR,
          TRANS_INV_ID,
          OUT_INTERNAL_ORDER_FUNDING_ID,
          NULL,
          NULL,
          OUT_GEN_CODE_VALUE_OTH,
          INVLOOP_INV_TOTAL_OTHER_COSTS_AMT) ;
 END IF;



 -- Insert for Overhead Rate Changes
 SET ERRLOC = '0042';
 SET OUT_INTERNAL_ORDER_FUNDING_ID = OUT_INTERNAL_ORDER_FUNDING_ID + 1 ;


  -- Increment the Total Amount for reconcilation
    SET ERRLOC = '043A';
    SET RECL_TOTAL_PAYMENT = 
                RECL_TOTAL_PAYMENT + INVLOOP_OVERHEAD_DOLLARS_ADJUST_AMT;

    SET ERRLOC = '043B'  ;
    IF RECL_TOTAL_PAYMENT > TRANS_PAYMENT_AMT THEN
        SET OVERAGE_AMT = RECL_TOTAL_PAYMENT - TRANS_PAYMENT_AMT ;
        SET INVLOOP_OVERHEAD_DOLLARS_ADJUST_AMT =
                       INVLOOP_OVERHEAD_DOLLARS_ADJUST_AMT - OVERAGE_AMT ;
        SET RECL_TOTAL_PAYMENT = RECL_TOTAL_PAYMENT - OVERAGE_AMT;
    END IF;

 SET ERRLOC = '0043';
 IF  INVLOOP_OVERHEAD_DOLLARS_ADJUST_AMT <> 0 THEN
     INSERT INTO INV_INTERNAL_ORDER_FUNDING
         (AGR,
          INV_ID,
          INTERNAL_ORDER_FUNDING_ID,
          TASK_ID,
          DETAIL_TASK_ID,
          INTERNAL_ORDER,
          FUNDING_AMT)
       VALUES
         (TRANS_AGR,
          TRANS_INV_ID,
          OUT_INTERNAL_ORDER_FUNDING_ID,
          NULL,
          NULL,
          OUT_GEN_CODE_VALUE_OVH,
          INVLOOP_OVERHEAD_DOLLARS_ADJUST_AMT) ;
 END IF;




 -- Insert for Audit Costs
 SET ERRLOC = '0044';
 SET OUT_INTERNAL_ORDER_FUNDING_ID = OUT_INTERNAL_ORDER_FUNDING_ID + 1 ;


  -- Increment the Total Amount for reconcilation
    SET ERRLOC = '045A';
    SET RECL_TOTAL_PAYMENT = 
                       RECL_TOTAL_PAYMENT + INVLOOP_AUDIT_DIRECT_PAYROLL_AMT;

    SET ERRLOC = '045B'  ;
    IF RECL_TOTAL_PAYMENT > TRANS_PAYMENT_AMT THEN
        SET OVERAGE_AMT = RECL_TOTAL_PAYMENT - TRANS_PAYMENT_AMT ;
        SET INVLOOP_AUDIT_DIRECT_PAYROLL_AMT = 
                            INVLOOP_AUDIT_DIRECT_PAYROLL_AMT - OVERAGE_AMT ;
        SET RECL_TOTAL_PAYMENT = RECL_TOTAL_PAYMENT - OVERAGE_AMT ;
    END IF;

 SET ERRLOC = '0045';
 IF  INVLOOP_AUDIT_DIRECT_PAYROLL_AMT <> 0 THEN
     INSERT INTO INV_INTERNAL_ORDER_FUNDING
         (AGR,
          INV_ID,
          INTERNAL_ORDER_FUNDING_ID,
          TASK_ID,
          DETAIL_TASK_ID,
          INTERNAL_ORDER,
          FUNDING_AMT)
       VALUES
         (TRANS_AGR,
          TRANS_INV_ID,
          OUT_INTERNAL_ORDER_FUNDING_ID,
          NULL,
          NULL,
          OUT_GEN_CODE_VALUE_AUD,
          INVLOOP_AUDIT_DIRECT_PAYROLL_AMT) ;
 END IF;

 END LOOP INVLOOP;
 SET ERRLOC = '0046';
 CLOSE INV_OUTER_LOOP;
 
 /****************************************************/
/*  End of Level 1 Outer Loop                       */
/****************************************************/

 -- Before leaving check to see
 -- if we have rounding problem where reconcile amt is too low
 SET ERRLOC = '0047';
 SELECT COALESCE(MIN(INTERNAL_ORDER_FUNDING_ID),0)
   INTO MIN_INTERNAL_ORDER_FUNDING_ID
   FROM INV_INTERNAL_ORDER_FUNDING
   WHERE AGR = TRANS_AGR
     AND INV_ID = TRANS_INV_ID;

 SET ERRLOC = '0048';
 SELECT FUNDING_AMT
    INTO MIN_FUNDING_AMT
    FROM INV_INTERNAL_ORDER_FUNDING
   WHERE AGR = TRANS_AGR
     AND INV_ID = TRANS_INV_ID
     AND INTERNAL_ORDER_FUNDING_ID = MIN_INTERNAL_ORDER_FUNDING_ID ;

  SET ERRLOC = '0049';
  IF RECL_TOTAL_PAYMENT < TRANS_PAYMENT_AMT THEN
  UPDATE INV_INTERNAL_ORDER_FUNDING
      SET FUNDING_AMT = (MIN_FUNDING_AMT +
          (TRANS_PAYMENT_AMT - RECL_TOTAL_PAYMENT))
      WHERE AGR =    TRANS_AGR
      AND INV_ID = TRANS_INV_ID
      AND INTERNAL_ORDER_FUNDING_ID = MIN_INTERNAL_ORDER_FUNDING_ID;
   END IF;

  -- Pass result set back to calling program
 SET ERRCODE = 0;
 OPEN SINGLE_PARM_CURSOR;
 

END P1

