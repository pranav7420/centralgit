CREATE PROCEDURE ECMSXADM.SPCA0051 (IN P_PROJNUM INTEGER , IN P_BIDPKGNUM SMALLINT , OUT P_SQLCODE INTEGER)
	VERSION V1
	ISOLATION LEVEL CS
	RESULT SETS 1
	LANGUAGE SQL
	ALLOW DEBUG MODE
	WLM ENVIRONMENT FOR DEBUG MODE DSNDWLM2
	P1: BEGIN

DECLARE V_SQLCODE                		INT     		DEFAULT 0;      
DECLARE V_SQLSTATE               		CHAR(5) 		DEFAULT '00000';
DECLARE SQLCODE                  		INT     		DEFAULT 0;      
DECLARE SQLSTATE                 		CHAR(5) 		DEFAULT '00000';
DECLARE V_TABLEID                  		CHAR(12)    	DEFAULT '$ECMSRETURN$';
DECLARE V_ERRCD                         SMALLINT    	DEFAULT 0;
DECLARE V_ERRLOC                        CHAR(5)     	DEFAULT '     ';
DECLARE V_END_OF_CURSOR                 CHAR(1)      	DEFAULT 'N';
DECLARE V_PRIME_BPID					CHAR(6)			DEFAULT ' ';
DECLARE V_GENNED_ITEM_NUM				SMALLINT		DEFAULT 0;
DECLARE V_LOW_BIDDER					SMALLINT		DEFAULT 1;
DECLARE V_PARM_CAT						CHAR(1)			DEFAULT ' ';
DECLARE V_PARM_TYPE						CHAR(3)			DEFAULT ' ';
DECLARE V_GP_GEN_CODE_VALUE				VARCHAR(255)	DEFAULT ' ';
DECLARE V_PARM_GEN_CODE_TYPE			SMALLINT		DEFAULT 79;
DECLARE V_ITEMNUM1						CHAR(4)			DEFAULT ' ';
DECLARE V_ITEMNUM2						CHAR(4)			DEFAULT ' ';
DECLARE V_SPLIT_TITLE_ITEMNUM			CHAR(8)			DEFAULT ' ';
DECLARE V_CBI_ITEM_NUM					CHAR(8)			DEFAULT ' ';
DECLARE V_CBI_BUS_PARTNER_ID			CHAR(6)			DEFAULT ' ';
DECLARE V_PARM_ITEMBPID					CHAR(6)			DEFAULT ' ';
DECLARE V_DI_ITEM_QTY					DECIMAL(15,3)	DEFAULT 0;
DECLARE V_CBI_ITEM_QTY					DECIMAL(15,3)	DEFAULT 0;       
DECLARE V_PARM_ITEMTITLE				VARCHAR(150)	DEFAULT ' ';
DECLARE V_PARM_STAT_CD					CHAR(1)			DEFAULT ' ';
DECLARE V_DISPLAY_QTY1					CHAR(20)		DEFAULT ' ';
DECLARE V_DISPLAY_QTY2					CHAR(20)		DEFAULT ' ';
DECLARE V_PARM_ITEMCOMMENT				VARCHAR(100)	DEFAULT ' ';
DECLARE V_SYSTEM_USERID					CHAR(19)		DEFAULT 'ECMS System/PennDOT';








DECLARE SINGLE_PARM_CURSOR CURSOR WITH RETURN
   FOR                                        
   SELECT                         
          V_SQLCODE,                          
          V_ERRCD,                          
          V_ERRLOC                         
                              
     FROM SYSIBM.SYSDUMMY1    ;
     
     
DECLARE IBITEM CURSOR FOR           
  SELECT 
  --	VALUE(DI.ITEM_QTY,0),    
  		VALUE(A_BX_MAX_DAYS, 0),  
         VALUE(CBI.ITEM_QTY,0),     
         VALUE(CBI.ITEM_NUMBER,' '),
         CBI.BUS_PARTNER_ID         
         
  FROM CONTR_ECMS_BID_ITEM_OPEN CBI,
     DESIGN_ITEM DI,              
     CONTR_ECMS_BID_OPEN CB,
	 COM_GENERAL_CODE GPC          
         
  WHERE CBI.ECMS_PROJECT_NUM 	= P_PROJNUM 
  	AND CBI.BID_PACKAGE_NUM 	= P_BIDPKGNUM
  	AND CBI.ECMS_PROJECT_NUM 	= CB.ECMS_PROJECT_NUM 
	AND CBI.BID_PACKAGE_NUM 	= CB.BID_PACKAGE_NUM   
	AND CBI.BUS_PARTNER_ID 		= CB.BUS_PARTNER_ID     
	AND CB.BID_RANKING 			= V_LOW_BIDDER  
	AND DI.ECMS_PROJECT_NUM 	= CBI.ECMS_PROJECT_NUM
	AND CBI.LINE_ITEM_NUM 		= DI.LINE_ITEM_NUM
	AND IB_ITEM_TYPE_CODE = '01'   
	AND GPC.GEN_CODE_TYPE = 119         
	AND GPC.GEN_CODE = IB_ITEM_TYPE_CODE	;      
	
	
	
	                          
     
DECLARE EXIT HANDLER FOR SQLEXCEPTION

	BEGIN
	
       
       SET V_SQLCODE = SQLCODE   ;
       SET V_ERRCD = -1;
       OPEN SINGLE_PARM_CURSOR;
       
	END;



SET V_ERRLOC = 'D010';
SELECT BUS_PARTNER_ID                 
  INTO V_PRIME_BPID                    
  FROM PROJ_CONTRACTOR                
 WHERE ECMS_PROJECT_NUM = P_PROJNUM 
   AND PROJ_CONTR_TYPE = 'P'  ;
   
SET V_ERRLOC = 'D020';
SELECT MAX(AC_ITEM_NUM)                 
  INTO V_GENNED_ITEM_NUM              
  FROM AC_ITEM                          
 WHERE ECMS_PROJECT_NUM = P_PROJNUM   
   AND BID_PACKAGE_NUM  = P_BIDPKGNUM 
   AND BUS_PARTNER_ID = V_PRIME_BPID ;
                  


SET V_PARM_CAT = '1';		-- AUTOMATIC SUBTYPE
SET V_PARM_TYPE = '180';	-- TYPE CODE COSTPLUS
SET V_ERRLOC = 'D030';
SELECT GEN_CODE_VALUE                     
  INTO V_GP_GEN_CODE_VALUE                 
  FROM COM_GENERAL_CODE                   
 WHERE GEN_CODE_TYPE = V_PARM_GEN_CODE_TYPE
   AND GEN_CODE = V_PARM_TYPE;              	  

SET V_ERRLOC = 'D040';
OPEN IBITEM;

SET V_END_OF_CURSOR       =  'N';
WHILE V_END_OF_CURSOR = 'N'
DO
SET V_ERRLOC = 'D050' ;     
FETCH IBITEM INTO      
  V_DI_ITEM_QTY,        
  V_CBI_ITEM_QTY,       
  V_CBI_ITEM_NUM,       
  V_CBI_BUS_PARTNER_ID  ;
  
IF SQLCODE = 100
THEN 
	SET V_ERRLOC = 'D060' ;  
	CLOSE IBITEM;  
    SET V_END_OF_CURSOR = 'Y';
   	ELSE
   		SET V_PARM_ITEMBPID = V_CBI_BUS_PARTNER_ID;
   		SET V_SPLIT_TITLE_ITEMNUM = V_CBI_ITEM_NUM;
   		SET V_ITEMNUM1 = SUBSTR(V_SPLIT_TITLE_ITEMNUM, 1, 4);
   		SET V_ITEMNUM2 = SUBSTR(V_SPLIT_TITLE_ITEMNUM, 5,4);
   		SET V_PARM_ITEMTITLE = 
   			V_GP_GEN_CODE_VALUE	||	' ' || '(' || V_ITEMNUM1 || '-' || V_ITEMNUM2 || ')' ;
   			
   		IF  V_DI_ITEM_QTY < V_CBI_ITEM_QTY
   		THEN
   			SET V_PARM_STAT_CD = '2';	-- FAILED STATUS
   		ELSE
   			SET V_PARM_STAT_CD = '1';	-- PASSED STATUS		
   		END IF;
   		
   		SET V_PARM_ITEMCOMMENT = SPACE(5);
   		SET V_DISPLAY_QTY1 = CHAR(V_DI_ITEM_QTY);
   		SET V_DISPLAY_QTY2 = CHAR(V_CBI_ITEM_QTY);
   		
   		SET V_PARM_ITEMCOMMENT = 'Maximum Days: ' || V_DISPLAY_QTY1 || ' ' ||
   			'Bid Days: ' || V_DISPLAY_QTY2 ;
   			
   		SET V_ERRLOC = 'D070' ;
   		SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
   		INSERT INTO AC_ITEM  
		( ECMS_PROJECT_NUM,  
		  BID_PACKAGE_NUM,   
		  BUS_PARTNER_ID,    
		  AC_ITEM_NUM,       
		  AC_ITEM_CAT_CODE,  
		  AC_ITEM_TYPE_CODE, 
		  AC_ITEM_STATUS_TS, 
		  AC_ITEM_STATUS_CD, 
		  AC_ITEM_STATUS_BY, 
		  AC_ITEM_BP_ID,     
		  AC_ITEM_DEFLT_IND, 
		  CREATED_BY,        
		  CREATED_BY_TS,     
		  LAST_MODIFIED_BY,  
		  LAST_MODIFIED_TS,  
		  AC_ITEM_TITLE,     
		  AC_ITEM_COMMENT )    
   		VALUES
   			( P_PROJNUM,                           
		  P_BIDPKGNUM,                         
		  V_PRIME_BPID,                           
		  V_GENNED_ITEM_NUM,                   
		  V_PARM_CAT,                             
		  V_PARM_TYPE,                            
		  CURRENT_TIMESTAMP,                     
		  V_PARM_STAT_CD,                         
		  V_SYSTEM_USERID,                        
		  V_PARM_ITEMBPID,                        
		  'Y',                                   
		  V_SYSTEM_USERID,                        
		  CURRENT_TIMESTAMP,                     
		  V_SYSTEM_USERID,                        
		  CURRENT_TIMESTAMP,                     
		  V_PARM_ITEMTITLE,                       
		  V_PARM_ITEMCOMMENT)	;
   		
   		
   		
END IF;

END WHILE;   		


OPEN SINGLE_PARM_CURSOR;	
	
END P1
