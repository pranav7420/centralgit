CREATE PROCEDURE ECMSXADM.AGR_WO_CLONE_SOW_DPE (
    IN PIN_FromAgr CHAR(6),
    IN PIN_FromWoId INTEGER,
    IN PIN_ToAgr CHAR(6),
    IN PIN_ToWoId INTEGER,
    IN PIN_UserName CHAR(80),
   OUT POUT_ReturnText VARCHAR(750),
   OUT POUT_RowCount INTEGER,
   OUT POUT_SQLSTATE CHAR(5),
   OUT POUT_SQLCode INTEGER
     )

	
----------------------------------------------------------------------- 
-- DESCRIPTION: This program copies the origional Scope of Work (SOW)
--              and Department Estimate (CST)
--              from one Consultant Work Order into another [Clone] 
----------------------------------------------------------------------- 
--   PROCEDURE: AGR_WO_CLONE_SOW_DEP
--        TYPE: DB2 NATIVE SQL PROCEDURE                               
--      AUTHOR: Bruce Russell                                           
--        DATE: 02/01/2018
--                                                                         
--       INPUT: AGR[from]; WO_ID[from];
--              AGR[to]; WO_ID[to]; User Name                    
--                                                                        
--     OUTPUTS: Last Processed:
--              Table-Name; Row-Count; SQL Return-Code; SQL State
--
-----------------------------------------------------------------------    

	LANGUAGE SQL
	QUALIFIER ECMSXADM
	COMMIT ON RETURN YES
	DYNAMIC RESULT SETS 2
	PACKAGE OWNER HWYDEV
	ISOLATION LEVEL CS

P1: BEGIN

	/***    SQL results codes    ***/
	DECLARE SQLCODE INTEGER DEFAULT 0;      
	DECLARE SQLSTATE CHAR(5) DEFAULT '00000';
	
	/***    Key Variables    ***/
    DECLARE From_SowId INTEGER DEFAULT 1; 
    DECLARE From_Main_Task_ID INTEGER;
    DECLARE From_Detail_Task_ID INTEGER;
    DECLARE To_SowId INTEGER DEFAULT 1;
    DECLARE To_Main_Task_ID INTEGER DEFAULT 0;
    DECLARE To_Detail_Task_ID INTEGER DEFAULT 0; 
    DECLARE Last_Main_Task_ID INTEGER DEFAULT 0;

	/***    Computed Constants    ***/
    DECLARE v_SowDetailId INTEGER DEFAULT 1; 
    DECLARE v_CstEstId INTEGER DEFAULT 1; 
    DECLARE v_VersionId INTEGER DEFAULT 0; 
    DECLARE v_WorkflowId INTEGER DEFAULT 0;
    DECLARE v_WorkflowText CHAR(80) DEFAULT ''; 
    DECLARE v_DebugText CHAR(80) DEFAULT '';
    
	/***    CURSORs    ***/
    DECLARE CUR_Main_Task_EOF CHAR(1) DEFAULT 'N';
    DECLARE CUR_Detail_Task_EOF CHAR(1) DEFAULT 'N';    
      
    /***    Define ROW Counts.    ***/
    DECLARE v_RowCount INTEGER DEFAULT 0; -- Generic
    DECLARE v_SOWRowCount1 INTEGER DEFAULT 0; -- SOW_SCOPE_OF_WORK
    DECLARE v_SOWRowCount2 INTEGER DEFAULT 0; -- SOW_DETAIL
    DECLARE v_SOWRowCount3 INTEGER DEFAULT 0; -- SOW_MAIN_TASK
    DECLARE v_SOWRowCount4 INTEGER DEFAULT 0; -- SOW_TASK_OBJECTIVE
    DECLARE v_SOWRowCount5 INTEGER DEFAULT 0; -- SOW_TASK_SCOPE
    DECLARE v_SOWRowCount6 INTEGER DEFAULT 0; -- SOW_WBS_NUMBER
    DECLARE v_SOWRowCount7 INTEGER DEFAULT 0; -- SOW_DETAIL_TASK
    DECLARE v_CSTRowCount01 INTEGER DEFAULT 0; -- CST_COST_ESTIMATE
    DECLARE v_CSTRowCount02 INTEGER DEFAULT 0; -- CST_DETAIL
    DECLARE v_CSTRowCount03 INTEGER DEFAULT 0; -- CST_COST_FACTOR 
    DECLARE v_CSTRowCount04 INTEGER DEFAULT 0; -- CST_ESCALATION
    DECLARE v_CSTRowCount05 INTEGER DEFAULT 0; -- CST_LABOR_TASK
    DECLARE v_CSTRowCount06 INTEGER DEFAULT 0; -- CST_OTHER_COST
    DECLARE v_CSTRowCount07 INTEGER DEFAULT 0; -- CST_LABOR_TASK_CLASSIFICATION_RATE
    DECLARE v_CSTRowCount08 INTEGER DEFAULT 0; -- CST_UNIT_OF_WORK
    DECLARE v_CSTRowCount09 INTEGER DEFAULT 0; -- CST_LABOR_TASK_UNITS_OF_WORK
    DECLARE v_CSTRowCount10 INTEGER DEFAULT 0; -- CST_OTHER_COST_UNITS_OF_WORK
        
	/***   Define SOW_MAIN_DETAIL_TASK [can have mutiple rows per TASK_ID]   ***/
	DECLARE CUR_MAIN_DETAIL_TASK CURSOR FOR    
	 SELECT m.TASK_ID, COALESCE(d.DETAIL_TASK_ID,0) AS DETAIL_TASK_ID
	   FROM SOW_MAIN_TASK m
	   LEFT OUTER JOIN SOW_DETAIL_TASK d
	     ON d.AGR = m.AGR
        AND d.SOW_ID = m.SOW_ID
        AND d.SOW_DETAIL_ID = m.SOW_DETAIL_ID
        AND d.TASK_ID = m.TASK_ID
	  WHERE m.AGR = PIN_FromAgr
	    AND m.SOW_ID = From_SowId
	    AND m.SOW_DETAIL_ID = 1
      ORDER BY m.TASK_ID, d.DETAIL_TASK_ID;
	     
	/***   Exit on all errors   ***/ 
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	
	/***   Initialize Return Parameters   ***/
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE; 
	Set POUT_RowCount = -1;	
	
		
	
 /***   -----------------------------------------------   ***/ 
 /***   INITAL PROCESSING                                 ***/ 
 /***   -----------------------------------------------   ***/ 
 
 	
 	/***   -----------------------------------------------   ***/ 
 	/***   Get the next SOW_ID for the new Work Order        ***/ 
 	/***   -----------------------------------------------   ***/ 
    Set POUT_ReturnText = 'Failure: Get next SOW_ID for the new Work Order'; 

    SELECT COALESCE(MAX(SOW_ID),0) + 1 into To_SowId
      FROM SOW_SCOPE_OF_WORK
     WHERE AGR = PIN_ToAgr;
     
	Set POUT_RowCount = 0;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;


 	/***   -----------------------------------------------   ***/
 	/***   Get the SOW_ID from the old Work Order            ***/ 
 	/***   -----------------------------------------------   ***/ 
    Set POUT_ReturnText = 'Failure: Get SOW_ID from old Work Order';
     
    SELECT SOW_ID into From_SowId
      FROM ECMSXADM.SOW_DETAIL
     WHERE AGR = PIN_FromAgr
       AND WO_ID =  PIN_FromWoId
       AND SUPPL_ID IS NULL
       AND AMEND_ID IS NULL;
       
	Set POUT_RowCount = 0;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;
    
    
 	/***   -----------------------------------------------   ***/
 	/***   Get the Next TASK_ID from the New AGR             ***/ 
 	/***   -----------------------------------------------   ***/ 
     SELECT COALESCE(MAX(TASK_ID),0) into To_Main_Task_ID
       FROM SOW_MAIN_TASK	
      WHERE AGR = PIN_ToAgr
	    AND SOW_ID < To_SowId  -- <== Next SOW_ID
        AND SOW_DETAIL_ID = 1;
       
	Set POUT_RowCount = 0;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE; 
    
    
 	/***   -----------------------------------------------   ***/ 
 	/***   Initialize the Workflow Comment                   ***/ 
 	/***   -----------------------------------------------   ***/ 
    Set v_WorkflowText = ' was cloned ' ||
    	' from AGR: ' || PIN_FromAgr || 
    	' WO_ID: ' || PIN_FromWoId ||
    	' [SOW: ' || From_SowId || ']'; 
    	

/***   -----------------------------------------------   ***/ 
/***                 MAIN PROCESSING                     ***/ 
/***   -----------------------------------------------   ***/ 
 
 
    -----------------------------------------------
    -- Clone data for SOW_SCOPE_OF_WORK.
    -----------------------------------------------
	Set POUT_ReturnText = 'Failure: SOW_SCOPE_OF_WORK Insert'; 
	
    SELECT count(*) into v_SOWRowCount1
	  FROM Final Table 
	   	 ( 
	INSERT INTO SOW_SCOPE_OF_WORK 
		 ( AGR, 
	   	   SOW_ID, 
	   	   SOW_STATUS_CODE, 
	   	   SOW_TYPE_CODE, 
	   	   SUPPL_ID, 
--	   	   WORKFLOW_ID, -- Set in next step
	   	   SOW_DESC, 
	   	   EXECUTIVE_SUMMARY_REQUIRED_IND, 
--	   	   FORUM_POST_ID, -- null
	   	   CREATED_BY, 
	   	   CREATED_BY_TS, 
	   	   LAST_MODIFIED_BY, 
	   	   LAST_MODIFIED_TS
         )
    SELECT PIN_ToAgr as AGR,
	   	   To_SowId as SOW_ID,
	   	   '01' as SOW_STATUS_CODE,
	   	   SOW_TYPE_CODE,
	   	   SUPPL_ID,
--	   	   0 as WORKFLOW_ID,  -- Set in next step
	   	   SOW_DESC,
--	   	   0 as FORUM_POST_ID, -- null
	   	   EXECUTIVE_SUMMARY_REQUIRED_IND,
	   	   PIN_UserName as CREATED_BY,
	   	   current timestamp as CREATED_BY_TS,
	   	   PIN_UserName as LAST_MODIFIED_BY,
	   	   current timestamp as LAST_MODIFIED_TS
	  FROM SOW_SCOPE_OF_WORK
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = From_SowId
	     );
	
	Set POUT_RowCount = v_SOWRowCount1;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;


	IF v_SOWRowCount1 > 0		--  SOW_SCOPE_OF_WORK had data
    THEN
    -----------------------------------------------
    -- Update new SOW with new workflow
    -----------------------------------------------
    Set POUT_ReturnText = 'Failure: (SOW) COM_WORKFLOW_LOG Insert';
     
	SELECT WORKFLOW_ID INTO v_WorkflowId
	  FROM FINAL TABLE
	     ( 
    INSERT INTO COM_WORKFLOW_LOG 
         ( WORKFLOW_ID, 
           WORKFLOW_SEQ_NBR, 
           WORKFLOW_LOG_TYPE_CODE, 
           WORKFLOW_STATUS_CODE, 
           DISP_CODE, 
           DISP_USER, 
           DISP_TS, 
           DISP_COMMENT, 
           DISP_TITLE, 
           CONVERTED_IND 
         ) VALUES ( 
           (SELECT MAX(WORKFLOW_ID) + 1 FROM COM_WORKFLOW_LOG), 
           1, 
           '16', 
           '01', 
           '073', 
           PIN_UserName, 
           current timestamp, 
           'This SOW data' || v_WorkflowText, 
           null, 
           null
         )
         );
           
    Set POUT_ReturnText = 'Failure: SOW_SCOPE_OF_WORK Update';
    
    UPDATE SOW_SCOPE_OF_WORK
       SET WORKFLOW_ID = v_WorkflowId
     WHERE AGR = PIN_ToAgr
       AND SOW_ID = To_SowId;
	
	Set POUT_RowCount = 0;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;
	   		
    END IF;

    
	IF v_SOWRowCount1 > 0		--  SOW_SCOPE_OF_WORK had data
	THEN    	   		
    -----------------------------------------------
    -- Clone data for SOW_DETAIL.
    -----------------------------------------------
    Set POUT_ReturnText = 'Failure: SOW_DETAIL Insert';
      
    SELECT count(*) into v_SOWRowCount2
	  FROM Final Table
	     ( 
	INSERT INTO SOW_DETAIL
		 ( AGR, 
	   	   SOW_ID, 
	   	   SOW_DETAIL_ID, 
	   	   PART_ID, 
	   	   SUPPL_ID, 
	   	   WO_ID, 
	   	   AMEND_ID 
         )
    SELECT PIN_ToAgr as AGR, 
	   	   To_SowId as SOW_ID, 
	   	   SOW_DETAIL_ID,
	   	   PART_ID,
	   	   SUPPL_ID, 
	   	   PIN_ToWoId as WO_ID, 
	   	   AMEND_ID 
	  FROM SOW_DETAIL	
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = From_SowId
	   AND SUPPL_ID IS NULL
	   AND WO_ID = PIN_FromWoId 
	   AND AMEND_ID IS NULL 
	     );
	       
	Set POUT_RowCount = v_SOWRowCount2;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;	
	
	END IF;
	
		
	IF v_SOWRowCount2 > 0		--  SOW_DETAIL had data
    THEN	   			
    -----------------------------------------------
    -- Clone data for CST_COST_ESTIMATE.
    -----------------------------------------------
    Set POUT_ReturnText = 'Failure: CST_COST_ESTIMATE Insert'; 
    
    SELECT count(*) into v_CSTRowCount01
	  FROM Final Table
	     (
	INSERT INTO CST_COST_ESTIMATE
		 ( AGR, 
	   	   SOW_ID, 
	   	   CST_EST_ID, 
	   	   DPE_ESTIMATE_IND,
	   	   ASSOC_HIERARCHY_ID, 
	   	   CST_STATUS_CODE, 
	   	   SUBMITTED_BY_BP_ID, 
	   	   WORKFLOW_ID, 
	   	   LAST_SNAPSHOT_VERSION_ID, 
	   	   DBE_GROUP_CODE, 
	   	   CST_TOTAL_COST_AMT, 
	   	   CURRENT_PRP_IND,  
	   	   SBE_IND, 
	   	   DBE_IND, 
	   	   CREATED_BY, 
	   	   CREATED_BY_TS, 
	   	   LAST_MODIFIED_BY, 
	   	   LAST_MODIFIED_TS
         )
	SELECT PIN_ToAgr as AGR,
	   	   To_SowId as SOW_ID,
	   	   CST_EST_ID,
	   	   DPE_ESTIMATE_IND,
	   	   ASSOC_HIERARCHY_ID,
	   	   '01' as CST_STATUS_CODE,
	   	   SUBMITTED_BY_BP_ID,
	   	   0 as WORKFLOW_ID,
	   	   0 as LAST_SNAPSHOT_VERSION_ID,
	   	   DBE_GROUP_CODE,
	   	   CST_TOTAL_COST_AMT,
	   	   CURRENT_PRP_IND,
	   	   SBE_IND,
	   	   DBE_IND,
	   	   PIN_UserName as CREATED_BY,
	   	   current timestamp as CREATED_BY_TS,
		   PIN_UserName as LAST_MODIFIED_BY,
		   current timestamp as LAST_MODIFIED_TS
	  FROM CST_COST_ESTIMATE
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = From_SowId
	   AND CST_EST_ID = v_CstEstId
	   AND DPE_ESTIMATE_IND = 'Y'
		 );
	       
	Set POUT_RowCount = v_CSTRowCount01;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;

	END IF;


	IF v_CSTRowCount01 > 0		--  CST_COST_ESTIMATE had data
    THEN    
    -----------------------------------------------
    -- Update new DPE with new workflow
    -----------------------------------------------
    Set POUT_ReturnText = 'Failure: (DPE) COM_WORKFLOW_LOG Insert'; 
    
	SELECT WORKFLOW_ID INTO v_WorkflowId
	  FROM FINAL TABLE
	     ( 
    INSERT INTO COM_WORKFLOW_LOG
         ( WORKFLOW_ID, 
           WORKFLOW_SEQ_NBR, 
           WORKFLOW_LOG_TYPE_CODE, 
           WORKFLOW_STATUS_CODE, 
           DISP_CODE, 
           DISP_USER, 
           DISP_TS, 
           DISP_COMMENT, 
           DISP_TITLE, 
           CONVERTED_IND 
         ) VALUES ( 
           (SELECT MAX(WORKFLOW_ID) + 1 FROM COM_WORKFLOW_LOG), 
           1, '06', '01', '073', PIN_UserName, current timestamp, 
           'This DPE data' || v_WorkflowText,
           null,
           null
         )
         );
           
    Set POUT_ReturnText = 'Failure: CST_COST_ESTIMATE Update'; 
    UPDATE CST_COST_ESTIMATE
       SET WORKFLOW_ID = v_WorkflowId	
	 WHERE AGR = PIN_ToAgr
	   AND SOW_ID = To_SowId
	   AND CST_EST_ID = v_CstEstId
	   AND DPE_ESTIMATE_IND = 'Y';
	
	Set POUT_RowCount = 0;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;
	   		
    END IF;


	IF v_CSTRowCount01 > 0	--  CST_COST_ESTIMATE had data
    THEN   			
    -----------------------------------------------
    -- Clone data for CST_DETAIL.
    -----------------------------------------------
    Set POUT_ReturnText = 'Failure: CST_DETAIL Insert'; 	
    
    SELECT count(*) into v_CSTRowCount02
	  FROM Final Table
	     (
	INSERT INTO CST_DETAIL
	     ( AGR,
	   	   SOW_ID,
	   	   CST_EST_ID,
	   	   SOW_DETAIL_ID, 
	   	   CST_DETAIL_TOTAL_COST_AMT, 
	   	   CANCELLED_PART_IND
	     )
	SELECT PIN_ToAgr as AGR,
	   	   To_SowId as SOW_ID,
	   	   CST_EST_ID,
	   	   SOW_DETAIL_ID, 
	   	   CST_DETAIL_TOTAL_COST_AMT, 
	   	   CANCELLED_PART_IND 
	  FROM CST_DETAIL
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = From_SowId
	   AND CST_EST_ID = v_CstEstId
		 );
	       
	Set POUT_RowCount = v_CSTRowCount02;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;
	   		
    END IF;	
	
	
	IF v_CSTRowCount02 > 0		--  CST_DETAIL had data
    THEN    	   			
    -----------------------------------------------
    -- Clone data for CST_COST_FACTOR.
    -----------------------------------------------
    Set POUT_ReturnText = 'Failure: CST_COST_FACTOR Insert'; 
    
    SELECT count(*) into v_CSTRowCount03
	  FROM Final Table
	     (
	INSERT INTO CST_COST_FACTOR
	     ( AGR, 
	   	   SOW_ID, 
	   	   CST_EST_ID, 
	   	   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   FIELD_OFFICE_IND, 
	   	   PROFIT_PCT, 
	   	   FIELD_OVERHEAD_PCT, 
	   	   OFFICE_OVERHEAD_PCT, 
	   	   HAZARD_PCT, 
	   	   PREMIUM_PAY_IND, 
	   	   OVERTIME_PCT, 
	   	   SPECIFIC_RATE_FACTOR, 
	   	   OVERTIME_SPECIFIC_RATE_FACTOR, 
	   	   HAZARD_SPECIFIC_RATE_FACTOR, 
	   	   HAZARD_OT_SPECIFIC_RATE_FACTOR, 
	   	   PROFIT_CLASS_CODE,  
	   	   CREATED_BY, 
	   	   CREATED_BY_TS, 
	   	   LAST_MODIFIED_BY, 
	   	   LAST_MODIFIED_TS
         )
	SELECT PIN_ToAgr as AGR,
	   	   To_SowId as SOW_ID, 
	   	   CST_EST_ID, 
	   	   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   FIELD_OFFICE_IND, 
	   	   PROFIT_PCT, 
	   	   FIELD_OVERHEAD_PCT, 
	   	   OFFICE_OVERHEAD_PCT, 
	   	   HAZARD_PCT, 
	   	   PREMIUM_PAY_IND, 
	   	   OVERTIME_PCT, 
	   	   SPECIFIC_RATE_FACTOR, 
	   	   OVERTIME_SPECIFIC_RATE_FACTOR, 
	   	   HAZARD_SPECIFIC_RATE_FACTOR, 
	   	   HAZARD_OT_SPECIFIC_RATE_FACTOR, 
	   	   PROFIT_CLASS_CODE,  
	   	   PIN_UserName as CREATED_BY,
	   	   current timestamp as CREATED_BY_TS,
		   PIN_UserName as LAST_MODIFIED_BY,
		   current timestamp as LAST_MODIFIED_TS
	  FROM CST_COST_FACTOR
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = From_SowId
	   AND CST_EST_ID = v_CstEstId
	   AND VERSION_ID = 0
         );
	       
	Set POUT_RowCount = v_CSTRowCount03;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;
	   		
    END IF;	
	
	
	IF v_CSTRowCount02 > 0		--  CST_DETAIL had data
    THEN    	   			
    -----------------------------------------------
    -- Clone data for CST_ESCALATION.
    -----------------------------------------------
    Set POUT_ReturnText = 'Failure: CST_ESCALATION Insert'; 
    
    SELECT count(*) into v_CSTRowCount04
	  FROM Final Table
	     (
	INSERT INTO CST_ESCALATION
	     ( AGR,
	   	   SOW_ID,
	   	   CST_EST_ID, 
	   	   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   ESCALATION_ID, 
	   	   ESCALATION_NAME, 
	   	   ESCALATION_PCT, 
	   	   ESCALATION_TEXT, 	
	   	   CREATED_BY,
	   	   CREATED_BY_TS,
		   LAST_MODIFIED_BY,
		   LAST_MODIFIED_TS
	   	 )
	SELECT PIN_ToAgr as AGR,
	   	   To_SowId as SOW_ID,
	   	   CST_EST_ID, 
	   	   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   ESCALATION_ID, 
	   	   ESCALATION_NAME, 
	   	   ESCALATION_PCT, 
	   	   ESCALATION_TEXT, 	
	   	   PIN_UserName as CREATED_BY,
	   	   current timestamp as CREATED_BY_TS,
		   PIN_UserName as LAST_MODIFIED_BY,
		   current timestamp as LAST_MODIFIED_TS
	  FROM CST_ESCALATION
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = From_SowId
	   AND CST_EST_ID = v_CstEstId
	   AND VERSION_ID = 0
		 );
	       
	Set POUT_RowCount = v_CSTRowCount04;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;
	   		
    END IF;	    
 		    
	
	IF v_CSTRowCount02 > 0		-- if CST_DETAIL had data
    THEN    	   			
    -----------------------------------------------
    -- Clone data for CST_OTHER_COST.
    -----------------------------------------------
    Set POUT_ReturnText = 'Failure: CST_OTHER_COST Insert'; 
    
    SELECT count(*) into v_CSTRowCount06
	  FROM Final Table
	     (
	INSERT INTO CST_OTHER_COST
	     ( AGR, 
	   	   SOW_ID, 
	   	   CST_EST_ID, 
	   	   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   OTHER_COST_ID, 
	   	   OTHER_COST_NAME, 
	   	   NBR_OF_UNITS, 
	   	   COST_PER_UNIT, 
	   	   OTHER_COST_NBR, 
	   	   TOTAL_OTHER_COSTS_AMT, 
	   	   PREDETERMINED_AMT_IND, 
	   	   ALLOWABLE_AMT, 
	   	   ITEM_CALCULATION_DESC,
	   	   OC_GEN_TASK,
	   	   CREATED_BY,
	   	   CREATED_BY_TS,
	   	   LAST_MODIFIED_BY,
	   	   LAST_MODIFIED_TS,
	   	   DBE_INCLUDE_IND,
	   	   SBE_INCLUDE_IND
	     )
	SELECT PIN_ToAgr as AGR,
	   	   To_SowId as SOW_ID,
	   	   CST_EST_ID, 
	   	   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   OTHER_COST_ID, 
	   	   OTHER_COST_NAME, 
	   	   NBR_OF_UNITS, 
	   	   COST_PER_UNIT, 
	   	   OTHER_COST_NBR, 
	   	   TOTAL_OTHER_COSTS_AMT, 
	   	   PREDETERMINED_AMT_IND, 
	   	   ALLOWABLE_AMT, 
	   	   ITEM_CALCULATION_DESC,
	   	   OC_GEN_TASK, 	
	   	   PIN_UserName as CREATED_BY,
	   	   current timestamp as CREATED_BY_TS,
		   PIN_UserName as LAST_MODIFIED_BY,
		   current timestamp as LAST_MODIFIED_TS,
	   	   DBE_INCLUDE_IND,
	   	   SBE_INCLUDE_IND
	  FROM CST_OTHER_COST
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = From_SowId
	   AND CST_EST_ID = v_CstEstId
	   AND VERSION_ID = 0
		 );
	       
	Set POUT_RowCount = v_CSTRowCount06;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;
	   		
    END IF;
    

 	/***   -------------------------------------------------   ***/ 
 	/***   SPECIAL CONSIDEATIONS FOR PROCESSING UNIT-OF-WORK   ***/ 
 	/***   -------------------------------------------------   ***/ 
 	/***        ONLY PROCESS WORK ORDERs WITHIN SAME AGR       ***/ 
 	/***       OR THE 'To' and 'From' AGRs ARE CLONEs          ***/ 
 	/***     SO THE UOW NBRs ARE CONSISTENT BETWEEN AGRs       ***/ 
 	/***   -------------------------------------------------   ***/ 
	IF v_CSTRowCount02 > 0		-- if CST_DETAIL had data
    THEN    			
    -----------------------------------------------
    -- Clone data for CST_UNIT_OF_WORK.
    -----------------------------------------------
    Set POUT_ReturnText = 'Failure: CST_UNIT_OF_WORK Insert'; 	   
    
    SELECT count(*) into v_CSTRowCount08
	  FROM Final Table
	     (
	INSERT INTO CST_UNIT_OF_WORK
	     ( AGR,
	   	   SOW_ID,
	   	   CST_EST_ID, 
	   	   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   UNIT_OF_WORK_NBR, 
	   	   UNIT_OF_WORK_NAME, 
	   	   NBR_OF_UNITS, 
	   	   COST_PER_UNIT, 
	   	   FIELD_OFFICE_IND, 
	   	   NEW_UNIT_IND, 
	   	   UW_GEN_TASK, 
	   	   CREATED_BY, 
	   	   CREATED_BY_TS, 
	   	   LAST_MODIFIED_BY, 
	   	   LAST_MODIFIED_TS
	     )
	SELECT PIN_ToAgr as AGR,
	   	   To_SowId as SOW_ID,
	   	   CST_EST_ID, 
	   	   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   UNIT_OF_WORK_NBR, 
	   	   UNIT_OF_WORK_NAME, 
	   	   NBR_OF_UNITS, 
	   	   COST_PER_UNIT, 
	   	   FIELD_OFFICE_IND, 
	   	   NEW_UNIT_IND, 
	   	   UW_GEN_TASK,	
	   	   PIN_UserName as CREATED_BY,
	   	   current timestamp as CREATED_BY_TS,
		   PIN_UserName as LAST_MODIFIED_BY,
		   current timestamp as LAST_MODIFIED_TS
	  FROM CST_UNIT_OF_WORK
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = From_SowId
	   AND CST_EST_ID = v_CstEstId
	   AND VERSION_ID = 0
		 );
	       
	Set POUT_RowCount = v_CSTRowCount08;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;
	   		
    END IF;	
	

/***   -----------------------------------------------   ***/ 
/***                TASK PROCESSING (loop)               ***/ 
/***   -----------------------------------------------   ***/ 

 
 	/***   -----------------------------------------------   ***/ 
	/***   LOOP THRU SOW_Detail_MAIN_TASK                    ***/
 	/***   -----------------------------------------------   ***/  
	Set POUT_ReturnText = 'Failure: SOW_MAIN_TASK LOOP';
	OPEN CUR_MAIN_DETAIL_TASK;
	WHILE CUR_Main_Task_EOF = 'N' DO
		FETCH CUR_MAIN_DETAIL_TASK INTO From_Main_Task_ID, From_Detail_Task_ID;      
		IF SQLCODE = 100 THEN
        	SET CUR_Main_Task_EOF = 'Y';
			CLOSE CUR_MAIN_DETAIL_TASK;
		ELSE 
 			IF From_Main_Task_ID > Last_Main_Task_ID THEN
 				SET Last_Main_Task_ID = From_Main_Task_ID;
 				SET To_Main_Task_ID = To_Main_Task_ID + 1;
 				SET To_Detail_Task_ID = 0;
      		   		
			 	/***   -----------------------------------------------   ***/ 
				/***   INSERT SOW_MAIN_TASK from SELECT                  ***/
			 	/***   -----------------------------------------------   ***/ 
			    Set POUT_ReturnText = 'Failure: SOW_MAIN_TASK Insert' || 
			    	' From AGR: ' || PIN_FromAgr || 
			    	' WO_ID: ' || PIN_FromWoId ||
			    	' SOW: ' || From_SowId ||
			    	' TASK_ID: ' || From_Main_Task_ID ||
			    	' DETAIL_TASK_ID: ' || From_Detail_Task_ID ||
			    	' To AGR: ' || PIN_ToAgr || 
			    	' WO_ID: ' || PIN_ToWoId ||
			    	' SOW: ' || To_SowId || 
			    	' TASK_ID: ' || To_Main_Task_ID ||
			    	' DETAIL_TASK_ID: ' || To_Detail_Task_ID;
			   	SELECT count(*) into v_RowCount
				  FROM Final Table
			    	 ( 
				INSERT INTO SOW_MAIN_TASK
					 ( AGR, 
				   	   SOW_ID, 
				   	   SOW_DETAIL_ID, 
				   	   TASK_ID, 
				   	   TASK_NBR, 
				   	   WBS_NBR, 
				   	   WBS_REVISION_DATE, 
				   	   NEW_TASK_IND, 
				   	   TASK_NAME, 
				   	   INTERNAL_ORDER, 
				   	   SOW_GENERATED_TASK, 
				   	   CREATED_BY, 
				   	   CREATED_BY_TS, 
				   	   LAST_MODIFIED_BY, 
				   	   LAST_MODIFIED_TS 
			         )
			    SELECT PIN_ToAgr as AGR, 
			    	   To_SowId as SOW_ID, 
			    	   SOW_DETAIL_ID, 
			    	   To_Main_Task_ID AS TASK_ID, 
			    	   TASK_NBR, 
			    	   WBS_NBR, 
			    	   WBS_REVISION_DATE, 
			    	   NEW_TASK_IND, 
			    	   TASK_NAME, 
			    	   INTERNAL_ORDER, 
			    	   SOW_GENERATED_TASK, 
				   	   PIN_UserName as CREATED_BY,
				   	   current timestamp as CREATED_BY_TS,
			    	   PIN_UserName as LAST_MODIFIED_BY, 
			    	   current timestamp as LAST_MODIFIED_TS
				  FROM SOW_MAIN_TASK	
				 WHERE AGR = PIN_FromAgr
				   AND SOW_ID = From_SowId
--				   AND SOW_DETAIL_ID = v_SowDetailId
				   AND TASK_ID = From_Main_Task_ID
				     );	
				             
				Set POUT_SQLCode = SQLCODE;	
				Set POUT_SQLSTATE = SQLSTATE;  
				Set v_SOWRowCount3 = v_SOWRowCount3 + v_RowCount; 
				Set POUT_RowCount = v_SOWRowCount3;
				
				
				
				IF v_SOWRowCount3 > 0		--  SOW_MAIN_TASK had data
			    THEN 	   		 	
			    -----------------------------------------------
			    -- Clone data for SOW_TASK_OBJECTIVE.
			    -----------------------------------------------
			    Set POUT_ReturnText = 'Failure: SOW_TASK_OBJECTIVE Insert' || 
			    	' From AGR: ' || PIN_FromAgr || 
			    	' WO_ID: ' || PIN_FromWoId ||
			    	' SOW: ' || From_SowId ||
			    	' TASK_ID: ' || From_Main_Task_ID ||
			    	' To AGR: ' || PIN_ToAgr || 
			    	' WO_ID: ' || PIN_ToWoId ||
			    	' SOW: ' || To_SowId || 
			    	' TASK_ID: ' || To_Main_Task_ID;
			        
			    SELECT count(*) into v_RowCount
				  FROM 	Final Table
			         ( 
				INSERT INTO SOW_TASK_OBJECTIVE
					 ( AGR, 
				   	   SOW_ID, 
				   	   SOW_DETAIL_ID, 
				   	   TASK_ID, 
				   	   SOW_TASK_OBJECTIVE 
			         )
			    SELECT PIN_ToAgr as AGR,
				   	   To_SowId as SOW_ID, 
				   	   SOW_DETAIL_ID, 
				   	   To_Main_Task_ID AS TASK_ID, 
				   	   SOW_TASK_OBJECTIVE 
				  FROM SOW_TASK_OBJECTIVE
				 WHERE AGR = PIN_FromAgr
				   AND SOW_ID = From_SowId
				   AND TASK_ID = From_Main_Task_ID
				     );
				               
				Set POUT_SQLCode = SQLCODE;
				Set POUT_SQLSTATE = SQLSTATE; 
				Set v_SOWRowCount4 = v_SOWRowCount4 + v_RowCount; 	  
				Set POUT_RowCount = v_SOWRowCount4;
					
				END IF;
			
				
				IF v_SOWRowCount3 > 0		--  SOW_MAIN_TASK had data
			    THEN	   			
			    -----------------------------------------------
			    -- Clone data for SOW_TASK_SCOPE.
			    -----------------------------------------------
			    Set POUT_ReturnText = 'Failure: SOW_TASK_SCOPE Insert' || 
			    	' From AGR: ' || PIN_FromAgr || 
			    	' WO_ID: ' || PIN_FromWoId ||
			    	' SOW: ' || From_SowId ||
			    	' TASK_ID: ' || From_Main_Task_ID ||
			    	' To AGR: ' || PIN_ToAgr || 
			    	' WO_ID: ' || PIN_ToWoId ||
			    	' SOW: ' || To_SowId || 
			    	' TASK_ID: ' || To_Main_Task_ID ;
			    
			    SELECT count(*) into v_RowCount
				  FROM Final Table
				     ( 
				INSERT INTO SOW_TASK_SCOPE
				 	 ( AGR, 
				   	   SOW_ID, 
				   	   SOW_DETAIL_ID, 
				   	   TASK_ID, 
				   	   SOW_TASK_SCOPE_LOB 
			         )
			    SELECT PIN_ToAgr as AGR, 
			    	   To_SowId as SOW_ID, 
			    	   SOW_DETAIL_ID, 
			    	   To_Main_Task_ID AS TASK_ID, 
			    	   SOW_TASK_SCOPE_LOB 
				  FROM SOW_TASK_SCOPE	
				 WHERE AGR = PIN_FromAgr
				   AND SOW_ID = From_SowId
				   AND TASK_ID = From_Main_Task_ID
				     );
				              
				Set POUT_SQLCode = SQLCODE;
				Set POUT_SQLSTATE = SQLSTATE; 
				Set v_SOWRowCount5 = v_SOWRowCount5 + v_RowCount; 	   
				Set POUT_RowCount = v_SOWRowCount5;
					
				END IF;
				
				
				IF v_SOWRowCount3 > 0		--  SOW_MAIN_TASK had data
			    THEN   			
			    -----------------------------------------------
			    -- Clone data for SOW_WBS_NUMBER.
			    -----------------------------------------------
			 	Set POUT_ReturnText = 'Failure: SOW_WBS_NUMBER Insert' || 
			    	' From AGR: ' || PIN_FromAgr || 
			    	' WO_ID: ' || PIN_FromWoId ||
			    	' SOW: ' || From_SowId ||
			    	' TASK_ID: ' || From_Main_Task_ID ||
			    	' To AGR: ' || PIN_ToAgr || 
			    	' WO_ID: ' || PIN_ToWoId ||
			    	' SOW: ' || To_SowId || 
			    	' TASK_ID: ' || To_Main_Task_ID; 
			 	
			    SELECT count(*) into v_RowCount
				  FROM Final Table
				     ( 
				INSERT INTO SOW_WBS_NUMBER
					 ( AGR, 
				   	   SOW_ID, 
				   	   SOW_DETAIL_ID, 
				   	   TASK_ID, 
				   	   WBS_NBR 
			         )
				SELECT PIN_ToAgr as AGR, 
				   	   To_SowId as SOW_ID, 
				   	   SOW_DETAIL_ID, 
				   	   To_Main_Task_ID AS TASK_ID,
				   	   WBS_NBR
				  FROM SOW_WBS_NUMBER	
				 WHERE AGR = PIN_FromAgr
				   AND SOW_ID = From_SowId
				   AND TASK_ID = From_Main_Task_ID
				     );
				               
				Set POUT_SQLCode = SQLCODE;
				Set POUT_SQLSTATE = SQLSTATE; 
				Set v_SOWRowCount6 = v_SOWRowCount6 + v_RowCount; 	   
				Set POUT_RowCount = v_SOWRowCount6; 
			
				END IF;
					
			
			END IF;		
			
	/***   -----------------------------------------------   ***/ 
	/***              DETAIL TASK PROCESSING                 ***/ 
	/***   -----------------------------------------------   ***/
 
			IF From_Detail_Task_ID > 0 THEN
				SET To_Detail_Task_ID = To_Detail_Task_ID + 1;
				
				   	
				IF v_SOWRowCount3 > 0		--  SOW_MAIN_TASK had data
			    THEN	   			
			    -----------------------------------------------
			    -- Clone data for SOW_DETAIL_TASK.
			    -----------------------------------------------
			    Set POUT_ReturnText = 'Failure: SOW_DETAIL_TASK Insert' || 
			    	' From AGR: ' || PIN_FromAgr || 
			    	' WO_ID: ' || PIN_FromWoId ||
			    	' SOW: ' || From_SowId ||
			    	' TASK_ID: ' || From_Main_Task_ID ||
			    	' DETAIL_TASK_ID: ' || From_Detail_Task_ID ||
			    	' To AGR: ' || PIN_ToAgr || 
			    	' WO_ID: ' || PIN_ToWoId ||
			    	' SOW: ' || To_SowId || 
			    	' TASK_ID: ' || To_Main_Task_ID ||
			    	' DETAIL_TASK_ID: ' || To_Detail_Task_ID; 
			    
			    SELECT count(*) into v_RowCount
				  FROM Final Table
				     ( 
				INSERT INTO SOW_DETAIL_TASK
					 ( AGR, 
				   	   SOW_ID, 
				   	   SOW_DETAIL_ID, 
				   	   TASK_ID, 
				   	   DETAIL_TASK_ID, 
				   	   DETAIL_TASK_NAME, 
				   	   NEW_TASK_IND, 
				   	   ESTIMATE_IND, 
				   	   DEPARTMENT_DETAILS, 
				   	   DETAIL_TASK_NBR, 
				   	   SOW_GENERATED_TASK, 
				   	   SOW_GENERATED_DETAIL_TASK, 
				   	   CREATED_BY, 
				   	   CREATED_BY_TS, 
				   	   LAST_MODIFIED_BY, 
				   	   LAST_MODIFIED_TS
				   	 )
				SELECT PIN_ToAgr as AGR, 
				       To_SowId as SOW_ID, 
					   SOW_DETAIL_ID, 
					   To_Main_Task_ID AS TASK_ID, 
					   To_Detail_Task_ID AS DETAIL_TASK_ID, 
					   DETAIL_TASK_NAME,
					   NEW_TASK_IND, 
					   ESTIMATE_IND, 
					   DEPARTMENT_DETAILS, 
					   DETAIL_TASK_NBR, 
					   SOW_GENERATED_TASK, 
					   SOW_GENERATED_DETAIL_TASK, 
				   	   PIN_UserName as CREATED_BY,
				   	   current timestamp as CREATED_BY_TS,
					   PIN_UserName as LAST_MODIFIED_BY,
					   current timestamp as LAST_MODIFIED_TS 
				  FROM SOW_DETAIL_TASK	
				 WHERE AGR = PIN_FromAgr
				   AND SOW_ID = From_SowId
				   AND TASK_ID = From_Main_Task_ID
				   AND DETAIL_TASK_ID = From_Detail_Task_ID
					 );
				             
				Set POUT_SQLCode = SQLCODE;
				Set POUT_SQLSTATE = SQLSTATE;
				SET v_SOWRowCount7 = v_SOWRowCount7 + v_RowCount;
				Set POUT_RowCount = v_SOWRowCount7; 	     
					
				END IF;	
				
				    
				IF v_SOWRowCount7 > 0		-- if SOW_DETAIL_TASK had data
			    THEN     	   			
			    -----------------------------------------------
			    -- Clone data for CST_LABOR_TASK.
			    -----------------------------------------------
			    Set POUT_ReturnText = 'Failure: CST_LABOR_TASK Insert' || 
			    	' From AGR: ' || PIN_FromAgr || 
			    	' WO_ID: ' || PIN_FromWoId ||
			    	' SOW: ' || From_SowId ||
			    	' TASK_ID: ' || From_Main_Task_ID ||
			    	' DETAIL_TASK_ID: ' || From_Detail_Task_ID ||
			    	' To AGR: ' || PIN_ToAgr || 
			    	' WO_ID: ' || PIN_ToWoId ||
			    	' SOW: ' || To_SowId || 
			    	' TASK_ID: ' || To_Main_Task_ID ||
			    	' DETAIL_TASK_ID: ' || To_Detail_Task_ID;
			    
			    SELECT count(*) into v_RowCount
				  FROM Final Table
				     (
				INSERT INTO CST_LABOR_TASK
				     ( AGR,
				   	   SOW_ID,
				   	   CST_EST_ID, 
				   	   SOW_DETAIL_ID, 
				   	   VERSION_ID, 
				   	   TASK_ID, 
				   	   DETAIL_TASK_ID, 
				   	   FIELD_OFFICE_IND, 
				   	   TOTAL_TASK_HOURS, 
				   	   TOTAL_PAYROLL_AMT, 
				   	   PROFIT_IND, 
				   	   AVERAGE_TASK_RATE, 
				   	   TOTAL_DETAIL_TASK_COST_AMT, 
				   	   FIELD_OVERHEAD_AMT, 
				   	   OFFICE_OVERHEAD_AMT, 
				   	   PROFIT_AMT, 
				   	   PROFIT_LIMIT_PCT, 
				   	   ESCALATION_ID, 
				   	   ESCALATION_AMT, 
				   	   SOW_GEN_TASK_ID, 
				   	   SOW_GEN_DTASK_ID, 	 	
				   	   CREATED_BY,
				   	   CREATED_BY_TS,
					   LAST_MODIFIED_BY,
					   LAST_MODIFIED_TS
				     )
				SELECT PIN_ToAgr as AGR,
				   	   To_SowId as SOW_ID,
				   	   CST_EST_ID, 
				   	   SOW_DETAIL_ID, 
				   	   VERSION_ID, 
				   	   To_Main_Task_ID AS TASK_ID, 
				   	   To_Detail_Task_ID AS DETAIL_TASK_ID, 
				   	   FIELD_OFFICE_IND, 
				   	   TOTAL_TASK_HOURS, 
				   	   TOTAL_PAYROLL_AMT, 
				   	   PROFIT_IND, 
				   	   AVERAGE_TASK_RATE, 
				   	   TOTAL_DETAIL_TASK_COST_AMT, 
				   	   FIELD_OVERHEAD_AMT, 
				   	   OFFICE_OVERHEAD_AMT, 
				   	   PROFIT_AMT, 
				   	   PROFIT_LIMIT_PCT, 
				   	   ESCALATION_ID, 
				   	   ESCALATION_AMT, 
				   	   SOW_GEN_TASK_ID, 
				   	   SOW_GEN_DTASK_ID, 	
				   	   PIN_UserName as CREATED_BY,
				   	   current timestamp as CREATED_BY_TS,
					   PIN_UserName as LAST_MODIFIED_BY,
					   current timestamp as LAST_MODIFIED_TS
				  FROM CST_LABOR_TASK
				 WHERE AGR = PIN_FromAgr
				   AND SOW_ID = From_SowId
				   AND CST_EST_ID = v_CstEstId
				   AND VERSION_ID = 0
				   AND TASK_ID = From_Main_Task_ID
				   AND DETAIL_TASK_ID = From_Detail_Task_ID
					 );
				             
				Set POUT_SQLCode = SQLCODE;
				Set POUT_SQLSTATE = SQLSTATE;
				SET v_CSTRowCount05 = v_CSTRowCount05 + v_RowCount;	
				Set POUT_RowCount = v_CSTRowCount05; 
				   		
			    END IF;	    
				
					
				IF v_CSTRowCount05 > 0		--  CST_LABOR_TASK had data
			    THEN     	   			
			    -----------------------------------------------------
			    -- Clone data for CST_LABOR_TASK_CLASSIFICATION_RATE.
			    -----------------------------------------------------
			    Set POUT_ReturnText = 'Failure: LABOR_TASK_CLASSIFICATION Insert' || 
			    	' From AGR: ' || PIN_FromAgr || 
			    	' WO_ID: ' || PIN_FromWoId ||
			    	' SOW: ' || From_SowId ||
			    	' TASK_ID: ' || From_Main_Task_ID ||
			    	' DETAIL_TASK_ID: ' || From_Detail_Task_ID ||
			    	' To AGR: ' || PIN_ToAgr || 
			    	' WO_ID: ' || PIN_ToWoId ||
			    	' SOW: ' || To_SowId || 
			    	' TASK_ID: ' || To_Main_Task_ID ||
			    	' DETAIL_TASK_ID: ' || To_Detail_Task_ID; 
			    	
			    SELECT count(*) into v_RowCount
				  FROM Final Table
				     (
				INSERT INTO CST_LABOR_TASK_CLASSIFICATION_RATE
				     ( AGR,
				   	   SOW_ID,
				   	   CST_EST_ID, 
				   	   SOW_DETAIL_ID, 
				   	   VERSION_ID, 
				   	   TASK_ID, 
				   	   DETAIL_TASK_ID, 
				   	   LABOR_TASK_CLASS_RATE_ID, 
				   	   DPE_EMR_JOB_CLASS_CODE, 
				   	   EMR_JOB_CLASS_DESC, 
				   	   REGULAR_HOURS, 
				   	   OVERTIME_HOURS, 
				   	   HAZARD_HOURS, 
				   	   OVERTIME_HAZARD_HOURS, 
				   	   REGULAR_TOTAL_COST_AMT, 
				   	   OVERTIME_TOTAL_COST_AMT, 
				   	   HAZARD_TOTAL_COST_AMT, 
				   	   OVERTIME_HAZARD_TOTAL_COST_AMT, 
				   	   JOB_CLASS_RATE, 
				   	   JOB_CLASS_HOURS, 
				   	   JOB_CLASS_TOTAL_COST_AMT
				   	 )
				SELECT PIN_ToAgr as AGR,
				   	   To_SowId as SOW_ID,
				   	   CST_EST_ID, 
				   	   SOW_DETAIL_ID, 
				   	   VERSION_ID, 
				   	   To_Main_Task_ID AS TASK_ID, 
				   	   To_Detail_Task_ID AS DETAIL_TASK_ID, 
				   	   LABOR_TASK_CLASS_RATE_ID, 
				   	   DPE_EMR_JOB_CLASS_CODE, 
				   	   EMR_JOB_CLASS_DESC, 
				   	   REGULAR_HOURS, 
				   	   OVERTIME_HOURS, 
				   	   HAZARD_HOURS, 
				   	   OVERTIME_HAZARD_HOURS, 
				   	   REGULAR_TOTAL_COST_AMT, 
				   	   OVERTIME_TOTAL_COST_AMT, 
				   	   HAZARD_TOTAL_COST_AMT, 
				   	   OVERTIME_HAZARD_TOTAL_COST_AMT, 
				   	   JOB_CLASS_RATE, 
				   	   JOB_CLASS_HOURS, 
				   	   JOB_CLASS_TOTAL_COST_AMT
				  FROM CST_LABOR_TASK_CLASSIFICATION_RATE
				 WHERE AGR = PIN_FromAgr
				   AND SOW_ID = From_SowId
				   AND CST_EST_ID = v_CstEstId
				   AND VERSION_ID = 0
				   AND TASK_ID = From_Main_Task_ID
				   AND DETAIL_TASK_ID = From_Detail_Task_ID
					 );
				            
				Set POUT_SQLCode = SQLCODE;
				Set POUT_SQLSTATE = SQLSTATE;
				SET v_CSTRowCount07 = v_CSTRowCount07 + v_RowCount;	
				Set POUT_RowCount = v_CSTRowCount07;  
				   		
			    END IF;
				  
				    
			 	/***   -------------------------------------------------   ***/ 
			 	/***   SPECIAL CONSIDEATIONS FOR PROCESSING UNIT-OF-WORK   ***/ 
			 	/***   -------------------------------------------------   ***/ 
			 	/***        ONLY PROCESS WORK ORDERs WITHIN SAME AGR       ***/ 
			 	/***       OR THE 'To' and 'From' AGRs ARE CLONEs          ***/ 
			 	/***     SO THE UOW NBRs ARE CONSISTENT BETWEEN AGRs       ***/ 
			 	/***   -------------------------------------------------   ***/  
				
				IF v_CSTRowCount05 > 0 AND v_CSTRowCount08 > 0
				-- if LABOR_TASK and UNIT_OF_WORK had data 
			    THEN     	   			
			    -----------------------------------------------
			    -- Clone data for CST_LABOR_TASK_UNITS_OF_WORK.
			    -----------------------------------------------
			    Set POUT_ReturnText = 'Failure: LABOR_TASK_UOW Insert' || 
			    	' From AGR: ' || PIN_FromAgr || 
			    	' WO_ID: ' || PIN_FromWoId ||
			    	' SOW: ' || From_SowId ||
			    	' TASK_ID: ' || From_Main_Task_ID ||
			    	' DETAIL_TASK_ID: ' || From_Detail_Task_ID ||
			    	' To AGR: ' || PIN_ToAgr || 
			    	' WO_ID: ' || PIN_ToWoId ||
			    	' SOW: ' || To_SowId || 
			    	' TASK_ID: ' || To_Main_Task_ID ||
			    	' DETAIL_TASK_ID: ' || To_Detail_Task_ID; 
			    
			    SELECT count(*) into v_RowCount
				  FROM Final Table
				     (
				INSERT INTO CST_LABOR_TASK_UNITS_OF_WORK
				     ( AGR,
				   	   SOW_ID,
				   	   CST_EST_ID, 
				   	   SOW_DETAIL_ID, 
				   	   VERSION_ID, 
				   	   UNIT_OF_WORK_NBR, 
				   	   TASK_ID, 
				   	   DETAIL_TASK_ID
				   	 )
				SELECT PIN_ToAgr as AGR,
				   	   To_SowId as SOW_ID,
				   	   CST_EST_ID, 
				   	   SOW_DETAIL_ID, 
				   	   VERSION_ID, 
				   	   UNIT_OF_WORK_NBR, 	   	   
				   	   To_Main_Task_ID AS TASK_ID, 
				   	   To_Detail_Task_ID AS DETAIL_TASK_ID
				  FROM CST_LABOR_TASK_UNITS_OF_WORK
				 WHERE AGR = PIN_FromAgr
				   AND SOW_ID = From_SowId
				   AND CST_EST_ID = v_CstEstId
				   AND VERSION_ID = 0
					 );
				              
				Set POUT_SQLCode = SQLCODE;
				Set POUT_SQLSTATE = SQLSTATE;
			    SET v_CSTRowCount09 = v_CSTRowCount09 + v_RowCount;
				Set POUT_RowCount = v_CSTRowCount09;
				   		
			    END IF;
			    
    
           		END IF;     

		
	 	/***   -----------------------------------------------   ***/ 
	 	/***   END OF PROCESS SOW_DETAIL_TASK                    ***/ 
	 	/***   -----------------------------------------------   ***/ 	
             

    END IF;     
    
    END WHILE;
    
	
 	/***   -----------------------------------------------   ***/ 
 	/***   END OF PROCESS SOW_MAIN_TASK                      ***/ 
 	/***   -----------------------------------------------   ***/ 	 
	
	
 	/***   -------------------------------------------------   ***/ 
 	/***   SPECIAL CONSIDEATIONS FOR PROCESSING UNIT-OF-WORK   ***/ 
 	/***   -------------------------------------------------   ***/ 
 	/***        ONLY PROCESS WORK ORDERs WITHIN SAME AGR       ***/ 
 	/***       OR THE 'To' and 'From' AGRs ARE CLONEs          ***/ 
 	/***     SO THE UOW NBRs ARE CONSISTENT BETWEEN AGRs       ***/ 
 	/***   -------------------------------------------------   ***/ 
	
	IF v_CSTRowCount06 > 0 AND v_CSTRowCount08 > 0
	-- if OTHER_COST and UNIT_OF_WORK had data 
    THEN     	   			
    -----------------------------------------------
    -- Clone data for CST_OTHER_COST_UNITS_OF_WORK.
    -----------------------------------------------
    Set POUT_ReturnText = 'Failure: CST_OTHER_COST_UOW Insert';
    
    SELECT count(*) into v_CSTRowCount10
	  FROM Final Table
	       (
	INSERT INTO CST_OTHER_COST_UNITS_OF_WORK (
	       AGR,
	   	   SOW_ID,
	   	   CST_EST_ID, 
	 	   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   UNIT_OF_WORK_NBR, 
	   	   OTHER_COST_ID
	   	   )
	SELECT PIN_ToAgr as AGR,
	   	   To_SowId AS SOW_ID,
	   	   CST_EST_ID, 
		   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   UNIT_OF_WORK_NBR, 
	   	   OTHER_COST_ID
	  FROM CST_OTHER_COST_UNITS_OF_WORK
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = From_SowId
	   AND CST_EST_ID = v_CstEstId
	   AND VERSION_ID = 0
		   );
	       
	Set POUT_RowCount = v_CSTRowCount10;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;
	   		
    END IF;	
    
	
    -----------------------------------------------
    -----------------------------------------------
    -- Normal Return Processing
    -----------------------------------------------
    -----------------------------------------------
    
	 Set v_RowCount = 
			v_SOWRowCount1 + 
			v_SOWRowCount2 + 
			v_SOWRowCount3 + 
			v_SOWRowCount4 +
			v_SOWRowCount5 +
			v_SOWRowCount6 +
			v_SOWRowCount7 +
			v_CSTRowCount01 +
			v_CSTRowCount02 +
			v_CSTRowCount03 + 
			v_CSTRowCount04 +
			v_CSTRowCount05 +
			v_CSTRowCount06 +
			v_CSTRowCount07 +
			v_CSTRowCount08 +
			v_CSTRowCount10;
    
/**	
	Set POUT_ReturnText = 'Success' || 
    	' From AGR: ' || PIN_FromAgr || 
    	' WO_ID: ' || PIN_FromWoId ||
    	' SOW: ' || From_SowId ||
    	' TASK_ID: ' || From_Main_Task_ID ||
    	' DETAIL_TASK_ID: ' || From_Detail_Task_ID ||
    	' To AGR: ' || PIN_ToAgr || 
    	' WO_ID: ' || PIN_ToWoId ||
    	' SOW: ' || To_SowId || 
    	' TASK_ID: ' || To_Main_Task_ID ||
    	' DETAIL_TASK_ID: ' || To_Detail_Task_ID;
    	
   Set POUT_ReturnText = POUT_ReturnText ||  	
    	' SOW_SCOPE_OF_WORK: ' || v_SOWRowCount1 ||
   			' SOW_DETAIL: ' || v_SOWRowCount2 || 
		' SOW_MAIN_TASK: ' || v_SOWRowCount3 ||
		' SOW_TASK_OBJECTIVE: ' || v_SOWRowCount4 ||
		' SOW_TASK_SCOPE: ' || v_SOWRowCount5 ||
		' SOW_WBS_NUMBER: ' || v_SOWRowCount6 || 
		' SOW_DETAIL_TASK: ' || v_SOWRowCount7;
		
   Set POUT_ReturnText = POUT_ReturnText ||  	
		' CST_COST_ESTIMATE: ' || v_CSTRowCount01 || 
		' CST_DETAIL: ' || v_CSTRowCount02 || 
		' CST_COST_FACTOR: ' || v_CSTRowCount03 || 
		' CST_ESCALATION: ' || v_CSTRowCount04 || 
		' CST_LABOR_TASK: ' || v_CSTRowCount05 || 
		' CST_OTHER_COST: ' || v_CSTRowCount06 || 
		' CST_LABOR_TASK_CLASSIFICATION_RATE: ' || v_CSTRowCount07 || 
		' CST_UNIT_OF_WORK: ' || v_CSTRowCount08 || 
		' CST_LABOR_TASK_UNITS_OF_WORK: ' || v_CSTRowCount09 || 
		' CST_OTHER_COST_UNITS_OF_WORK: ' || v_CSTRowCount10;
		
    Set POUT_RowCount = v_RowCount;
**/
			
	IF (POUT_SQLCode = 0 AND POUT_SQLSTATE = '00000')
	THEN	
    	Set POUT_ReturnText = 'Success';
    	Set POUT_RowCount = v_RowCount;
    END IF;
    
    
END P1;
