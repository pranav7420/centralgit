CREATE PROCEDURE ECMSXADM.SPCA0019 (IN P_PROJNUM INTEGER , IN P_BIDPKGNUM SMALLINT , IN P_BPID	CHAR(6) , OUT P_SQLCODE INTEGER)
	VERSION V1
	ISOLATION LEVEL CS
	RESULT SETS 1
	LANGUAGE SQL
	ALLOW DEBUG MODE
	WLM ENVIRONMENT FOR DEBUG MODE DSNDWLM2
	P1: BEGIN


DECLARE V_SQLCODE                		INT     DEFAULT 0;      
DECLARE V_SQLSTATE               		CHAR(5) DEFAULT '00000';
DECLARE SQLCODE                  		INT     DEFAULT 0;      
DECLARE SQLSTATE                 		CHAR(5) DEFAULT '00000';
DECLARE V_PRJ_PREQ_REQD_IND      		CHAR(1) DEFAULT ' ';  
DECLARE V_APF_ITEM_NUMBER				CHAR(8) DEFAULT '        ';
DECLARE V_APF_ITEM_TYPE_CODE			CHAR(2) DEFAULT '  ';
DECLARE V_APF_WCC						CHAR(2) DEFAULT '  ';
DECLARE V_APF_AMT						DECIMAL (13,4) DEFAULT 0;
DECLARE V_APF_TOTAL						DECIMAL (13,4) DEFAULT 0;
DECLARE V_TOTAL_CREDIT					DECIMAL (13,4) DEFAULT 0;
DECLARE V_TOTAL_PRICE					DECIMAL (13,4) DEFAULT 0;
DECLARE V_TOTAL_QITEMS					DECIMAL (13,4) DEFAULT 0;
DECLARE V_TOTAL_XITEMS					DECIMAL (13,4) DEFAULT 0;
DECLARE V_TOTAL_ZZITEMS					DECIMAL (13,4) DEFAULT 0;
DECLARE V_TOTAL_ZITEMS					DECIMAL (13,4) DEFAULT 0;
DECLARE V_PB							DECIMAL (13,4) DEFAULT 0;
DECLARE V_CALCULATED_PERCENT			DECIMAL (13,4) DEFAULT 0;

DECLARE V_ACITEM_BPID					CHAR(6);
DECLARE V_EMAILNUM						SMALLINT DEFAULT 0;
DECLARE V_HOLD_ITEM_TYPE_CODE			CHAR(2) DEFAULT '  ';
DECLARE V_HOLD_ITEM_NUMBER				CHAR(8) DEFAULT '        ';
DECLARE V_AUTOMATIC_SUBTYPE				CHAR(1) DEFAULT ' ';
DECLARE V_SYSTEM_USERID					CHAR(19) DEFAULT 'ECMS System/PennDOT';
DECLARE V_VERIFIED_APPARENT_LOW			CHAR(2)  DEFAULT '02';
DECLARE V_GEN_CODE_VALUE150             CHAR(150) DEFAULT '    ';
DECLARE V_PASSED_STATUS                 CHAR(1) DEFAULT 'P';
DECLARE V_FAILED_STATUS                 CHAR(1) DEFAULT 'F';

DECLARE V_BPID_ERRORS					CHAR(34) DEFAULT ' ';
DECLARE V_LENGTH						SMALLINT DEFAULT 0;






DECLARE V_PERCENT_REQUIREDTO_PASS		DECIMAL(5,2) DEFAULT 0;
DECLARE V_TEST_PASS                     CHAR(1) DEFAULT '1';  
-- 1 = ALL PASSED,  2 = ONE FAILED, 0 = NO PASSED STATE
DECLARE V_GP_GEN_CODE_VALUE             VARCHAR(255);
DECLARE V_PARM_GEN_CODE_TYPE     		SMALLINT DEFAULT 79;
DECLARE V_TYPE_CODE_FIFTYWCC			CHAR(3) DEFAULT '110';
DECLARE V_TYPE_CODE_FINCAP       		CHAR(3) DEFAULT '100';
DECLARE V_PROCESS_PRIME                 CHAR(1) DEFAULT 'Y';
DECLARE V_END_OF_CURSOR                 CHAR(1) DEFAULT 'N';
DECLARE V_END_OF_CURSOR_2				CHAR(1)	DEFAULT 'N';		
DECLARE V_PC_BUS_PARTNER_ID             CHAR(6) DEFAULT '      ';
DECLARE V_JV_ID							CHAR(6) DEFAULT '      ';
DECLARE V_PRIME_BPID                    CHAR(6) DEFAULT '   ';
DECLARE V_PARENT_BPID                   CHAR(6) DEFAULT '   ';
DECLARE V_WCC_BPID  	                CHAR(6) DEFAULT '   ';
DECLARE V_GHC_BPID      	            CHAR(6) DEFAULT '   ';
DECLARE V_GENNED_ITEM_NUM        		SMALLINT DEFAULT 0;
DECLARE V_PC_CONTR_GHC_IND 				CHAR(1)	 DEFAULT ' ';
DECLARE V_PARM_STATUS                   CHAR(1)  DEFAULT ' ';
DECLARE V_ERRCD                         SMALLINT     DEFAULT 0;
DECLARE V_ERRLOC                        CHAR(5)      DEFAULT '     ';
DECLARE V_TABLEID                  		CHAR(12)     DEFAULT '$ECMSRETURN$';


DECLARE SINGLE_PARM_CURSOR CURSOR WITH RETURN
   FOR                                        
   SELECT V_TABLEID,                        
          V_SQLCODE,                          
          V_ERRCD,                          
          V_ERRLOC,
          V_BPID_ERRORS                    
     FROM SYSIBM.SYSDUMMY1    ;
     

DECLARE BID_CONTRACTOR CURSOR FOR           
  SELECT A.PARTNER_BP_ID              
    FROM CONTR_ECMS_BID_PARTNER_WORK A             
   WHERE ECMS_PROJECT_NUM = P_PROJNUM
     AND PROJ_CONTR_TYPE IN ( 'P')
     AND A.BID_PACKAGE_NUM = P_BIDPKGNUM
     AND A.BUS_PARTNER_ID = P_BPID
     
   ORDER BY PROJ_CONTR_TYPE DESC       ;
   
   
DECLARE APF CURSOR FOR                                   
SELECT DI.ITEM_NUMBER,                                   
                                     
       DIWCC.WORK_CLASS_CODE,                            
       VALUE (SUM(CEBIW.ITEM_QTY * CEBIW.ITEM_UNIT_PRICE),0)    
  FROM DESIGN_ITEM DI,                                    
       DESIGN_ITEM_WCC DIWCC,
       CONTR_ECMS_BID_ITEM_WORK CEBIW,                             
       CONTR_REG_WCC CRWCC                               
 WHERE CEBIW.ECMS_PROJECT_NUM = P_PROJNUM  
   AND CEBIW.BID_PACKAGE_NUM  = P_BIDPKGNUM               
   AND DI.ECMS_PROJECT_NUM    = DIWCC.ECMS_PROJECT_NUM 
   AND DI.ECMS_PROJECT_NUM    = CEBIW.ECMS_PROJECT_NUM     
 
   AND DI.LINE_ITEM_NUM = DIWCC.LINE_ITEM_NUM 
   AND DI.LINE_ITEM_NUM = CEBIW.LINE_ITEM_NUM             
     
   AND DIWCC.WORK_CLASS_CODE NOT IN ('Q ','Z ','X ','ZZ')
   AND DIWCC.WORK_CLASS_CODE = CRWCC.WORK_CLASS_CODE     
   AND CRWCC.BUS_PARTNER_ID = V_WCC_BPID                  
   AND CRWCC.WC_STATUS_CODE = '2'                        
 GROUP BY DI.ITEM_NUMBER,                                
                                   
          DIWCC.WORK_CLASS_CODE                          
 ORDER BY DI.ITEM_NUMBER;                                


DECLARE BID_CONTRACTOR_JV CURSOR FOR           
  SELECT A.PARTNER_BP_ID              
    FROM CONTR_ECMS_BID_PARTNER_WORK A             
   WHERE ECMS_PROJECT_NUM = P_PROJNUM
     AND PROJ_CONTR_TYPE IN ( 'J')
     AND A.BID_PACKAGE_NUM = P_BIDPKGNUM
     AND A.BUS_PARTNER_ID = P_BPID
     
   ORDER BY PROJ_CONTR_TYPE DESC       ;   
   
                                       


            
DECLARE EXIT HANDLER FOR SQLEXCEPTION

	BEGIN
	
	   SET V_SQLCODE = SQLCODE   ;
       SET V_ERRCD = -1;
       OPEN SINGLE_PARM_CURSOR;
       
   END;

--SET CURRENT PRECISION = 'D31.5';

SET V_PARM_STATUS = V_PASSED_STATUS;

SET V_TEST_PASS = '1';
SET V_ERRLOC = 'D010';   
SELECT DEC(GEN_CODE_VALUE,5,2)                
  INTO V_PERCENT_REQUIREDTO_PASS               
  FROM ECMSXADM.COM_GENERAL_CODE                       
 WHERE GEN_CODE_TYPE = 921 AND GEN_CODE = '05';
 
SET V_ERRLOC = 'D020';   
SELECT PREQ_REQD_IND                       
  INTO V_PRJ_PREQ_REQD_IND 
  FROM PROJECT                             
WHERE ECMS_PROJECT_NUM = P_PROJNUM ;

IF V_PRJ_PREQ_REQD_IND = ' ' OR V_PRJ_PREQ_REQD_IND IS NULL 
THEN
	SET V_PRJ_PREQ_REQD_IND = 'Y';
END IF;

SET V_ERRLOC = 'D030'; 
SELECT GEN_CODE_VALUE                      
INTO V_GP_GEN_CODE_VALUE                  
FROM ECMSXADM.COM_GENERAL_CODE                    
WHERE GEN_CODE_TYPE = V_PARM_GEN_CODE_TYPE 
  AND GEN_CODE = V_TYPE_CODE_FIFTYWCC ;
  
IF V_PRJ_PREQ_REQD_IND = 'Y'
THEN
	OPEN BID_CONTRACTOR;
    SET V_PROCESS_PRIME       =  'Y';
    SET V_END_OF_CURSOR       =  'N';
    WHILE V_END_OF_CURSOR = 'N'
    DO
    SET V_ERRLOC = 'D040' ;     
    FETCH FROM BID_CONTRACTOR
    INTO   V_PC_BUS_PARTNER_ID;
    IF SQLCODE = 100
    THEN 
    	CLOSE BID_CONTRACTOR;  
        SET V_END_OF_CURSOR = 'Y';
   	ELSE
   		   	SET V_PROCESS_PRIME = 'N';
         	SET V_PRIME_BPID = V_PC_BUS_PARTNER_ID;
         	SET V_ACITEM_BPID  = V_PC_BUS_PARTNER_ID;	
                 
         	SET V_ERRLOC = 'D050'; 
            SELECT PARENT_BP_ID                
  			INTO V_PARENT_BPID                
  			FROM ECMSXADM.CONTRACTOR                  
 			WHERE BUS_PARTNER_ID = V_PRIME_BPID;
 			 
 			IF  SQLCODE = 0
 			THEN
 			 	SET V_GHC_BPID = V_PARENT_BPID ;
 			 	SET V_WCC_BPID = V_PARENT_BPID ;
 			ELSE
 			 	SET V_ACITEM_BPID = V_PC_BUS_PARTNER_ID ;
 			 	SET V_GHC_BPID 	  = V_PC_BUS_PARTNER_ID ;	
 			END IF;
 			 
 			SET V_ERRLOC = 'D060';
 			SELECT CONTR_GHC_IND                       
  			INTO V_PC_CONTR_GHC_IND  
  			FROM ECMSXADM.PREQ_CONTRACTOR                     
 			WHERE BUS_PARTNER_ID = V_GHC_BPID  ;
 			           		
 			IF V_PC_CONTR_GHC_IND IS NULL
 			THEN
 				SET V_PC_CONTR_GHC_IND = 'N'  ; -- NOT GHC-CONTRACTOR
 			END IF;
 			 
 			IF V_PC_CONTR_GHC_IND = 'N'   -- GHC-CONTRACTOR
 			THEN
 				OPEN APF ;
  				SET V_END_OF_CURSOR_2 =  'F';
				WHILE V_END_OF_CURSOR_2 = 'F'
				DO
					FETCH APF 
					INTO	V_APF_ITEM_NUMBER,   
  						--	V_APF_ITEM_TYPE_CODE,
  							V_APF_WCC,           
  							V_APF_AMT ;
  					IF SQLCODE = 100
  					THEN
  						SET V_END_OF_CURSOR_2 = 'V' ;
  						CLOSE APF;
  					ELSE
  						IF  V_APF_ITEM_NUMBER <> V_HOLD_ITEM_NUMBER
  						THEN
  							SET V_APF_TOTAL =	V_APF_TOTAL + V_APF_AMT	;
  							SET V_HOLD_ITEM_NUMBER = V_APF_ITEM_NUMBER;
  							SET V_HOLD_ITEM_TYPE_CODE =	V_APF_ITEM_TYPE_CODE ;	
  						--ELSE
  						--	IF V_APF_ITEM_TYPE_CODE <> V_HOLD_ITEM_TYPE_CODE
  						--	THEN
  						--		SET V_APF_TOTAL = V_APF_TOTAL + V_APF_AMT;
  						--		SET V_HOLD_ITEM_TYPE_CODE = V_APF_ITEM_TYPE_CODE;
  						--	END IF;		
  						END IF;		
  					END IF;					
  				END WHILE;
  				
  				SET V_ERRLOC = 'D070';	
  				SELECT VALUE (SUM(CAST(CEBIW.ITEM_QTY * CEBIW.ITEM_UNIT_PRICE AS DECIMAL(13,4))),0) 
  				INTO V_TOTAL_QITEMS
  				                                  
  				FROM ECMSXADM.DESIGN_ITEM DI, 
  					 ECMSXADM.CONTR_ECMS_BID_ITEM_WORK CEBIW,
  					 ECMSXADM.DESIGN_ITEM_WCC DIWCC   
  					                         
 				WHERE CEBIW.ECMS_PROJECT_NUM 	= P_PROJNUM 
 				  AND CEBIW.BID_PACKAGE_NUM 	= P_BIDPKGNUM
     			  AND CEBIW.BUS_PARTNER_ID 		= P_BPID             
   				  AND DI.ECMS_PROJECT_NUM 		= DIWCC.ECMS_PROJECT_NUM
   				  AND DI.ECMS_PROJECT_NUM 		= CEBIW.ECMS_PROJECT_NUM   
   				
   				  AND DI.LINE_ITEM_NUM = DIWCC.LINE_ITEM_NUM 
   				  AND DI.LINE_ITEM_NUM = CEBIW.LINE_ITEM_NUM                
   				    
   				  AND DIWCC.WORK_CLASS_CODE = 'Q '  ;    
   				 
   				
   				  
   				SET V_ERRLOC = 'D080';
   				SELECT VALUE (SUM(CAST(CEBIW.ITEM_QTY * CEBIW.ITEM_UNIT_PRICE AS DECIMAL(13,4))),0)
  				INTO V_TOTAL_ZITEMS                                 
  				FROM ECMSXADM.DESIGN_ITEM DI,                                
       				 ECMSXADM.DESIGN_ITEM_WCC DIWCC,
       				 ECMSXADM.CONTR_ECMS_BID_ITEM_WORK CEBIW                          
 				WHERE CEBIW.ECMS_PROJECT_NUM = P_PROJNUM 
 				  AND CEBIW.BID_PACKAGE_NUM = P_BIDPKGNUM
     			  AND CEBIW.BUS_PARTNER_ID = P_BPID                 
   				  AND DI.ECMS_PROJECT_NUM = DIWCC.ECMS_PROJECT_NUM 
   				  AND DI.ECMS_PROJECT_NUM = CEBIW.ECMS_PROJECT_NUM 
   				 -- AND CI.ITEM_NUMBER = CIWCC.ITEM_NUMBER 
   				  AND DI.LINE_ITEM_NUM = DIWCC.LINE_ITEM_NUM 
   				  AND DI.LINE_ITEM_NUM = CEBIW.LINE_ITEM_NUM                
   				 -- AND CI.ITEM_TYPE_CODE = CIWCC.ITEM_TYPE_CODE      
   				  AND DIWCC.WORK_CLASS_CODE = 'Z '   ;
   				  
   				  
   				SET V_ERRLOC = 'D090';	                 
   				SELECT VALUE (SUM(CAST(CEBIW.ITEM_QTY * CEBIW.ITEM_UNIT_PRICE AS DECIMAL(13,4))),0)
  				INTO V_TOTAL_XITEMS                                 
  				FROM ECMSXADM.DESIGN_ITEM DI,                                
       				 ECMSXADM.DESIGN_ITEM_WCC DIWCC,
       				 ECMSXADM.CONTR_ECMS_BID_ITEM_WORK CEBIW                          
 				WHERE CEBIW.ECMS_PROJECT_NUM = P_PROJNUM 
 				  AND CEBIW.BID_PACKAGE_NUM = P_BIDPKGNUM
     			  AND CEBIW.BUS_PARTNER_ID = P_BPID                 
   				  AND DI.ECMS_PROJECT_NUM = DIWCC.ECMS_PROJECT_NUM 
   				  AND DI.ECMS_PROJECT_NUM = CEBIW.ECMS_PROJECT_NUM 
   				 -- AND CI.ITEM_NUMBER = CIWCC.ITEM_NUMBER  
   				  AND DI.LINE_ITEM_NUM = DIWCC.LINE_ITEM_NUM  
   				  AND DI.LINE_ITEM_NUM = CEBIW.LINE_ITEM_NUM            
   				--  AND CI.ITEM_TYPE_CODE = CIWCC.ITEM_TYPE_CODE      
   				  AND DIWCC.WORK_CLASS_CODE = 'X '   ;               	   
   				
   				
   				SET V_ERRLOC = 'D100';	      
   				SELECT VALUE (SUM(CAST(CEBIW.ITEM_QTY * CEBIW.ITEM_UNIT_PRICE AS DECIMAL(13,4))),0)
  				INTO V_TOTAL_ZZITEMS                                
  				FROM ECMSXADM.DESIGN_ITEM DI,                                
       				 ECMSXADM.DESIGN_ITEM_WCC DIWCC,
       				 ECMSXADM.CONTR_ECMS_BID_ITEM_WORK CEBIW                          
 				WHERE CEBIW.ECMS_PROJECT_NUM = P_PROJNUM
 				  AND CEBIW.BID_PACKAGE_NUM = P_BIDPKGNUM
     			  AND CEBIW.BUS_PARTNER_ID = P_BPID              
   				  AND DI.ECMS_PROJECT_NUM = DIWCC.ECMS_PROJECT_NUM  
   				  AND DI.ECMS_PROJECT_NUM = CEBIW.ECMS_PROJECT_NUM
   				 -- AND CI.ITEM_NUMBER = CIWCC.ITEM_NUMBER 
   				  AND DI.LINE_ITEM_NUM = DIWCC.LINE_ITEM_NUM 
   				  AND DI.LINE_ITEM_NUM = CEBIW.LINE_ITEM_NUM              
   				--  AND CI.ITEM_TYPE_CODE = CIWCC.ITEM_TYPE_CODE      
   				  AND DIWCC.WORK_CLASS_CODE = 'ZZ'       ;
   				  
   				SET V_TOTAL_CREDIT = V_APF_TOTAL + V_TOTAL_QITEMS + V_TOTAL_ZITEMS ;
   				
   				SET V_ERRLOC = 'D110';	
   				SELECT VALUE (SUM(CAST(CEBIW.ITEM_QTY * CEBIW.ITEM_UNIT_PRICE AS DECIMAL(13,4))),0)
  				INTO V_PB                                           
  				--FROM ECMSXADM.DESIGN_ITEM 
  				FROM ECMSXADM.CONTR_ECMS_BID_ITEM_WORK CEBIW
  				INNER JOIN ECMSXADM.DESIGN_ITEM DI 
  				  ON CEBIW.ECMS_PROJECT_NUM = DI.ECMS_PROJECT_NUM
  				 AND CEBIW.LINE_ITEM_NUM = DI.LINE_ITEM_NUM 
  				WHERE CEBIW.ECMS_PROJECT_NUM 	= P_PROJNUM 
  				  AND CEBIW.BID_PACKAGE_NUM 	= P_BIDPKGNUM
     			  AND CEBIW.BUS_PARTNER_ID 		= P_BPID
     			  AND COALESCE(DI.IB_ITEM_TYPE_CODE, '') = ''       ;
 				
 				SET V_TOTAL_PRICE = ((V_PB - V_TOTAL_XITEMS) - V_TOTAL_ZZITEMS);
 				IF V_TOTAL_PRICE <> 0
 				THEN
 					SET V_CALCULATED_PERCENT = (V_TOTAL_CREDIT / V_TOTAL_PRICE) * 100 ;
 				END IF;	
 				
 				IF V_CALCULATED_PERCENT <  V_PERCENT_REQUIREDTO_PASS
 				THEN
 					SET V_PARM_STATUS = V_FAILED_STATUS;
 					SET V_BPID_ERRORS = TRIM(V_BPID_ERRORS) || V_PC_BUS_PARTNER_ID || ',';
 				END IF;	 	   				
   				
   				
  						
 			END IF;
                
    END IF;
   	END WHILE;  
   
 
   
   
   -- LOGIC FOR JOINT VENTURE STARTS HERE
   
  	OPEN BID_CONTRACTOR_JV;
   -- SET V_PROCESS_PRIME       =  'Y';
    SET V_END_OF_CURSOR       =  'N';
    WHILE V_END_OF_CURSOR = 'N'
    DO
    SET V_ERRLOC = 'J010' ;     
    FETCH FROM BID_CONTRACTOR_JV
    INTO   V_PC_BUS_PARTNER_ID;
    IF SQLCODE = 100
    THEN 
    	CLOSE BID_CONTRACTOR_JV;  
        SET V_END_OF_CURSOR = 'Y';
   	ELSE
   		   --	SET V_PROCESS_PRIME = 'N';
   		   	
         	SET V_PRIME_BPID 	= V_PC_BUS_PARTNER_ID;
         	SET V_ACITEM_BPID  	= V_PC_BUS_PARTNER_ID;
         	SET V_JV_ID		   	= V_PC_BUS_PARTNER_ID;		
                 
         	SET V_ERRLOC = 'J020'; 
            SELECT PARENT_BP_ID                
  			INTO V_PARENT_BPID                
  			FROM ECMSXADM.CONTRACTOR                  
 			WHERE BUS_PARTNER_ID = V_PRIME_BPID;
 			 
 			IF  SQLCODE = 0
 			THEN
 			 	SET V_GHC_BPID = V_PARENT_BPID ;
 			 	SET V_WCC_BPID = V_PARENT_BPID ;
 			ELSE
 			 	SET V_ACITEM_BPID = V_PC_BUS_PARTNER_ID ;
 			 	SET V_GHC_BPID 	  = V_PC_BUS_PARTNER_ID ;	
 			END IF;
 			 
 			SET V_ERRLOC = 'J030';
 			SELECT CONTR_GHC_IND                       
  			INTO V_PC_CONTR_GHC_IND  
  			FROM ECMSXADM.PREQ_CONTRACTOR                     
 			WHERE BUS_PARTNER_ID = V_GHC_BPID  ;
 			           		
 			IF V_PC_CONTR_GHC_IND IS NULL
 			THEN
 				SET V_PC_CONTR_GHC_IND = 'N'  ; -- NOT GHC-CONTRACTOR
 			END IF;
 			 
 			IF V_PC_CONTR_GHC_IND = 'N'   -- GHC-CONTRACTOR
 			THEN
 				OPEN APF ;
  				SET V_END_OF_CURSOR_2 =  'F';
				WHILE V_END_OF_CURSOR_2 = 'F'
				DO
					FETCH APF 
					INTO	V_APF_ITEM_NUMBER,   
  						--	V_APF_ITEM_TYPE_CODE,
  							V_APF_WCC,           
  							V_APF_AMT ;
  					IF SQLCODE = 100
  					THEN
  						SET V_END_OF_CURSOR_2 = 'V' ;
  						CLOSE APF;
  					ELSE
  						IF  V_APF_ITEM_NUMBER <> V_HOLD_ITEM_NUMBER
  						THEN
  							SET V_APF_TOTAL =	V_APF_TOTAL + V_APF_AMT	;
  							SET V_HOLD_ITEM_NUMBER = V_APF_ITEM_NUMBER;
  							SET V_HOLD_ITEM_TYPE_CODE =	V_APF_ITEM_TYPE_CODE ;	
  						--ELSE
  						--	IF V_APF_ITEM_TYPE_CODE <> V_HOLD_ITEM_TYPE_CODE
  						--	THEN
  						--		SET V_APF_TOTAL = V_APF_TOTAL + V_APF_AMT;
  						--		SET V_HOLD_ITEM_TYPE_CODE = V_APF_ITEM_TYPE_CODE;
  						--	END IF;		
  						END IF;		
  					END IF;					
  				END WHILE;
  				
  				SET V_ERRLOC = 'J040';	
  				SELECT VALUE (SUM(CEBIW.ITEM_QTY_SUB * CEBIW.ITEM_UNIT_PRICE_SUB),0) 
  				INTO V_TOTAL_QITEMS                                  
  				FROM ECMSXADM.DESIGN_ITEM DI, 
  					 ECMSXADM.CONTR_ECMS_BID_ITEM_SUB_WORK CEBIW,
  					 ECMSXADM.DESIGN_ITEM_WCC DIWCC
  					                            
 				WHERE CEBIW.ECMS_PROJECT_NUM 	= P_PROJNUM 
 				  AND CEBIW.BID_PACKAGE_NUM 	= P_BIDPKGNUM
     			  AND CEBIW.BUS_PARTNER_ID 		= P_BPID
     			  AND CEBIW.PARTNER_BP_ID  		= V_JV_ID             
   				  AND DI.ECMS_PROJECT_NUM 		= DIWCC.ECMS_PROJECT_NUM
   				  AND DI.ECMS_PROJECT_NUM 		= CEBIW.ECMS_PROJECT_NUM   
   				
   				  AND DI.LINE_ITEM_NUM = DIWCC.LINE_ITEM_NUM 
   				  AND DI.LINE_ITEM_NUM = CEBIW.LINE_ITEM_NUM                
   				     
   				  AND DIWCC.WORK_CLASS_CODE = 'Q '  ;    
   				 
   				  
   				SET V_ERRLOC = 'J050';
   				SELECT VALUE (SUM(CEBIW.ITEM_QTY_SUB * CEBIW.ITEM_UNIT_PRICE_SUB),0)
  				INTO V_TOTAL_ZITEMS                                 
  				FROM ECMSXADM.DESIGN_ITEM DI,                                
       				 ECMSXADM.DESIGN_ITEM_WCC DIWCC,
       				 ECMSXADM.CONTR_ECMS_BID_ITEM_SUB_WORK CEBIW  
       				                         
 				WHERE CEBIW.ECMS_PROJECT_NUM 	= P_PROJNUM 
 				  AND CEBIW.BID_PACKAGE_NUM 	= P_BIDPKGNUM
     			  AND CEBIW.BUS_PARTNER_ID 		= P_BPID 
     			  AND CEBIW.PARTNER_BP_ID  		= V_JV_ID                 
   				  AND DI.ECMS_PROJECT_NUM 		= DIWCC.ECMS_PROJECT_NUM 
   				  AND DI.ECMS_PROJECT_NUM 		= CEBIW.ECMS_PROJECT_NUM 
   				 
   				  AND DI.LINE_ITEM_NUM = DIWCC.LINE_ITEM_NUM 
   				  AND DI.LINE_ITEM_NUM = CEBIW.LINE_ITEM_NUM                
   				      
   				  AND DIWCC.WORK_CLASS_CODE = 'Z '   ;
   				  
   				  
   				SET V_ERRLOC = 'J060';	                 
   				SELECT VALUE (SUM(CEBIW.ITEM_QTY_SUB * CEBIW.ITEM_UNIT_PRICE_SUB),0)
  				INTO V_TOTAL_XITEMS                                 
  				FROM ECMSXADM.DESIGN_ITEM DI,                                
       				 ECMSXADM.DESIGN_ITEM_WCC DIWCC,
       				 ECMSXADM.CONTR_ECMS_BID_ITEM_SUB_WORK CEBIW  
       				                         
 				WHERE CEBIW.ECMS_PROJECT_NUM 	= P_PROJNUM 
 				  AND CEBIW.BID_PACKAGE_NUM 	= P_BIDPKGNUM
     			  AND CEBIW.BUS_PARTNER_ID 		= P_BPID 
     			  AND CEBIW.PARTNER_BP_ID  		= V_JV_ID                 
   				  AND DI.ECMS_PROJECT_NUM 		= DIWCC.ECMS_PROJECT_NUM 
   				  AND DI.ECMS_PROJECT_NUM 		= CEBIW.ECMS_PROJECT_NUM 
   				 
   				  AND DI.LINE_ITEM_NUM = DIWCC.LINE_ITEM_NUM  
   				  AND DI.LINE_ITEM_NUM = CEBIW.LINE_ITEM_NUM            
   				     
   				  AND DIWCC.WORK_CLASS_CODE = 'X '   ;               	   
   				
   				
   				SET V_ERRLOC = 'J070';	      
   				SELECT VALUE (SUM(CEBIW.ITEM_QTY_SUB * CEBIW.ITEM_UNIT_PRICE_SUB),0)
  				INTO V_TOTAL_ZZITEMS                                
  				FROM ECMSXADM.DESIGN_ITEM DI,                                
       				 ECMSXADM.DESIGN_ITEM_WCC DIWCC,
       				 ECMSXADM.CONTR_ECMS_BID_ITEM_SUB_WORK CEBIW  
       				                         
 				WHERE CEBIW.ECMS_PROJECT_NUM 	= P_PROJNUM
 				  AND CEBIW.BID_PACKAGE_NUM 	= P_BIDPKGNUM
     			  AND CEBIW.BUS_PARTNER_ID 		= P_BPID
     			  AND CEBIW.PARTNER_BP_ID  		= V_JV_ID               
   				  AND DI.ECMS_PROJECT_NUM 		= DIWCC.ECMS_PROJECT_NUM  
   				  AND DI.ECMS_PROJECT_NUM 		= CEBIW.ECMS_PROJECT_NUM
   				 
   				  AND DI.LINE_ITEM_NUM = DIWCC.LINE_ITEM_NUM 
   				  AND DI.LINE_ITEM_NUM = CEBIW.LINE_ITEM_NUM              
   				    
   				  AND DIWCC.WORK_CLASS_CODE = 'ZZ'       ;
   				  
   				SET V_TOTAL_CREDIT = V_APF_TOTAL + V_TOTAL_QITEMS + V_TOTAL_ZITEMS ;
   				
   				
   				SET V_ERRLOC = 'J080';	
   				SELECT VALUE (SUM(CEBIW.ITEM_QTY_SUB * CEBIW.ITEM_UNIT_PRICE_SUB),0)
  				INTO V_PB                                           
  				
  				FROM ECMSXADM.CONTR_ECMS_BID_ITEM_SUB_WORK CEBIW
  				
  				WHERE ECMS_PROJECT_NUM 		= P_PROJNUM
  				  AND BID_PACKAGE_NUM 		= P_BIDPKGNUM
     			  AND BUS_PARTNER_ID 		= P_BPID
     			  AND CEBIW.PARTNER_BP_ID  	= V_JV_ID        ;
 				
 				SET V_TOTAL_PRICE = ((V_PB - V_TOTAL_XITEMS) - V_TOTAL_ZZITEMS);
 				IF V_TOTAL_PRICE <> 0
 				THEN
 					SET V_CALCULATED_PERCENT = (V_TOTAL_CREDIT / V_TOTAL_PRICE) * 100 ;
 				END IF;	
 				
 				IF V_CALCULATED_PERCENT <  V_PERCENT_REQUIREDTO_PASS
 				THEN
 					SET V_PARM_STATUS = V_FAILED_STATUS;
 					SET V_BPID_ERRORS = TRIM(V_BPID_ERRORS) || V_PC_BUS_PARTNER_ID || ',';
 				END IF;	 	   				
   				
   				
  						
 			END IF;
                
    END IF;
   	END WHILE;  
  
  
   
   
   -- UPDATE FOR BOTH PRIME AND JOINT VENTURE
    	
   	SET V_ERRLOC = 'D090';
  	UPDATE ECMSXADM.CONTR_ECMS_BID_WORK
    SET WCC_CHECK_IND 		= V_PARM_STATUS       
  	WHERE ECMS_PROJECT_NUM  = P_PROJNUM               
      AND BID_PACKAGE_NUM   = P_BIDPKGNUM                
      AND BUS_PARTNER_ID    = P_BPID ;   
                        
END IF;


        
OPEN SINGLE_PARM_CURSOR;




END P1
