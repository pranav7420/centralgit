CREATE PROCEDURE ECMSXADM.SPCA0031 (IN P_PROJNUM INTEGER , IN P_BIDPKGNUM SMALLINT , OUT P_SQLCODE INTEGER)
	VERSION V1
	ISOLATION LEVEL CS
	RESULT SETS 1
	LANGUAGE SQL
	ALLOW DEBUG MODE
	WLM ENVIRONMENT FOR DEBUG MODE DSNDWLM2
	P1: BEGIN
	
DECLARE V_SQLCODE                		INT     		DEFAULT 0;      
DECLARE V_SQLSTATE               		CHAR(5) 		DEFAULT '00000';
DECLARE SQLCODE                  		INT     		DEFAULT 0;      
DECLARE SQLSTATE                 		CHAR(5) 		DEFAULT '00000';
DECLARE V_TABLEID                  		CHAR(12)    	DEFAULT '$ECMSRETURN$';
DECLARE V_ERRCD                         SMALLINT    	DEFAULT 0;
DECLARE V_ERRLOC                        CHAR(5)     	DEFAULT '     ';
DECLARE V_END_OF_CURSOR                 CHAR(1)      	DEFAULT 'N';
DECLARE V_PARM_STATUS					CHAR(1)			DEFAULT '1';
  -- 1 = PASSED STATUS    2 = FAILED STATUS 
DECLARE V_SYSTEM_USERID					CHAR(19) DEFAULT 'ECMS System/PennDOT';  
DECLARE V_GEN_CODE_VALUE				VARCHAR(255)	DEFAULT ' ';						
DECLARE V_GPC_CODE_TYPE 				SMALLINT 	 	DEFAULT 79;
DECLARE V_TYPE_CODE_PMCAPPRAMT			CHAR(3)			DEFAULT '130';
DECLARE V_DOLLAR_TOLERANCE   			DECIMAL(15,2)	DEFAULT 0;
DECLARE V_PRIME_BPID					CHAR(6)			DEFAULT ' ';
DECLARE V_GENNED_ITEM_NUM				SMALLINT		DEFAULT 0;
DECLARE V_SKIP_PMC_CHECK				CHAR(1)			DEFAULT ' ';
DECLARE V_COUNT							SMALLINT		DEFAULT 0;
DECLARE V_PMC_AMT						DECIMAL(13,2)	DEFAULT 0;
DECLARE V_CONST_PHS_TYPE_CD				CHAR(5)			DEFAULT 'CON  ';
DECLARE V_VERIFY_AMOUNT					DECIMAL(15,2)	DEFAULT 0;
DECLARE V_CB_CONT_BID_TOT_AMT			DECIMAL(15,2)	DEFAULT 0;
DECLARE V_AUTOMATIC_SUBTYPE				CHAR(1)			DEFAULT '1';
DECLARE V_GEN_CODE_VALUE150				VARCHAR(150)	DEFAULT ' ';

DECLARE SINGLE_PARM_CURSOR CURSOR WITH RETURN
   FOR                                        
   SELECT                         
          V_SQLCODE,                          
          V_ERRCD,                          
          V_ERRLOC                         
                              
     FROM SYSIBM.SYSDUMMY1    ;
     
DECLARE EXIT HANDLER FOR SQLEXCEPTION

	BEGIN
	
       
       SET V_SQLCODE = SQLCODE   ;
       SET V_ERRCD = -1;
       OPEN SINGLE_PARM_CURSOR;
       
	END;


SET V_ERRLOC = 'D010';
SELECT DEC(GEN_CODE_VALUE,15,2)               
INTO V_DOLLAR_TOLERANCE                   
FROM COM_GENERAL_CODE                       
WHERE GEN_CODE_TYPE = 921 AND GEN_CODE = '06';

SET V_ERRLOC = 'D020';
SELECT GEN_CODE_VALUE                  
INTO V_GEN_CODE_VALUE              
FROM COM_GENERAL_CODE                
WHERE GEN_CODE_TYPE = V_GPC_CODE_TYPE  
  AND GEN_CODE = V_TYPE_CODE_PMCAPPRAMT; 	
  
SET V_GEN_CODE_VALUE150 = SUBSTR(V_GEN_CODE_VALUE, 1, 150);  
  
SET V_ERRLOC = 'D030';
SELECT BUS_PARTNER_ID                 
INTO V_PRIME_BPID                    
  FROM PROJ_CONTRACTOR                
 WHERE ECMS_PROJECT_NUM = P_PROJNUM 
   AND PROJ_CONTR_TYPE = 'P'   ;
            

SET V_ERRLOC = 'D040';
SELECT CONT_BID_TOT_AMT               
INTO V_CB_CONT_BID_TOT_AMT           
FROM CONTR_ECMS_BID_OPEN            
WHERE ECMS_PROJECT_NUM = P_PROJNUM 
  AND BID_PACKAGE_NUM = P_BIDPKGNUM
  AND BUS_PARTNER_ID = V_PRIME_BPID   
  AND BID_RANKING = 1 ;
  
SET V_ERRLOC = 'D050';  
SELECT MAX(AC_ITEM_NUM)               
  INTO V_GENNED_ITEM_NUM            
  FROM AC_ITEM                        
 WHERE ECMS_PROJECT_NUM = P_PROJNUM 
   AND BID_PACKAGE_NUM = P_BIDPKGNUM
   AND BUS_PARTNER_ID = V_PRIME_BPID   ;

SET V_SKIP_PMC_CHECK = 'N';
SET V_ERRLOC = 'D060'; 
SELECT COUNT(*)                          
INTO V_COUNT                         
FROM MPMSPROD.T043ASSOCPROJCLASS T043, 
    COM_GENERAL_CODE GPC                   
  WHERE T043.PRJCT_ID = P_PROJNUM AND  
   T043.PRJCT_CLS_CD = GPC.GEN_CODE AND  
   GPC.GEN_CODE_TYPE = 155   ;

IF V_COUNT >  0
THEN
	SET V_SKIP_PMC_CHECK = 'Y';
END IF;

IF V_SKIP_PMC_CHECK = 'N'
THEN
	IF V_PARM_STATUS = '1'
	THEN
		SET V_ERRLOC = 'D070'; 
		SELECT (DOL_TABLE.DOL_VAL * (100 - CENG_COST_PCT) / 100) 
  		INTO V_PMC_AMT                                       
 	 	FROM                                                   
	       (SELECT (VALUE (PHS_FDRL_AM, 0) +                 
	                VALUE (PHS_ST_AM, 0) +                   
	                VALUE (PHS_LCL_AM, 0)) AS DOL_VAL        
	          FROM MPMSPROD.T053PROJECTPHASE T053,           
	               MPMSPROD.T054PHASEFUND T054               
	         WHERE T053.PRJCT_ID = P_PROJNUM               
	           AND T053.PHS_TYPE_CD = V_CONST_PHS_TYPE_CD     
	           AND T053.PRJCT_ID = T054.PRJCT_ID             
	           AND T053.PHS_ID = T054.PHS_ID                 
	           AND T054.PHS_FUND_USE_CD = 'A') AS DOL_TABLE, 
	               
	      PMC_CENG_PCT                                      
                                                         
 		WHERE DOL_TABLE.DOL_VAL BETWEEN LOW_RANGE_AMT AND          
                              HIGH_RANGE_AMT  ;    
	    IF SQLCODE = 100
	    THEN
	    	SET V_PARM_STATUS = '2';	-- FAILED STATUS
	    END IF;	  
		IF V_PARM_STATUS = '1'
		THEN
			IF V_CB_CONT_BID_TOT_AMT > V_PMC_AMT
			THEN
				IF V_PMC_AMT > V_VERIFY_AMOUNT
				THEN
					SET V_PARM_STATUS = '2';	-- FAILED STATUS
				ELSE
					IF (V_CB_CONT_BID_TOT_AMT - V_PMC_AMT) > V_DOLLAR_TOLERANCE
					THEN
						SET V_PARM_STATUS = '2';	-- FAILED STATUS
					END IF;
				END IF;
			END IF;
		END IF;					                            
	END IF;
	
END IF;	                                   	                 

SET V_ERRLOC = 'D080';    	     	
SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
INSERT INTO AC_ITEM  
( ECMS_PROJECT_NUM,  
  BID_PACKAGE_NUM,   
  BUS_PARTNER_ID,    
  AC_ITEM_NUM,       
  AC_ITEM_CAT_CODE,  
  AC_ITEM_TYPE_CODE, 
  AC_ITEM_SUBMIT_TS, 
  AC_ITEM_STATUS_TS, 
  AC_ITEM_STATUS_CD, 
  AC_ITEM_STATUS_BY, 
  AC_ITEM_BP_ID,     
  AC_ITEM_DEFLT_IND, 
  CREATED_BY,        
  CREATED_BY_TS,     
  LAST_MODIFIED_BY,  
  LAST_MODIFIED_TS,  
  EDMS_DOC_LINK,     
  AC_ITEM_TITLE,     
  AC_ITEM_COMMENT )  	
VALUES
( P_PROJNUM,            
  P_BIDPKGNUM,          
  V_PRIME_BPID,            
  V_GENNED_ITEM_NUM,    
  V_AUTOMATIC_SUBTYPE,     
  V_TYPE_CODE_PMCAPPRAMT,  
  NULL,                   
  CURRENT_TIMESTAMP,      
  V_PARM_STATUS,           
  V_SYSTEM_USERID,         
  V_PRIME_BPID,            
  'Y',                    
  V_SYSTEM_USERID,         
  CURRENT_TIMESTAMP,      
  V_SYSTEM_USERID,         
  CURRENT_TIMESTAMP,      
  NULL,                   
  V_GEN_CODE_VALUE150,  
  NULL )   ;
  
	
OPEN SINGLE_PARM_CURSOR;	
	
END P1
