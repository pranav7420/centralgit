CREATE PROCEDURE ECMSXADM.SPCA0012 (IN P_PROJNUM INTEGER , IN P_BIDPKGNUM SMALLINT , OUT P_SQLCODE INTEGER)
	VERSION V1
	ISOLATION LEVEL CS
	RESULT SETS 1
	LANGUAGE SQL
	WLM ENVIRONMENT FOR DEBUG MODE DSNDWLM2
	ALLOW DEBUG MODE
	P1: BEGIN


DECLARE V_SQLCODE                		INT     DEFAULT 0;      
DECLARE V_SQLSTATE               		CHAR(5) DEFAULT '00000';
DECLARE SQLCODE                  		INT     DEFAULT 0;      
DECLARE SQLSTATE                 		CHAR(5) DEFAULT '00000';
DECLARE V_ERRCD                         SMALLINT     DEFAULT 0;
DECLARE V_ERRLOC                        CHAR(5)      DEFAULT '     ';
DECLARE V_TABLEID                  		CHAR(12)     DEFAULT '$ECMSRETURN$';
DECLARE V_BEO_SUBMISSION_DAYS			DECIMAL(15,3) DEFAULT 0;
DECLARE V_CIS_SUBMISSION_DAYS			DECIMAL(18,6) DEFAULT 0;
DECLARE V_PRJ_FED_PROJ_STAT_CD			CHAR(1) 	DEFAULT ' ';
	-- 1 = PENNDOT-OVERSIGHT-NHS
	-- 2 = PENNDOT OVERSIGHT NON NHS
	-- 3 = FEDERAL OVERSIGHT
	-- 4 = 100 PERCENT STATE
DECLARE V_END_OF_CURSOR                 CHAR(1) DEFAULT 'N';
DECLARE V_END_OF_CURSOR_2				CHAR(1)	DEFAULT 'N';
DECLARE V_END_OF_PRIMES					CHAR(1) DEFAULT 'N';
DECLARE V_END_OF_JV						CHAR(1) DEFAULT 'N';		
DECLARE V_STATUS_TIMESTAMP				CHAR(26) 	DEFAULT ' ';
DECLARE V_PRJ_PREQ_REQD_IND 			CHAR(1) 	DEFAULT ' ';           
DECLARE V_PRJ_CURR_BID_PKG_NUM 			SMALLINT	DEFAULT 0;     
DECLARE V_PRJ_COST_PLUS_TIME_IND		CHAR(1)		DEFAULT ' ';	 
DECLARE V_PRJ_LANE_RENTAL_IND 			CHAR(1)		DEFAULT ' ';       
DECLARE V_PRJ_DESIGN_BUILD_IND 			CHAR(1)		DEFAULT ' ';     
DECLARE V_PRJ_INCEN_DISINCEN_IND 		CHAR(1)		DEFAULT ' '; 
DECLARE V_PRJ_RULD_IND 					CHAR(1)		DEFAULT ' ';                     
DECLARE V_PRJ_PROJ_TYPE 				CHAR(2)		DEFAULT '  ';				                   
DECLARE V_PRJ_RAIL_INVOLV_IND			CHAR(1)		DEFAULT ' ';   
DECLARE V_DI_LINE_ITEM_NUM				SMALLINT	DEFAULT 0;			                        


DECLARE V_PRJ_STATE_PROJECT_STATUS_CODE CHAR(1)		DEFAULT ' ';
DECLARE V_PRJ_STATE_PROJ_NO_GOAL_IND	CHAR(1)		DEFAULT ' '; 
DECLARE V_COUNT							SMALLINT	DEFAULT 0; 
DECLARE V_PREBID_STATUS					CHAR(1)		DEFAULT '0';
	-- 0 = NO MANDATORY PREBID
	-- 1 = MANDATORY PREBID 
DECLARE V_PRIME_BPID					CHAR(6)		DEFAULT ' ';
DECLARE V_JV1_BPID						CHAR(6)		DEFAULT ' ';
DECLARE V_JV2_BPID						CHAR(6)		DEFAULT ' ';
DECLARE V_PARTNER_BP_ID					CHAR(6)		DEFAULT ' ';
DECLARE V_SYSTEM_USERID					CHAR(19)	DEFAULT 'ECMS System/PennDOT';	
DECLARE V_LOW_BIDDER					SMALLINT	DEFAULT 1;				
DECLARE V_PARM_STATUS					CHAR(1)		DEFAULT ' ';
DECLARE V_PARM_CAT						CHAR(1)		DEFAULT ' ';
DECLARE V_PARM_TYPE						CHAR(3)		DEFAULT ' '; 
DECLARE V_PARM_ITEMBPID					CHAR(6)		DEFAULT ' ';
DECLARE V_ITEMNUM1						CHAR(4)		DEFAULT ' ';
DECLARE V_ITEMNUM2						CHAR(4)		DEFAULT ' ';
DECLARE V_CIS_TITLE_ITEMNUM1			CHAR(4)		DEFAULT ' ';
DECLARE V_CIS_TITLE_ITEMNUM2			CHAR(4)		DEFAULT ' ';
DECLARE V_PARM_ITEMTITLE				VARCHAR(150) DEFAULT '  ';
DECLARE V_ITEM_TITLE_CIS				CHAR(6) DEFAULT 'CIS - ';
DECLARE V_MILE_ACTUAL_LET_DATE			CHAR(10)	DEFAULT	' ';	
DECLARE V_DI_ALT_ITEM_CODE				CHAR(1)		DEFAULT ' ';	
DECLARE V_DI_ITEM_DESC					VARCHAR(255)	DEFAULT ' ';
DECLARE V_CBI_ITEM_NUM					CHAR(8)		DEFAULT ' ';
DECLARE V_CBI_BUS_PARTNER_ID			CHAR(6)		DEFAULT ' ';
DECLARE V_WS_ALTITEM_IND				CHAR(1)		DEFAULT ' ';
DECLARE V_SPLIT_TITLE_ITEMNUM			CHAR(8)		DEFAULT ' ';
DECLARE V_GENNED_ITEM_NUM				SMALLINT	DEFAULT 0;
DECLARE V_STATUS_USERID					CHAR(19)	DEFAULT ' ';
DECLARE V_ALTITEM_IND					CHAR(1)		DEFAULT ' ';
DECLARE V_DCI_COMP_LINE_ITEM_NUM		SMALLINT	DEFAULT 0;
DECLARE V_DCI_COMP_ITEM_SEQ_NUM			SMALLINT	DEFAULT 0;
DECLARE V_DCI_ITEM_NUMBER				CHAR(8)		DEFAULT ' ';		
DECLARE V_DCI_ITEM_UNIT_MEASURE			CHAR(5)		DEFAULT ' ';
DECLARE V_DCI_ITEM_QTY					DECIMAL(15,3)	DEFAULT 0;
DECLARE V_DCI_ITEM_DESC					VARCHAR(255) DEFAULT ' ';
DECLARE V_GP_GEN_CODE_VALUE				VARCHAR(255)	DEFAULT ' ';
DECLARE V_PARM_GEN_CODE_TYPE			SMALLINT	DEFAULT 79;	
												
DECLARE V_BP_MAILING_ADDRESS_1			CHAR(40) DEFAULT ' ';
DECLARE V_BP_MAILING_ADDRESS_2			CHAR(40) DEFAULT ' ';
DECLARE V_BP_MAILING_ADDRESS_3			CHAR(40) DEFAULT ' ';
DECLARE V_BP_MAILING_ADDRESS_4			CHAR(40) DEFAULT ' ';
DECLARE V_BP_MAILING_CITY				CHAR(40) DEFAULT ' ';
DECLARE V_BP_MAILING_STATE				CHAR(2)	DEFAULT ' ';
DECLARE V_BP_MAILING_ZIP				CHAR(5)	DEFAULT ' ';
DECLARE V_BP_MAILING_ZIP_EXT			CHAR(4) DEFAULT ' ';
DECLARE V_BP_FEIN						CHAR(9) DEFAULT ' ';
DECLARE  V_BP_BUS_PARTNER_NAME			CHAR(50) DEFAULT ' ';
DECLARE V_MUNI_BPID						CHAR(6)  DEFAULT ' ';
DECLARE V_VALIDATION_IND				CHAR(10) DEFAULT ' ';
DECLARE V_FV_BPID						CHAR(6)	DEFAULT ' ';
DECLARE V_ITEM_STATUS_CODE				CHAR(1) DEFAULT ' ';
DECLARE V_PC_BUS_PARTNER_ID				CHAR(6) DEFAULT ' ';	
DECLARE V_IS_BID_SUBMITTED_IN_ECMS		CHAR(1) DEFAULT ' ';				




DECLARE SINGLE_PARM_CURSOR CURSOR WITH RETURN
   FOR                                        
   SELECT V_TABLEID,                        
          V_SQLCODE,                          
          V_ERRCD,                          
          V_ERRLOC
                          
     FROM SYSIBM.SYSDUMMY1    ;
     

 DECLARE BIDITEM CURSOR FOR                          
   SELECT DI.ALT_ITEM_CODE,                          
          DI.ITEM_DESC,                              
          CBI.ITEM_NUMBER,                           
          CBI.BUS_PARTNER_ID,                        
          DI.LINE_ITEM_NUM,                          
          CASE DI.COMP_ITEM_REQD_IND                 
               WHEN 'Y' THEN 'N' ELSE 'Y' END        
     FROM CONTR_ECMS_BID_ITEM_OPEN CBI,                        
          DESIGN_ITEM DI,                            
          CONTR_ECMS_BID_OPEN CB                               
    WHERE CBI.ECMS_PROJECT_NUM 		= P_PROJNUM         
      AND CBI.BID_PACKAGE_NUM 		= P_BIDPKGNUM        
      AND CBI.ECMS_PROJECT_NUM 		= CB.ECMS_PROJECT_NUM 
      AND CBI.BID_PACKAGE_NUM 		= CB.BID_PACKAGE_NUM   
      AND CBI.BUS_PARTNER_ID 		= CB.BUS_PARTNER_ID     
      AND CB.BID_RANKING 			= V_LOW_BIDDER               
      AND DI.ECMS_PROJECT_NUM 		= CBI.ECMS_PROJECT_NUM 
      AND CBI.LINE_ITEM_NUM 		= DI.LINE_ITEM_NUM       
      AND DI.CONTR_CI_REQD_IND = 'Y'      ;           


DECLARE DESIGNCI CURSOR FOR                    
  SELECT COMP_LINE_ITEM_NUM,                   
         COMP_ITEM_SEQ_NUM,                    
         ITEM_NUMBER,                          
         ITEM_UNIT_MEASURE,                    
         ITEM_QTY,                             
         ITEM_DESC                             
    FROM DESIGN_CI DCI                         
   WHERE DCI.ECMS_PROJECT_NUM 	= P_PROJNUM    
     AND DCI.LINE_ITEM_NUM 		= V_DI_LINE_ITEM_NUM ;
     

 
     
DECLARE PRIMES_CSR CURSOR FOR
	SELECT BUS_PARTNER_ID                 
  	FROM CONTR_ECMS_BID_PARTNER_OPEN                
 	WHERE ECMS_PROJECT_NUM	= P_PROJNUM 
 	AND BID_PACKAGE_NUM 	= P_BIDPKGNUM
   	  AND PROJ_CONTR_TYPE 	= 'P' ;         
   	  

DECLARE JOINTVENTURES_CSR CURSOR FOR
	SELECT PARTNER_BP_ID                  
  	FROM CONTR_ECMS_BID_PARTNER_OPEN                
 	WHERE ECMS_PROJECT_NUM	= P_PROJNUM 
 	AND BID_PACKAGE_NUM 	= P_BIDPKGNUM
 	AND BUS_PARTNER_ID 		= V_PRIME_BPID
   	  AND PROJ_CONTR_TYPE 	= 'J' ;          	  
   	  
               
     
DECLARE EXIT HANDLER FOR SQLEXCEPTION

	BEGIN
	
	   SET V_SQLCODE = SQLCODE   ;
       SET V_ERRCD = -1;
       OPEN SINGLE_PARM_CURSOR;
       
   END;



SET V_STATUS_USERID = V_SYSTEM_USERID;
SET V_STATUS_TIMESTAMP = CURRENT TIMESTAMP;

SET V_ERRLOC = 'D010';
SELECT PREQ_REQD_IND,                                  
       CURR_BID_PKG_NUM,                               
       COST_PLUS_TIME_IND,                             
       LANE_RENTAL_IND,                                
       DESIGN_BUILD_IND,                               
       INCEN_DISINCEN_IND,                             
       RULD_IND,                                       
       PROJ_TYPE,                                      
       VALUE(RAIL_INVOLV_IND,'N'),                     
       VALUE(FED_PROJ_STAT_CD,''),                     
       STATE_PROJECT_STATUS_CODE,                      
       STATE_PROJ_NO_GOAL_IND,
       IS_BID_SUBMITTED_IN_ECMS                          
  INTO V_PRJ_PREQ_REQD_IND ,           
       V_PRJ_CURR_BID_PKG_NUM ,     
       V_PRJ_COST_PLUS_TIME_IND , 
       V_PRJ_LANE_RENTAL_IND ,       
       V_PRJ_DESIGN_BUILD_IND ,     
       V_PRJ_INCEN_DISINCEN_IND , 
       V_PRJ_RULD_IND ,                     
       V_PRJ_PROJ_TYPE ,                   
       V_PRJ_RAIL_INVOLV_IND,                           
       V_PRJ_FED_PROJ_STAT_CD,                          
       V_PRJ_STATE_PROJECT_STATUS_CODE ,        
       V_PRJ_STATE_PROJ_NO_GOAL_IND,
       V_IS_BID_SUBMITTED_IN_ECMS            
  FROM PROJECT                                         
 WHERE ECMS_PROJECT_NUM = P_PROJNUM     ;  
 
 IF  V_PRJ_STATE_PROJECT_STATUS_CODE IS NULL
 THEN
 	SET V_PRJ_STATE_PROJECT_STATUS_CODE = ' ';
 END IF;
 
 IF V_PRJ_STATE_PROJ_NO_GOAL_IND IS NULL
 THEN
 	SET V_PRJ_STATE_PROJ_NO_GOAL_IND = ' ';
 END IF;	 	           
 
SET V_PREBID_STATUS = '0'; 
SET V_ERRLOC = 'D020';
SELECT COUNT(*)                               
  INTO V_COUNT                              
  FROM BID_PACKAGE                            
 WHERE ECMS_PROJECT_NUM = P_PROJNUM         
   AND BID_PACKAGE_NUM = V_PRJ_CURR_BID_PKG_NUM
   AND PREBID_MEETING_IND = 'M'     ;

IF V_COUNT > 0
THEN
	SET V_PREBID_STATUS = '1' ;  -- MANDATORY PREBID
END IF;	
	

-- LOGIC BELOW REMOVED BECAUSE THIS SP IS CALLED FOR
-- FEDERAL PROJECTS ONLY

--IF V_PRJ_FED_PROJ_STAT_CD = '4'    -- 100 PERCENT STATE
--THEN

--	SET V_ERRLOC = 'D030';      
--	SELECT INT(BEO.GEN_CODE_VALUE),                       
--	  INT(CIS.GEN_CODE_VALUE)                             
--	  INTO V_BEO_SUBMISSION_DAYS, V_CIS_SUBMISSION_DAYS     
--	  FROM COM_GENERAL_CODE BEO, COM_GENERAL_CODE CIS     
--	 WHERE BEO.GEN_CODE_TYPE = 921 AND BEO.GEN_CODE = '13'
--	  AND  CIS.GEN_CODE_TYPE = 921 AND CIS.GEN_CODE = '04';
--ELSE  
	SET V_ERRLOC = 'D040';
	SELECT INT(BEO.GEN_CODE_VALUE),                      
	  INT(CIS.GEN_CODE_VALUE)                            
	  INTO V_BEO_SUBMISSION_DAYS, V_CIS_SUBMISSION_DAYS  
	FROM COM_GENERAL_CODE BEO, COM_GENERAL_CODE CIS      
	WHERE BEO.GEN_CODE_TYPE = CIS.GEN_CODE_TYPE 
	  AND BEO.GEN_CODE_TYPE = 921 
	  AND BEO.GEN_CODE = '03'
	  AND CIS.GEN_CODE = '04' ;  
--END IF;


-- This has been handled in JAVA -------

--SET V_ERRLOC = 'D050';
--SELECT COUNT(*)                      
--  INTO V_COUNT                     
--  FROM CONT_AWD_REGISTER             
-- WHERE ECMS_PROJECT_NUM = P_PROJNUM ;
 
--IF V_COUNT > 0
--THEN
--	SET V_ERRLOC = 'D060';
--	SELECT ECMS_ACTUAL_DATE                          
--  	INTO V_MILE_ACTUAL_LET_DATE
--  	FROM PROJ_MILESTONE                            
-- 	WHERE ECMS_PROJECT_NUM = P_PROJNUM            
--   	  AND MILEST_DATE_CODE = '01' ;
   
--   SET V_ERRLOC = 'D070';
--   UPDATE CONT_AWD_REGISTER                       
--   SET AWD_EXPIRE_DATE =                       
--         DATE(V_MILE_ACTUAL_LET_DATE) + 60 DAYS,
--       	NTP_EXPIRE_DATE = NULL,                 
--       	WAGE_EXPIRE_DATE = NULL,                
--       	AWD_EXT_REQ_DATE = NULL,                
--       	NTP_EXT_REQ_DATE = NULL,                
--       	AWD_COMMENT = NULL,                     
--       	NTP_ISSUE_DATE = NULL                   
-- WHERE ECMS_PROJECT_NUM = P_PROJNUM          ;
 
--ELSE
--	 SET V_ERRLOC = 'D080';	
--     INSERT INTO CONT_AWD_REGISTER
--	( ECMS_PROJECT_NUM,          
--  		AWD_EXPIRE_DATE,           
--  		NTP_EXPIRE_DATE,           
--  		WAGE_EXPIRE_DATE,          
--  		PREV_BID_DATE,             
--  		AWD_EXT_REQ_DATE,          
--  		NTP_EXT_REQ_DATE,          
--  		AWD_COMMENT,               
--  		NTP_ISSUE_DATE )           
--	VALUES                       
--		( P_PROJNUM,               
--  		(CURRENT_DATE + 60 DAYS),  
--  		NULL,                      
--  		NULL,                      
--  		NULL,                      
--  		NULL,                      
--  		NULL,                      
--  		NULL,                      
--  		NULL )         ;
 
-- END IF;
  		                             	
-- END of comment handled in JAVA -------

SET V_ERRLOC = 'D090';
OPEN PRIMES_CSR;

SET V_END_OF_PRIMES = 'N';
WHILE V_END_OF_PRIMES = 'N'
DO	FETCH PRIMES_CSR
	INTO V_PRIME_BPID;
	
	IF SQLCODE = 100
	THEN
		SET V_END_OF_PRIMES = 'Y';
		CLOSE PRIMES_CSR;
	ELSE
		SET V_ERRLOC = 'D092';
		OPEN JOINTVENTURES_CSR;
		SET V_JV1_BPID = ' ';
		SET V_JV2_BPID = ' ';
		SET V_END_OF_JV = 'N';
		WHILE V_END_OF_JV = 'N'
		DO FETCH JOINTVENTURES_CSR
			INTO V_PARTNER_BP_ID;
			IF SQLCODE = 100
			THEN
				SET V_END_OF_JV = 'Y';
				CLOSE JOINTVENTURES_CSR;
			ELSE
				IF V_JV1_BPID = ' '
				THEN
					SET V_JV1_BPID = V_PARTNER_BP_ID;
				ELSE
					IF V_JV2_BPID = ' '
					THEN
						SET V_JV2_BPID = V_PARTNER_BP_ID;
						SET V_END_OF_JV = 'Y';
						CLOSE JOINTVENTURES_CSR;
					END IF;
				END IF;
			END IF;					
		END WHILE;	
		
		IF V_IS_BID_SUBMITTED_IN_ECMS = 'Y'
		THEN
			SET V_ERRLOC = 'D094';
			SELECT COUNT(*)
			INTO V_COUNT
			FROM ECMSXADM.CONTR_ECMS_BID_OPEN
			WHERE ECMS_PROJECT_NUM	= P_PROJNUM 
 			  AND BID_PACKAGE_NUM 	= P_BIDPKGNUM
 			  AND BUS_PARTNER_ID 	= V_PRIME_BPID;
		ELSE
			SET V_ERRLOC = 'D096';
			SELECT COUNT(*)
			INTO V_COUNT
			FROM ECMSXADM.CONTR_BID
			WHERE ECMS_PROJECT_NUM	= P_PROJNUM 
 			  AND BID_PACKAGE_NUM 	= P_BIDPKGNUM
 			  AND BUS_PARTNER_ID 	= V_PRIME_BPID;
		END IF;	
		
		IF V_COUNT <> 1
		THEN
			SET V_ERRLOC = 'A011';
     		SET V_ERRCD  = -1;
     		OPEN SINGLE_PARM_CURSOR;
     		RETURN -200;
		END IF;	
			
		SET V_ERRLOC = 'D100';		
		INSERT INTO AWARD_CHECKLIST                
		( ECMS_PROJECT_NUM,                        
		  BID_PACKAGE_NUM,                         
		  BUS_PARTNER_ID,                          
		  BEO_INFO_DUE_DATE,                       
		  CIS_DUE_DATE,                            
		  AC_AVAIL_IND,                            
		  CREATED_BY_TS,                           
		  CREATED_BY,                              
		  LAST_MODIFIED_BY,                        
		  LAST_MODIFIED_TS )                       
		VALUES                                     
		( P_PROJNUM,                             
		  P_BIDPKGNUM,                           
		  V_PRIME_BPID,                             
		  CURRENT_DATE + V_BEO_SUBMISSION_DAYS DAYS,
		  CURRENT_DATE + V_CIS_SUBMISSION_DAYS DAYS,
		  'N',                                     
		  CURRENT_TIMESTAMP,                       
		  V_SYSTEM_USERID,                          
		  V_SYSTEM_USERID,                          
		  CURRENT_TIMESTAMP )   ;

  		SET V_ERRLOC = 'D105';
		OPEN BIDITEM;  

		SET V_PARM_STATUS = '6'  ; -- DRAFT STATUS

		SET V_END_OF_CURSOR       =  'N';
              
		WHILE V_END_OF_CURSOR = 'N'
		DO 
			SET V_ERRLOC = 'D110';
			FETCH BIDITEM INTO                     
		  		V_DI_ALT_ITEM_CODE, 
		  		V_DI_ITEM_DESC,         
		  		V_CBI_ITEM_NUM,          
		  		V_CBI_BUS_PARTNER_ID,                 
		  		V_DI_LINE_ITEM_NUM,                   
		  		V_ALTITEM_IND   ;    
  		
		   IF SQLCODE = 100
		   THEN 
		       CLOSE BIDITEM;  
		       SET V_END_OF_CURSOR = 'Y';
		   ELSE
		   		SET V_ITEMNUM1 = SUBSTR(V_CBI_ITEM_NUM, 1, 4);
		   		SET V_ITEMNUM2 = SUBSTR(V_CBI_ITEM_NUM, 5, 4);
		   		SET V_PARM_ITEMTITLE = V_ITEM_TITLE_CIS || V_ITEMNUM1 || '-' || V_ITEMNUM2;
		   		SET V_PARM_CAT = 2 ;  -- PREWARD-SUBTYPE                
		   		SET V_PARM_TYPE = 210 ;  -- TYPE CODE COMPITEMSCH 
		        SET V_PARM_ITEMBPID = V_CBI_BUS_PARTNER_ID;
        
        
		        SET V_ERRLOC = 'D120';
		        SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
		        INSERT INTO AC_ITEM    
				( ECMS_PROJECT_NUM,    
				  BID_PACKAGE_NUM,     
				  BUS_PARTNER_ID,      
				  AC_ITEM_NUM,         
				  AC_ITEM_CAT_CODE,    
				  AC_ITEM_TYPE_CODE,   
				  AC_ITEM_STATUS_TS,   
				  AC_ITEM_STATUS_CD,   
				  AC_ITEM_STATUS_BY,   
				  AC_ITEM_BP_ID,       
				  AC_ITEM_DEFLT_IND,   
				  CREATED_BY,          
				  CREATED_BY_TS,       
				  LAST_MODIFIED_BY,    
				  LAST_MODIFIED_TS,    
				  AC_ITEM_TITLE )
				VALUES                                   
				( P_PROJNUM,                           
				  P_BIDPKGNUM,                         
				  V_PRIME_BPID,                           
				  V_GENNED_ITEM_NUM,                   
				  V_PARM_CAT,                             
				  V_PARM_TYPE,                            
				  V_STATUS_TIMESTAMP,
				  V_PARM_STATUS ,          
				  V_STATUS_USERID ,      
				  V_PARM_ITEMBPID,                        
				  'Y',                                   
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_PARM_ITEMTITLE)    ;
		  
		  		
			  
				SET V_ERRLOC = 'D130';
				INSERT INTO AC_COMP_ITEM_SCHED 
				( ECMS_PROJECT_NUM,            
				  BID_PACKAGE_NUM,             
				  BUS_PARTNER_ID,              
				  AC_ITEM_NUM,                 
				  ITEM_NUMBER,                 
				  CIS_ALT_ITEM_IND,            
				  ITEM_DESC )                  
				VALUES                         
				( P_PROJNUM,                 
				  P_BIDPKGNUM,               
				  V_PRIME_BPID,                 
				  V_GENNED_ITEM_NUM,         
				  V_CBI_ITEM_NUM ,  
				  V_ALTITEM_IND,             
				  V_DI_ITEM_DESC );
		  
				OPEN DESIGNCI;
				SET V_END_OF_CURSOR_2	= 'N';
				WHILE V_END_OF_CURSOR_2 = 'N'
				DO
					SET V_ERRLOC = 'D140';
					FETCH DESIGNCI INTO                            
					  V_DCI_COMP_LINE_ITEM_NUM,
					  V_DCI_COMP_ITEM_SEQ_NUM ,
					  V_DCI_ITEM_NUMBER ,
					  V_DCI_ITEM_UNIT_MEASURE ,
					  V_DCI_ITEM_QTY,
					  V_DCI_ITEM_DESC    ;
			
					IF SQLCODE = 100
		   			THEN 
		       			CLOSE DESIGNCI;  
		       			SET V_END_OF_CURSOR_2 = 'Y';
		   			ELSE
		   				SET V_ERRLOC = 'D150';
		   				INSERT INTO AC_COMP_ITEM  
						( ECMS_PROJECT_NUM,       
						  BID_PACKAGE_NUM,        
						  BUS_PARTNER_ID,         
						  AC_ITEM_NUM,            
						  LINE_ITEM_NUM,          
						  COMP_LINE_ITEM_NUM,     
						  COMP_ITEM_SEQ_NUM,      
						  ITEM_NUMBER,            
						  ITEM_QTY,               
						  ITEM_UNIT_MEASURE,      
						  LUMP_SUM_ITEM_NUM,      
						  ITEM_DESC,              
						  CREATED_BY,             
						  CREATED_BY_TS,          
						  LAST_MODIFIED_BY,       
						  LAST_MODIFIED_TS )   
						VALUES                                          
						( P_PROJNUM,                                  
						  P_BIDPKGNUM,                                
						  V_PRIME_BPID,                                  
						  V_GENNED_ITEM_NUM,                          
						  V_DI_LINE_ITEM_NUM,                            
						  V_DCI_COMP_LINE_ITEM_NUM,                      
						  V_DCI_COMP_ITEM_SEQ_NUM , 
						  V_DCI_ITEM_NUMBER ,             
						  V_DCI_ITEM_QTY ,                   
						  V_DCI_ITEM_UNIT_MEASURE , 
						  V_CBI_ITEM_NUM ,                   
						  V_DCI_ITEM_DESC ,                 
						  V_SYSTEM_USERID,                               
						  CURRENT_TIMESTAMP,                            
						  V_SYSTEM_USERID,                               
						  CURRENT_TIMESTAMP )    ;                       	  
					
		   			END IF;	  
				END WHILE; 
		
   			END IF;
   
		END WHILE;          


		  
		SET V_PARM_STATUS = NULL;
		  
		IF  V_PRJ_STATE_PROJ_NO_GOAL_IND = '1'
		THEN
			SET V_PARM_STATUS = '7';    --  REVIEW STATUS
			SET V_STATUS_USERID = V_SYSTEM_USERID;
			SET V_PARM_ITEMBPID = V_PRIME_BPID;
			SET V_PARM_CAT = '2';   -- PREAWARD SUBTYPE
			SET V_PARM_TYPE =  '204'   ;  -- TYPE CODE MINPART FED
			
			SET V_GP_GEN_CODE_VALUE = SPACE(5);
			SET V_ERRLOC = 'D160';
			SELECT GEN_CODE_VALUE                     
		  	INTO V_GP_GEN_CODE_VALUE                 
		  	FROM COM_GENERAL_CODE                   
		 	WHERE GEN_CODE_TYPE = V_PARM_GEN_CODE_TYPE
		   	  AND GEN_CODE = V_PARM_TYPE    ;  
   	  
		   	SET V_PARM_TYPE =  '205'   ;  -- TYPE CODE MINPART  
		   	SET V_PARM_ITEMTITLE = V_GP_GEN_CODE_VALUE;	      
			SET V_ERRLOC = 'D170';
		    SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
	        INSERT INTO AC_ITEM    
			( ECMS_PROJECT_NUM,    
			  BID_PACKAGE_NUM,     
			  BUS_PARTNER_ID,      
			  AC_ITEM_NUM,         
			  AC_ITEM_CAT_CODE,    
			  AC_ITEM_TYPE_CODE,   
			  AC_ITEM_STATUS_TS,   
			  AC_ITEM_STATUS_CD,   
			  AC_ITEM_STATUS_BY,   
			  AC_ITEM_BP_ID,       
			  AC_ITEM_DEFLT_IND,   
			  CREATED_BY,          
			  CREATED_BY_TS,       
			  LAST_MODIFIED_BY,    
			  LAST_MODIFIED_TS,    
			  AC_ITEM_TITLE )
			VALUES                                   
			( P_PROJNUM,                           
			  P_BIDPKGNUM,                         
			  V_PRIME_BPID,                           
			  V_GENNED_ITEM_NUM,                   
			  V_PARM_CAT,                             
			  V_PARM_TYPE,                            
			  V_STATUS_TIMESTAMP,
			  V_PARM_STATUS ,          
			  V_STATUS_USERID ,      
			  V_PARM_ITEMBPID,                        
			  'Y',                                   
			  V_SYSTEM_USERID,                        
			  CURRENT_TIMESTAMP,                     
			  V_SYSTEM_USERID,                        
			  CURRENT_TIMESTAMP,                     
			  V_PARM_ITEMTITLE)    ;
			  
			  IF V_JV1_BPID <> ' '
		  		THEN
		  			SET V_ERRLOC = 'D172';
		        	SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
		  			INSERT INTO AC_ITEM    
				( ECMS_PROJECT_NUM,    
				  BID_PACKAGE_NUM,     
				  BUS_PARTNER_ID,      
				  AC_ITEM_NUM,         
				  AC_ITEM_CAT_CODE,    
				  AC_ITEM_TYPE_CODE,   
				  AC_ITEM_STATUS_TS,   
				  AC_ITEM_STATUS_CD,   
				  AC_ITEM_STATUS_BY,   
				  AC_ITEM_BP_ID,       
				  AC_ITEM_DEFLT_IND,   
				  CREATED_BY,          
				  CREATED_BY_TS,       
				  LAST_MODIFIED_BY,    
				  LAST_MODIFIED_TS,    
				  AC_ITEM_TITLE )
				VALUES                                   
				( P_PROJNUM,                           
				  P_BIDPKGNUM,                         
				  V_PRIME_BPID,                           
				  V_GENNED_ITEM_NUM,                   
				  V_PARM_CAT,                             
				  V_PARM_TYPE,                            
				  V_STATUS_TIMESTAMP,
				  V_PARM_STATUS ,          
				  V_STATUS_USERID ,      
				  V_PARM_ITEMBPID,                        
				  'Y',                                   
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_PARM_ITEMTITLE)    ;
		  			
		  		END IF;	
			  
			  	IF V_JV2_BPID <> ' '
		  		THEN
		  			SET V_ERRLOC = 'D174';
		        	SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
		  			INSERT INTO AC_ITEM    
				( ECMS_PROJECT_NUM,    
				  BID_PACKAGE_NUM,     
				  BUS_PARTNER_ID,      
				  AC_ITEM_NUM,         
				  AC_ITEM_CAT_CODE,    
				  AC_ITEM_TYPE_CODE,   
				  AC_ITEM_STATUS_TS,   
				  AC_ITEM_STATUS_CD,   
				  AC_ITEM_STATUS_BY,   
				  AC_ITEM_BP_ID,       
				  AC_ITEM_DEFLT_IND,   
				  CREATED_BY,          
				  CREATED_BY_TS,       
				  LAST_MODIFIED_BY,    
				  LAST_MODIFIED_TS,    
				  AC_ITEM_TITLE )
				VALUES                                   
				( P_PROJNUM,                           
				  P_BIDPKGNUM,                         
				  V_PRIME_BPID,                           
				  V_GENNED_ITEM_NUM,                   
				  V_PARM_CAT,                             
				  V_PARM_TYPE,                            
				  V_STATUS_TIMESTAMP,
				  V_PARM_STATUS ,          
				  V_STATUS_USERID ,      
				  V_PARM_ITEMBPID,                        
				  'Y',                                   
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_PARM_ITEMTITLE)    ;
		  			
		  		END IF;	
			  
			 
		  
			SET V_PARM_STATUS = NULL;  
	
			SET V_ERRLOC = 'D180';	  
			INSERT INTO AC_MIN_PART_CMMT
				( ECMS_PROJECT_NUM,         
				  BID_PACKAGE_NUM,          
				  BUS_PARTNER_ID,           
				  AC_ITEM_NUM,              
				  ATT_A_STATUS_CODE,        
				  CREATED_BY,               
				  CREATED_BY_TS,            
				  LAST_MODIFIED_BY,         
				  LAST_MODIFIED_TS )        
				VALUES                      
				( P_PROJNUM,              
				  P_BIDPKGNUM,            
				  V_PRIME_BPID,              
				  V_GENNED_ITEM_NUM,      
				  '01' ,                    
	  			  V_SYSTEM_USERID,           
  				  CURRENT_TIMESTAMP,        
				  V_SYSTEM_USERID,           
				  CURRENT_TIMESTAMP)  ;  
	
	
		  
			SET V_PARM_STATUS = '6';	-- DRAFT STATUS
			SET V_PARM_ITEMBPID = V_PRIME_BPID;
			SET V_PARM_CAT = '2' ; 	-- PREAWARD SUBTYPE
			SET V_PARM_TYPE = '200';	-- TYPE CODE MINSOL
			
			SET V_GP_GEN_CODE_VALUE = SPACE(5);
			SET V_ERRLOC = 'D190';
			SELECT GEN_CODE_VALUE                     
		  	INTO V_GP_GEN_CODE_VALUE                 
		  	FROM COM_GENERAL_CODE                   
		 	WHERE GEN_CODE_TYPE = V_PARM_GEN_CODE_TYPE
		   	  AND GEN_CODE = V_PARM_TYPE    ;  
				      	  
			SET V_PARM_ITEMTITLE = V_GP_GEN_CODE_VALUE;	      	  
			SET V_ERRLOC = 'D200';
		    SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
	        INSERT INTO AC_ITEM    
			( ECMS_PROJECT_NUM,    
			  BID_PACKAGE_NUM,     
			  BUS_PARTNER_ID,      
			  AC_ITEM_NUM,         
			  AC_ITEM_CAT_CODE,    
			  AC_ITEM_TYPE_CODE,   
			  AC_ITEM_STATUS_TS,   
			  AC_ITEM_STATUS_CD,   
			  AC_ITEM_STATUS_BY,   
			  AC_ITEM_BP_ID,       
			  AC_ITEM_DEFLT_IND,   
			  CREATED_BY,          
			  CREATED_BY_TS,       
			  LAST_MODIFIED_BY,    
			  LAST_MODIFIED_TS,    
			  AC_ITEM_TITLE )
			VALUES                                   
			( P_PROJNUM,                           
			  P_BIDPKGNUM,                         
			  V_PRIME_BPID,                           
			  V_GENNED_ITEM_NUM,                   
			  V_PARM_CAT,                             
			  V_PARM_TYPE,                            
			  V_STATUS_TIMESTAMP,
			  V_PARM_STATUS ,          
			  V_STATUS_USERID ,      
			  V_PARM_ITEMBPID,                        
			  'Y',                                   
			  V_SYSTEM_USERID,                        
			  CURRENT_TIMESTAMP,                     
			  V_SYSTEM_USERID,                        
			  CURRENT_TIMESTAMP,                     
			  V_PARM_ITEMTITLE)    ;
		  
		  
		  	IF V_JV1_BPID <> ' '
		  		THEN
		  			SET V_ERRLOC = 'D202';
		        	SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
		  			INSERT INTO AC_ITEM    
				( ECMS_PROJECT_NUM,    
				  BID_PACKAGE_NUM,     
				  BUS_PARTNER_ID,      
				  AC_ITEM_NUM,         
				  AC_ITEM_CAT_CODE,    
				  AC_ITEM_TYPE_CODE,   
				  AC_ITEM_STATUS_TS,   
				  AC_ITEM_STATUS_CD,   
				  AC_ITEM_STATUS_BY,   
				  AC_ITEM_BP_ID,       
				  AC_ITEM_DEFLT_IND,   
				  CREATED_BY,          
				  CREATED_BY_TS,       
				  LAST_MODIFIED_BY,    
				  LAST_MODIFIED_TS,    
				  AC_ITEM_TITLE )
				VALUES                                   
				( P_PROJNUM,                           
				  P_BIDPKGNUM,                         
				  V_PRIME_BPID,                           
				  V_GENNED_ITEM_NUM,                   
				  V_PARM_CAT,                             
				  V_PARM_TYPE,                            
				  V_STATUS_TIMESTAMP,
				  V_PARM_STATUS ,          
				  V_STATUS_USERID ,      
				  V_PARM_ITEMBPID,                        
				  'Y',                                   
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_PARM_ITEMTITLE)    ;
		  			
		  		END IF;	
			  
			  	IF V_JV2_BPID <> ' '
		  		THEN
		  			SET V_ERRLOC = 'D204';
		        	SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
		  			INSERT INTO AC_ITEM    
				( ECMS_PROJECT_NUM,    
				  BID_PACKAGE_NUM,     
				  BUS_PARTNER_ID,      
				  AC_ITEM_NUM,         
				  AC_ITEM_CAT_CODE,    
				  AC_ITEM_TYPE_CODE,   
				  AC_ITEM_STATUS_TS,   
				  AC_ITEM_STATUS_CD,   
				  AC_ITEM_STATUS_BY,   
				  AC_ITEM_BP_ID,       
				  AC_ITEM_DEFLT_IND,   
				  CREATED_BY,          
				  CREATED_BY_TS,       
				  LAST_MODIFIED_BY,    
				  LAST_MODIFIED_TS,    
				  AC_ITEM_TITLE )
				VALUES                                   
				( P_PROJNUM,                           
				  P_BIDPKGNUM,                         
				  V_PRIME_BPID,                           
				  V_GENNED_ITEM_NUM,                   
				  V_PARM_CAT,                             
				  V_PARM_TYPE,                            
				  V_STATUS_TIMESTAMP,
				  V_PARM_STATUS ,          
				  V_STATUS_USERID ,      
				  V_PARM_ITEMBPID,                        
				  'Y',                                   
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_PARM_ITEMTITLE)    ;
		  			
		  		END IF;	
		  
			SET V_PARM_STATUS = NULL;	  
	
			SET V_ERRLOC = 'D210';	  
			INSERT INTO AC_MIN_SOLICIT 
				( ECMS_PROJECT_NUM,        
				  BID_PACKAGE_NUM,         
				  BUS_PARTNER_ID,          
				  AC_ITEM_NUM )            	  
			VALUES                 
				( P_PROJNUM,         
				  P_BIDPKGNUM,       
				  V_PRIME_BPID,         
				  V_GENNED_ITEM_NUM )	;
		ELSE

			SET V_ERRLOC = 'D220';
			SELECT COUNT(*) INTO V_COUNT                  
		 	FROM (SELECT '1' FROM PROJ_GOAL GOAL,          
		 	PROJECT P WHERE                                
		 	GOAL.ECMS_PROJECT_NUM = P.ECMS_PROJECT_NUM     
		 	AND P.FED_PROJ_STAT_CD = '4'                   
		 	AND                                            
		 	(                                              
		 	(UCASE(GOAL.GOAL_CODE) IN ('DBE') AND          
		 	P.STATE_PROJECT_STATUS_CODE = '1')             
			OR                                              
			(                                               
		  	(UCASE(GOAL.GOAL_CODE) IN ('MBE', 'WBE') AND  
		  	(P.STATE_PROJECT_STATUS_CODE = '0' OR         
		   	P.STATE_PROJECT_STATUS_CODE IS NULL))        
			)                                               
			)                                               
		 	AND GOAL.ECMS_PROJECT_NUM = P_PROJNUM        
		 	UNION 
 	                                         
 			SELECT '1' FROM PROJ_GOAL GOAL, PROJECT P      
			WHERE GOAL.ECMS_PROJECT_NUM = P.ECMS_PROJECT_NUM
		 	  AND P.FED_PROJ_STAT_CD IN ('1', '2', '3')      
			  AND COALESCE(GOAL.GOAL_PCT,0) > 0               
		 	  AND UCASE(GOAL.GOAL_CODE) = 'DBE'              
		 	  AND GOAL.ECMS_PROJECT_NUM = P_PROJNUM ) F   ;
		  
			IF  V_COUNT > 0
		 	THEN
		 		SET V_PARM_STATUS = '7';  	-- REVIEW STATUS
		 		IF  V_PRJ_FED_PROJ_STAT_CD <> '4'		-- NOT 100 PERCENT STATE (INSERT THE FEDERAL ITEM)
		 		THEN
		 			SET V_PARM_ITEMBPID = V_PRIME_BPID;
		 			SET V_PARM_CAT = '2' ;	-- PREAWARD SUBTYPE
		 			SET V_PARM_TYPE = '204';	-- TYPE CODE MINPART FED
		 			SET V_ERRLOC = 'D230';
					SELECT GEN_CODE_VALUE                     
				  	INTO V_GP_GEN_CODE_VALUE                 
				  	FROM COM_GENERAL_CODE                   
				 	WHERE GEN_CODE_TYPE = V_PARM_GEN_CODE_TYPE
				   	  AND GEN_CODE = V_PARM_TYPE    ;  	  	    
			
					SET V_PARM_ITEMTITLE = V_GP_GEN_CODE_VALUE;
					SET V_PARM_TYPE = '205';	-- TYPE CODE MINPART
					SET V_ERRLOC = 'D240';
					SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
			        INSERT INTO AC_ITEM    
					( ECMS_PROJECT_NUM,    
					  BID_PACKAGE_NUM,     
					  BUS_PARTNER_ID,      
					  AC_ITEM_NUM,         
					  AC_ITEM_CAT_CODE,    
					  AC_ITEM_TYPE_CODE,   
					  AC_ITEM_STATUS_TS,   
					  AC_ITEM_STATUS_CD,   
					  AC_ITEM_STATUS_BY,   
					  AC_ITEM_BP_ID,       
					  AC_ITEM_DEFLT_IND,   
					  CREATED_BY,          
					  CREATED_BY_TS,       
					  LAST_MODIFIED_BY,    
					  LAST_MODIFIED_TS,    
					  AC_ITEM_TITLE )
					VALUES                                   
					( P_PROJNUM,                           
					  P_BIDPKGNUM,                         
					  V_PRIME_BPID,                           
					  V_GENNED_ITEM_NUM,                   
					  V_PARM_CAT,                             
					  V_PARM_TYPE,                            
					  V_STATUS_TIMESTAMP,
					  V_PARM_STATUS ,          
					  V_STATUS_USERID ,      
					  V_PARM_ITEMBPID,                        
					  'Y',                                   
					  V_SYSTEM_USERID,                        
					  CURRENT_TIMESTAMP,                     
					  V_SYSTEM_USERID,                        
					  CURRENT_TIMESTAMP,                     
					  V_PARM_ITEMTITLE)    ;
					  
					  
			
					SET V_PARM_STATUS = NULL;  
			  
					SET V_ERRLOC = 'D250';
					INSERT INTO AC_MIN_PART_CMMT
					( ECMS_PROJECT_NUM,         
					  BID_PACKAGE_NUM,          
					  BUS_PARTNER_ID,           
					  AC_ITEM_NUM,              
					  ATT_A_STATUS_CODE,        
					  CREATED_BY,               
					  CREATED_BY_TS,            
					  LAST_MODIFIED_BY,         
					  LAST_MODIFIED_TS )        
					VALUES                      
					( P_PROJNUM,              
					  P_BIDPKGNUM,            
					  V_PRIME_BPID,              
					  V_GENNED_ITEM_NUM,      
					  '01' ,                    
					  V_SYSTEM_USERID,           
					  CURRENT_TIMESTAMP,        
					  V_SYSTEM_USERID,           
					  CURRENT_TIMESTAMP)  ;  	  
			  	  
				ELSE
					-- INSERT THE STATE ITEM
					IF V_PRJ_STATE_PROJECT_STATUS_CODE = '1'
					THEN
						-- STATE AND ONE GOAL PROJECT
						SET V_PARM_ITEMBPID = V_PRIME_BPID;
						SET V_PARM_CAT = '2';	-- PREAWARD SUBTYPE
						SET V_PARM_TYPE = '204';	-- TYPE CODE MINPART FED
				
						SET V_ERRLOC = 'D260';
						SELECT GEN_CODE_VALUE                     
					  	INTO V_GP_GEN_CODE_VALUE                 
					  	FROM COM_GENERAL_CODE                   
					 	WHERE GEN_CODE_TYPE = V_PARM_GEN_CODE_TYPE
					   	  AND GEN_CODE = V_PARM_TYPE    ;  	  	 
			   	     
						SET V_PARM_ITEMTITLE = V_GP_GEN_CODE_VALUE;
						SET V_PARM_TYPE = '205';	-- TYPE CODE MINPART
						SET V_ERRLOC = 'D270';
						SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
				        INSERT INTO AC_ITEM    
						( ECMS_PROJECT_NUM,    
						  BID_PACKAGE_NUM,     
						  BUS_PARTNER_ID,      
						  AC_ITEM_NUM,         
						  AC_ITEM_CAT_CODE,    
						  AC_ITEM_TYPE_CODE,   
						  AC_ITEM_STATUS_TS,   
						  AC_ITEM_STATUS_CD,   
						  AC_ITEM_STATUS_BY,   
						  AC_ITEM_BP_ID,       
						  AC_ITEM_DEFLT_IND,   
						  CREATED_BY,          
						  CREATED_BY_TS,       
						  LAST_MODIFIED_BY,    
						  LAST_MODIFIED_TS,    
						  AC_ITEM_TITLE )
						VALUES                                   
						( P_PROJNUM,                           
						  P_BIDPKGNUM,                         
						  V_PRIME_BPID,                           
						  V_GENNED_ITEM_NUM,                   
						  V_PARM_CAT,                             
						  V_PARM_TYPE,                            
						  V_STATUS_TIMESTAMP,
						  V_PARM_STATUS ,          
						  V_STATUS_USERID ,      
						  V_PARM_ITEMBPID,                        
						  'Y',                                   
						  V_SYSTEM_USERID,                        
						  CURRENT_TIMESTAMP,                     
						  V_SYSTEM_USERID,                        
						  CURRENT_TIMESTAMP,                     
						  V_PARM_ITEMTITLE)    ;
						  
						  
						
				  
						SET V_PARM_STATUS = NULL;  
				  
						SET V_ERRLOC = 'D280';
						INSERT INTO AC_MIN_PART_CMMT
							( ECMS_PROJECT_NUM,         
							  BID_PACKAGE_NUM,          
							  BUS_PARTNER_ID,           
							  AC_ITEM_NUM,              
							  ATT_A_STATUS_CODE,        
							  CREATED_BY,               
							  CREATED_BY_TS,            
							  LAST_MODIFIED_BY,         
							  LAST_MODIFIED_TS )        
							VALUES                      
							( P_PROJNUM,              
							  P_BIDPKGNUM,            
							  V_PRIME_BPID,              
							  V_GENNED_ITEM_NUM,      
							  '01' ,                    
							  V_SYSTEM_USERID,           
							  CURRENT_TIMESTAMP,        
							  V_SYSTEM_USERID,           
							  CURRENT_TIMESTAMP)  ;    
					ELSE
						SET V_PARM_ITEMBPID = V_PRIME_BPID;
						SET V_PARM_CAT = '2'; 	-- PREAWARD SUBTYPE
						SET V_PARM_TYPE = '203';	--	TYPE-CODE-MINPART-STATE
						SET V_ERRLOC = 'D290';
						SELECT GEN_CODE_VALUE                     
					  	INTO V_GP_GEN_CODE_VALUE                 
					  	FROM COM_GENERAL_CODE                   
					 	WHERE GEN_CODE_TYPE = V_PARM_GEN_CODE_TYPE
					   	  AND GEN_CODE = V_PARM_TYPE    ;  
			   	  	  	    
						SET V_PARM_ITEMTITLE = V_GP_GEN_CODE_VALUE;
						SET V_PARM_TYPE = '205';	-- TYPE CODE MINPART
						SET V_ERRLOC = 'D300';
						SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
				        INSERT INTO AC_ITEM    
						( ECMS_PROJECT_NUM,    
						  BID_PACKAGE_NUM,     
						  BUS_PARTNER_ID,      
						  AC_ITEM_NUM,         
						  AC_ITEM_CAT_CODE,    
						  AC_ITEM_TYPE_CODE,   
						  AC_ITEM_STATUS_TS,   
						  AC_ITEM_STATUS_CD,   
						  AC_ITEM_STATUS_BY,   
						  AC_ITEM_BP_ID,       
						  AC_ITEM_DEFLT_IND,   
						  CREATED_BY,          
						  CREATED_BY_TS,       
						  LAST_MODIFIED_BY,    
						  LAST_MODIFIED_TS,    
						  AC_ITEM_TITLE )
						VALUES                                   
						( P_PROJNUM,                           
						  P_BIDPKGNUM,                         
						  V_PRIME_BPID,                           
						  V_GENNED_ITEM_NUM,                   
						  V_PARM_CAT,                             
						  V_PARM_TYPE,                            
						  V_STATUS_TIMESTAMP,
						  V_PARM_STATUS ,          
						  V_STATUS_USERID ,      
						  V_PARM_ITEMBPID,                        
						  'Y',                                   
						  V_SYSTEM_USERID,                        
						  CURRENT_TIMESTAMP,                     
						  V_SYSTEM_USERID,                        
						  CURRENT_TIMESTAMP,                     
						  V_PARM_ITEMTITLE)    ;
						  
						  
						
						  
						  
						SET V_PARM_STATUS = NULL;  
				  
						SET V_ERRLOC = 'D310';
						INSERT INTO AC_MIN_PART_CMMT
							( ECMS_PROJECT_NUM,         
							  BID_PACKAGE_NUM,          
							  BUS_PARTNER_ID,           
							  AC_ITEM_NUM,              
							  ATT_A_STATUS_CODE,        
							  CREATED_BY,               
							  CREATED_BY_TS,            
							  LAST_MODIFIED_BY,         
							  LAST_MODIFIED_TS )        
							VALUES                      
							( P_PROJNUM,              
							  P_BIDPKGNUM,            
							  V_PRIME_BPID,              
							  V_GENNED_ITEM_NUM,      
							  '01' ,                    
							  V_SYSTEM_USERID,           
							  CURRENT_TIMESTAMP,        
							  V_SYSTEM_USERID,           
							  CURRENT_TIMESTAMP)  ;
					  
						SET V_PARM_STATUS = '6';	--	DRAFT STATUS
						SET V_STATUS_USERID = V_SYSTEM_USERID;
						SET V_PARM_ITEMBPID = V_PRIME_BPID;
						SET V_PARM_CAT = '2';	-- PREAWARD SUBTYPE
						SET V_PARM_TYPE = '200';	-- TYPE CODE MINSOL
						SET V_ERRLOC = 'D320';
						SELECT GEN_CODE_VALUE                     
					  	INTO V_GP_GEN_CODE_VALUE                 
					  	FROM COM_GENERAL_CODE                   
					 	WHERE GEN_CODE_TYPE = V_PARM_GEN_CODE_TYPE
					   	  AND GEN_CODE = V_PARM_TYPE    ;  
			   	  	  	    
						SET V_PARM_ITEMTITLE = V_GP_GEN_CODE_VALUE;
						SET V_ERRLOC = 'D330';
						SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
				        INSERT INTO AC_ITEM    
						( ECMS_PROJECT_NUM,    
						  BID_PACKAGE_NUM,     
						  BUS_PARTNER_ID,      
						  AC_ITEM_NUM,         
						  AC_ITEM_CAT_CODE,    
						  AC_ITEM_TYPE_CODE,   
						  AC_ITEM_STATUS_TS,   
						  AC_ITEM_STATUS_CD,   
						  AC_ITEM_STATUS_BY,   
						  AC_ITEM_BP_ID,       
						  AC_ITEM_DEFLT_IND,   
						  CREATED_BY,          
						  CREATED_BY_TS,       
						  LAST_MODIFIED_BY,    
						  LAST_MODIFIED_TS,    
						  AC_ITEM_TITLE )
						VALUES                                   
						( P_PROJNUM,                           
						  P_BIDPKGNUM,                         
						  V_PRIME_BPID,                           
						  V_GENNED_ITEM_NUM,                   
						  V_PARM_CAT,                             
						  V_PARM_TYPE,                            
						  V_STATUS_TIMESTAMP,
						  V_PARM_STATUS ,          
						  V_STATUS_USERID ,      
						  V_PARM_ITEMBPID,                        
						  'Y',                                   
						  V_SYSTEM_USERID,                        
						  CURRENT_TIMESTAMP,                     
						  V_SYSTEM_USERID,                        
						  CURRENT_TIMESTAMP,                     
						  V_PARM_ITEMTITLE)    ;	
						  
						  
						IF V_JV1_BPID <> ' '
				  		THEN
				  			SET V_ERRLOC = 'D332';
				        	SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
				  			INSERT INTO AC_ITEM    
						( ECMS_PROJECT_NUM,    
						  BID_PACKAGE_NUM,     
						  BUS_PARTNER_ID,      
						  AC_ITEM_NUM,         
						  AC_ITEM_CAT_CODE,    
						  AC_ITEM_TYPE_CODE,   
						  AC_ITEM_STATUS_TS,   
						  AC_ITEM_STATUS_CD,   
						  AC_ITEM_STATUS_BY,   
						  AC_ITEM_BP_ID,       
						  AC_ITEM_DEFLT_IND,   
						  CREATED_BY,          
						  CREATED_BY_TS,       
						  LAST_MODIFIED_BY,    
						  LAST_MODIFIED_TS,    
						  AC_ITEM_TITLE )
						VALUES                                   
						( P_PROJNUM,                           
						  P_BIDPKGNUM,                         
						  V_PRIME_BPID,                           
						  V_GENNED_ITEM_NUM,                   
						  V_PARM_CAT,                             
						  V_PARM_TYPE,                            
						  V_STATUS_TIMESTAMP,
						  V_PARM_STATUS ,          
						  V_STATUS_USERID ,      
						  V_PARM_ITEMBPID,                        
						  'Y',                                   
						  V_SYSTEM_USERID,                        
						  CURRENT_TIMESTAMP,                     
						  V_SYSTEM_USERID,                        
						  CURRENT_TIMESTAMP,                     
						  V_PARM_ITEMTITLE)    ;
				  			
				  		END IF;	
			  
					  	IF V_JV2_BPID <> ' '
				  		THEN
				  			SET V_ERRLOC = 'D334';
				        	SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
				  			INSERT INTO AC_ITEM    
						( ECMS_PROJECT_NUM,    
						  BID_PACKAGE_NUM,     
						  BUS_PARTNER_ID,      
						  AC_ITEM_NUM,         
						  AC_ITEM_CAT_CODE,    
						  AC_ITEM_TYPE_CODE,   
						  AC_ITEM_STATUS_TS,   
						  AC_ITEM_STATUS_CD,   
						  AC_ITEM_STATUS_BY,   
						  AC_ITEM_BP_ID,       
						  AC_ITEM_DEFLT_IND,   
						  CREATED_BY,          
						  CREATED_BY_TS,       
						  LAST_MODIFIED_BY,    
						  LAST_MODIFIED_TS,    
						  AC_ITEM_TITLE )
						VALUES                                   
						( P_PROJNUM,                           
						  P_BIDPKGNUM,                         
						  V_PRIME_BPID,                           
						  V_GENNED_ITEM_NUM,                   
						  V_PARM_CAT,                             
						  V_PARM_TYPE,                            
						  V_STATUS_TIMESTAMP,
						  V_PARM_STATUS ,          
						  V_STATUS_USERID ,      
						  V_PARM_ITEMBPID,                        
						  'Y',                                   
						  V_SYSTEM_USERID,                        
						  CURRENT_TIMESTAMP,                     
						  V_SYSTEM_USERID,                        
						  CURRENT_TIMESTAMP,                     
						  V_PARM_ITEMTITLE)    ;
				  			
				  		END IF;	  
				  
						SET V_PARM_STATUS = NULL;  
				  
						SET V_ERRLOC = 'D340';	  
						INSERT INTO AC_MIN_SOLICIT 
							( ECMS_PROJECT_NUM,        
							  BID_PACKAGE_NUM,         
							  BUS_PARTNER_ID,          
							  AC_ITEM_NUM )            	  
						VALUES                 
							( P_PROJNUM,         
							  P_BIDPKGNUM,       
							  V_PRIME_BPID,         
							  V_GENNED_ITEM_NUM )	;	    
				
					END IF;		
				END IF;	  
			END IF;		  
		END IF;	                      		 
		 
		SET V_PARM_ITEMBPID = V_PRIME_BPID;
		SET V_PARM_CAT = '5';
		SET V_PARM_TYPE = '300';	-- TYPE CODE MAILADDR
		SET V_PARM_STATUS = '3';	-- COMPLETE STATUS
		SET V_ERRLOC = 'D350';
		SELECT GEN_CODE_VALUE                     
		INTO V_GP_GEN_CODE_VALUE                 
		FROM COM_GENERAL_CODE                   
		WHERE GEN_CODE_TYPE = V_PARM_GEN_CODE_TYPE
		  AND GEN_CODE = V_PARM_TYPE    ;  	  	    
		SET V_PARM_ITEMTITLE = V_GP_GEN_CODE_VALUE;
		SET V_ERRLOC = 'D360';
		SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
		INSERT INTO AC_ITEM    
		( ECMS_PROJECT_NUM,    
		  BID_PACKAGE_NUM,     
		  BUS_PARTNER_ID,      
		  AC_ITEM_NUM,         
		  AC_ITEM_CAT_CODE,    
		  AC_ITEM_TYPE_CODE,   
		  AC_ITEM_STATUS_TS,   
		  AC_ITEM_STATUS_CD,   
		  AC_ITEM_STATUS_BY,   
		  AC_ITEM_BP_ID,       
		  AC_ITEM_DEFLT_IND,   
		  CREATED_BY,          
		  CREATED_BY_TS,       
		  LAST_MODIFIED_BY,    
		  LAST_MODIFIED_TS,    
		  AC_ITEM_TITLE )
		VALUES                                   
		( P_PROJNUM,                           
		  P_BIDPKGNUM,                         
		  V_PRIME_BPID,                           
		  V_GENNED_ITEM_NUM,                   
		  V_PARM_CAT,                             
		  V_PARM_TYPE,                            
		  V_STATUS_TIMESTAMP,
		  V_PARM_STATUS ,          
		  V_STATUS_USERID ,      
		  V_PARM_ITEMBPID,                        
		  'Y',                                   
		  V_SYSTEM_USERID,                        
		  CURRENT_TIMESTAMP,                     
		  V_SYSTEM_USERID,                        
		  CURRENT_TIMESTAMP,                     
		  V_PARM_ITEMTITLE)    ;
		  
		
		  
  		  
		SET V_PARM_STATUS = NULL;  
		
		SET V_ERRLOC = 'D370';
		SELECT BUS_PARTNER_NAME,
		       MAILING_ADDRESS_1,
		       MAILING_ADDRESS_2,
		       MAILING_ADDRESS_3,
		       MAILING_CITY,
		       MAILING_STATE,
		       MAILING_ZIP,
		       MAILING_ZIP_EXT,
		       BUS_PARTNER_FID
		INTO   V_BP_BUS_PARTNER_NAME,  
		       V_BP_MAILING_ADDRESS_1,
		       V_BP_MAILING_ADDRESS_2,
		       V_BP_MAILING_ADDRESS_3,
		       V_BP_MAILING_CITY ,          
		       V_BP_MAILING_STATE,        
		       V_BP_MAILING_ZIP ,            
		       V_BP_MAILING_ZIP_EXT,    
		       V_BP_FEIN                                    
		FROM BUSINESS_PARTNER                            
		WHERE BUS_PARTNER_ID = V_PRIME_BPID; 

		SET V_ERRLOC = 'D380';
		INSERT INTO AC_MAIL_ADDR 
		( ECMS_PROJECT_NUM,      
		  BID_PACKAGE_NUM,       
		  BUS_PARTNER_ID,        
		  AC_ITEM_NUM,           
		  ADDRESS_LINE_1,        
		  ADDRESS_LINE_2,        
		  ADDRESS_LINE_3,        
		  ADDRESS_CITY,          
		  ADDRESS_STATE,         
		  ADDRESS_ZIP,           
		  ADDRESS_ZIP_EXT,       
		  ADDRESS_NAME )         
		VALUES                                        
		( P_PROJNUM,                                
		  P_BIDPKGNUM,                              
		  V_PRIME_BPID,                                
		  V_GENNED_ITEM_NUM,                        
		  V_BP_MAILING_ADDRESS_1,
		  V_BP_MAILING_ADDRESS_2,
		  V_BP_MAILING_ADDRESS_3,
		  V_BP_MAILING_CITY,          
		  V_BP_MAILING_STATE,        
		  V_BP_MAILING_ZIP,            
		  V_BP_MAILING_ZIP_EXT,    
		  V_BP_BUS_PARTNER_NAME);		
		
		IF  V_PRJ_PROJ_TYPE = '02'  OR	-- IF MUNICIPAL OR LOCAL PROJECT
		    V_PRJ_PROJ_TYPE = '03'
		THEN
			SET V_ERRLOC = 'D390';
			SELECT BUS_PARTNER_ID                 
		  	INTO V_MUNI_BPID                     
		  	FROM PROJ_CONTRACTOR                
		 	WHERE ECMS_PROJECT_NUM = P_PROJNUM 
		   	  AND PROJ_CONTR_TYPE = 'M' ; 
		   	SET V_ERRLOC = 'D400';    
		   	SELECT BUS_PARTNER_FID            
		  	INTO V_BP_FEIN                   
		  	FROM BUSINESS_PARTNER           
		 	WHERE BUS_PARTNER_ID = V_MUNI_BPID  ;        
    
    		SET V_FV_BPID = V_MUNI_BPID;
    
    	-- LP PROCESS --
	     	SET V_ERRLOC = 'D405';		
			 SELECT                                                 
			 CASE RAS.RA_STATUS_CODE                                
			 WHEN '11' THEN 'PASS' ELSE 'FAIL' END AS VALIDATION_IND
			 INTO V_VALIDATION_IND                                
			 FROM ECMSXADM.PROJECT P                                
			 LEFT OUTER JOIN ECMSXADM.RAS_PROJECT_XREF RASP         
			      ON P.ECMS_PROJECT_NUM = RASP.ECMS_PROJECT_NUM     
			 LEFT OUTER JOIN ECMSXADM.RAS_REIMBURSEMENT_SUMMARY RAS 
			      ON RASP.RA_NUM = RAS.RA_NUM                       
			 WHERE P.ECMS_PROJECT_NUM = P_PROJNUM   ;   
			 IF V_VALIDATION_IND = 'PASS'           
			 THEN
			 	SET V_ITEM_STATUS_CODE = '1';
			 ELSE
			 	IF V_VALIDATION_IND = 'FAIL'
			 	THEN
			 		SET V_ITEM_STATUS_CODE = '2';
			 	END IF;
			 END IF;	
	 
	 
			 -- RA CHECK --
			 SET V_PARM_TYPE = '466';	-- TYPE CODE EXECUTED RA CHECK
			 SET V_ERRLOC = 'D410';
			 SELECT GEN_CODE_VALUE                     
			 INTO V_GP_GEN_CODE_VALUE                 
			 FROM COM_GENERAL_CODE                   
			 WHERE GEN_CODE_TYPE = V_PARM_GEN_CODE_TYPE
			   AND GEN_CODE = V_PARM_TYPE    ; 
			    	  	    
			 SET V_PARM_ITEMTITLE = V_GP_GEN_CODE_VALUE;
			 SET V_ERRLOC = 'D420';
			 SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
			 INSERT INTO AC_ITEM 
			 ( ECMS_PROJECT_NUM, 
			  BID_PACKAGE_NUM,  
			  BUS_PARTNER_ID,   
			  AC_ITEM_NUM,      
			  AC_ITEM_CAT_CODE, 
			  AC_ITEM_TYPE_CODE,
			  AC_ITEM_STATUS_TS,
			  AC_ITEM_STATUS_CD,
			  AC_ITEM_STATUS_BY,
			  AC_ITEM_BP_ID,    
			  AC_ITEM_DEFLT_IND,
			  AC_ITEM_TITLE,    
			  EDMS_DOC_LINK,    
			  AC_ITEM_COMMENT,  
			  CREATED_BY,       
			  CREATED_BY_TS,    
			  LAST_MODIFIED_BY, 
			  LAST_MODIFIED_TS, 
			  WORKFLOW_ID,      
			  DOCUMENT_ID,      
			  ATTACHMENT_ID)
			 VALUES                             
			( P_PROJNUM,                     
			  P_BIDPKGNUM,                   
			  V_PRIME_BPID,                     
			  V_GENNED_ITEM_NUM,             
			   '1',                            
			  V_PARM_TYPE,                      
			  CURRENT TIMESTAMP,               
			  V_ITEM_STATUS_CODE,            
			  V_STATUS_USERID,
			  V_MUNI_BPID,                      
			  NULL,                            
			  V_PARM_ITEMTITLE,                 
			  NULL,                            
			  NULL,                            
			  V_SYSTEM_USERID,                  
			  CURRENT TIMESTAMP,               
			  V_SYSTEM_USERID,                  
			  CURRENT TIMESTAMP,               
			  NULL,                            
			  NULL,                            
			  NULL)  ;
			  
			  IF V_JV1_BPID <> ' '
		  		THEN
		  			SET V_ERRLOC = 'D422';
		        	SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
		  			INSERT INTO AC_ITEM    
				( ECMS_PROJECT_NUM,    
				  BID_PACKAGE_NUM,     
				  BUS_PARTNER_ID,      
				  AC_ITEM_NUM,         
				  AC_ITEM_CAT_CODE,    
				  AC_ITEM_TYPE_CODE,   
				  AC_ITEM_STATUS_TS,   
				  AC_ITEM_STATUS_CD,   
				  AC_ITEM_STATUS_BY,   
				  AC_ITEM_BP_ID,       
				  AC_ITEM_DEFLT_IND,   
				  CREATED_BY,          
				  CREATED_BY_TS,       
				  LAST_MODIFIED_BY,    
				  LAST_MODIFIED_TS,    
				  AC_ITEM_TITLE )
				VALUES                                   
				( P_PROJNUM,                           
				  P_BIDPKGNUM,                         
				  V_PRIME_BPID,                           
				  V_GENNED_ITEM_NUM,                   
				  V_PARM_CAT,                             
				  V_PARM_TYPE,                            
				  V_STATUS_TIMESTAMP,
				  V_PARM_STATUS ,          
				  V_STATUS_USERID ,      
				  V_PARM_ITEMBPID,                        
				  'Y',                                   
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_PARM_ITEMTITLE)    ;
		  			
		  		END IF;	
			  
			  	IF V_JV2_BPID <> ' '
		  		THEN
		  			SET V_ERRLOC = 'D424';
		        	SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
		  			INSERT INTO AC_ITEM    
				( ECMS_PROJECT_NUM,    
				  BID_PACKAGE_NUM,     
				  BUS_PARTNER_ID,      
				  AC_ITEM_NUM,         
				  AC_ITEM_CAT_CODE,    
				  AC_ITEM_TYPE_CODE,   
				  AC_ITEM_STATUS_TS,   
				  AC_ITEM_STATUS_CD,   
				  AC_ITEM_STATUS_BY,   
				  AC_ITEM_BP_ID,       
				  AC_ITEM_DEFLT_IND,   
				  CREATED_BY,          
				  CREATED_BY_TS,       
				  LAST_MODIFIED_BY,    
				  LAST_MODIFIED_TS,    
				  AC_ITEM_TITLE )
				VALUES                                   
				( P_PROJNUM,                           
				  P_BIDPKGNUM,                         
				  V_PRIME_BPID,                           
				  V_GENNED_ITEM_NUM,                   
				  V_PARM_CAT,                             
				  V_PARM_TYPE,                            
				  V_STATUS_TIMESTAMP,
				  V_PARM_STATUS ,          
				  V_STATUS_USERID ,      
				  V_PARM_ITEMBPID,                        
				  'Y',                                   
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_PARM_ITEMTITLE)    ;
		  			
		  		END IF;	
	  
				-- RA SERVICE DATE --
			  SET V_ERRLOC = 'D430';
			  SELECT                                                 
		      CASE                                             
		          WHEN RAS.RA_END_DATE >= PRJM.ECMS_ANTIC_DATE 
		            OR RAS.RA_END_DATE IS NULL                 
				 THEN 'PASS' ELSE 'FAIL' END AS VALIDATION_IND         
				 INTO V_VALIDATION_IND                               
				 FROM ECMSXADM.PROJECT P                               
				 LEFT OUTER JOIN ECMSXADM.PROJ_MILESTONE PRJM          
				      ON P.ECMS_PROJECT_NUM = PRJM.ECMS_PROJECT_NUM    
				 LEFT OUTER JOIN ECMSXADM.RAS_PROJECT_XREF RASP        
				      ON PRJM.ECMS_PROJECT_NUM = RASP.ECMS_PROJECT_NUM 
				 LEFT OUTER JOIN ECMSXADM.RAS_REIMBURSEMENT_SUMMARY RAS
				      ON RASP.RA_NUM = RAS.RA_NUM                      
				WHERE P.ECMS_PROJECT_NUM = P_PROJNUM                 
				  AND PRJM.MILEST_DATE_CODE = 04 ;
			   IF V_VALIDATION_IND = 'PASS'
			   THEN
			   		SET V_ITEM_STATUS_CODE = '1';
			   ELSE
			   		IF V_VALIDATION_IND = 'FAIL'
			   		THEN
			   			SET V_ITEM_STATUS_CODE = '2';
			   		END IF;	
			 	END IF;	
			 	SET V_PARM_TYPE = '467'; 	-- TYPE CODE RA SERVICE DATES
			 	SET V_ERRLOC = 'D440';
				 SELECT GEN_CODE_VALUE                     
				 INTO V_GP_GEN_CODE_VALUE                 
				 FROM COM_GENERAL_CODE                   
				 WHERE GEN_CODE_TYPE = V_PARM_GEN_CODE_TYPE
				   AND GEN_CODE = V_PARM_TYPE    ;  	  	    
				 SET V_PARM_ITEMTITLE = V_GP_GEN_CODE_VALUE;
				 SET V_ERRLOC = 'D450';
				 SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
			 	INSERT INTO AC_ITEM 
				( ECMS_PROJECT_NUM, 
				  BID_PACKAGE_NUM,  
				  BUS_PARTNER_ID,   
				  AC_ITEM_NUM,      
				  AC_ITEM_CAT_CODE, 
				  AC_ITEM_TYPE_CODE,
				  AC_ITEM_STATUS_TS,
				  AC_ITEM_STATUS_CD,
				  AC_ITEM_STATUS_BY,
				  AC_ITEM_BP_ID,    
				  AC_ITEM_DEFLT_IND,
				  AC_ITEM_TITLE,    
				  EDMS_DOC_LINK,    
				  AC_ITEM_COMMENT,  
				  CREATED_BY,       
				  CREATED_BY_TS,    
				  LAST_MODIFIED_BY, 
				  LAST_MODIFIED_TS, 
				  WORKFLOW_ID,      
				  DOCUMENT_ID,      
				  ATTACHMENT_ID)
				 VALUES                             
				( P_PROJNUM,                     
				  P_BIDPKGNUM,                   
				  V_PRIME_BPID,                     
				  V_GENNED_ITEM_NUM,             
				   '1',                            
				  V_PARM_TYPE,                      
				  CURRENT TIMESTAMP,               
				  V_ITEM_STATUS_CODE,            
				  V_STATUS_USERID,
				  V_MUNI_BPID,                      
				  NULL,                            
				  V_PARM_ITEMTITLE,                 
				  NULL,                            
				  NULL,                            
				  V_SYSTEM_USERID,                  
				  CURRENT TIMESTAMP,               
				  V_SYSTEM_USERID,                  
				  CURRENT TIMESTAMP,               
				  NULL,                            
				  NULL,                            
				  NULL)  ; 
				  
				  IF V_JV1_BPID <> ' '
		  		THEN
		  			SET V_ERRLOC = 'D452';
		        	SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
		  			INSERT INTO AC_ITEM    
				( ECMS_PROJECT_NUM,    
				  BID_PACKAGE_NUM,     
				  BUS_PARTNER_ID,      
				  AC_ITEM_NUM,         
				  AC_ITEM_CAT_CODE,    
				  AC_ITEM_TYPE_CODE,   
				  AC_ITEM_STATUS_TS,   
				  AC_ITEM_STATUS_CD,   
				  AC_ITEM_STATUS_BY,   
				  AC_ITEM_BP_ID,       
				  AC_ITEM_DEFLT_IND,   
				  CREATED_BY,          
				  CREATED_BY_TS,       
				  LAST_MODIFIED_BY,    
				  LAST_MODIFIED_TS,    
				  AC_ITEM_TITLE )
				VALUES                                   
				( P_PROJNUM,                           
				  P_BIDPKGNUM,                         
				  V_PRIME_BPID,                           
				  V_GENNED_ITEM_NUM,                   
				  V_PARM_CAT,                             
				  V_PARM_TYPE,                            
				  V_STATUS_TIMESTAMP,
				  V_PARM_STATUS ,          
				  V_STATUS_USERID ,      
				  V_PARM_ITEMBPID,                        
				  'Y',                                   
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_PARM_ITEMTITLE)    ;
		  			
		  		END IF;	
			  
			  	IF V_JV2_BPID <> ' '
		  		THEN
		  			SET V_ERRLOC = 'D454';
		        	SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
		  			INSERT INTO AC_ITEM    
				( ECMS_PROJECT_NUM,    
				  BID_PACKAGE_NUM,     
				  BUS_PARTNER_ID,      
				  AC_ITEM_NUM,         
				  AC_ITEM_CAT_CODE,    
				  AC_ITEM_TYPE_CODE,   
				  AC_ITEM_STATUS_TS,   
				  AC_ITEM_STATUS_CD,   
				  AC_ITEM_STATUS_BY,   
				  AC_ITEM_BP_ID,       
				  AC_ITEM_DEFLT_IND,   
				  CREATED_BY,          
				  CREATED_BY_TS,       
				  LAST_MODIFIED_BY,    
				  LAST_MODIFIED_TS,    
				  AC_ITEM_TITLE )
				VALUES                                   
				( P_PROJNUM,                           
				  P_BIDPKGNUM,                         
				  V_PRIME_BPID,                           
				  V_GENNED_ITEM_NUM,                   
				  V_PARM_CAT,                             
				  V_PARM_TYPE,                            
				  V_STATUS_TIMESTAMP,
				  V_PARM_STATUS ,          
				  V_STATUS_USERID ,      
				  V_PARM_ITEMBPID,                        
				  'Y',                                   
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_PARM_ITEMTITLE)    ;
		  			
		  		END IF;	
		  
				 -- RA CONS COST CHECK --
	--			 SET V_ERRLOC = 'D460';
	--			 SELECT                                      
	--	      			CASE WHEN  RAS.FEDERAL_FUNDING_AMT >= 
	--	                 TEMP.FPN_AVAILABLE_AMT  AND
	--	                 RAS.STATE_FUNDING_AMT   >= 
	--	                 TEMP.SPN_AVAILABLE_AMT AND  
	--	          (RAS.CONSTRUCT_MUNI_INCUR_COST+RAS.CONSTRUCT_STATE_INCUR_COST)
	--	                 	>= TEMP.TOTAL_AVAILABLE_AMT 
	--	          		 THEN 'PASS' ELSE 'FAIL' END AS VALIDATION_IND      	
	--		 	 INTO V_VALIDATION_IND                                
	--			FROM ECMSXADM.PROJECT P                                
	--			LEFT OUTER JOIN ECMSXADM.RAS_PROJECT_XREF RASP         
	--			  ON P.ECMS_PROJECT_NUM = RASP.ECMS_PROJECT_NUM        
	--			LEFT OUTER JOIN ECMSXADM.RAS_REIMBURSEMENT_SUMMARY RAS 
	--			  ON RASP.RA_NUM = RAS.RA_NUM                          
	--			LEFT OUTER JOIN(SELECT CRAS.FPN_AVAILABLE_AMT,         
	--			                    CRAS.SPN_AVAILABLE_AMT,            
	--			                    CPRAS.TOTAL_AVAILABLE_AMT,         
	--			                    CRAS.RA_NUM AS RA1,                
	--			                    CRAS.RA_NUM AS RA2                 
	--			             FROM  ECMSXADM.CMP_RAS_SUMMARY CRAS       
	--			  INNER JOIN ECMSXADM.CMP_RAS_PHASE_SUMMARY CPRAS      
	--			             ON CPRAS.RA_NUM = CRAS.RA_NUM             
	--			             AND CPRAS.PHASE_ID = '01')TEMP            
	--			ON TEMP.RA1 = RAS.RA_NUM                               
	--			WHERE P.ECMS_PROJECT_NUM = P_PROJNUM   ;  
	
	
			SELECT
			                                                   
         CASE WHEN RAS.FEDERAL_FUNDING_AMT >=             
			CMP.FPN_AVAILABLE_AMT                                     
              AND RAS.STATE_FUNDING_AMT >=                
					CMP.SPN_AVAILABLE_AMT                                     
			 AND (RAS.CONSTRUCT_MUNI_INCUR_COST                        
					+ RAS.CONSTRUCT_STATE_INCUR_COST) >=                      
						CMP.TOTAL_AVAILABLE_AMT                                   
             THEN 'PASS' ELSE 'FAIL' END AS VALIDATION_IND
                                                          
       INTO V_VALIDATION_IND                            
    FROM ECMSXADM.RAS_REIMBURSEMENT_SUMMARY RAS           
                                                          
    LEFT OUTER JOIN ECMSXADM.CMP_RAS_PHASE_SUMMARY CMP    
      ON CMP.RA_NUM = RAS.RA_NUM                          
   AND CMP.PHASE_ID = '01'                                
                                                          
WHERE RAS.RA_NUM =                                        
        (                                                 
          SELECT RA_NUM                                   
            FROM ECMSXADM.RAS_PROJECT_XREF X  
            INNER JOIN ECMSXADM.PDC_ITEM I            
				ON I.ECMS_PROJECT_NUM = X.ECMS_PROJECT_NUM
			AND I.PDC_ITEM_TYPE_CODE = '05'           
			AND I.CL_ITEM_NUM = 17                    
		INNER JOIN ECMSXADM.PDC_ITEM_DETAIL D     
			ON D.ECMS_PROJECT_NUM = I.ECMS_PROJECT_NUM
		AND D.CL_LINE_NUM = I.CL_LINE_NUM         
		AND D.VENDOR_AGREEMENT = X.RA_NUM         
                                          
		WHERE X.ECMS_PROJECT_NUM = P_PROJNUM   );    
		
		
		IF SQLCODE = 100
		THEN
			SET V_ITEM_STATUS_CODE = '2';
			
		ELSE
			IF V_VALIDATION_IND = 'PASS'
	   		THEN
	   			SET V_ITEM_STATUS_CODE = '1';
	   		ELSE
	   			IF V_VALIDATION_IND = 'FAIL'
	   			THEN
	   				SET V_ITEM_STATUS_CODE = '2';
	   			END IF;	
	 		END IF;	
	 	END IF;	 
	
					 	
			 	SET V_PARM_TYPE = '468'; 	-- TYPE CODE RA CON COSTS
				SET V_ERRLOC = 'D470';
				 SELECT GEN_CODE_VALUE                     
				 INTO V_GP_GEN_CODE_VALUE                 
				 FROM COM_GENERAL_CODE                   
				 WHERE GEN_CODE_TYPE = V_PARM_GEN_CODE_TYPE
				   AND GEN_CODE = V_PARM_TYPE    ;  	  	    
				 SET V_PARM_ITEMTITLE = V_GP_GEN_CODE_VALUE;
				 SET V_ERRLOC = 'D480';
				 SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
			 	INSERT INTO AC_ITEM 
				( ECMS_PROJECT_NUM, 
				  BID_PACKAGE_NUM,  
				  BUS_PARTNER_ID,   
				  AC_ITEM_NUM,      
				  AC_ITEM_CAT_CODE, 
				  AC_ITEM_TYPE_CODE,
				  AC_ITEM_STATUS_TS,
				  AC_ITEM_STATUS_CD,
				  AC_ITEM_STATUS_BY,
				  AC_ITEM_BP_ID,    
				  AC_ITEM_DEFLT_IND,
				  AC_ITEM_TITLE,    
				  EDMS_DOC_LINK,    
				  AC_ITEM_COMMENT,  
				  CREATED_BY,       
				  CREATED_BY_TS,    
				  LAST_MODIFIED_BY, 
				  LAST_MODIFIED_TS, 
				  WORKFLOW_ID,      
				  DOCUMENT_ID,      
				  ATTACHMENT_ID)
				 VALUES                             
				( P_PROJNUM,                     
				  P_BIDPKGNUM,                   
				  V_PRIME_BPID,                     
				  V_GENNED_ITEM_NUM,             
				   '1',                            
				  V_PARM_TYPE,                      
				  CURRENT TIMESTAMP,               
				  V_ITEM_STATUS_CODE,            
				  V_STATUS_USERID,
				  V_MUNI_BPID,                      
				  NULL,                            
				  V_PARM_ITEMTITLE,                 
				  NULL,                            
				  NULL,                            
				  V_SYSTEM_USERID,                  
				  CURRENT TIMESTAMP,               
				  V_SYSTEM_USERID,                  
				  CURRENT TIMESTAMP,               
				  NULL,                            
				  NULL,                            
				  NULL)  ;  
				  
				IF V_JV1_BPID <> ' '
		  		THEN
		  			SET V_ERRLOC = 'D482';
		        	SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
		  			INSERT INTO AC_ITEM    
				( ECMS_PROJECT_NUM,    
				  BID_PACKAGE_NUM,     
				  BUS_PARTNER_ID,      
				  AC_ITEM_NUM,         
				  AC_ITEM_CAT_CODE,    
				  AC_ITEM_TYPE_CODE,   
				  AC_ITEM_STATUS_TS,   
				  AC_ITEM_STATUS_CD,   
				  AC_ITEM_STATUS_BY,   
				  AC_ITEM_BP_ID,       
				  AC_ITEM_DEFLT_IND,   
				  CREATED_BY,          
				  CREATED_BY_TS,       
				  LAST_MODIFIED_BY,    
				  LAST_MODIFIED_TS,    
				  AC_ITEM_TITLE )
				VALUES                                   
				( P_PROJNUM,                           
				  P_BIDPKGNUM,                         
				  V_PRIME_BPID,                           
				  V_GENNED_ITEM_NUM,                   
				  V_PARM_CAT,                             
				  V_PARM_TYPE,                            
				  V_STATUS_TIMESTAMP,
				  V_PARM_STATUS ,          
				  V_STATUS_USERID ,      
				  V_PARM_ITEMBPID,                        
				  'Y',                                   
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_PARM_ITEMTITLE)    ;
		  			
		  		END IF;	
			  
			  	IF V_JV2_BPID <> ' '
		  		THEN
		  			SET V_ERRLOC = 'D484';
		        	SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
		  			INSERT INTO AC_ITEM    
				( ECMS_PROJECT_NUM,    
				  BID_PACKAGE_NUM,     
				  BUS_PARTNER_ID,      
				  AC_ITEM_NUM,         
				  AC_ITEM_CAT_CODE,    
				  AC_ITEM_TYPE_CODE,   
				  AC_ITEM_STATUS_TS,   
				  AC_ITEM_STATUS_CD,   
				  AC_ITEM_STATUS_BY,   
				  AC_ITEM_BP_ID,       
				  AC_ITEM_DEFLT_IND,   
				  CREATED_BY,          
				  CREATED_BY_TS,       
				  LAST_MODIFIED_BY,    
				  LAST_MODIFIED_TS,    
				  AC_ITEM_TITLE )
				VALUES                                   
				( P_PROJNUM,                           
				  P_BIDPKGNUM,                         
				  V_PRIME_BPID,                           
				  V_GENNED_ITEM_NUM,                   
				  V_PARM_CAT,                             
				  V_PARM_TYPE,                            
				  V_STATUS_TIMESTAMP,
				  V_PARM_STATUS ,          
				  V_STATUS_USERID ,      
				  V_PARM_ITEMBPID,                        
				  'Y',                                   
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_PARM_ITEMTITLE)    ;
		  			
		  		END IF;	  
	  
			    -- SUFFICIENT FUNDS CHECK  --
	--			SET V_ERRLOC = 'D490';
	--			SELECT                                                    
	--			  CASE WHEN TEMP.TOTAL_AVAILABLE_AMT >=                   
	--			                 TEMP.TOTAL_COST                          
	--			       THEN 'PASS' ELSE 'FAIL' END AS VALIDATE_IND        
	--			  INTO V_VALIDATION_IND                                 
	--			  FROM PROJECT P                                          
	--			  LEFT OUTER JOIN ECMSXADM.RAS_PROJECT_XREF PR            
	--			  ON PR.ECMS_PROJECT_NUM = P.ECMS_PROJECT_NUM             
	--			  LEFT OUTER JOIN (SELECT                                 
	--			COALESCE(RAS.TOTAL_AVAILABLE_AMT,0) AS TOTAL_AVAILABLE_AMT,
	--			         COALESCE(RAC.TOTAL_COST,0) AS TOTAL_COST,        
	--			                          RAS.RA_NUM                      
	--			                  FROM ECMSXADM.CMP_RAS_SUMMARY RAS       
	--			       LEFT OUTER JOIN ECMSXADM.CMP_RA_COST_SUMMARY RAC   
	--			       ON RAS.RA_NUM = RAC.RA_NUM)TEMP                    
	--			  ON TEMP.RA_NUM = PR.RA_NUM                              
	--			  WHERE P.ECMS_PROJECT_NUM = P_PROJNUM ; 
				  
	--			  IF V_VALIDATION_IND = 'PASS'
	--		   THEN
	--		   		SET V_ITEM_STATUS_CODE = '1';
	--		   ELSE
	--		   		IF V_VALIDATION_IND = 'FAIL'
	--		   		THEN
	--		   			SET V_ITEM_STATUS_CODE = '2';
	--		   		END IF;	
	--		 	END IF;	
			 	
	--		 	SET V_PARM_TYPE = '471'; 	-- TYPE CODE SUFFIC FUNDS
	--			SET V_ERRLOC = 'D500';
	--			 SELECT GEN_CODE_VALUE                     
	--			 INTO V_GP_GEN_CODE_VALUE                 
	--			 FROM COM_GENERAL_CODE                   
	--			 WHERE GEN_CODE_TYPE = V_PARM_GEN_CODE_TYPE
	--			   AND GEN_CODE = V_PARM_TYPE    ;  	  	    
	--			 SET V_PARM_ITEMTITLE = V_GP_GEN_CODE_VALUE;
	--			 SET V_ERRLOC = 'D510';
	--			 SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
	--		 	INSERT INTO AC_ITEM 
	--			( ECMS_PROJECT_NUM, 
	--			  BID_PACKAGE_NUM,  
	--			  BUS_PARTNER_ID,   
	--			  AC_ITEM_NUM,      
	--			  AC_ITEM_CAT_CODE, 
	--			  AC_ITEM_TYPE_CODE,
	--			  AC_ITEM_STATUS_TS,
	--			  AC_ITEM_STATUS_CD,
	--			  AC_ITEM_STATUS_BY,
	--			  AC_ITEM_BP_ID,    
	--			  AC_ITEM_DEFLT_IND,
	--			  AC_ITEM_TITLE,    
	--			  EDMS_DOC_LINK,    
	--			  AC_ITEM_COMMENT,  
	--			  CREATED_BY,       
	--			  CREATED_BY_TS,    
	--			  LAST_MODIFIED_BY, 
	--			  LAST_MODIFIED_TS, 
	--			  WORKFLOW_ID,      
	--			  DOCUMENT_ID,      
	--			  ATTACHMENT_ID)
	--			 VALUES                             
	--			( P_PROJNUM,                     
	--			  P_BIDPKGNUM,                   
	--			  V_PRIME_BPID,                     
	--			  V_GENNED_ITEM_NUM,             
	--			   '1',                            
	--			  V_PARM_TYPE,                      
	--			  CURRENT TIMESTAMP,               
	--			  V_ITEM_STATUS_CODE,            
	--			  V_STATUS_USERID,
	--			  V_MUNI_BPID,                      
	--			  NULL,                            
	--			  V_PARM_ITEMTITLE,                 
	--			  NULL,                            
	--			  NULL,                            
	--			  V_SYSTEM_USERID,                  
	--			  CURRENT TIMESTAMP,               
	--			  V_SYSTEM_USERID,                  
	--			  CURRENT TIMESTAMP,               
	--			  NULL,                            
	--			  NULL,                            
	--			  NULL)  ;
				  
	--			IF V_JV1_BPID <> ' '
	--	  		THEN
	--	  			SET V_ERRLOC = 'D512';
	--	        	SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
	--	  			INSERT INTO AC_ITEM    
	--			( ECMS_PROJECT_NUM,    
	--			  BID_PACKAGE_NUM,     
	--			  BUS_PARTNER_ID,      
	--			  AC_ITEM_NUM,         
	--			  AC_ITEM_CAT_CODE,    
	--			  AC_ITEM_TYPE_CODE,   
	--			  AC_ITEM_STATUS_TS,   
	--			  AC_ITEM_STATUS_CD,   
	--			  AC_ITEM_STATUS_BY,   
	--			  AC_ITEM_BP_ID,       
	--			  AC_ITEM_DEFLT_IND,   
	--			  CREATED_BY,          
	--			  CREATED_BY_TS,       
	--			  LAST_MODIFIED_BY,    
	--			  LAST_MODIFIED_TS,    
	--			  AC_ITEM_TITLE )
	--			VALUES                                   
	--			( P_PROJNUM,                           
	--			  P_BIDPKGNUM,                         
	--			  V_PRIME_BPID,                           
	--			  V_GENNED_ITEM_NUM,                   
	--			  V_PARM_CAT,                             
	--			  V_PARM_TYPE,                            
	--			  V_STATUS_TIMESTAMP,
	--			  V_PARM_STATUS ,          
	--			  V_STATUS_USERID ,      
	--			  V_PARM_ITEMBPID,                        
	--			  'Y',                                   
	--			  V_SYSTEM_USERID,                        
	--			  CURRENT_TIMESTAMP,                     
	--			  V_SYSTEM_USERID,                        
	--			  CURRENT_TIMESTAMP,                     
	--			  V_PARM_ITEMTITLE)    ;
		  			
	--	  		END IF;	
			  
	--		  	IF V_JV2_BPID <> ' '
	--	  		THEN
	--	  			SET V_ERRLOC = 'D514';
	--	        	SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
	--	  			INSERT INTO AC_ITEM    
	--			( ECMS_PROJECT_NUM,    
	--			  BID_PACKAGE_NUM,     
	--			  BUS_PARTNER_ID,      
	--			  AC_ITEM_NUM,         
	--			  AC_ITEM_CAT_CODE,    
	--			  AC_ITEM_TYPE_CODE,   
	--			  AC_ITEM_STATUS_TS,   
	--			  AC_ITEM_STATUS_CD,   
	--			  AC_ITEM_STATUS_BY,   
	--			  AC_ITEM_BP_ID,       
	--			  AC_ITEM_DEFLT_IND,   
	--			  CREATED_BY,          
	--			  CREATED_BY_TS,       
	--			  LAST_MODIFIED_BY,    
	--			  LAST_MODIFIED_TS,    
	--			  AC_ITEM_TITLE )
	--			VALUES                                   
	--			( P_PROJNUM,                           
	--			  P_BIDPKGNUM,                         
	--			  V_PRIME_BPID,                           
	--			  V_GENNED_ITEM_NUM,                   
	--			  V_PARM_CAT,                             
	--			  V_PARM_TYPE,                            
	--			  V_STATUS_TIMESTAMP,
	--			  V_PARM_STATUS ,          
	--			  V_STATUS_USERID ,      
	--			  V_PARM_ITEMBPID,                        
	--			  'Y',                                   
	--			  V_SYSTEM_USERID,                        
	--			  CURRENT_TIMESTAMP,                     
	--			  V_SYSTEM_USERID,                        
	--			  CURRENT_TIMESTAMP,                     
	--			  V_PARM_ITEMTITLE)    ;
		  			
	--	  		END IF;		  
		  
		ELSE
			SET V_FV_BPID = V_PRIME_BPID;    
    
		END IF;
	  
		SET V_PARM_ITEMBPID = V_PRIME_BPID;
		SET V_PARM_CAT = '5';	
		SET V_PARM_TYPE = '310'; 	--	TYPE CODE PYMTADDR
		SET V_ERRLOC = 'D520';
		SELECT GEN_CODE_VALUE                     
		INTO V_GP_GEN_CODE_VALUE                 
		FROM COM_GENERAL_CODE                   
		WHERE GEN_CODE_TYPE = V_PARM_GEN_CODE_TYPE
		  AND GEN_CODE = V_PARM_TYPE    ;  	  	    
		SET V_PARM_ITEMTITLE = V_GP_GEN_CODE_VALUE;
		SET V_ERRLOC = 'D530';
		SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
		
		INSERT INTO AC_ITEM    
		( ECMS_PROJECT_NUM,    
		  BID_PACKAGE_NUM,     
		  BUS_PARTNER_ID,      
		  AC_ITEM_NUM,         
		  AC_ITEM_CAT_CODE,    
		  AC_ITEM_TYPE_CODE,   
		  AC_ITEM_STATUS_TS,   
		  AC_ITEM_STATUS_CD,   
		  AC_ITEM_STATUS_BY,   
		  AC_ITEM_BP_ID,       
		  AC_ITEM_DEFLT_IND,   
		  CREATED_BY,          
		  CREATED_BY_TS,       
		  LAST_MODIFIED_BY,    
		  LAST_MODIFIED_TS,    
		  AC_ITEM_TITLE )
		VALUES                                   
		( P_PROJNUM,                           
		  P_BIDPKGNUM,                         
		  V_PRIME_BPID,                           
		  V_GENNED_ITEM_NUM,                   
		  V_PARM_CAT,                             
		  V_PARM_TYPE,                            
		  V_STATUS_TIMESTAMP,
		  V_PARM_STATUS ,          
		  V_STATUS_USERID ,      
		  V_PARM_ITEMBPID,                        
		  'Y',                                   
		  V_SYSTEM_USERID,                        
		  CURRENT_TIMESTAMP,                     
		  V_SYSTEM_USERID,                        
		  CURRENT_TIMESTAMP,                     
		  V_PARM_ITEMTITLE)    ;
		  
		  
		
		  
		SET V_PARM_STATUS = NULL;  

		SET V_ERRLOC = 'D550';                
		INSERT INTO AC_PYMT_ADDR 
		( ECMS_PROJECT_NUM,      
		  BID_PACKAGE_NUM,       
		  BUS_PARTNER_ID,        
		  AC_ITEM_NUM,           
		  BUS_PARTNER_FID,       
		  VENDOR_NUMBER )        
		VALUES                
		( P_PROJNUM,        
		  P_BIDPKGNUM,      
		  V_PRIME_BPID,        
		  V_GENNED_ITEM_NUM,
		  V_BP_FEIN,           
		  NULL )    ;              
  	

		IF V_PRJ_RAIL_INVOLV_IND = 'Y'		-- RAILROAD INVOLVED
		THEN
			SET V_PARM_ITEMBPID = V_PRIME_BPID;
			SET V_PARM_CAT = '5';
			SET V_PARM_TYPE = '340';	--	TYPE CODE RAILADDR
			SET V_PARM_STATUS = '8';	-- INCOMPLETE STATUS
			SET V_ERRLOC = 'D560';
			SELECT GEN_CODE_VALUE                     
			INTO V_GP_GEN_CODE_VALUE                 
			FROM COM_GENERAL_CODE                   
			WHERE GEN_CODE_TYPE = V_PARM_GEN_CODE_TYPE
			  AND GEN_CODE = V_PARM_TYPE    ;  	  	    
			SET V_PARM_ITEMTITLE = V_GP_GEN_CODE_VALUE;
			
			SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
			SET V_ERRLOC = 'D570';
			INSERT INTO AC_ITEM    
			( ECMS_PROJECT_NUM,    
			  BID_PACKAGE_NUM,     
			  BUS_PARTNER_ID,      
			  AC_ITEM_NUM,         
			  AC_ITEM_CAT_CODE,    
			  AC_ITEM_TYPE_CODE,   
			  AC_ITEM_STATUS_TS,   
			  AC_ITEM_STATUS_CD,   
			  AC_ITEM_STATUS_BY,   
			  AC_ITEM_BP_ID,       
			  AC_ITEM_DEFLT_IND,   
			  CREATED_BY,          
			  CREATED_BY_TS,       
			  LAST_MODIFIED_BY,    
			  LAST_MODIFIED_TS,    
			  AC_ITEM_TITLE )
			VALUES                                   
			( P_PROJNUM,                           
			  P_BIDPKGNUM,                         
			  V_PRIME_BPID,                           
			  V_GENNED_ITEM_NUM,                   
			  V_PARM_CAT,                             
			  V_PARM_TYPE,                            
			  V_STATUS_TIMESTAMP,
			  V_PARM_STATUS ,          
			  V_STATUS_USERID ,      
			  V_PARM_ITEMBPID,                        
			  'Y',                                   
			  V_SYSTEM_USERID,                        
			  CURRENT_TIMESTAMP,                     
			  V_SYSTEM_USERID,                        
			  CURRENT_TIMESTAMP,                     
			  V_PARM_ITEMTITLE)    ;
			  
			IF V_JV1_BPID <> ' '
		  		THEN
		  			SET V_ERRLOC = 'D572';
		        	SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
		  			INSERT INTO AC_ITEM    
				( ECMS_PROJECT_NUM,    
				  BID_PACKAGE_NUM,     
				  BUS_PARTNER_ID,      
				  AC_ITEM_NUM,         
				  AC_ITEM_CAT_CODE,    
				  AC_ITEM_TYPE_CODE,   
				  AC_ITEM_STATUS_TS,   
				  AC_ITEM_STATUS_CD,   
				  AC_ITEM_STATUS_BY,   
				  AC_ITEM_BP_ID,       
				  AC_ITEM_DEFLT_IND,   
				  CREATED_BY,          
				  CREATED_BY_TS,       
				  LAST_MODIFIED_BY,    
				  LAST_MODIFIED_TS,    
				  AC_ITEM_TITLE )
				VALUES                                   
				( P_PROJNUM,                           
				  P_BIDPKGNUM,                         
				  V_PRIME_BPID,                           
				  V_GENNED_ITEM_NUM,                   
				  V_PARM_CAT,                             
				  V_PARM_TYPE,                            
				  V_STATUS_TIMESTAMP,
				  V_PARM_STATUS ,          
				  V_STATUS_USERID ,      
				  V_PARM_ITEMBPID,                        
				  'Y',                                   
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_PARM_ITEMTITLE)    ;
		  			
		  		END IF;	
			  
			  	IF V_JV2_BPID <> ' '
		  		THEN
		  			SET V_ERRLOC = 'D574';
		        	SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
		  			INSERT INTO AC_ITEM    
				( ECMS_PROJECT_NUM,    
				  BID_PACKAGE_NUM,     
				  BUS_PARTNER_ID,      
				  AC_ITEM_NUM,         
				  AC_ITEM_CAT_CODE,    
				  AC_ITEM_TYPE_CODE,   
				  AC_ITEM_STATUS_TS,   
				  AC_ITEM_STATUS_CD,   
				  AC_ITEM_STATUS_BY,   
				  AC_ITEM_BP_ID,       
				  AC_ITEM_DEFLT_IND,   
				  CREATED_BY,          
				  CREATED_BY_TS,       
				  LAST_MODIFIED_BY,    
				  LAST_MODIFIED_TS,    
				  AC_ITEM_TITLE )
				VALUES                                   
				( P_PROJNUM,                           
				  P_BIDPKGNUM,                         
				  V_PRIME_BPID,                           
				  V_GENNED_ITEM_NUM,                   
				  V_PARM_CAT,                             
				  V_PARM_TYPE,                            
				  V_STATUS_TIMESTAMP,
				  V_PARM_STATUS ,          
				  V_STATUS_USERID ,      
				  V_PARM_ITEMBPID,                        
				  'Y',                                   
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_PARM_ITEMTITLE)    ;
		  			
		  		END IF;	  
			  
			SET V_PARM_STATUS = NULL;  
			
			SET V_ERRLOC = 'D580';
			INSERT INTO AC_RAIL_INS_ADDR 
			( ECMS_PROJECT_NUM,          
		  		BID_PACKAGE_NUM,           
		  		BUS_PARTNER_ID,            
		  		AC_ITEM_NUM,               
		  		ADDRESS_NAME )    
		  	VALUES                
				( P_PROJNUM,        
		  		P_BIDPKGNUM,      
		  		V_PRIME_BPID,        
		  		V_GENNED_ITEM_NUM,
		  		V_PARM_ITEMTITLE ) ;  	         
		END IF;
	  
		-- LOCAL PROJECT OR EME IMMEDNEED

		IF V_PRJ_PROJ_TYPE = '03'  OR
		   V_PRJ_PROJ_TYPE = '04'
		THEN
			SET V_PARM_ITEMBPID = V_PRIME_BPID;
			SET V_PARM_CAT = '3';	-- POSTAWARD SUBTYPE
			SET V_PARM_TYPE = '345';	-- TYPE CODE PAPER CONTRACT
			SET V_ERRLOC = 'D585';
			SELECT GEN_CODE_VALUE                     
			INTO V_GP_GEN_CODE_VALUE                 
			FROM COM_GENERAL_CODE                   
			WHERE GEN_CODE_TYPE = V_PARM_GEN_CODE_TYPE
			  AND GEN_CODE = V_PARM_TYPE    ;  	  	    
			SET V_PARM_ITEMTITLE = V_GP_GEN_CODE_VALUE;
			
			SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
			SET V_ERRLOC = 'D590';
			INSERT INTO AC_ITEM    
			( ECMS_PROJECT_NUM,    
			  BID_PACKAGE_NUM,     
			  BUS_PARTNER_ID,      
			  AC_ITEM_NUM,         
			  AC_ITEM_CAT_CODE,    
			  AC_ITEM_TYPE_CODE,   
			  AC_ITEM_STATUS_TS,   
			  AC_ITEM_STATUS_CD,   
			  AC_ITEM_STATUS_BY,   
			  AC_ITEM_BP_ID,       
			  AC_ITEM_DEFLT_IND,   
			  CREATED_BY,          
			  CREATED_BY_TS,       
			  LAST_MODIFIED_BY,    
			  LAST_MODIFIED_TS,    
			  AC_ITEM_TITLE )
			VALUES                                   
			( P_PROJNUM,                           
			  P_BIDPKGNUM,                         
			  V_PRIME_BPID,                           
			  V_GENNED_ITEM_NUM,                   
			  V_PARM_CAT,                             
			  V_PARM_TYPE,                            
			  V_STATUS_TIMESTAMP,
			  V_PARM_STATUS ,          
			  V_STATUS_USERID ,      
			  V_PARM_ITEMBPID,                        
			  'Y',                                   
			  V_SYSTEM_USERID,                        
			  CURRENT_TIMESTAMP,                     
			  V_SYSTEM_USERID,                        
			  CURRENT_TIMESTAMP,                     
			  V_PARM_ITEMTITLE)    ;
			  
			IF V_JV1_BPID <> ' '
	  		THEN
	  			SET V_ERRLOC = 'D592';
	        	SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
	  			INSERT INTO AC_ITEM    
			( ECMS_PROJECT_NUM,    
			  BID_PACKAGE_NUM,     
			  BUS_PARTNER_ID,      
			  AC_ITEM_NUM,         
			  AC_ITEM_CAT_CODE,    
			  AC_ITEM_TYPE_CODE,   
			  AC_ITEM_STATUS_TS,   
			  AC_ITEM_STATUS_CD,   
			  AC_ITEM_STATUS_BY,   
			  AC_ITEM_BP_ID,       
			  AC_ITEM_DEFLT_IND,   
			  CREATED_BY,          
			  CREATED_BY_TS,       
			  LAST_MODIFIED_BY,    
			  LAST_MODIFIED_TS,    
			  AC_ITEM_TITLE )
			VALUES                                   
			( P_PROJNUM,                           
			  P_BIDPKGNUM,                         
			  V_PRIME_BPID,                           
			  V_GENNED_ITEM_NUM,                   
			  V_PARM_CAT,                             
			  V_PARM_TYPE,                            
			  V_STATUS_TIMESTAMP,
			  V_PARM_STATUS ,          
			  V_STATUS_USERID ,      
			  V_PARM_ITEMBPID,                        
			  'Y',                                   
			  V_SYSTEM_USERID,                        
			  CURRENT_TIMESTAMP,                     
			  V_SYSTEM_USERID,                        
			  CURRENT_TIMESTAMP,                     
			  V_PARM_ITEMTITLE)    ;
	  			
	  		END IF;	
			  
		  	IF V_JV2_BPID <> ' '
	  		THEN
	  			SET V_ERRLOC = 'D594';
	        	SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
	  			INSERT INTO AC_ITEM    
			( ECMS_PROJECT_NUM,    
			  BID_PACKAGE_NUM,     
			  BUS_PARTNER_ID,      
			  AC_ITEM_NUM,         
			  AC_ITEM_CAT_CODE,    
			  AC_ITEM_TYPE_CODE,   
			  AC_ITEM_STATUS_TS,   
			  AC_ITEM_STATUS_CD,   
			  AC_ITEM_STATUS_BY,   
			  AC_ITEM_BP_ID,       
			  AC_ITEM_DEFLT_IND,   
			  CREATED_BY,          
			  CREATED_BY_TS,       
			  LAST_MODIFIED_BY,    
			  LAST_MODIFIED_TS,    
			  AC_ITEM_TITLE )
			VALUES                                   
			( P_PROJNUM,                           
			  P_BIDPKGNUM,                         
			  V_PRIME_BPID,                           
			  V_GENNED_ITEM_NUM,                   
			  V_PARM_CAT,                             
			  V_PARM_TYPE,                            
			  V_STATUS_TIMESTAMP,
			  V_PARM_STATUS ,          
			  V_STATUS_USERID ,      
			  V_PARM_ITEMBPID,                        
			  'Y',                                   
			  V_SYSTEM_USERID,                        
			  CURRENT_TIMESTAMP,                     
			  V_SYSTEM_USERID,                        
			  CURRENT_TIMESTAMP,                     
			  V_PARM_ITEMTITLE)    ;
	  			
	  		END IF;	  
		
		END IF;	 

		SET V_PARM_STATUS = NULL; 

		--  EMERGENCY PARTIAL ECMS PROJECT --
		IF V_PRJ_PROJ_TYPE = '04'  		    
		THEN
			SET V_PARM_ITEMBPID = V_PRIME_BPID;
			SET V_PARM_CAT = '2';	-- PREAWARD SUBTYPE
			SET V_PARM_TYPE = '275';	-- TYPE CODE PAPER CONCUR
			SET V_ERRLOC = 'D600';
			SELECT GEN_CODE_VALUE                     
			INTO V_GP_GEN_CODE_VALUE                 
			FROM COM_GENERAL_CODE                   
			WHERE GEN_CODE_TYPE = V_PARM_GEN_CODE_TYPE
			  AND GEN_CODE = V_PARM_TYPE    ;  	  	    
			SET V_PARM_ITEMTITLE = V_GP_GEN_CODE_VALUE;
			
			SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
			SET V_ERRLOC = 'D610';
			INSERT INTO AC_ITEM    
			( ECMS_PROJECT_NUM,    
			  BID_PACKAGE_NUM,     
			  BUS_PARTNER_ID,      
			  AC_ITEM_NUM,         
			  AC_ITEM_CAT_CODE,    
			  AC_ITEM_TYPE_CODE,   
			  AC_ITEM_STATUS_TS,   
			  AC_ITEM_STATUS_CD,   
			  AC_ITEM_STATUS_BY,   
			  AC_ITEM_BP_ID,       
			  AC_ITEM_DEFLT_IND,   
			  CREATED_BY,          
			  CREATED_BY_TS,       
			  LAST_MODIFIED_BY,    
			  LAST_MODIFIED_TS,    
			  AC_ITEM_TITLE )
			VALUES                                   
			( P_PROJNUM,                           
			  P_BIDPKGNUM,                         
			  V_PRIME_BPID,                           
			  V_GENNED_ITEM_NUM,                   
			  V_PARM_CAT,                             
			  V_PARM_TYPE,                            
			  V_STATUS_TIMESTAMP,
			  V_PARM_STATUS ,          
			  V_STATUS_USERID ,      
			  V_PARM_ITEMBPID,                        
			  'Y',                                   
			  V_SYSTEM_USERID,                        
			  CURRENT_TIMESTAMP,                     
			  V_SYSTEM_USERID,                        
			  CURRENT_TIMESTAMP,                     
			  V_PARM_ITEMTITLE)    ;
			  
			IF V_JV1_BPID <> ' '
	  		THEN
	  			SET V_ERRLOC = 'D612';
	        	SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
	  			INSERT INTO AC_ITEM    
			( ECMS_PROJECT_NUM,    
			  BID_PACKAGE_NUM,     
			  BUS_PARTNER_ID,      
			  AC_ITEM_NUM,         
			  AC_ITEM_CAT_CODE,    
			  AC_ITEM_TYPE_CODE,   
			  AC_ITEM_STATUS_TS,   
			  AC_ITEM_STATUS_CD,   
			  AC_ITEM_STATUS_BY,   
			  AC_ITEM_BP_ID,       
			  AC_ITEM_DEFLT_IND,   
			  CREATED_BY,          
			  CREATED_BY_TS,       
			  LAST_MODIFIED_BY,    
			  LAST_MODIFIED_TS,    
			  AC_ITEM_TITLE )
			VALUES                                   
			( P_PROJNUM,                           
			  P_BIDPKGNUM,                         
			  V_PRIME_BPID,                           
			  V_GENNED_ITEM_NUM,                   
			  V_PARM_CAT,                             
			  V_PARM_TYPE,                            
			  V_STATUS_TIMESTAMP,
			  V_PARM_STATUS ,          
			  V_STATUS_USERID ,      
			  V_PARM_ITEMBPID,                        
			  'Y',                                   
			  V_SYSTEM_USERID,                        
			  CURRENT_TIMESTAMP,                     
			  V_SYSTEM_USERID,                        
			  CURRENT_TIMESTAMP,                     
			  V_PARM_ITEMTITLE)    ;
	  			
	  		END IF;	
			  
		  	IF V_JV2_BPID <> ' '
	  		THEN
	  			SET V_ERRLOC = 'D614';
	        	SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
	  			INSERT INTO AC_ITEM    
			( ECMS_PROJECT_NUM,    
			  BID_PACKAGE_NUM,     
			  BUS_PARTNER_ID,      
			  AC_ITEM_NUM,         
			  AC_ITEM_CAT_CODE,    
			  AC_ITEM_TYPE_CODE,   
			  AC_ITEM_STATUS_TS,   
			  AC_ITEM_STATUS_CD,   
			  AC_ITEM_STATUS_BY,   
			  AC_ITEM_BP_ID,       
			  AC_ITEM_DEFLT_IND,   
			  CREATED_BY,          
			  CREATED_BY_TS,       
			  LAST_MODIFIED_BY,    
			  LAST_MODIFIED_TS,    
			  AC_ITEM_TITLE )
			VALUES                                   
			( P_PROJNUM,                           
			  P_BIDPKGNUM,                         
			  V_PRIME_BPID,                           
			  V_GENNED_ITEM_NUM,                   
			  V_PARM_CAT,                             
			  V_PARM_TYPE,                            
			  V_STATUS_TIMESTAMP,
			  V_PARM_STATUS ,          
			  V_STATUS_USERID ,      
			  V_PARM_ITEMBPID,                        
			  'Y',                                   
			  V_SYSTEM_USERID,                        
			  CURRENT_TIMESTAMP,                     
			  V_SYSTEM_USERID,                        
			  CURRENT_TIMESTAMP,                     
			  V_PARM_ITEMTITLE)    ;
	  			
	  		END IF;	  
			  
		
		END IF; 	 

		SET V_PARM_STATUS = NULL;

		-- MANDATORY PRE-BID 

		IF V_PREBID_STATUS = '1'	-- MANDATORY PREBID  		    
		THEN
			SET V_PARM_ITEMBPID = V_PRIME_BPID;
			SET V_PARM_CAT = '2';	-- PREAWARD SUBTYPE
			SET V_PARM_TYPE = '250';	-- TYPE CODE PREBID
			SET V_ERRLOC = 'D620';
			SELECT GEN_CODE_VALUE                     
			INTO V_GP_GEN_CODE_VALUE                 
			FROM COM_GENERAL_CODE                   
			WHERE GEN_CODE_TYPE = V_PARM_GEN_CODE_TYPE
			  AND GEN_CODE = V_PARM_TYPE    ;  	  	    
			SET V_PARM_ITEMTITLE = V_GP_GEN_CODE_VALUE;
			
			SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
			SET V_ERRLOC = 'D630';
			INSERT INTO AC_ITEM    
			( ECMS_PROJECT_NUM,    
			  BID_PACKAGE_NUM,     
			  BUS_PARTNER_ID,      
			  AC_ITEM_NUM,         
			  AC_ITEM_CAT_CODE,    
			  AC_ITEM_TYPE_CODE,   
			  AC_ITEM_STATUS_TS,   
			  AC_ITEM_STATUS_CD,   
			  AC_ITEM_STATUS_BY,   
			  AC_ITEM_BP_ID,       
			  AC_ITEM_DEFLT_IND,   
			  CREATED_BY,          
			  CREATED_BY_TS,       
			  LAST_MODIFIED_BY,    
			  LAST_MODIFIED_TS,    
			  AC_ITEM_TITLE )
			VALUES                                   
			( P_PROJNUM,                           
			  P_BIDPKGNUM,                         
			  V_PRIME_BPID,                           
			  V_GENNED_ITEM_NUM,                   
			  V_PARM_CAT,                             
			  V_PARM_TYPE,                            
			  V_STATUS_TIMESTAMP,
			  V_PARM_STATUS ,          
			  V_STATUS_USERID ,      
			  V_PARM_ITEMBPID,                        
			  'Y',                                   
			  V_SYSTEM_USERID,                        
			  CURRENT_TIMESTAMP,                     
			  V_SYSTEM_USERID,                        
			  CURRENT_TIMESTAMP,                     
			  V_PARM_ITEMTITLE)    ;
			  
			  
			
			
		END IF;		  

		SET V_PARM_STATUS = NULL;
	  
		-- FEDERAL DEBARMENT CHECK --

		SET V_PARM_CAT = '2';	-- PREAWARD SUBTYPE

		
		
   		--SET V_PARM_ITEMBPID = V_PC_BUS_PARTNER_ID; -- COMING FROM PRIME_CSR
   		SET V_PARM_ITEMBPID = V_PRIME_BPID;
   		SET V_PARM_TYPE = '240';	-- TYPE CODE CRPCHECK
   		SET V_ERRLOC = 'D650';
   		SELECT GEN_CODE_VALUE                     
		INTO V_GP_GEN_CODE_VALUE                 
		FROM COM_GENERAL_CODE                   
		WHERE GEN_CODE_TYPE = V_PARM_GEN_CODE_TYPE
		  AND GEN_CODE = V_PARM_TYPE    ;  	  	    
		SET V_PARM_ITEMTITLE = V_GP_GEN_CODE_VALUE;
			
		SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
		SET V_ERRLOC = 'D660';
		INSERT INTO AC_ITEM    
		( ECMS_PROJECT_NUM,    
		  BID_PACKAGE_NUM,     
		  BUS_PARTNER_ID,      
		  AC_ITEM_NUM,         
		  AC_ITEM_CAT_CODE,    
		  AC_ITEM_TYPE_CODE,   
		  AC_ITEM_STATUS_TS,   
		  AC_ITEM_STATUS_CD,   
		  AC_ITEM_STATUS_BY,   
		  AC_ITEM_BP_ID,       
		  AC_ITEM_DEFLT_IND,   
		  CREATED_BY,          
		  CREATED_BY_TS,       
		  LAST_MODIFIED_BY,    
		  LAST_MODIFIED_TS,    
		  AC_ITEM_TITLE )
		VALUES                                   
		( P_PROJNUM,                           
		  P_BIDPKGNUM,                         
		  V_PRIME_BPID,                           
		  V_GENNED_ITEM_NUM,                   
		  V_PARM_CAT,                             
		  V_PARM_TYPE,                            
		  V_STATUS_TIMESTAMP,
		  V_PARM_STATUS ,          
		  V_STATUS_USERID ,      
		  V_PARM_ITEMBPID,                        
		  'Y',                                   
		  V_SYSTEM_USERID,                        
		  CURRENT_TIMESTAMP,                     
		  V_SYSTEM_USERID,                        
		  CURRENT_TIMESTAMP,                     
		  V_PARM_ITEMTITLE)    ;
		  
		IF V_JV1_BPID <> ' '
  		THEN
  			SET V_PARM_ITEMBPID = V_JV1_BPID;
  			SET V_ERRLOC = 'D662';
        	SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
  			INSERT INTO AC_ITEM    
		( ECMS_PROJECT_NUM,    
		  BID_PACKAGE_NUM,     
		  BUS_PARTNER_ID,      
		  AC_ITEM_NUM,         
		  AC_ITEM_CAT_CODE,    
		  AC_ITEM_TYPE_CODE,   
		  AC_ITEM_STATUS_TS,   
		  AC_ITEM_STATUS_CD,   
		  AC_ITEM_STATUS_BY,   
		  AC_ITEM_BP_ID,       
		  AC_ITEM_DEFLT_IND,   
		  CREATED_BY,          
		  CREATED_BY_TS,       
		  LAST_MODIFIED_BY,    
		  LAST_MODIFIED_TS,    
		  AC_ITEM_TITLE )
		VALUES                                   
		( P_PROJNUM,                           
		  P_BIDPKGNUM,                         
		  V_PRIME_BPID,                           
		  V_GENNED_ITEM_NUM,                   
		  V_PARM_CAT,                             
		  V_PARM_TYPE,                            
		  V_STATUS_TIMESTAMP,
		  V_PARM_STATUS ,          
		  V_STATUS_USERID ,      
		  V_PARM_ITEMBPID,                        
		  'Y',                                   
		  V_SYSTEM_USERID,                        
		  CURRENT_TIMESTAMP,                     
		  V_SYSTEM_USERID,                        
		  CURRENT_TIMESTAMP,                     
		  V_PARM_ITEMTITLE)    ;
  			
  		END IF;	
			  
	  	IF V_JV2_BPID <> ' '
  		THEN
  			SET V_PARM_ITEMBPID = V_JV2_BPID;
  			SET V_ERRLOC = 'D664';
        	SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
  			INSERT INTO AC_ITEM    
		( ECMS_PROJECT_NUM,    
		  BID_PACKAGE_NUM,     
		  BUS_PARTNER_ID,      
		  AC_ITEM_NUM,         
		  AC_ITEM_CAT_CODE,    
		  AC_ITEM_TYPE_CODE,   
		  AC_ITEM_STATUS_TS,   
		  AC_ITEM_STATUS_CD,   
		  AC_ITEM_STATUS_BY,   
		  AC_ITEM_BP_ID,       
		  AC_ITEM_DEFLT_IND,   
		  CREATED_BY,          
		  CREATED_BY_TS,       
		  LAST_MODIFIED_BY,    
		  LAST_MODIFIED_TS,    
		  AC_ITEM_TITLE )
		VALUES                                   
		( P_PROJNUM,                           
		  P_BIDPKGNUM,                         
		  V_PRIME_BPID,                           
		  V_GENNED_ITEM_NUM,                   
		  V_PARM_CAT,                             
		  V_PARM_TYPE,                            
		  V_STATUS_TIMESTAMP,
		  V_PARM_STATUS ,          
		  V_STATUS_USERID ,      
		  V_PARM_ITEMBPID,                        
		  'Y',                                   
		  V_SYSTEM_USERID,                        
		  CURRENT_TIMESTAMP,                     
		  V_SYSTEM_USERID,                        
		  CURRENT_TIMESTAMP,                     
		  V_PARM_ITEMTITLE)    ;
  			
  		END IF;	  
		  
				  
		SET V_PARM_STATUS = NULL;  
   		
   		SET V_PARM_TYPE = '230';	-- TYPE CODE FEDDEBAR
   		SET V_PARM_ITEMBPID = V_PRIME_BPID;
   		SET V_ERRLOC = 'D670';
   		SELECT GEN_CODE_VALUE                     
		INTO V_GP_GEN_CODE_VALUE                 
		FROM COM_GENERAL_CODE                   
		WHERE GEN_CODE_TYPE = V_PARM_GEN_CODE_TYPE
		  AND GEN_CODE = V_PARM_TYPE    ;  	  	    
		SET V_PARM_ITEMTITLE = V_GP_GEN_CODE_VALUE;
	
		SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
		SET V_ERRLOC = 'D680';
		INSERT INTO AC_ITEM    
		( ECMS_PROJECT_NUM,    
		  BID_PACKAGE_NUM,     
		  BUS_PARTNER_ID,      
		  AC_ITEM_NUM,         
		  AC_ITEM_CAT_CODE,    
		  AC_ITEM_TYPE_CODE,   
		  AC_ITEM_STATUS_TS,   
		  AC_ITEM_STATUS_CD,   
		  AC_ITEM_STATUS_BY,   
		  AC_ITEM_BP_ID,       
		  AC_ITEM_DEFLT_IND,   
		  CREATED_BY,          
		  CREATED_BY_TS,       
		  LAST_MODIFIED_BY,    
		  LAST_MODIFIED_TS,    
		  AC_ITEM_TITLE )
		VALUES                                   
		( P_PROJNUM,                           
		  P_BIDPKGNUM,                         
		  V_PRIME_BPID,                           
		  V_GENNED_ITEM_NUM,                   
		  V_PARM_CAT,                             
		  V_PARM_TYPE,                            
		  V_STATUS_TIMESTAMP,
		  V_PARM_STATUS ,          
		  V_STATUS_USERID ,      
		  V_PARM_ITEMBPID,                        
		  'Y',                                   
		  V_SYSTEM_USERID,                        
		  CURRENT_TIMESTAMP,                     
		  V_SYSTEM_USERID,                        
		  CURRENT_TIMESTAMP,                     
		  V_PARM_ITEMTITLE)    ;
		   		
		
		IF V_JV1_BPID <> ' '
  		THEN
  			SET V_PARM_ITEMBPID = V_JV1_BPID;
  			SET V_ERRLOC = 'D682';
        	SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
  			INSERT INTO AC_ITEM    
		( ECMS_PROJECT_NUM,    
		  BID_PACKAGE_NUM,     
		  BUS_PARTNER_ID,      
		  AC_ITEM_NUM,         
		  AC_ITEM_CAT_CODE,    
		  AC_ITEM_TYPE_CODE,   
		  AC_ITEM_STATUS_TS,   
		  AC_ITEM_STATUS_CD,   
		  AC_ITEM_STATUS_BY,   
		  AC_ITEM_BP_ID,       
		  AC_ITEM_DEFLT_IND,   
		  CREATED_BY,          
		  CREATED_BY_TS,       
		  LAST_MODIFIED_BY,    
		  LAST_MODIFIED_TS,    
		  AC_ITEM_TITLE )
		VALUES                                   
		( P_PROJNUM,                           
		  P_BIDPKGNUM,                         
		  V_PRIME_BPID,                           
		  V_GENNED_ITEM_NUM,                   
		  V_PARM_CAT,                             
		  V_PARM_TYPE,                            
		  V_STATUS_TIMESTAMP,
		  V_PARM_STATUS ,          
		  V_STATUS_USERID ,      
		  V_PARM_ITEMBPID,                        
		  'Y',                                   
		  V_SYSTEM_USERID,                        
		  CURRENT_TIMESTAMP,                     
		  V_SYSTEM_USERID,                        
		  CURRENT_TIMESTAMP,                     
		  V_PARM_ITEMTITLE)    ;
  			
  		END IF;	
			  
	  	IF V_JV2_BPID <> ' '
  		THEN
  			SET V_PARM_ITEMBPID = V_JV2_BPID;
  			SET V_ERRLOC = 'D684';
        	SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
  			INSERT INTO AC_ITEM    
		( ECMS_PROJECT_NUM,    
		  BID_PACKAGE_NUM,     
		  BUS_PARTNER_ID,      
		  AC_ITEM_NUM,         
		  AC_ITEM_CAT_CODE,    
		  AC_ITEM_TYPE_CODE,   
		  AC_ITEM_STATUS_TS,   
		  AC_ITEM_STATUS_CD,   
		  AC_ITEM_STATUS_BY,   
		  AC_ITEM_BP_ID,       
		  AC_ITEM_DEFLT_IND,   
		  CREATED_BY,          
		  CREATED_BY_TS,       
		  LAST_MODIFIED_BY,    
		  LAST_MODIFIED_TS,    
		  AC_ITEM_TITLE )
		VALUES                                   
		( P_PROJNUM,                           
		  P_BIDPKGNUM,                         
		  V_PRIME_BPID,                           
		  V_GENNED_ITEM_NUM,                   
		  V_PARM_CAT,                             
		  V_PARM_TYPE,                            
		  V_STATUS_TIMESTAMP,
		  V_PARM_STATUS ,          
		  V_STATUS_USERID ,      
		  V_PARM_ITEMBPID,                        
		  'Y',                                   
		  V_SYSTEM_USERID,                        
		  CURRENT_TIMESTAMP,                     
		  V_SYSTEM_USERID,                        
		  CURRENT_TIMESTAMP,                     
		  V_PARM_ITEMTITLE)    ;
  			
  		END IF;	   	
		   	
	   	SET V_PARM_STATUS = NULL;
   	
 
	  	SET V_PARM_ITEMBPID = V_PRIME_BPID;
		-- INSERT ROW INTO AC BID JUST AND DO NOT INSERT IF EMERGENCY PARTIAL ECMS PROJECT
		IF V_PRJ_PROJ_TYPE <> '04'	-- NOT EMER IMMEDNEED
		THEN
			SET V_PARM_ITEMBPID = V_PRIME_BPID;
			SET V_PARM_CAT = '1';	-- AUTOMATIC SUBTYPE
			SET V_PARM_TYPE = '120';	-- TYPE CODE BIDJUST
			SET V_ERRLOC = 'D690';
			SELECT GEN_CODE_VALUE                     
				INTO V_GP_GEN_CODE_VALUE                 
				FROM COM_GENERAL_CODE                   
				WHERE GEN_CODE_TYPE = V_PARM_GEN_CODE_TYPE
				  AND GEN_CODE = V_PARM_TYPE    ;  	  	    
				SET V_PARM_ITEMTITLE = V_GP_GEN_CODE_VALUE;
			
				SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
				SET V_ERRLOC = 'D700';
				INSERT INTO AC_ITEM    
				( ECMS_PROJECT_NUM,    
				  BID_PACKAGE_NUM,     
				  BUS_PARTNER_ID,      
				  AC_ITEM_NUM,         
				  AC_ITEM_CAT_CODE,    
				  AC_ITEM_TYPE_CODE,   
				  AC_ITEM_STATUS_TS,   
				  AC_ITEM_STATUS_CD,   
				  AC_ITEM_STATUS_BY,   
				  AC_ITEM_BP_ID,       
				  AC_ITEM_DEFLT_IND,   
				  CREATED_BY,          
				  CREATED_BY_TS,       
				  LAST_MODIFIED_BY,    
				  LAST_MODIFIED_TS,    
				  AC_ITEM_TITLE )
				VALUES                                   
				( P_PROJNUM,                           
				  P_BIDPKGNUM,                         
				  V_PRIME_BPID,                           
				  V_GENNED_ITEM_NUM,                   
				  V_PARM_CAT,                             
				  V_PARM_TYPE,                            
				  V_STATUS_TIMESTAMP,
				  V_PARM_STATUS ,          
				  V_STATUS_USERID ,      
				  V_PARM_ITEMBPID,                        
				  'Y',                                   
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_PARM_ITEMTITLE)    ;
				  
				
				  
				  
				SET V_PARM_STATUS = NULL;  
		
				SET V_ERRLOC = 'D710';
				INSERT INTO AC_BID_JUST
				( ECMS_PROJECT_NUM,    
				  BID_PACKAGE_NUM,     
				  BUS_PARTNER_ID,      
				  AC_ITEM_NUM )        
				VALUES                 
				( P_PROJNUM,         
				  P_BIDPKGNUM,       
				  V_PRIME_BPID,         
				  V_GENNED_ITEM_NUM );
		
		END IF;
	  

		-- INSERT ROW INTO THE CHECKLIST ITEM TABLE --
		SET V_PARM_ITEMBPID = V_PRIME_BPID;
		SET V_PARM_CAT = '2';	-- PREAWARD SUBTYPE
		SET V_PARM_TYPE = '125';	-- TYPE CODE PWEV
		SET V_ERRLOC = 'D720';
		SELECT GEN_CODE_VALUE                     
				INTO V_GP_GEN_CODE_VALUE                 
				FROM COM_GENERAL_CODE                   
				WHERE GEN_CODE_TYPE = V_PARM_GEN_CODE_TYPE
				  AND GEN_CODE = V_PARM_TYPE    ;  	  	    
				SET V_PARM_ITEMTITLE = V_GP_GEN_CODE_VALUE;
			
				SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
				SET V_ERRLOC = 'D730';
				INSERT INTO AC_ITEM    
				( ECMS_PROJECT_NUM,    
				  BID_PACKAGE_NUM,     
				  BUS_PARTNER_ID,      
				  AC_ITEM_NUM,         
				  AC_ITEM_CAT_CODE,    
				  AC_ITEM_TYPE_CODE,   
				  AC_ITEM_STATUS_TS,   
				  AC_ITEM_STATUS_CD,   
				  AC_ITEM_STATUS_BY,   
				  AC_ITEM_BP_ID,       
				  AC_ITEM_DEFLT_IND,   
				  CREATED_BY,          
				  CREATED_BY_TS,       
				  LAST_MODIFIED_BY,    
				  LAST_MODIFIED_TS,    
				  AC_ITEM_TITLE )
				VALUES                                   
				( P_PROJNUM,                           
				  P_BIDPKGNUM,                         
				  V_PRIME_BPID,                           
				  V_GENNED_ITEM_NUM,                   
				  V_PARM_CAT,                             
				  V_PARM_TYPE,                            
				  V_STATUS_TIMESTAMP,
				  V_PARM_STATUS ,          
				  V_STATUS_USERID ,      
				  V_PARM_ITEMBPID,                        
				  'Y',                                   
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_SYSTEM_USERID,                        
				  CURRENT_TIMESTAMP,                     
				  V_PARM_ITEMTITLE)    ;
				  
				  
				
				  
				SET V_PARM_STATUS = NULL; 
				
	END IF;		 
		
END WHILE;

OPEN SINGLE_PARM_CURSOR;	  

 
 
END P1
