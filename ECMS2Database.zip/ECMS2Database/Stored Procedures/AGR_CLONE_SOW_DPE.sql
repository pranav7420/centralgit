CREATE PROCEDURE ECMSXADM.AGR_CLONE_SOW_DPE (
    IN PIN_FromAgr CHAR(6),
    IN PIN_ToAgr CHAR(6),
    IN PIN_UserName CHAR(80),
   OUT POUT_TableAction CHAR(40),
   OUT POUT_RowCount INTEGER,
   OUT POUT_SQLSTATE CHAR(5),
   OUT POUT_SQLCode INTEGER
    )
	
----------------------------------------------------------------------- 
-- DESCRIPTION: This program copies the origional Scope of Work (SOW)
--              and Department Estimate (DPE/CST)
--              from one Agreement into another [Clone]
--              It is called from ECMS   
--              Created for CQ2709 on 05/15/14 by B.Russell
----------------------------------------------------------------------- 
--   PROCEDURE: AGR_CLONE_SOW_DEP
--        TYPE: DB2 NATIVE SQL PROCEDURE                               
--      AUTHOR: Bruce Russell                                           
--        DATE: 05/01/2014
--                                                                         
--       INPUT: AGR[from]; AGR[to]; User Name                    
--                                                                        
--     OUTPUTS: Table-Name; Row-Count; SQL Return-Code; SQL State
--
-----------------------------------------------------------------------    

	LANGUAGE SQL
	QUALIFIER ECMSXADM
	COMMIT ON RETURN YES
	PACKAGE OWNER HWYDEV
	ISOLATION LEVEL CS
	WLM ENVIRONMENT FOR DEBUG MODE WLMENV1
	ALLOW DEBUG MODE

P1: BEGIN

	-- SQL results codes
	DECLARE SQLCODE INTEGER DEFAULT 0;      
	DECLARE SQLSTATE CHAR(5) DEFAULT '00000';
	
	-- Table Key Constants
    DECLARE v_SowId INTEGER DEFAULT 1; 
    DECLARE v_CstEstId INTEGER DEFAULT 1; 
    DECLARE v_VersionId INTEGER DEFAULT 0; 
    DECLARE v_WorkflowId INTEGER DEFAULT 0;     
      
    -- Define SOW ROW Counts.
    DECLARE v_SOWRowCount1 INTEGER DEFAULT 0; -- SOW_SCOPE_OF_WORK
    DECLARE v_SOWRowCount2 INTEGER DEFAULT 0; -- SOW_DETAIL
    DECLARE v_SOWRowCount3 INTEGER DEFAULT 0; -- SOW_MAIN_TASK
    DECLARE v_SOWRowCount4 INTEGER DEFAULT 0; -- SOW_TASK_OBJECTIVE
    DECLARE v_SOWRowCount5 INTEGER DEFAULT 0; -- SOW_TASK_SCOPE
    DECLARE v_SOWRowCount6 INTEGER DEFAULT 0; -- SOW_WBS_NUMBER
    DECLARE v_SOWRowCount7 INTEGER DEFAULT 0; -- SOW_DETAIL_TASK
    
    -- Define DPE ROW Counts.
    DECLARE v_CSTRowCount01 INTEGER DEFAULT 0; -- CST_COST_ESTIMATE
    DECLARE v_CSTRowCount02 INTEGER DEFAULT 0; -- CST_DETAIL
    DECLARE v_CSTRowCount03 INTEGER DEFAULT 0; -- CST_COST_FACTOR 
    DECLARE v_CSTRowCount04 INTEGER DEFAULT 0; -- CST_ESCALATION
    DECLARE v_CSTRowCount05 INTEGER DEFAULT 0; -- CST_LABOR_TASK
    DECLARE v_CSTRowCount06 INTEGER DEFAULT 0; -- CST_OTHER_COST
    DECLARE v_CSTRowCount07 INTEGER DEFAULT 0; -- CST_LABOR_TASK_CLASSIFICATION_RATE
    DECLARE v_CSTRowCount08 INTEGER DEFAULT 0; -- CST_UNIT_OF_WORK
    DECLARE v_CSTRowCount09 INTEGER DEFAULT 0; -- CST_LABOR_TASK_UNITS_OF_WORK
    DECLARE v_CSTRowCount10 INTEGER DEFAULT 0; -- CST_OTHER_COST_UNITS_OF_WORK
    
    -- Exit on all errors 
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	
	-- Initialize Return Parameters
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;
	Set POUT_RowCount = -1;		
	
	
    -----------------------------------------------
    -----------------------------------------------
    -- Clone SCOPE OF WORK data (SOW)
    -----------------------------------------------
    -----------------------------------------------
    
    
    -----------------------------------------------
    -- Clone data for SOW_SCOPE_OF_WORK.
    -----------------------------------------------
	Set POUT_TableAction = 'Failure: SOW_SCOPE_OF_WORK Insert'; 
	
    SELECT count(*) into v_SOWRowCount1
	  FROM Final Table 
	   	   ( 
	INSERT INTO SOW_SCOPE_OF_WORK (
		   AGR, 
	   	   SOW_ID, 
	   	   SOW_STATUS_CODE, 
	   	   SOW_TYPE_CODE, 
	   	   SUPPL_ID, 
--	   	   WORKFLOW_ID, -- Set in next step
	   	   SOW_DESC, 
	   	   EXECUTIVE_SUMMARY_REQUIRED_IND, 
--	   	   FORUM_POST_ID, -- null
	   	   CREATED_BY, 
	   	   CREATED_BY_TS, 
	   	   LAST_MODIFIED_BY, 
	   	   LAST_MODIFIED_TS
           )
    SELECT PIN_ToAgr as AGR,
	   	   SOW_ID,
	   	   '01' as SOW_STATUS_CODE,
	   	   SOW_TYPE_CODE,
	   	   SUPPL_ID,
--	   	   0 as WORKFLOW_ID,  -- Set in next step
	   	   SOW_DESC,
--	   	   0 as FORUM_POST_ID, -- null
	   	   EXECUTIVE_SUMMARY_REQUIRED_IND,
	   	   PIN_UserName as CREATED_BY,
	   	   current timestamp as CREATED_BY_TS,
	   	   PIN_UserName as LAST_MODIFIED_BY,
	   	   current timestamp as LAST_MODIFIED_TS
	  FROM SOW_SCOPE_OF_WORK
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = v_SowId
	       );
	
	Set POUT_RowCount = v_SOWRowCount1;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;


	IF v_SOWRowCount1 > 0
	-- if SOW_SCOPE_OF_WORK had data
    THEN
    -----------------------------------------------
    -- Update new SOW with new workflow
    -----------------------------------------------
    Set POUT_TableAction = 'Failure: (SOW) COM_WORKFLOW_LOG Insert';
     
	SELECT WORKFLOW_ID INTO v_WorkflowId
	  FROM FINAL TABLE
	       ( 
    INSERT INTO COM_WORKFLOW_LOG ( 
           WORKFLOW_ID, 
           WORKFLOW_SEQ_NBR, 
           WORKFLOW_LOG_TYPE_CODE, 
           WORKFLOW_STATUS_CODE, 
           DISP_CODE, 
           DISP_USER, 
           DISP_TS, 
           DISP_COMMENT, 
           DISP_TITLE, 
           CONVERTED_IND 
           ) VALUES ( 
           (SELECT MAX(WORKFLOW_ID) + 1 FROM COM_WORKFLOW_LOG), 
           1, 
           '16', 
           '01', 
           '073', 
           PIN_UserName, 
           current timestamp, 
           'From Agr: ' || PIN_FromAgr, 
           null, 
           null)
           );
           
    Set POUT_TableAction = 'Failure: SOW_SCOPE_OF_WORK Update'; 
    UPDATE SOW_SCOPE_OF_WORK
       SET WORKFLOW_ID = v_WorkflowId
     WHERE AGR = PIN_ToAgr
       AND SOW_ID = v_SowId;
	
	Set POUT_RowCount = 0;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;
	   		
    END IF;

    
	IF v_SOWRowCount1 > 0
	-- if SOW_SCOPE_OF_WORK had data
    THEN    	   		
    -----------------------------------------------
    -- Clone data for SOW_DETAIL.
    -----------------------------------------------
    Set POUT_TableAction = 'Failure: SOW_DETAIL Insert';
      
    SELECT count(*) into v_SOWRowCount2
	  FROM Final Table
	   	   ( 
	INSERT INTO SOW_DETAIL (
		   AGR, 
	   	   SOW_ID, 
	   	   SOW_DETAIL_ID, 
	   	   PART_ID, 
	   	   SUPPL_ID, 
	   	   WO_ID, 
	   	   AMEND_ID 
           )
    SELECT PIN_ToAgr as AGR, 
	   	   SOW_ID, 
	   	   SOW_DETAIL_ID,
	   	   PART_ID,
	   	   SUPPL_ID, 
	   	   WO_ID, 
	   	   AMEND_ID 
	  FROM SOW_DETAIL	
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = v_SowId
	       );
	       
	Set POUT_RowCount = v_SOWRowCount2;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;	
	
	END IF;
	
		
	IF v_SOWRowCount2 > 0
	-- if SOW_DETAIL had data
    THEN	   		   		
    -----------------------------------------------
    -- Clone data for SOW_MAIN_TASK.
    -----------------------------------------------    
    Set POUT_TableAction = 'Failure: SOW_MAIN_TASK Insert';
     
   	SELECT count(*) into v_SOWRowCount3
	  FROM Final Table
    	   ( 
	INSERT INTO SOW_MAIN_TASK (
		   AGR, 
	   	   SOW_ID, 
	   	   SOW_DETAIL_ID, 
	   	   TASK_ID, 
	   	   TASK_NBR, 
	   	   WBS_NBR, 
	   	   WBS_REVISION_DATE, 
	   	   NEW_TASK_IND, 
	   	   TASK_NAME, 
	   	   INTERNAL_ORDER, 
	   	   SOW_GENERATED_TASK, 
	   	   CREATED_BY, 
	   	   CREATED_BY_TS, 
	   	   LAST_MODIFIED_BY, 
	   	   LAST_MODIFIED_TS 
           )
    SELECT PIN_ToAgr as AGR, 
    	   SOW_ID, 
    	   SOW_DETAIL_ID, 
    	   TASK_ID, 
    	   TASK_NBR, 
    	   WBS_NBR, 
    	   WBS_REVISION_DATE, 
    	   NEW_TASK_IND, 
    	   TASK_NAME, 
    	   INTERNAL_ORDER, 
    	   SOW_GENERATED_TASK, 
	   	   PIN_UserName as CREATED_BY,
	   	   current timestamp as CREATED_BY_TS,
    	   PIN_UserName as LAST_MODIFIED_BY, 
    	   current timestamp as LAST_MODIFIED_TS
	  FROM SOW_MAIN_TASK	
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = v_SowId
	       );	
	        
	Set POUT_RowCount = v_SOWRowCount3;       
	Set POUT_SQLCode = SQLCODE;	
	Set POUT_SQLSTATE = SQLSTATE; 
	
	END IF;
	
	
	IF v_SOWRowCount3 > 0
	-- if SOW_MAIN_TASK had data
    THEN 	   		 	
    -----------------------------------------------
    -- Clone data for SOW_TASK_OBJECTIVE.
    -----------------------------------------------
    Set POUT_TableAction = 'Failure: SOW_TASK_OBJECTIVE Insert';
        
    SELECT count(*) into v_SOWRowCount4
	  FROM 	Final Table
	   	   ( 
	INSERT INTO SOW_TASK_OBJECTIVE (
		   AGR, 
	   	   SOW_ID, 
	   	   SOW_DETAIL_ID, 
	   	   TASK_ID, 
	   	   SOW_TASK_OBJECTIVE 
           )
    SELECT PIN_ToAgr as AGR,
	   	   SOW_ID, 
	   	   SOW_DETAIL_ID, 
	   	   TASK_ID, 
	   	   SOW_TASK_OBJECTIVE 
	  FROM SOW_TASK_OBJECTIVE
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = v_SowId
	       );
	        
	Set POUT_RowCount = v_SOWRowCount4;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;	  
		
	END IF;

	
	IF v_SOWRowCount3 > 0 AND v_SOWRowCount4 > 0
	-- if both SOW_MAIN_TASK and SOW_TASK_OBJECTIVE had data
    THEN	   			
    -----------------------------------------------
    -- Clone data for SOW_TASK_SCOPE.
    -----------------------------------------------
    Set POUT_TableAction = 'Failure: SOW_TASK_SCOPE Insert'; 
    
    SELECT count(*) into v_SOWRowCount5
	  FROM Final Table
	       ( 
	INSERT INTO SOW_TASK_SCOPE (
	 	   AGR, 
	   	   SOW_ID, 
	   	   SOW_DETAIL_ID, 
	   	   TASK_ID, 
	   	   SOW_TASK_SCOPE_LOB 
           )
    SELECT PIN_ToAgr as AGR, 
    	   SOW_ID, 
    	   SOW_DETAIL_ID, 
    	   TASK_ID, 
    	   SOW_TASK_SCOPE_LOB 
	  FROM SOW_TASK_SCOPE	
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = v_SowId
	       );
	       
	Set POUT_RowCount = v_SOWRowCount5;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;	   
		
	END IF;
	
	
	IF v_SOWRowCount3 > 0 AND v_SOWRowCount5 > 0
	-- if both SOW_MAIN_TASK and SOW_TASK_SCOPE had data
    THEN   			
    -----------------------------------------------
    -- Clone data for SOW_WBS_NUMBER.
    -----------------------------------------------
 	Set POUT_TableAction = 'Failure: SOW_WBS_NUMBER Insert'; 
 	
    SELECT count(*) into v_SOWRowCount6
	  FROM Final Table
	       ( 
	INSERT INTO SOW_WBS_NUMBER (
		   AGR, 
	   	   SOW_ID, 
	   	   SOW_DETAIL_ID, 
	   	   TASK_ID, 
	   	   WBS_NBR 
           )
	SELECT PIN_ToAgr as AGR, 
	   	   SOW_ID, 
	   	   SOW_DETAIL_ID, 
	   	   TASK_ID, 
	   	   WBS_NBR
	  FROM SOW_WBS_NUMBER	
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = v_SowId
	       );
	        
	Set POUT_RowCount = v_SOWRowCount6;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;	    
		
	END IF;	
		
	
	IF v_SOWRowCount3 > 0 
	-- if SOW_MAIN_TASK had data
    THEN	   			
    -----------------------------------------------
    -- Clone data for SOW_DETAIL_TASK.
    -----------------------------------------------
    Set POUT_TableAction = 'Failure: SOW_DETAIL_TASK Insert'; 
    
    SELECT count(*) into v_SOWRowCount7
	  FROM Final Table
	       ( 
	INSERT INTO SOW_DETAIL_TASK (
		   AGR, 
	   	   SOW_ID, 
	   	   SOW_DETAIL_ID, 
	   	   TASK_ID, 
	   	   DETAIL_TASK_ID, 
	   	   DETAIL_TASK_NAME, 
	   	   NEW_TASK_IND, 
	   	   ESTIMATE_IND, 
	   	   DEPARTMENT_DETAILS, 
	   	   DETAIL_TASK_NBR, 
	   	   SOW_GENERATED_TASK, 
	   	   SOW_GENERATED_DETAIL_TASK, 
	   	   CREATED_BY, 
	   	   CREATED_BY_TS, 
	   	   LAST_MODIFIED_BY, 
	   	   LAST_MODIFIED_TS
	   	   )
	SELECT PIN_ToAgr as AGR, 
	       SOW_ID, 
		   SOW_DETAIL_ID, 
		   TASK_ID, 
		   DETAIL_TASK_ID, 
		   DETAIL_TASK_NAME,
		   NEW_TASK_IND, 
		   ESTIMATE_IND, 
		   DEPARTMENT_DETAILS, 
		   DETAIL_TASK_NBR, 
		   SOW_GENERATED_TASK, 
		   SOW_GENERATED_DETAIL_TASK, 
	   	   PIN_UserName as CREATED_BY,
	   	   current timestamp as CREATED_BY_TS,
		   PIN_UserName as LAST_MODIFIED_BY,
		   current timestamp as LAST_MODIFIED_TS 
	  FROM SOW_DETAIL_TASK	
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = v_SowId
		   );
	       
	Set POUT_RowCount = v_SOWRowCount7;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;	     
		
	END IF;	
    

    -----------------------------------------------
    -----------------------------------------------
    -- Clone Department Estimate DATA (CST)
    -----------------------------------------------
    -----------------------------------------------
	    
  	 
  	 IF v_SOWRowCount3 > 0 AND v_SOWRowCount7 > 0
	-- if both SOW_MAIN_TASK and SOW_DETAIL_TASK had data
    THEN    			
    -----------------------------------------------
    -- Clone data for CST_COST_ESTIMATE.
    -----------------------------------------------
    Set POUT_TableAction = 'Failure: CST_COST_ESTIMATE Insert'; 
    
    SELECT count(*) into v_CSTRowCount01
	  FROM Final Table
	       (
	INSERT INTO CST_COST_ESTIMATE (
		   AGR, 
	   	   SOW_ID, 
	   	   CST_EST_ID, 
	   	   DPE_ESTIMATE_IND,
	   	   ASSOC_HIERARCHY_ID, 
	   	   CST_STATUS_CODE, 
	   	   SUBMITTED_BY_BP_ID, 
	   	   WORKFLOW_ID, 
	   	   LAST_SNAPSHOT_VERSION_ID, 
	   	   DBE_GROUP_CODE, 
	   	   CST_TOTAL_COST_AMT, 
	   	   CURRENT_PRP_IND,  
	   	   SBE_IND, 
	   	   DBE_IND, 
	   	   CREATED_BY, 
	   	   CREATED_BY_TS, 
	   	   LAST_MODIFIED_BY, 
	   	   LAST_MODIFIED_TS
           )
	SELECT PIN_ToAgr as AGR,
	   	   SOW_ID,
	   	   CST_EST_ID,
	   	   DPE_ESTIMATE_IND,
	   	   ASSOC_HIERARCHY_ID,
	   	   '01' as CST_STATUS_CODE,
	   	   SUBMITTED_BY_BP_ID,
	   	   0 as WORKFLOW_ID,
	   	   0 as LAST_SNAPSHOT_VERSION_ID,
	   	   DBE_GROUP_CODE,
	   	   CST_TOTAL_COST_AMT,
	   	   CURRENT_PRP_IND,
	   	   SBE_IND,
	   	   DBE_IND,
	   	   PIN_UserName as CREATED_BY,
	   	   current timestamp as CREATED_BY_TS,
		   PIN_UserName as LAST_MODIFIED_BY,
		   current timestamp as LAST_MODIFIED_TS
	  FROM CST_COST_ESTIMATE
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = v_SowId
	   AND CST_EST_ID = v_CstEstId
	   AND DPE_ESTIMATE_IND = 'Y'
		   );
	       
	Set POUT_RowCount = v_CSTRowCount01;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;
	
	END IF;


	IF v_CSTRowCount01 > 0
	-- if CST_COST_ESTIMATE had data
    THEN    
    -----------------------------------------------
    -- Update new DPE with new workflow
    -----------------------------------------------
    Set POUT_TableAction = 'Failure: (DPE) COM_WORKFLOW_LOG Insert'; 
    
	SELECT WORKFLOW_ID INTO v_WorkflowId
	  FROM FINAL TABLE
	       ( 
    INSERT INTO COM_WORKFLOW_LOG ( 
           WORKFLOW_ID, 
           WORKFLOW_SEQ_NBR, 
           WORKFLOW_LOG_TYPE_CODE, 
           WORKFLOW_STATUS_CODE, 
           DISP_CODE, 
           DISP_USER, 
           DISP_TS, 
           DISP_COMMENT, 
           DISP_TITLE, 
           CONVERTED_IND 
           ) VALUES ( 
           (SELECT MAX(WORKFLOW_ID) + 1 FROM COM_WORKFLOW_LOG), 
           1, '06', '01', '073', PIN_UserName, current timestamp, 
           'From Agr: ' || PIN_FromAgr, null, null)
           );
           
    Set POUT_TableAction = 'Failure: CST_COST_ESTIMATE Update'; 
    UPDATE CST_COST_ESTIMATE
       SET WORKFLOW_ID = v_WorkflowId	
	 WHERE AGR = PIN_ToAgr
	   AND SOW_ID = v_SowId
	   AND CST_EST_ID = v_CstEstId
	   AND DPE_ESTIMATE_IND = 'Y';
	
	Set POUT_RowCount = 0;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;
	   		
    END IF;


	IF v_CSTRowCount01 > 0
	-- if CST_COST_ESTIMATE had data
    THEN   			
    -----------------------------------------------
    -- Clone data for CST_DETAIL.
    -----------------------------------------------
    Set POUT_TableAction = 'Failure: CST_DETAIL Insert'; 	
    
    SELECT count(*) into v_CSTRowCount02
	  FROM Final Table
	       (
	INSERT INTO CST_DETAIL (
	       AGR,
	   	   SOW_ID,
	   	   CST_EST_ID,
	   	   SOW_DETAIL_ID, 
	   	   CST_DETAIL_TOTAL_COST_AMT, 
	   	   CANCELLED_PART_IND
	   	   )
	SELECT PIN_ToAgr as AGR,
	   	   SOW_ID,
	   	   CST_EST_ID,
	   	   SOW_DETAIL_ID, 
	   	   CST_DETAIL_TOTAL_COST_AMT, 
	   	   CANCELLED_PART_IND 
	  FROM CST_DETAIL
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = v_SowId
	   AND CST_EST_ID = v_CstEstId
		   );
	       
	Set POUT_RowCount = v_CSTRowCount02;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;
	   		
    END IF;	
	
	
	IF v_CSTRowCount02 > 0
	-- if CST_DETAIL had data
    THEN    	   			
    -----------------------------------------------
    -- Clone data for CST_COST_FACTOR.
    -----------------------------------------------
    Set POUT_TableAction = 'Failure: CST_COST_FACTOR Insert'; 
    
    SELECT count(*) into v_CSTRowCount03
	  FROM Final Table
	       (
	INSERT INTO CST_COST_FACTOR (
	       AGR, 
	   	   SOW_ID, 
	   	   CST_EST_ID, 
	   	   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   FIELD_OFFICE_IND, 
	   	   PROFIT_PCT, 
	   	   FIELD_OVERHEAD_PCT, 
	   	   OFFICE_OVERHEAD_PCT, 
	   	   HAZARD_PCT, 
	   	   PREMIUM_PAY_IND, 
	   	   OVERTIME_PCT, 
	   	   SPECIFIC_RATE_FACTOR, 
	   	   OVERTIME_SPECIFIC_RATE_FACTOR, 
	   	   HAZARD_SPECIFIC_RATE_FACTOR, 
	   	   HAZARD_OT_SPECIFIC_RATE_FACTOR, 
	   	   CREATED_BY, 
	   	   CREATED_BY_TS, 
	   	   LAST_MODIFIED_BY, 
	   	   LAST_MODIFIED_TS, 
	   	   PROFIT_CLASS_CODE
	   	   )
	SELECT PIN_ToAgr as AGR,
	   	   SOW_ID, 
	   	   CST_EST_ID, 
	   	   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   FIELD_OFFICE_IND, 
	   	   PROFIT_PCT, 
	   	   FIELD_OVERHEAD_PCT, 
	   	   OFFICE_OVERHEAD_PCT, 
	   	   HAZARD_PCT, 
	   	   PREMIUM_PAY_IND, 
	   	   OVERTIME_PCT, 
	   	   SPECIFIC_RATE_FACTOR, 
	   	   OVERTIME_SPECIFIC_RATE_FACTOR, 
	   	   HAZARD_SPECIFIC_RATE_FACTOR, 
	   	   HAZARD_OT_SPECIFIC_RATE_FACTOR,
	   	   PIN_UserName as CREATED_BY,
	   	   current timestamp as CREATED_BY_TS,
		   PIN_UserName as LAST_MODIFIED_BY,
		   current timestamp as LAST_MODIFIED_TS, 
	   	   PROFIT_CLASS_CODE
	  FROM CST_COST_FACTOR
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = v_SowId
	   AND CST_EST_ID = v_CstEstId
	   AND VERSION_ID = 0
		   );
	       
	Set POUT_RowCount = v_CSTRowCount03;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;
	   		
    END IF;	
	
	
	IF v_CSTRowCount03 > 0
	-- if CST_COST_FACTOR had data
    THEN    	   			
    -----------------------------------------------
    -- Clone data for CST_ESCALATION.
    -----------------------------------------------
    Set POUT_TableAction = 'Failure: CST_ESCALATION Insert'; 
    
    SELECT count(*) into v_CSTRowCount04
	  FROM Final Table
	       (
	INSERT INTO CST_ESCALATION (
	       AGR,
	   	   SOW_ID,
	   	   CST_EST_ID, 
	   	   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   ESCALATION_ID, 
	   	   ESCALATION_NAME, 
	   	   ESCALATION_PCT, 
	   	   ESCALATION_TEXT, 	
	   	   CREATED_BY,
	   	   CREATED_BY_TS,
		   LAST_MODIFIED_BY,
		   LAST_MODIFIED_TS
	   	   )
	SELECT PIN_ToAgr as AGR,
	   	   SOW_ID,
	   	   CST_EST_ID, 
	   	   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   ESCALATION_ID, 
	   	   ESCALATION_NAME, 
	   	   ESCALATION_PCT, 
	   	   ESCALATION_TEXT, 	
	   	   PIN_UserName as CREATED_BY,
	   	   current timestamp as CREATED_BY_TS,
		   PIN_UserName as LAST_MODIFIED_BY,
		   current timestamp as LAST_MODIFIED_TS
	  FROM CST_ESCALATION
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = v_SowId
	   AND CST_EST_ID = v_CstEstId
	   AND VERSION_ID = 0
		   );
	       
	Set POUT_RowCount = v_CSTRowCount04;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;
	   		
    END IF;	    
	
	
	IF v_CSTRowCount04 > 0
	-- if CST_ESCALATION had data
    THEN     	   			
    -----------------------------------------------
    -- Clone data for CST_LABOR_TASK.
    -----------------------------------------------
    Set POUT_TableAction = 'Failure: CST_LABOR_TASK Insert';
    
    SELECT count(*) into v_CSTRowCount05
	  FROM Final Table
	       (
	INSERT INTO CST_LABOR_TASK (
	       AGR,
	   	   SOW_ID,
	   	   CST_EST_ID, 
	   	   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   TASK_ID, 
	   	   DETAIL_TASK_ID, 
	   	   FIELD_OFFICE_IND, 
	   	   TOTAL_TASK_HOURS, 
	   	   TOTAL_PAYROLL_AMT, 
	   	   PROFIT_IND, 
	   	   AVERAGE_TASK_RATE, 
	   	   TOTAL_DETAIL_TASK_COST_AMT, 
	   	   FIELD_OVERHEAD_AMT, 
	   	   OFFICE_OVERHEAD_AMT, 
	   	   PROFIT_AMT, 
	   	   PROFIT_LIMIT_PCT, 
	   	   ESCALATION_ID, 
	   	   ESCALATION_AMT, 
	   	   SOW_GEN_TASK_ID, 
	   	   SOW_GEN_DTASK_ID, 	 	
	   	   CREATED_BY,
	   	   CREATED_BY_TS,
		   LAST_MODIFIED_BY,
		   LAST_MODIFIED_TS
	   	   )
	SELECT PIN_ToAgr as AGR,
	   	   SOW_ID,
	   	   CST_EST_ID, 
	   	   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   TASK_ID, 
	   	   DETAIL_TASK_ID, 
	   	   FIELD_OFFICE_IND, 
	   	   TOTAL_TASK_HOURS, 
	   	   TOTAL_PAYROLL_AMT, 
	   	   PROFIT_IND, 
	   	   AVERAGE_TASK_RATE, 
	   	   TOTAL_DETAIL_TASK_COST_AMT, 
	   	   FIELD_OVERHEAD_AMT, 
	   	   OFFICE_OVERHEAD_AMT, 
	   	   PROFIT_AMT, 
	   	   PROFIT_LIMIT_PCT, 
	   	   ESCALATION_ID, 
	   	   ESCALATION_AMT, 
	   	   SOW_GEN_TASK_ID, 
	   	   SOW_GEN_DTASK_ID, 	
	   	   PIN_UserName as CREATED_BY,
	   	   current timestamp as CREATED_BY_TS,
		   PIN_UserName as LAST_MODIFIED_BY,
		   current timestamp as LAST_MODIFIED_TS
	  FROM CST_LABOR_TASK
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = v_SowId
	   AND CST_EST_ID = v_CstEstId
	   AND VERSION_ID = 0
		   );
	       
	Set POUT_RowCount = v_CSTRowCount05;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;
	   		
    END IF;	    
	
	
	IF v_CSTRowCount05 > 0
	-- if CST_LABOR_TASK had data
    THEN    	   			
    -----------------------------------------------
    -- Clone data for CST_OTHER_COST.
    -----------------------------------------------
    Set POUT_TableAction = 'Failure: CST_OTHER_COST Insert'; 
    
    SELECT count(*) into v_CSTRowCount06
	  FROM Final Table
	       (
	INSERT INTO CST_OTHER_COST (
	       AGR, 
	   	   SOW_ID, 
	   	   CST_EST_ID, 
	   	   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   OTHER_COST_ID, 
	   	   OTHER_COST_NAME, 
	   	   NBR_OF_UNITS, 
	   	   COST_PER_UNIT, 
	   	   OTHER_COST_NBR, 
	   	   TOTAL_OTHER_COSTS_AMT, 
	   	   PREDETERMINED_AMT_IND, 
	   	   ALLOWABLE_AMT, 
	   	   ITEM_CALCULATION_DESC,
	   	   OC_GEN_TASK,
	   	   CREATED_BY,
	   	   CREATED_BY_TS,
	   	   LAST_MODIFIED_BY,
	   	   LAST_MODIFIED_TS,
	   	   DBE_INCLUDE_IND,
	   	   SBE_INCLUDE_IND
	   	   )
	SELECT PIN_ToAgr as AGR,
	   	   SOW_ID,
	   	   CST_EST_ID, 
	   	   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   OTHER_COST_ID, 
	   	   OTHER_COST_NAME, 
	   	   NBR_OF_UNITS, 
	   	   COST_PER_UNIT, 
	   	   OTHER_COST_NBR, 
	   	   TOTAL_OTHER_COSTS_AMT, 
	   	   PREDETERMINED_AMT_IND, 
	   	   ALLOWABLE_AMT, 
	   	   ITEM_CALCULATION_DESC,
	   	   OC_GEN_TASK, 	
	   	   PIN_UserName as CREATED_BY,
	   	   current timestamp as CREATED_BY_TS,
		   PIN_UserName as LAST_MODIFIED_BY,
		   current timestamp as LAST_MODIFIED_TS,
	   	   DBE_INCLUDE_IND,
	   	   SBE_INCLUDE_IND
	  FROM CST_OTHER_COST
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = v_SowId
	   AND CST_EST_ID = v_CstEstId
	   AND VERSION_ID = 0
		   );
	       
	Set POUT_RowCount = v_CSTRowCount06;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;
	   		
    END IF;	
    
	
	
	IF v_CSTRowCount05 > 0
	-- if CST_LABOR_TASK had data
    THEN     	   			
    -----------------------------------------------------
    -- Clone data for CST_LABOR_TASK_CLASSIFICATION_RATE.
    -----------------------------------------------------
    Set POUT_TableAction = 'Failure: LABOR_TASK_CLASSIFICATION Insert';
    
    SELECT count(*) into v_CSTRowCount07
	  FROM Final Table
	       (
	INSERT INTO CST_LABOR_TASK_CLASSIFICATION_RATE (
	       AGR,
	   	   SOW_ID,
	   	   CST_EST_ID, 
	   	   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   TASK_ID, 
	   	   DETAIL_TASK_ID, 
	   	   LABOR_TASK_CLASS_RATE_ID, 
	   	   DPE_EMR_JOB_CLASS_CODE, 
	   	   EMR_JOB_CLASS_DESC, 
	   	   REGULAR_HOURS, 
	   	   OVERTIME_HOURS, 
	   	   HAZARD_HOURS, 
	   	   OVERTIME_HAZARD_HOURS, 
	   	   REGULAR_TOTAL_COST_AMT, 
	   	   OVERTIME_TOTAL_COST_AMT, 
	   	   HAZARD_TOTAL_COST_AMT, 
	   	   OVERTIME_HAZARD_TOTAL_COST_AMT, 
	   	   JOB_CLASS_RATE, 
	   	   JOB_CLASS_HOURS, 
	   	   JOB_CLASS_TOTAL_COST_AMT
	   	   )
	SELECT PIN_ToAgr as AGR,
	   	   SOW_ID,
	   	   CST_EST_ID, 
	   	   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   TASK_ID, 
	   	   DETAIL_TASK_ID, 
	   	   LABOR_TASK_CLASS_RATE_ID, 
	   	   DPE_EMR_JOB_CLASS_CODE, 
	   	   EMR_JOB_CLASS_DESC, 
	   	   REGULAR_HOURS, 
	   	   OVERTIME_HOURS, 
	   	   HAZARD_HOURS, 
	   	   OVERTIME_HAZARD_HOURS, 
	   	   REGULAR_TOTAL_COST_AMT, 
	   	   OVERTIME_TOTAL_COST_AMT, 
	   	   HAZARD_TOTAL_COST_AMT, 
	   	   OVERTIME_HAZARD_TOTAL_COST_AMT, 
	   	   JOB_CLASS_RATE, 
	   	   JOB_CLASS_HOURS, 
	   	   JOB_CLASS_TOTAL_COST_AMT
	  FROM CST_LABOR_TASK_CLASSIFICATION_RATE
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = v_SowId
	   AND CST_EST_ID = v_CstEstId
	   AND VERSION_ID = 0
		   );
	       
	Set POUT_RowCount = v_CSTRowCount07;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;
	   		
    END IF;
	
	
	IF v_CSTRowCount05 > 0
	-- if CST_LABOR_TASK had data
    THEN    			
    -----------------------------------------------
    -- Clone data for CST_x.
    -----------------------------------------------
    Set POUT_TableAction = 'Failure: CST_UNIT_OF_WORK Insert'; 	   
    
    SELECT count(*) into v_CSTRowCount08
	  FROM Final Table
	       (
	INSERT INTO CST_UNIT_OF_WORK (
	       AGR,
	   	   SOW_ID,
	   	   CST_EST_ID, 
	   	   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   UNIT_OF_WORK_NBR, 
	   	   UNIT_OF_WORK_NAME, 
	   	   NBR_OF_UNITS, 
	   	   COST_PER_UNIT, 
	   	   FIELD_OFFICE_IND, 
	   	   NEW_UNIT_IND, 
	   	   UW_GEN_TASK, 
	   	   CREATED_BY, 
	   	   CREATED_BY_TS, 
	   	   LAST_MODIFIED_BY, 
	   	   LAST_MODIFIED_TS
	   	   )
	SELECT PIN_ToAgr as AGR,
	   	   SOW_ID,
	   	   CST_EST_ID, 
	   	   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   UNIT_OF_WORK_NBR, 
	   	   UNIT_OF_WORK_NAME, 
	   	   NBR_OF_UNITS, 
	   	   COST_PER_UNIT, 
	   	   FIELD_OFFICE_IND, 
	   	   NEW_UNIT_IND, 
	   	   UW_GEN_TASK,	
	   	   PIN_UserName as CREATED_BY,
	   	   current timestamp as CREATED_BY_TS,
		   PIN_UserName as LAST_MODIFIED_BY,
		   current timestamp as LAST_MODIFIED_TS
	  FROM CST_UNIT_OF_WORK
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = v_SowId
	   AND CST_EST_ID = v_CstEstId
	   AND VERSION_ID = 0
		   );
	       
	Set POUT_RowCount = v_CSTRowCount08;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;
	   		
    END IF;	
	
	
	IF v_CSTRowCount05 > 0 AND v_CSTRowCount08 > 0
	-- if LABOR_TASK and UNIT_OF_WORK had data 
    THEN     	   			
    -----------------------------------------------
    -- Clone data for CST_LABOR_TASK_UNITS_OF_WORK.
    -----------------------------------------------
    Set POUT_TableAction = 'Failure: LABOR_TASK_UOW Insert';
    
    SELECT count(*) into v_CSTRowCount09
	  FROM Final Table
	       (
	INSERT INTO CST_LABOR_TASK_UNITS_OF_WORK (
	       AGR,
	   	   SOW_ID,
	   	   CST_EST_ID, 
	   	   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   UNIT_OF_WORK_NBR, 
	   	   TASK_ID, 
	   	   DETAIL_TASK_ID
	   	   )
	SELECT PIN_ToAgr as AGR,
	   	   SOW_ID,
	   	   CST_EST_ID, 
	   	   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   UNIT_OF_WORK_NBR, 
	   	   TASK_ID, 
	   	   DETAIL_TASK_ID
	  FROM CST_LABOR_TASK_UNITS_OF_WORK
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = v_SowId
	   AND CST_EST_ID = v_CstEstId
	   AND VERSION_ID = 0
		   );
	       
	Set POUT_RowCount = v_CSTRowCount09;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;
	   		
    END IF;	
    
	
	
	IF v_CSTRowCount06 > 0 AND v_CSTRowCount08 > 0
	-- if OTHER_COST and UNIT_OF_WORK had data 
    THEN     	   			
    -----------------------------------------------
    -- Clone data for CST_OTHER_COST_UNITS_OF_WORK.
    -----------------------------------------------
    Set POUT_TableAction = 'Failure: CST_OTHER_COST_UOW Insert';
    
    SELECT count(*) into v_CSTRowCount10
	  FROM Final Table
	       (
	INSERT INTO CST_OTHER_COST_UNITS_OF_WORK (
	       AGR,
	   	   SOW_ID,
	   	   CST_EST_ID, 
	 	   	   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   UNIT_OF_WORK_NBR, 
	   	   OTHER_COST_ID
	   	   )
	SELECT PIN_ToAgr as AGR,
	   	   SOW_ID,
	   	   CST_EST_ID, 
		   	   SOW_DETAIL_ID, 
	   	   VERSION_ID, 
	   	   UNIT_OF_WORK_NBR, 
	   	   OTHER_COST_ID
	  FROM CST_OTHER_COST_UNITS_OF_WORK
	 WHERE AGR = PIN_FromAgr
	   AND SOW_ID = v_SowId
	   AND CST_EST_ID = v_CstEstId
	   AND VERSION_ID = 0
		   );
	       
	Set POUT_RowCount = v_CSTRowCount10;       
	Set POUT_SQLCode = SQLCODE;
	Set POUT_SQLSTATE = SQLSTATE;
	   		
    END IF;	
    
	
    -----------------------------------------------
    -----------------------------------------------
    -- Normal Return Processing
    -----------------------------------------------
    -----------------------------------------------
	
	IF (SQLCODE = 0 AND SQLSTATE = '00000')
	THEN	
    	Set POUT_TableAction = 'Success';
    	Set POUT_RowCount = 
				v_SOWRowCount1 + 
				v_SOWRowCount2 + 
				v_SOWRowCount3 + 
				v_SOWRowCount4 +
   		  		v_SOWRowCount5 +
   	 			v_SOWRowCount6 +
   		 		v_SOWRowCount7 +
    			v_CSTRowCount01 +
    			v_CSTRowCount02 +
    			v_CSTRowCount03 + 
    			v_CSTRowCount04 +
    			v_CSTRowCount05 +
    			v_CSTRowCount06 +
    			v_CSTRowCount07 +
    			v_CSTRowCount08 +
    			v_CSTRowCount09 +
    			v_CSTRowCount10;
    			
 --   		COMMIT; 
    		
    END IF;
    
    
END P1
