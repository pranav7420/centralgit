CREATE PROCEDURE ECMSXADM.SPCA0041 (IN P_PROJNUM INTEGER , IN P_BIDPKGNUM SMALLINT , OUT P_SQLCODE INTEGER)
	VERSION V1
	ISOLATION LEVEL CS
	RESULT SETS 1
	LANGUAGE SQL
	ALLOW DEBUG MODE
	WLM ENVIRONMENT FOR DEBUG MODE DSNDWLM2
	P1: BEGIN
       

DECLARE V_SQLCODE                		INT     DEFAULT 0;      
DECLARE V_SQLSTATE               		CHAR(5) DEFAULT '00000';
DECLARE SQLCODE                  		INT     DEFAULT 0;      
DECLARE SQLSTATE                 		CHAR(5) DEFAULT '00000';
DECLARE V_BPID_ERRORS					CHAR(34) DEFAULT ' ';
DECLARE V_PRJ_PREQ_REQD_IND      		CHAR(1) DEFAULT ' ';  
DECLARE V_GP_GEN_CODE_VALUE             VARCHAR(255) DEFAULT '  ';
DECLARE V_PARM_GEN_CODE_TYPE     		SMALLINT DEFAULT 79;
DECLARE V_TYPE_CODE_FINCAP       		CHAR(3)      DEFAULT '100';
DECLARE V_PROCESS_PRIME                 CHAR(1) DEFAULT 'Y';
DECLARE V_END_OF_CURSOR                 CHAR(1)      DEFAULT 'N';
DECLARE V_PC_BUS_PARTNER_ID             CHAR(6) DEFAULT '      ';
DECLARE V_PC_PROJ_CONTR_AMT             DECIMAL(15,2) DEFAULT 0;
DECLARE V_PRIME_BPID                    CHAR(6) DEFAULT ' ';
DECLARE V_PARENT_BPID                   CHAR(6) DEFAULT ' ';
DECLARE V_GENNED_ITEM_NUM        		SMALLINT DEFAULT 0;
DECLARE V_PARM_ITEMBPID                 CHAR(6) DEFAULT ' ';
DECLARE V_AUTOMATIC_SUBTYPE             CHAR(1) DEFAULT '1';
DECLARE V_PARM_STATUS                   CHAR(1) DEFAULT ' ';
DECLARE V_SYSTEM_USERID                 CHAR(19) DEFAULT 'ECMS System/PennDOT';
DECLARE V_GEN_CODE_VALUE150             CHAR(150) DEFAULT '  ';
DECLARE V_STRNEWTOPADOT                 DECIMAL(3,1) DEFAULT 0; 
DECLARE V_STRNEWTOPADOTCAP       		DECIMAL(11,2) DEFAULT 0;
DECLARE V_FIN_CAP                       DECIMAL(15,2) DEFAULT 0;
DECLARE V_FIN_CAP_AUX					DECIMAL(15,5) DEFAULT 0;
DECLARE V_TEMP_AVAIL_CAP         		DECIMAL(15,2) DEFAULT 0;
DECLARE V_AVAIL_CAP                     DECIMAL(15,2) DEFAULT 0;
DECLARE V_THRESHOLD_AVAIL_CAP    		DECIMAL(15,2) DEFAULT 0;
DECLARE V_THRESHOLD                     DECIMAL(11,2) DEFAULT 0;
DECLARE V_SUBCONTRACTOR_AMOUNT   		DECIMAL(15,2) DEFAULT 0;
DECLARE V_CONTRACT_AMOUNT        		DECIMAL(15,2) DEFAULT 0;
DECLARE V_TEST_PASS                     CHAR(1) DEFAULT '1';  
-- 1 = ALL PASSED,  2 = ONE FAILED, 0 = NO PASSED STATE
DECLARE V_NEW_AVAIL                      DECIMAL(15,2) DEFAULT 0;
DECLARE V_E_BPID                        CHAR(6) DEFAULT '    ';
DECLARE V_EMAIL_INDEX                   SMALLINT DEFAULT 0;
DECLARE V_EMAIL_SEPARATOR        		CHAR(1) DEFAULT ' ';
DECLARE V_VERIFIED_APPARENT_LOW  		CHAR(2) DEFAULT '02';
DECLARE V_TYPE_CODE_FIFTYWCC     		CHAR(3) DEFAULT '110';
DECLARE V_PASSED_STATUS                 CHAR(1) DEFAULT '1';
DECLARE V_FAILED_STATUS                 CHAR(1) DEFAULT '2';
DECLARE V_CONTRACTOR_TYPE        		CHAR(1) DEFAULT ' ';
DECLARE V_PREQ_CONTR                    CHAR(1) DEFAULT '1';
DECLARE V_PREQ_EXEMPT_CONTR             CHAR(1) DEFAULT '2';
DECLARE V_PDOTWORK_UPDATE        		CHAR(1) DEFAULT 'Y';
DECLARE V_CURRENT_PDOT_WORK             DECIMAL (15,2) DEFAULT 0;
DECLARE V_TABLEID                  		CHAR(12)     DEFAULT '$ECMSRETURN$';
DECLARE V_ERRCD                         SMALLINT     DEFAULT 0;
DECLARE V_ERRLOC                        CHAR(5)             DEFAULT '     ';
--DECLARE V_EMAIL_BPID               		CHAR(35);



DECLARE SINGLE_PARM_CURSOR CURSOR WITH RETURN
   FOR                                        
   SELECT V_TABLEID,                        
          V_SQLCODE,                          
          V_ERRCD,                          
          V_ERRLOC,
          V_BPID_ERRORS                 
     FROM SYSIBM.SYSDUMMY1    ;
     
     
 

DECLARE PROJCONTR CURSOR FOR                 
  SELECT A.BUS_PARTNER_ID,                   
         VALUE(PROJ_CONTR_AMT,0)             
    FROM ECMSXADM.PROJ_CONTRACTOR A, ECMSXADM.PREQ_CONTRACTOR B
   WHERE A.ECMS_PROJECT_NUM = P_PROJNUM    
     AND A.PROJ_CONTR_TYPE IN ( 'P', 'J')    
     AND A.BUS_PARTNER_ID = B.BUS_PARTNER_ID 
   ORDER BY A.PROJ_CONTR_TYPE DESC  ;
            
             


            
DECLARE EXIT HANDLER FOR SQLEXCEPTION

	BEGIN
	
       SET V_SQLCODE = SQLCODE   ;
       SET V_ERRCD = -1;
       OPEN SINGLE_PARM_CURSOR;
       
	END;


       
       
                   
  
SET V_ERRLOC = 'D010';    
SELECT PREQ_REQD_IND                        
INTO V_PRJ_PREQ_REQD_IND
FROM ECMSXADM.PROJECT                              
WHERE ECMS_PROJECT_NUM = P_PROJNUM  ;

IF V_PRJ_PREQ_REQD_IND IS NULL
THEN
    SET V_PRJ_PREQ_REQD_IND = 'N';
END IF;     

SET V_ERRLOC = 'D020';    
SELECT GEN_CODE_VALUE                      
INTO V_GP_GEN_CODE_VALUE                  
FROM ECMSXADM.COM_GENERAL_CODE                    
WHERE GEN_CODE_TYPE = V_PARM_GEN_CODE_TYPE 
  AND GEN_CODE = V_TYPE_CODE_FINCAP ;

SET V_GEN_CODE_VALUE150 = SPACE(150);
SET V_GEN_CODE_VALUE150 = SUBSTR(V_GP_GEN_CODE_VALUE, 1, 150); 

IF V_PRJ_PREQ_REQD_IND = 'Y'
THEN
    OPEN PROJCONTR;
       
    SET V_PROCESS_PRIME       =  'Y';
    SET V_END_OF_CURSOR       =  'N';
              
    WHILE V_END_OF_CURSOR = 'N'
    DO FETCH FROM PROJCONTR
       INTO   V_PC_BUS_PARTNER_ID, V_PC_PROJ_CONTR_AMT;
       IF SQLCODE = 100
       THEN 
           CLOSE PROJCONTR;  
           SET V_END_OF_CURSOR = 'Y';
       ELSE
       		-- BECAUSE OF ORDER BY THE FIRST CONTRACTOR WILL BE THE PRIME     
         --	IF V_PROCESS_PRIME = 'Y'  
         --	THEN
         
         		  
         
         
         		  IF V_PROCESS_PRIME = 'Y'
         		  THEN
         		  	  SET V_PROCESS_PRIME = 'N';
         		  	  
         		  	  SET V_PRIME_BPID = V_PC_BUS_PARTNER_ID;
         		  	  
         		  	  SET V_ERRLOC = 'D030';
	                  SELECT MAX(AC_ITEM_NUM)                
	                  INTO V_GENNED_ITEM_NUM             
	                  FROM ECMSXADM.AC_ITEM                         
	                  WHERE ECMS_PROJECT_NUM    = P_PROJNUM  
	                    AND BID_PACKAGE_NUM     = P_BIDPKGNUM 
	                    AND BUS_PARTNER_ID      = V_PRIME_BPID;
                    
	                  SET V_ERRLOC = 'D040';
	                  SELECT PARENT_BP_ID                 
	                  INTO V_PARENT_BPID                 
	                  FROM ECMSXADM.CONTRACTOR                   
	                  WHERE BUS_PARTNER_ID      = V_PRIME_BPID;
	                  
         		  END IF;
         		   
                                    
                  SET V_PARM_ITEMBPID = V_PC_BUS_PARTNER_ID;
                    
                                   
                  -- CHEK PRIME AND EACH JOINT VENTURES  --
                  -- GET NEW TO PENNDOT PERCENTAGE TO MULTIPLY BY
                  SET V_ERRLOC = 'D050';
                  SELECT DEC(GEN_CODE_VALUE,3,2)                
                  INTO V_STRNEWTOPADOT                         
            	  FROM ECMSXADM.COM_GENERAL_CODE                       
                  WHERE GEN_CODE_TYPE = 921 AND GEN_CODE = '08';
                    
                  -- GET THE CAP FINANCIAL CAPACITY AMOUNT
                  SET V_ERRLOC = 'D060';
                  SELECT DEC(GEN_CODE_VALUE,11,2)             
                  INTO V_STRNEWTOPADOTCAP                    
              	  FROM ECMSXADM.COM_GENERAL_CODE                     
                  WHERE GEN_CODE_TYPE = 921 AND GEN_CODE = '09';
                     
                  -- GET AVAILABLE CAPACITY THRESHOLD
                  SET V_ERRLOC = 'D070';
                  SELECT DEC(GEN_CODE_VALUE,3,2)               
                  INTO V_THRESHOLD                         
              	  FROM ECMSXADM.COM_GENERAL_CODE                      
                  WHERE GEN_CODE_TYPE = 921 AND GEN_CODE = '10';
                     
                     
                  -- DETERMINE THE FINANCIAL CAPACITY OF THE BUSINESS PARTNER
                  -- THIS MUST BE DETERMINED BEFORE AVAILABLE CAPACITY IS
                  -- DETERMINED BECAUSE IT IS INPUT TO THE AVAILABLE
                  -- CAPACITY FORMULA
                     
                                        
                  SET V_ERRLOC = 'D080';
                    
                  SET V_FIN_CAP =
                  (
                   SELECT CASE  WHEN NEW_TO_PADOT_IND = 'Y'                   
                   THEN                                          
                       CASE   WHEN COALESCE(PERF_FACTOR, 1) *             
                                  CAST( COALESCE(WORKING_CAPITAL, 0) *         
                               	   V_STRNEWTOPADOT AS DECIMAL(15,2)  )   > V_STRNEWTOPADOTCAP 
              		   THEN V_STRNEWTOPADOTCAP                      
                       ELSE   
                    	   COALESCE(PERF_FACTOR, 1) *             
                           CAST(COALESCE(WORKING_CAPITAL, 0) *         
                           V_STRNEWTOPADOT AS DECIMAL(15,2) )
                       END                                         
                   ELSE                                          
                   	   CAST(COALESCE(PERF_FACTOR, 1) *                 
                       WORKING_CAPITAL AS DECIMAL(15,2) )                         
                   END                                           
                   FROM ECMSXADM.PREQ_CONTRACTOR
                   WHERE BUS_PARTNER_ID =                               
                         (SELECT PARENT_BP_ID                            
                          FROM ECMSXADM.CONTRACTOR
                          WHERE BUS_PARTNER_ID = V_PC_BUS_PARTNER_ID)     
                   AND PREQ_CONTR_TYPE = '12'                            
                                                     
                   UNION 
                         
                   SELECT CASE  WHEN NEW_TO_PADOT_IND = 'Y'
                   THEN                                            
                   		CASE   WHEN COALESCE(PERF_FACTOR, 1) *              
                               		CAST((COALESCE(WORKING_CAPITAL, 0) +          
                               	CAST(COALESCE(LOC_AMOUNT, 0) * .5 AS DOUBLE) +         
                               	CAST(COALESCE(EQUIP_BOOK_VALUE, 0) * .5 AS DOUBLE)) *  
                           			 V_STRNEWTOPADOT AS DECIMAL(15,2) )   > V_STRNEWTOPADOTCAP   
                   		THEN V_STRNEWTOPADOTCAP                       
                    	ELSE                                         
                        	COALESCE(PERF_FACTOR, 1) *              
                        CAST((COALESCE(WORKING_CAPITAL, 0) +          
                            CAST(COALESCE(LOC_AMOUNT, 0) * .5 AS DOUBLE )  +         
                        	CAST(COALESCE(EQUIP_BOOK_VALUE, 0) * .5 AS DOUBLE))  *  
                        	V_STRNEWTOPADOT   AS DECIMAL(15,2) )                        
                    	END                                          
                    ELSE                                            
                    	CAST(COALESCE(PERF_FACTOR, 1) *                   
                    	(COALESCE(WORKING_CAPITAL, 0) +               
                    	CAST(COALESCE(LOC_AMOUNT, 0) * .5 AS DOUBLE)  +              
                    	CAST(COALESCE(EQUIP_BOOK_VALUE, 0) * .5 AS DOUBLE)) AS DECIMAL(15,2) )
                    END                                             
                    --INTO V_FIN_CAP                                          
                    FROM ECMSXADM.PREQ_CONTRACTOR 
                    WHERE BUS_PARTNER_ID =                                 
                           (SELECT PARENT_BP_ID                              
                            FROM ECMSXADM.CONTRACTOR
                            WHERE BUS_PARTNER_ID = V_PC_BUS_PARTNER_ID)       
                    AND PREQ_CONTR_TYPE = '11'    );
                    
                    --SET V_FIN_CAP = CAST(V_FIN_CAP_AUX AS DECIMAL(15,2) );
                     
                    -- DETERMINE AVAILABLE CAPACITY SIDE OF THE FORMULA 
                    SET V_ERRLOC = 'D090';
                    SELECT (COALESCE(SUM(PC.PRIME_CONTR_AMT), 0) +
                           COALESCE(SUM(PC.PRIME_WO_AMT), 0) -   
                           COALESCE(SUM(PC.PRIME_PAID_AMT), 0)) -
                           COALESCE(SUM(PC.NON_PD_WORK_AMT), 0) -
                           COALESCE(SUM(PC.SUB_WORK_AMT), 0) +   
                           COALESCE(SUM(PC.WORK_SUB_AMT), 0)     
                    INTO V_TEMP_AVAIL_CAP                          
                    FROM ECMSXADM.PREQ_CONTRACTOR PC,                      
                    ECMSXADM.CONTRACTOR CR                            
                    WHERE CR.PARENT_BP_ID =                       
                           (SELECT PARENT_BP_ID                         
                            FROM ECMSXADM.CONTRACTOR
                            WHERE BUS_PARTNER_ID = V_PC_BUS_PARTNER_ID)  
                    AND CR.BUS_PARTNER_ID = PC.BUS_PARTNER_ID;
                    
                    IF V_TEMP_AVAIL_CAP < 0
                    THEN
                        SET V_TEMP_AVAIL_CAP = 0;
                    END IF;
                    
                    SET V_AVAIL_CAP = (V_FIN_CAP - V_TEMP_AVAIL_CAP);
                    
                    -- CONTRACTORS BID CAN ONLY TAKE UP TO 90% OF HIS 
                    -- AVAILABLE CAPACITY (90% IS ACTUALLY A PERCENT STORED
                    -- IN THE SYSTEM CODE TABLE
                    SET V_THRESHOLD_AVAIL_CAP = (V_AVAIL_CAP * V_THRESHOLD);
                    
                    -- DETERMINE CONTRACT AMOUNT
                    -- IF THE BID IS A JOINT VENTURE, WE MUST SUM THE CONTRACTOR
                    -- AMOUNT FOR ALL THE SUBS AND SUBTRACT THAT AMOUNT FROM
                    -- THE CONTRACT AMOUNT
                    
                    	-- Matt - no longer need to calculate with sub's total
                  --  SET V_SUBCONTRACTOR_AMOUNT = 0;
                    
                  --  SET V_ERRLOC = 'D100';
                  --  SELECT VALUE (SUM(PROJ_CONTR_TOT_AMT),0)     
                  --  INTO V_SUBCONTRACTOR_AMOUNT                   
                  --  FROM ECMSXADM.CONTR_ECMS_BID_OPEN A, 
                  --  ECMSXADM.CONTR_ECMS_BID_PARTNER_OPEN B
                  --  WHERE A.ECMS_PROJECT_NUM = P_PROJNUM       
                  --  AND A.BID_PACKAGE_NUM      = P_BIDPKGNUM      
                  --  AND A.BUS_PARTNER_ID       = V_PRIME_BPID         
                  --  AND A.ECMS_PROJECT_NUM     = B.ECMS_PROJECT_NUM
                  --  AND A.BID_PACKAGE_NUM      = B.BID_PACKAGE_NUM  
                  --  AND A.BUS_PARTNER_ID       = B.BUS_PARTNER_ID    
                  --  AND B.PROJ_CONTR_TYPE      = 'S';
                                    
                  --  SET V_CONTRACT_AMOUNT = ( V_PC_PROJ_CONTR_AMT - V_SUBCONTRACTOR_AMOUNT );
                  
                  	SET V_CONTRACT_AMOUNT = V_PC_PROJ_CONTR_AMT;
                    
                    -- IF THE BUSINESS PARTNER IS ASSIGNED TO MORE ITEMS THAN THEY HAVE
                    -- FINANCIAL CAPACITY TO DO, INSERT THE AC_ITEM WITH A FAILED STATUS
                    -- CHECK CONTRACT AMOUNT TO 90% OF THE CONTRACTORS AVAILABLE CAPACITY RATHER
                    -- THAN TOTAL AVAILABLE CAPACITY
                    IF V_CONTRACT_AMOUNT > V_THRESHOLD_AVAIL_CAP
                    THEN
                        SET V_PARM_STATUS = '2';  -- FAILED STATUS
                        SET V_TEST_PASS   = '2';  -- ONE FAILED                 
                    ELSE                                       
                        SET V_PARM_STATUS = '1';  -- PASSED STATUS    
                        SET V_NEW_AVAIL = (V_AVAIL_CAP - V_CONTRACT_AMOUNT) ;   
                        IF V_NEW_AVAIL <  (V_FIN_CAP * .10)
                        THEN                 
                            SET V_EMAIL_INDEX = V_EMAIL_INDEX + 1;
                            SET V_BPID_ERRORS = TRIM(V_BPID_ERRORS) || V_PC_BUS_PARTNER_ID || ';';
                          --SET V_E_BPID(V_EMAIL_INDEX) = V_PC_BUS_PARTNER_ID;
                          --SET V_EMAIL_SEPARATOR(V_EMAIL_INDEX) = ';' ;
                        END IF;     
                    END IF;
                    
                                                               
                     
                    SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
                    SET V_ERRLOC = 'D110';                
                    INSERT INTO ECMSXADM.AC_ITEM 
                    ( ECMS_PROJECT_NUM, 
                      BID_PACKAGE_NUM,  
                      BUS_PARTNER_ID,   
                      AC_ITEM_NUM,      
                      AC_ITEM_CAT_CODE, 
                      AC_ITEM_TYPE_CODE,
                      AC_ITEM_SUBMIT_TS,
                      AC_ITEM_STATUS_TS,
                      AC_ITEM_STATUS_CD,
                      AC_ITEM_STATUS_BY,
                      AC_ITEM_BP_ID,    
                      AC_ITEM_DEFLT_IND,
                      CREATED_BY,       
                      CREATED_BY_TS,    
                      LAST_MODIFIED_BY, 
                      LAST_MODIFIED_TS, 
                      EDMS_DOC_LINK,    
                      AC_ITEM_TITLE,    
                      AC_ITEM_COMMENT ) 
                    VALUES     
                         ( P_PROJNUM,          
                         P_BIDPKGNUM,        
                         V_PRIME_BPID,          
                         V_GENNED_ITEM_NUM,  
                         V_AUTOMATIC_SUBTYPE,   
                         V_TYPE_CODE_FINCAP,    
                         NULL,                 
                         CURRENT_TIMESTAMP,    
                         V_PARM_STATUS,         
                         V_SYSTEM_USERID,       
                         V_PARM_ITEMBPID,       
                         'Y',                  
                         V_SYSTEM_USERID,       
                         CURRENT_TIMESTAMP,    
                         V_SYSTEM_USERID,       
                         CURRENT_TIMESTAMP,    
                         NULL,                 
                         V_GEN_CODE_VALUE150,
                         NULL );
          --    END IF;                    
       END IF;                           
       END WHILE;

       
       -- IF ALL THE ITEMS ON THIS PROJECT HAVE PASSED FIN CAPACITY
       -- THIS STORED PROCEDURE CANNOT COMMIT SO IT MUST KEEP TRACK
       -- OF WHETHER WE ARE PASSING ALL THE ITEMS
       
       IF V_TEST_PASS = '1'  -- ALL PASSED
       THEN
              SET V_ERRLOC = 'D120';
              UPDATE ECMSXADM.CONTR_ECMS_BID_OPEN                                   
                     SET BID_STATUS_CODE = V_VERIFIED_APPARENT_LOW       
              WHERE ECMS_PROJECT_NUM = P_PROJNUM               
              AND BID_PACKAGE_NUM = P_BIDPKGNUM                
              AND BUS_PARTNER_ID = V_PRIME_BPID                   
              AND 0 =                                            
                    (SELECT COUNT(*)                                
              FROM ECMSXADM.AC_ITEM                                   
              WHERE AC_ITEM_TYPE_CODE = V_TYPE_CODE_FIFTYWCC  
              AND ECMS_PROJECT_NUM = P_PROJNUM             
              AND BID_PACKAGE_NUM = P_BIDPKGNUM            
              AND BUS_PARTNER_ID = V_PRIME_BPID               
              AND AC_ITEM_STATUS_CD <> V_PASSED_STATUS )      
              AND EXISTS                                        
                    (SELECT ECMS_PROJECT_NUM                        
              FROM ECMSXADM.AC_ITEM                                   
              WHERE AC_ITEM_TYPE_CODE = V_TYPE_CODE_FIFTYWCC  
              AND ECMS_PROJECT_NUM = P_PROJNUM             
              AND BID_PACKAGE_NUM = P_BIDPKGNUM            
              AND BUS_PARTNER_ID = V_PRIME_BPID);
              
       		  IF SQLCODE = 0 OR SQLCODE = 100
       		  THEN
              	  SET V_SQLCODE = 0;
       		  END IF;
       
       END IF;  
                    
END IF;

IF V_PRJ_PREQ_REQD_IND <> 'Y'
THEN
       SET V_ERRLOC = 'D130';
       SELECT A.BUS_PARTNER_ID                 
       INTO V_PRIME_BPID                      
       FROM ECMSXADM.PROJ_CONTRACTOR A                
       WHERE A.ECMS_PROJECT_NUM = P_PROJNUM 
         AND A.PROJ_CONTR_TYPE = 'P' ;
       
       SET V_ERRLOC = 'D135';  
       SELECT PARENT_BP_ID                
       INTO V_PARENT_BPID                
       FROM ECMSXADM.CONTRACTOR                  
       WHERE BUS_PARTNER_ID = V_PRIME_BPID;
       
       SET V_ERRLOC = 'D140';
       SELECT CONTR_TYPE_CODE               
       INTO V_CONTRACTOR_TYPE              
       FROM ECMSXADM.CONTRACTOR                    
       WHERE BUS_PARTNER_ID = V_PARENT_BPID;
      
       
       IF V_CONTRACTOR_TYPE = V_PREQ_EXEMPT_CONTR
      THEN
             SET V_PDOTWORK_UPDATE = 'N';
      END IF;
      
END IF;

IF     V_PDOTWORK_UPDATE = 'Y'
      THEN
             SET V_ERRLOC = 'D150';
             SELECT VALUE(SUM(PRIME_CONTR_AMT +        
                 CONT_BID_TOT_AMT),0)     
              INTO V_CURRENT_PDOT_WORK              
              FROM ECMSXADM.PREQ_CONTRACTOR A, 
              	   ECMSXADM.CONTR_ECMS_BID_OPEN B     
              WHERE A.BUS_PARTNER_ID           = V_PRIME_BPID     
                AND B.ECMS_PROJECT_NUM = P_PROJNUM   
                AND B.BID_PACKAGE_NUM   = P_BIDPKGNUM  
                AND B.BUS_PARTNER_ID           = A.BUS_PARTNER_ID;
                     
              SET V_ERRLOC = 'D160';    
              UPDATE ECMSXADM.PREQ_CONTRACTOR                        
                    SET PRIME_CONTR_AMT = V_CURRENT_PDOT_WORK
             WHERE BUS_PARTNER_ID      = V_PRIME_BPID  ;   
      
END IF;

                                                                
OPEN SINGLE_PARM_CURSOR;

       
       
END P1
