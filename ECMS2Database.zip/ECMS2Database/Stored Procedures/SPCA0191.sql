CREATE PROCEDURE ECMSXADM.SPCA0191 (IN P_PROJNUM INTEGER , IN P_BIDPKGNUM SMALLINT , OUT P_SQLCODE INTEGER)
	VERSION V1
	ISOLATION LEVEL CS
	RESULT SETS 1
	LANGUAGE SQL
	WLM ENVIRONMENT FOR DEBUG MODE DSNDWLM2
	ALLOW DEBUG MODE
	P1: BEGIN

DECLARE V_SQLCODE                		INT     DEFAULT 0;      
DECLARE V_SQLSTATE               		CHAR(5) DEFAULT '00000';
DECLARE SQLCODE                  		INT     DEFAULT 0;      
DECLARE SQLSTATE                 		CHAR(5) DEFAULT '00000';
DECLARE V_END_OF_CURSOR                 CHAR(1) DEFAULT 'N';
DECLARE V_ERRCD                         SMALLINT     DEFAULT 0;
DECLARE V_ERRLOC                        CHAR(5)      DEFAULT '     ';
DECLARE V_TABLEID                  		CHAR(12)     DEFAULT '$ECMSRETURN$';
DECLARE V_USER_ID						CHAR(80) DEFAULT 'Ecms system/PennDOT';

DECLARE V_IN_PARTNER_ID					CHAR(6) DEFAULT ' ';
DECLARE V_CONT_MAX_CHG_AMT				DECIMAL (15,2) DEFAULT 0;
DECLARE V_NULL							CHAR(1) DEFAULT NULL;
DECLARE V_AC_ITEM_NUM					SMALLINT	DEFAULT 0;
DECLARE	V_CONTACT_PERSON				VARCHAR(50) DEFAULT ' ';
DECLARE	V_CONTACT_PHONE					VARCHAR(21) DEFAULT ' ';
DECLARE	V_CREATED_BY					VARCHAR(80) DEFAULT ' ';
DECLARE	V_CREATED_BY_TS					TIMESTAMP;	
DECLARE	V_LAST_MODIFIED_BY				VARCHAR(80) DEFAULT ' ';
DECLARE	V_LAST_MODIFIED_TS				TIMESTAMP;


DECLARE SINGLE_PARM_CURSOR CURSOR WITH RETURN
   FOR                                        
   SELECT V_TABLEID,                        
          V_SQLCODE,                          
          V_ERRCD,                          
          V_ERRLOC
                           
     FROM SYSIBM.SYSDUMMY1    ;


DECLARE PMPC_INFO_CURSOR CURSOR WITH HOLD FOR  
SELECT                                         
       A.WORKFLOW_SEQ_NBR,                     
       A.WORKFLOW_STATUS_CODE,                 
       A.DISP_CODE,                            
       A.DISP_USER,                            
       A.DISP_TS,                              
       A.DISP_COMMENT                          
  FROM  COM_WORKFLOW_LOG A, AC_MIN_PART_CMMT B 
 WHERE B.ECMS_PROJECT_NUM  = P_PROJNUM
   AND B.BID_PACKAGE_NUM   = P_BIDPKGNUM
   AND B.BUS_PARTNER_ID    = V_IN_PARTNER_ID 
   AND B.WORKFLOW_ID       = A.WORKFLOW_ID     
ORDER BY A.WORKFLOW_SEQ_NBR  ;             


DECLARE BPID_CSR CURSOR FOR
SELECT BUS_PARTNER_ID,                    
       DECIMAL(RTRIM(GEN_CODE_VALUE),15,2)
--INTO V_IN_PARTNER_ID,                   
--     V_CONT_MAX_CHG_AMT                 
FROM CONTR_ECMS_BID_OPEN, COM_GENERAL_CODE                 
WHERE ECMS_PROJECT_NUM  = P_PROJNUM     
AND BID_PACKAGE_NUM     = P_BIDPKGNUM    
--AND BID_RANKING         = 1                      
AND GEN_CODE_TYPE       = 921 AND GEN_CODE = '11';


DECLARE EXIT HANDLER FOR SQLEXCEPTION

	BEGIN
	
	   SET V_SQLCODE = SQLCODE   ;
       SET V_ERRCD = -1;
       OPEN SINGLE_PARM_CURSOR;
       
   END;
   




SET V_ERRLOC = 'D010';
OPEN BPID_CSR;

SET V_END_OF_CURSOR = 'N';
WHILE V_END_OF_CURSOR = 'N'
DO FETCH BPID_CSR
	INTO V_IN_PARTNER_ID, V_CONT_MAX_CHG_AMT;
	
	IF SQLCODE = 100
    THEN 
    	CLOSE BPID_CSR;  
    	SET V_END_OF_CURSOR = 'Y';
    ELSE
      
	--	SET V_ERRLOC = 'D015';
	--	UPDATE PROJECT
	--	SET CONT_MAX_CHG_AMT	=	V_CONT_MAX_CHG_AMT ,
	--	    LAST_MODIFIED_BY	=	V_USER_ID ,
	--	    LAST_MODIFIED_TS	=	CURRENT TIMESTAMP;	


		SET V_ERRLOC = 'D020';
		SELECT AC_ITEM_NUM
		INTO V_AC_ITEM_NUM
		FROM AC_MIN_PART_CMMT
		WHERE ECMS_PROJECT_NUM	=	P_PROJNUM
		  AND BID_PACKAGE_NUM	=	P_BIDPKGNUM
		  AND BUS_PARTNER_ID	=	V_IN_PARTNER_ID;
  
		SET V_ERRLOC = 'D030';
		SELECT  
		       B.CONTACT_PERSON,                       
		       B.CONTACT_PHONE,                        
		       B.CREATED_BY,                           
		       B.CREATED_BY_TS,                        
		       B.LAST_MODIFIED_BY,                     
		       B.LAST_MODIFIED_TS                     
		INTO 
			V_CONTACT_PERSON,
			V_CONTACT_PHONE,
			V_CREATED_BY,
			V_CREATED_BY_TS,
			V_LAST_MODIFIED_BY,
			V_LAST_MODIFIED_TS
			                                  
		FROM AC_DBE_CMMT_PRE_BID B                   
		WHERE B.ECMS_PROJECT_NUM  = P_PROJNUM
		  AND B.BID_PACKAGE_NUM   = P_BIDPKGNUM
		  AND B.BUS_PARTNER_ID    = V_IN_PARTNER_ID ;  
  
  		IF SQLCODE = 100
  		THEN
  			SET V_CONTACT_PERSON = SPACE(50);
  			SET V_CONTACT_PHONE  = SPACE(21);
  		END IF;
  


		SET V_ERRLOC = 'D040';
		UPDATE AC_MIN_PART_CMMT  
		    SET ATT_A_STATUS_CODE		=	'01'     
		      , CONTACT_PERSON			=	V_CONTACT_PERSON        
		      , CONTACT_PHONE			=	V_CONTACT_PHONE         
		      , DBE_READY_RVW_PCT     	=	0.00
		      , MBE_READY_RVW_PCT     	=	0.00
		      , WBE_READY_RVW_PCT     	=	0.00
		      , DBE_APPROVED_PCT      	=	0.00
		      , MBE_APPROVED_PCT      	=	0.00
		      , WBE_APPROVED_PCT      	=	0.00
		      , SELF_CONTAINED_IND    	=	NULL
		      , PERF_50_WI_IND        	=	NULL
		      , GF_EFFORT_IND         	=	NULL
		    --  , CREATED_BY            	=	V_CREATED_BY
		    --  , CREATED_BY_TS         	=	V_CREATED_BY_TS
		    --  , LAST_MODIFIED_BY      	=	V_LAST_MODIFIED_BY
		    --  , LAST_MODIFIED_TS   		=	V_LAST_MODIFIED_TS   
		      , MPL_EVAL_IND			=	NULL          
		      , WORKFLOW_ID  			=	NULL          
		                    
		  WHERE ECMS_PROJECT_NUM  = P_PROJNUM
		   AND BID_PACKAGE_NUM    = P_BIDPKGNUM
		   AND BUS_PARTNER_ID     = V_IN_PARTNER_ID ;
		--   AND AC_ITEM_NUM		  = V_AC_ITEM_NUM	;	



		SET V_ERRLOC = 'D030';
		INSERT INTO AC_MPC_SUB          
		      (ECMS_PROJECT_NUM,  
		       BID_PACKAGE_NUM, 
		       BUS_PARTNER_ID, 
		       AC_ITEM_NUM,    
		       SUB_BP_SEQ_NUM,          
		       SUB_BP_ID,               
		----       ATT_A_SUBMIT_TS,         
		       MPC_SUB_STATUS,          
		       DBE_CERT_NUM,            
		----       DBE_CERT_EXP_DATE,       
		       CONTACT_PERSON,          
		       CONTACT_PHONE,           
		       MIN_CLASS_CODE,          
		       BUSINESS_TYPE,           
		--       BUSINESS_TYPE_OTH,       
		--       SUB_ACK_BY,              
		--       SUB_ACK_TS,              
		--       MIN_DBE_JVT_PCT,         
		       MOBIL_AMT,               
		--       SUB_ANTIC_END_DATE,      
		--       SUB_ANTIC_START_DT,      
		       SUB_WORK_AMT,            
		--       BEO_COMMENT,             
		       CREATED_BY,              
		       CREATED_BY_TS,           
		       LAST_MODIFIED_BY,        
		       LAST_MODIFIED_TS,        
		--      WORKFLOW_ID,             
		       NON_DBE_2ND_TIER_SUB_IND,
		       NON_DBE_2ND_TIER_SUB_AMT,
		       SUB_TO_PRIME_IND,        
		       SUB_NOT_TO_PRIME_VALUE,  
		       VBE_CODE,                
		       DIVERSE_BUSINESS_IND)    
		SELECT B.ECMS_PROJECT_NUM,
			   B.BID_PACKAGE_NUM,  
			   B.BUS_PARTNER_ID, 
			   V_AC_ITEM_NUM,    
			   B.SUB_BP_SEQ_NUM,              
		       B.SUB_BP_ID,                   
		 ----      V_NULL,                          
		       B.MPC_SUB_STATUS,              
		       B.DBE_CERT_NUM,                
		----       B.DBE_CERT_EXP_DATE,           
		       B.CONTACT_PERSON,              
		       B.CONTACT_PHONE,               
		       B.MIN_CLASS_CODE,              
		       B.BUSINESS_TYPE,               
		--       B.BUSINESS_TYPE_OTH,           
		--       B.SUB_ACK_BY,                  
		--       B.SUB_ACK_TS,                  
		--       B.MIN_DBE_JVT_PCT,             
		       B.MOBIL_AMT,                   
		--       B.SUB_ANTIC_END_DATE,          -- COLUMNS NOT IN AC_DBE_CMMT_PRE_BID_SUB
		--       B.SUB_ANTIC_START_DT,          
		       B.SUB_WORK_AMT,                
		 --      B.BEO_COMMENT,                 
		       V_USER_ID, CURRENT_TIMESTAMP,
		       V_USER_ID, CURRENT_TIMESTAMP,
		 --      B.WORKFLOW_ID,                 
		       B.NON_DBE_2ND_TIER_SUB_IND,    
		       B.NON_DBE_2ND_TIER_SUB_AMT,    
		       B.SUB_TO_PRIME_IND,            
		       B.SUB_NOT_TO_PRIME_VALUE,      
		       B.VBE_CODE,                    
		       B.DIVERSE_BUSINESS_IND         
		FROM  AC_DBE_CMMT_PRE_BID_SUB B              
		WHERE B.ECMS_PROJECT_NUM  = P_PROJNUM
		  AND B.BID_PACKAGE_NUM   = P_BIDPKGNUM
		  AND B.BUS_PARTNER_ID    = V_IN_PARTNER_ID   ;   



		SET V_ERRLOC = 'D040';  
		INSERT INTO AC_MPC_SUB_NAICS                   
		      (ECMS_PROJECT_NUM,                       
		       BID_PACKAGE_NUM,                        
		       BUS_PARTNER_ID,                         
		       AC_ITEM_NUM,                            
		       SUB_BP_SEQ_NUM,                         
		       NAICS_CODE)                             
		SELECT B.ECMS_PROJECT_NUM,                     
		       B.BID_PACKAGE_NUM,                      
		       B.BUS_PARTNER_ID,                       
		       V_AC_ITEM_NUM,                                      
		       B.SUB_BP_SEQ_NUM,                       
		       B.NAICS_CODE                            
		 FROM  AC_DBE_CMMT_PRE_BID_SUB_NAICS B         
		 WHERE B.ECMS_PROJECT_NUM  = P_PROJNUM
		   AND B.BID_PACKAGE_NUM   = P_BIDPKGNUM
		   AND B.BUS_PARTNER_ID    = V_IN_PARTNER_ID ;
		   
	END IF;		   
   
END WHILE;


OPEN SINGLE_PARM_CURSOR;

END P1
