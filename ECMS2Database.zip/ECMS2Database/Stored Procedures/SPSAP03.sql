CREATE PROCEDURE ECMSXADM.SPSAP03
		(
       		IN IN_ECMS_TRANSACTION_ID         INTEGER,
			IN IN_PAYMENT_ADJUSTMENT_IND      CHAR(1)
		)
		
          LANGUAGE SQL
            FENCED
       RESULT SETS 1
 NOT DETERMINISTIC
     EXTERNAL NAME SPSAP03
 MODIFIES SQL DATA
         NO DBINFO
            COLLID ECMSODBC
   WLM ENVIRONMENT DSNDWLM2
           ASUTIME LIMIT 10000
     STAY RESIDENT NO
      PROGRAM TYPE MAIN
          SECURITY DB2
  COMMIT ON RETURN NO
      RUN OPTIONS 'NOTEST(ALL,*,,VADTCPIP&10.27.80.85:*)'
------------------------------------------------------------------------
-- SQL Stored Procedure
------------------------------------------------------------------------
P1: BEGIN

/************************************/
/* SQL VARIABLE DECLARATIONS        */
/************************************/

 DECLARE   MAX_SAP_DOCUMENT_ID              INTEGER;
 DECLARE   HOLD_INTERFACE_ID                CHAR(16);
 DECLARE   HOLD_SOURCE_SYSTEM_NAME          CHAR(50);
 DECLARE   HOLD_TARGET_SYSTEM_NAME          CHAR(50);
 DECLARE   HOLD_INTERFACE_TYPE              CHAR(20);
 DECLARE   HOLD_ECMS_TRANSACTION_TYPE_CODE  CHAR(2);
 DECLARE   HOLD_PROJECT_ID                  CHAR(6);
 DECLARE   HOLD_FUNDS_COMMITMENT_DOC_NUM    CHAR(10);
 DECLARE   HOLD_AGREEMENT_PREFIX            CHAR(1);
 DECLARE   HOLD_PROJECT_PREFIX              CHAR(1);
 DECLARE SQLSTATE CHAR(5) DEFAULT '00000';
 DECLARE SQLCODE INT DEFAULT 0;
 DECLARE ERRLOC CHAR(4);
 DECLARE ERRCODE INTEGER;

/************************************************/
/* INITIALIZE                                   */
/************************************************/

  -- Declare return cursor
    DECLARE SINGLE_PARM_CURSOR CURSOR WITH RETURN
       FOR
     SELECT SQLCODE,
            SQLSTATE,
            ERRLOC,
            ERRCODE
       FROM SYSIBM.SYSDUMMY1;

    -- Declare handler
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
 /*        SET OUT_SQLCODE = SQLCODE ; */
 /*        SET OUT_SQLSTATE = SQLSTATE ; */
       OPEN SINGLE_PARM_CURSOR;

     -- Initialize return values
   SET ERRCODE = -1;
   SET ERRLOC = '0001';





/************************************************/
/* GET MAX ECMS TRANSACTION DOCUMENT ID        */
/***********************************************/

   SELECT COALESCE(MAX(SAP_TRANSACTION_DOCUMENT_ID),0)
      INTO MAX_SAP_DOCUMENT_ID
      FROM ECMSXADM.SAP_TRANSACTION ;

   SET MAX_SAP_DOCUMENT_ID = MAX_SAP_DOCUMENT_ID + 1;

/*************************************************/
/* GET VALUES FROM SAP PARAMETER TABLES (GPC)    */
/*************************************************/

  SET ERRLOC = '0002';

-- Interface ID
 SELECT GEN_CODE_VALUE
   INTO HOLD_INTERFACE_ID
   FROM ECMSXADM.COM_GENERAL_CODE
  WHERE GEN_CODE_TYPE = 905
    AND GEN_CODE = '08';

  SET ERRLOC = '0003';

-- Source System Name
 SELECT GEN_CODE_VALUE
   INTO HOLD_SOURCE_SYSTEM_NAME
   FROM ECMSXADM.COM_GENERAL_CODE
  WHERE GEN_CODE_TYPE = 905
    AND GEN_CODE = '04';

 SET ERRLOC = '0004';

 -- Target System Name
 SELECT GEN_CODE_VALUE
   INTO HOLD_TARGET_SYSTEM_NAME
   FROM ECMSXADM.COM_GENERAL_CODE
  WHERE GEN_CODE_TYPE = 905
    AND GEN_CODE = '05';

 SET ERRLOC = '0005';

-- Interface Type
 SELECT GEN_CODE_VALUE
   INTO HOLD_INTERFACE_TYPE
   FROM ECMSXADM.COM_GENERAL_CODE
  WHERE GEN_CODE_TYPE = 610
    AND GEN_CODE = '15';

/***********************************************************/
/* GET PROJECT ID AND BUILD FUNDS COMMITMENT DOC NUMBER    */
/***********************************************************/

  SET ERRLOC = '0006';

-- Project ID and Trans Type Code
 SELECT ECMS_PROJECT_ID, ECMS_TRANSACTION_TYPE_CODE, LEFT(ECMS_PROJECT_ID, 1)
   INTO HOLD_PROJECT_ID,
        HOLD_ECMS_TRANSACTION_TYPE_CODE,
        HOLD_AGREEMENT_PREFIX
   FROM ECMSXADM.SAP_ECMS_TRANSACTION
  WHERE ECMS_TRANSACTION_ID = IN_ECMS_TRANSACTION_ID;

  SET ERRLOC = '0007';

  IF HOLD_ECMS_TRANSACTION_TYPE_CODE = '03' AND HOLD_AGREEMENT_PREFIX = 'E'
     THEN SET HOLD_PROJECT_ID = '9' || RIGHT(HOLD_PROJECT_ID,5);
  END IF;

   SET ERRLOC = '0008';

  IF HOLD_ECMS_TRANSACTION_TYPE_CODE = '03'
    THEN SET HOLD_PROJECT_PREFIX = 'D';
    ELSE SET HOLD_PROJECT_PREFIX = 'V';
  END IF;

 SET ERRLOC = '0009';

  SET HOLD_FUNDS_COMMITMENT_DOC_NUM = HOLD_PROJECT_PREFIX || HOLD_PROJECT_ID || '000';


 /************************************/
 /* Build new SAP Transaction       */
 /************************************/

  SET ERRLOC = '0010';

 INSERT INTO ECMSXADM.SAP_TRANSACTION
	(
		SAP_TRANSACTION_DOCUMENT_ID,
        SAP_TRANSACTION_TYPE_CODE,
        SAP_TRANSACTION_STATUS_CODE,
        TRANSACTION_STATUS_TS,
        WORKFLOW_ID,
        ECMS_TRANSACTION_ID,
        SAP_ERROR_ID,
        INTERFACE_ID,
        INTERFACE_TYPE,
        TRANSACTION_DATE,
        TRANSACTION_TIME,
        SOURCE_SYSTEM_NAME,
        TARGET_SYSTEM_NAME,
        TARGET_DOCUMENT_ID,
        XML_MESSAGE_TYPE_CODE,
        CREATED_BY,
        CREATED_BY_TS,
        LAST_MODIFIED_BY,
        LAST_MODIFIED_TS
	) VALUES (
		MAX_SAP_DOCUMENT_ID,
         '03',
         '08',
         CURRENT_TIMESTAMP,
         NULL,
         IN_ECMS_TRANSACTION_ID,
         NULL,
         HOLD_INTERFACE_ID,
         HOLD_INTERFACE_TYPE,
         DATE(CURRENT_TIMESTAMP),
         TIME(CURRENT_TIMESTAMP),
         HOLD_SOURCE_SYSTEM_NAME,
         HOLD_TARGET_SYSTEM_NAME,
         NULL,
         '03',
         'ECMS SYSTEM',
         CURRENT_TIMESTAMP,
        'ECMS SYSTEM',
         CURRENT_TIMESTAMP
	);


 /************************************/
 /* Build new SAP Inquiry Transaction       */
 /************************************/

 SET ERRLOC = '0011';

 INSERT INTO ECMSXADM.SAP_INQUIRY_TRANSACTION
	(
        SAP_TRANSACTION_DOCUMENT_ID,
         PAYMENT_ADJUSTMENT_IND,
         SAP_ADJUSTMENT_LINE_NBR,
         FUNDS_COMMITMENT_DOCUMENT_NBR,
         CREATED_BY,
         CREATED_BY_TS,
         LAST_MODIFIED_BY,
         LAST_MODIFIED_TS 
	) VALUES (
 		MAX_SAP_DOCUMENT_ID,
         IN_PAYMENT_ADJUSTMENT_IND,
         '000',
         HOLD_FUNDS_COMMITMENT_DOC_NUM,
         'ECMS SYSTEM',
         CURRENT_TIMESTAMP,
         'ECMS SYSTEM',
         CURRENT_TIMESTAMP 
	);


    -- Cursor left open for client application
    SET ERRLOC = '0000';
    SET ERRCODE = 0;

    OPEN SINGLE_PARM_CURSOR;

END P1