CREATE PROCEDURE ECMSXADM.SPCA0021 (IN P_PROJNUM INTEGER , IN P_BIDPKGNUM SMALLINT , OUT P_SQLCODE INTEGER)
	VERSION V1
	ISOLATION LEVEL CS
	RESULT SETS 1
	LANGUAGE SQL
	ALLOW DEBUG MODE
	WLM ENVIRONMENT FOR DEBUG MODE DSNDWLM2
	P1: BEGIN


DECLARE V_SQLCODE                		INT     DEFAULT 0;      
DECLARE V_SQLSTATE               		CHAR(5) DEFAULT '00000';
DECLARE SQLCODE                  		INT     DEFAULT 0;      
DECLARE SQLSTATE                 		CHAR(5) DEFAULT '00000';
DECLARE V_PRJ_PREQ_REQD_IND      		CHAR(1) DEFAULT ' ';  
DECLARE V_APF_ITEM_NUMBER				CHAR(8) DEFAULT '        ';
DECLARE V_APF_ITEM_TYPE_CODE			CHAR(2) DEFAULT '  ';
DECLARE V_APF_WCC						CHAR(2) DEFAULT '  ';
DECLARE V_APF_AMT						DECIMAL (13,4) DEFAULT 0;
DECLARE V_APF_TOTAL						DECIMAL (13,4) DEFAULT 0;
DECLARE V_TOTAL_CREDIT					DECIMAL (13,4) DEFAULT 0;
DECLARE V_TOTAL_PRICE					DECIMAL (13,4) DEFAULT 0;
DECLARE V_TOTAL_QITEMS					DECIMAL (13,4) DEFAULT 0;
DECLARE V_TOTAL_XITEMS					DECIMAL (13,4) DEFAULT 0;
DECLARE V_TOTAL_ZZITEMS					DECIMAL (13,4) DEFAULT 0;
DECLARE V_TOTAL_ZITEMS					DECIMAL (13,4) DEFAULT 0;
DECLARE V_PB							DECIMAL (13,4) DEFAULT 0;
DECLARE V_CALCULATED_PERCENT			DECIMAL (13,4) DEFAULT 0;

DECLARE V_ACITEM_BPID					CHAR(6);
DECLARE V_EMAILNUM						SMALLINT DEFAULT 0;
DECLARE V_HOLD_ITEM_TYPE_CODE			CHAR(2) DEFAULT '  ';
DECLARE V_HOLD_ITEM_NUMBER				CHAR(8) DEFAULT '        ';
DECLARE V_AUTOMATIC_SUBTYPE				CHAR(1) DEFAULT '1';
DECLARE V_SYSTEM_USERID					CHAR(19) DEFAULT 'ECMS System/PennDOT';
DECLARE V_VERIFIED_APPARENT_LOW			CHAR(2)  DEFAULT '02';
DECLARE V_GEN_CODE_VALUE150             CHAR(150) DEFAULT '    ';
DECLARE V_PASSED_STATUS                 CHAR(1) DEFAULT '1';
DECLARE V_FAILED_STATUS                 CHAR(1) DEFAULT '2';

DECLARE V_BPID_ERRORS					CHAR(34) DEFAULT ' ';
DECLARE V_LENGTH						SMALLINT DEFAULT 0;






DECLARE V_PERCENT_REQUIREDTO_PASS		DECIMAL(5,2) DEFAULT 0;
DECLARE V_TEST_PASS                     CHAR(1) DEFAULT '1';  
-- 1 = ALL PASSED,  2 = ONE FAILED, 0 = NO PASSED STATE
DECLARE V_GP_GEN_CODE_VALUE             VARCHAR(255);
DECLARE V_PARM_GEN_CODE_TYPE     		SMALLINT DEFAULT 79;
DECLARE V_TYPE_CODE_FIFTYWCC			CHAR(3) DEFAULT '110';
DECLARE V_TYPE_CODE_FINCAP       		CHAR(3) DEFAULT '100';
DECLARE V_PROCESS_PRIME                 CHAR(1) DEFAULT 'Y';
DECLARE V_END_OF_CURSOR                 CHAR(1) DEFAULT 'N';
DECLARE V_END_OF_CURSOR_2				CHAR(1)	DEFAULT 'N';		
DECLARE V_PC_BUS_PARTNER_ID             CHAR(6) DEFAULT '      ';
DECLARE V_PRIME_BPID                    CHAR(6) DEFAULT '   ';
DECLARE V_PARENT_BPID                   CHAR(6) DEFAULT '   ';
DECLARE V_WCC_BPID  	                CHAR(6) DEFAULT '   ';
DECLARE V_GHC_BPID      	            CHAR(6) DEFAULT '   ';
DECLARE V_GENNED_ITEM_NUM        		SMALLINT DEFAULT 0;
DECLARE V_PC_CONTR_GHC_IND 				CHAR(1)	 DEFAULT ' ';
DECLARE V_PARM_STATUS                   CHAR(1)  DEFAULT ' ';
DECLARE V_ERRCD                         SMALLINT     DEFAULT 0;
DECLARE V_ERRLOC                        CHAR(5)      DEFAULT '     ';
DECLARE V_TABLEID                  		CHAR(12)     DEFAULT '$ECMSRETURN$';


DECLARE SINGLE_PARM_CURSOR CURSOR WITH RETURN
   FOR                                        
   SELECT V_TABLEID,                        
          V_SQLCODE,                          
          V_ERRCD,                          
          V_ERRLOC,
          V_BPID_ERRORS                    
     FROM SYSIBM.SYSDUMMY1    ;

DECLARE PROJCONTR CURSOR FOR
	SELECT A.BUS_PARTNER_ID               
	  FROM PROJ_CONTRACTOR A              
	 WHERE ECMS_PROJECT_NUM = P_PROJNUM 
	   AND PROJ_CONTR_TYPE IN ( 'P', 'J') 
	 ORDER BY PROJ_CONTR_TYPE DESC    ;
          

   
DECLARE APF CURSOR FOR                                   
	SELECT CI.ITEM_NUMBER,                                   
       CI.ITEM_TYPE_CODE,                                
       CIWCC.WORK_CLASS_CODE,                            
       VALUE (SUM(ITEM_ORIG_QTY * ITEM_UNIT_PRICE),0)    
  FROM CONST_ITEM CI,                                    
       CONST_ITEM_WCC CIWCC,                             
       CONTR_REG_WCC CRWCC                               
 WHERE CI.ECMS_PROJECT_NUM = P_PROJNUM                 
   AND CI.ECMS_PROJECT_NUM = CIWCC.ECMS_PROJECT_NUM      
   AND CI.ITEM_NUMBER = CIWCC.ITEM_NUMBER                
   AND CI.ITEM_TYPE_CODE = CIWCC.ITEM_TYPE_CODE          
   AND CIWCC.WORK_CLASS_CODE NOT IN ('Q ','Z ','X ','ZZ')
   AND CIWCC.WORK_CLASS_CODE = CRWCC.WORK_CLASS_CODE     
   AND CRWCC.BUS_PARTNER_ID = V_WCC_BPID                  
   AND CRWCC.WC_STATUS_CODE = '2'                        
 GROUP BY CI.ITEM_NUMBER,                                
          CI.ITEM_TYPE_CODE,                             
          CIWCC.WORK_CLASS_CODE                          
 ORDER BY CI.ITEM_NUMBER,                                
          CI.ITEM_TYPE_CODE ;

                                      


            
DECLARE EXIT HANDLER FOR SQLEXCEPTION

	BEGIN
	
	   SET V_SQLCODE = SQLCODE   ;
       SET V_ERRCD = -1;
       OPEN SINGLE_PARM_CURSOR;
       
   END;


SET V_TEST_PASS = '1';
SET V_ERRLOC = 'D010';   
SELECT DEC(GEN_CODE_VALUE,5,2)                
  INTO V_PERCENT_REQUIREDTO_PASS               
  FROM ECMSXADM.COM_GENERAL_CODE                       
 WHERE GEN_CODE_TYPE = 921 AND GEN_CODE = '05';
 
SET V_ERRLOC = 'D020';   
SELECT PREQ_REQD_IND                       
  INTO V_PRJ_PREQ_REQD_IND 
  FROM PROJECT                             
WHERE ECMS_PROJECT_NUM = P_PROJNUM ;

IF V_PRJ_PREQ_REQD_IND = ' ' OR V_PRJ_PREQ_REQD_IND IS NULL 
THEN
	SET V_PRJ_PREQ_REQD_IND = 'Y';
END IF;

SET V_ERRLOC = 'D030'; 
SELECT GEN_CODE_VALUE                      
INTO V_GP_GEN_CODE_VALUE                  
FROM ECMSXADM.COM_GENERAL_CODE                    
WHERE GEN_CODE_TYPE = V_PARM_GEN_CODE_TYPE 
  AND GEN_CODE = V_TYPE_CODE_FIFTYWCC ;

SET V_GEN_CODE_VALUE150 = SUBSTR(V_GP_GEN_CODE_VALUE, 1, 150);
  
IF V_PRJ_PREQ_REQD_IND = 'Y'
THEN
	OPEN PROJCONTR;
    SET V_PROCESS_PRIME       =  'Y';
    SET V_END_OF_CURSOR       =  'N';
    WHILE V_END_OF_CURSOR = 'N'
    DO
    SET V_ERRLOC = 'D040' ;     
    FETCH FROM PROJCONTR
    INTO   V_PC_BUS_PARTNER_ID;
    IF SQLCODE = 100
    THEN 
    	CLOSE PROJCONTR;  
        SET V_END_OF_CURSOR = 'Y';
   	ELSE
   			IF  V_PROCESS_PRIME = 'Y'
   			THEN
 				SET V_PROCESS_PRIME = 'N';
	         	SET V_PRIME_BPID = V_PC_BUS_PARTNER_ID;
	         	SET V_ACITEM_BPID  = V_PC_BUS_PARTNER_ID;	
	            
	            SET V_ERRLOC = 'D050'; 
	            SELECT COALESCE(MAX(AC_ITEM_NUM),0)                
				  INTO V_GENNED_ITEM_NUM             
				  FROM AC_ITEM                         
				 WHERE ECMS_PROJECT_NUM = P_PROJNUM  
				   AND BID_PACKAGE_NUM 	= P_BIDPKGNUM 
				   AND BUS_PARTNER_ID 	= V_PRIME_BPID;
	            
	            
	            	                 
	         	SET V_ERRLOC = 'D060'; 
	            SELECT PARENT_BP_ID                
	  			INTO V_PARENT_BPID                
	  			FROM ECMSXADM.CONTRACTOR                  
	 			WHERE BUS_PARTNER_ID = V_PRIME_BPID;
	 			 
	 			SET V_GHC_BPID = V_PARENT_BPID ;
	 			SET V_WCC_BPID = V_PARENT_BPID ;
	 		ELSE
	 		 	SET V_ACITEM_BPID = V_PC_BUS_PARTNER_ID ;
	 		 	SET V_GHC_BPID 	  = V_PC_BUS_PARTNER_ID ;	
	 		END IF;
	 			 
 			SET V_ERRLOC = 'D070';
 			SELECT CONTR_GHC_IND                       
  			INTO V_PC_CONTR_GHC_IND  
  			FROM ECMSXADM.PREQ_CONTRACTOR                     
 			WHERE BUS_PARTNER_ID = V_GHC_BPID  ;
	 			           		
 			IF V_PC_CONTR_GHC_IND IS NULL
 			THEN
 				SET V_PC_CONTR_GHC_IND = 'N'  ; -- NOT GHC-CONTRACTOR
 			END IF;
 			 
 			IF V_PC_CONTR_GHC_IND = 'Y'   -- GHC-CONTRACTOR
 			THEN
 				SET V_ERRLOC = 'D080';
 				SET V_PARM_STATUS = '1';
 				SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
			  INSERT INTO AC_ITEM       
			  ( ECMS_PROJECT_NUM,       
			    BID_PACKAGE_NUM,        
			    BUS_PARTNER_ID,         
			    AC_ITEM_NUM,            
			    AC_ITEM_CAT_CODE,       
			    AC_ITEM_TYPE_CODE,      
			    AC_ITEM_SUBMIT_TS,      
			    AC_ITEM_STATUS_TS,      
			    AC_ITEM_STATUS_CD,      
			    AC_ITEM_STATUS_BY,      
			    AC_ITEM_BP_ID,          
			    AC_ITEM_DEFLT_IND,      
			    CREATED_BY,             
			    CREATED_BY_TS,          
			    LAST_MODIFIED_BY,       
			    LAST_MODIFIED_TS,       
			    EDMS_DOC_LINK,          
			    AC_ITEM_TITLE,          
			    AC_ITEM_COMMENT )  
			   VALUES                  
			( P_PROJNUM,          
			  P_BIDPKGNUM,        
			  V_PRIME_BPID,          
			  V_GENNED_ITEM_NUM,  
			  V_AUTOMATIC_SUBTYPE,   
			  V_TYPE_CODE_FIFTYWCC,  
			  NULL,                 
			  CURRENT_TIMESTAMP,    
			  V_PARM_STATUS,         
			  V_SYSTEM_USERID,       
			  V_ACITEM_BPID,         
			  'Y',                  
			  V_SYSTEM_USERID,       
			  CURRENT_TIMESTAMP,    
			  V_SYSTEM_USERID,       
			  CURRENT_TIMESTAMP,    
			  NULL,                 
			  V_GEN_CODE_VALUE150,
			  NULL )   ;
			                     
 			ELSE
 			
 				OPEN APF ;
  				SET V_END_OF_CURSOR_2 =  'F';
				WHILE V_END_OF_CURSOR_2 = 'F'
				DO
					SET V_ERRLOC = 'D090';
					FETCH APF 
					INTO	V_APF_ITEM_NUMBER,   
  							V_APF_ITEM_TYPE_CODE,
  							V_APF_WCC,           
  							V_APF_AMT ;
  					IF SQLCODE = 100
  					THEN
  						SET V_END_OF_CURSOR_2 = 'V' ;
  						CLOSE APF;
  					ELSE
  						IF  V_APF_ITEM_NUMBER <> V_HOLD_ITEM_NUMBER
  						THEN
  							SET V_APF_TOTAL =	V_APF_TOTAL + V_APF_AMT	;
  							SET V_HOLD_ITEM_NUMBER = V_APF_ITEM_NUMBER;
  							SET V_HOLD_ITEM_TYPE_CODE =	V_APF_ITEM_TYPE_CODE ;	
  						ELSE
  							IF V_APF_ITEM_TYPE_CODE <> V_HOLD_ITEM_TYPE_CODE
  							THEN
  								SET V_APF_TOTAL = V_APF_TOTAL + V_APF_AMT;
  								SET V_HOLD_ITEM_TYPE_CODE = V_APF_ITEM_TYPE_CODE;
  							END IF;		
  						END IF;		
  					END IF;					
  				END WHILE;
  				
  				SET V_ERRLOC = 'D100';	
  				SELECT VALUE (SUM(ITEM_ORIG_QTY * ITEM_UNIT_PRICE),0) 
  				INTO V_TOTAL_QITEMS                                  
  				FROM ECMSXADM.CONST_ITEM CI,  
  					 ECMSXADM.CONST_ITEM_WCC CIWCC		                          
 				WHERE CI.ECMS_PROJECT_NUM 	= P_PROJNUM 
 				  AND CI.ECMS_PROJECT_NUM 	= CIWCC.ECMS_PROJECT_NUM
 				  AND CI.ITEM_NUMBER = CIWCC.ITEM_NUMBER      
				  AND CI.ITEM_TYPE_CODE = CIWCC.ITEM_TYPE_CODE
				  AND CIWCC.WORK_CLASS_CODE = 'Q '  ;          
 				 
   				  
   				SET V_ERRLOC = 'D110';
   				SELECT VALUE (SUM(ITEM_ORIG_QTY * ITEM_UNIT_PRICE),0)
  				INTO V_TOTAL_ZITEMS                                 
  				FROM CONST_ITEM CI,      
     				 CONST_ITEM_WCC CIWCC 
     			WHERE CI.ECMS_PROJECT_NUM = P_PROJNUM           
				  AND CI.ECMS_PROJECT_NUM = CIWCC.ECMS_PROJECT_NUM
				  AND CI.ITEM_NUMBER = CIWCC.ITEM_NUMBER          
				  AND CI.ITEM_TYPE_CODE = CIWCC.ITEM_TYPE_CODE    	    
   				  AND CIWCC.WORK_CLASS_CODE = 'Z '   ;
   				  
   				  
   				SET V_ERRLOC = 'D120';	                 
   				SELECT VALUE (SUM(ITEM_ORIG_QTY * ITEM_UNIT_PRICE),0)
  				INTO V_TOTAL_XITEMS                                 
  				FROM CONST_ITEM CI,      
     				 CONST_ITEM_WCC CIWCC                        
 				WHERE CI.ECMS_PROJECT_NUM = P_PROJNUM            
				  AND CI.ECMS_PROJECT_NUM = CIWCC.ECMS_PROJECT_NUM 
				  AND CI.ITEM_NUMBER = CIWCC.ITEM_NUMBER           
				  AND CI.ITEM_TYPE_CODE = CIWCC.ITEM_TYPE_CODE           
   				  AND CIWCC.WORK_CLASS_CODE = 'X '   ;               	   
   				
   				
   				SET V_ERRLOC = 'D130';	      
   				SELECT VALUE (SUM(ITEM_ORIG_QTY * ITEM_UNIT_PRICE),0)
  				INTO V_TOTAL_ZZITEMS                                
  				FROM CONST_ITEM CI,      
     				 CONST_ITEM_WCC CIWCC                       
 				WHERE CI.ECMS_PROJECT_NUM = P_PROJNUM            
				  AND CI.ECMS_PROJECT_NUM = CIWCC.ECMS_PROJECT_NUM 
				  AND CI.ITEM_NUMBER = CIWCC.ITEM_NUMBER           
				  AND CI.ITEM_TYPE_CODE = CIWCC.ITEM_TYPE_CODE         
				  AND CIWCC.WORK_CLASS_CODE = 'ZZ' ;
   				  
   				SET V_TOTAL_CREDIT = V_APF_TOTAL + V_TOTAL_QITEMS + V_TOTAL_ZITEMS ;
   				
   				SET V_ERRLOC = 'D140';	
   				SELECT VALUE (SUM(ITEM_ORIG_QTY * ITEM_UNIT_PRICE),0)
  				INTO V_PB                                           
  				FROM ECMSXADM.CONST_ITEM  
  				WHERE ECMS_PROJECT_NUM = P_PROJNUM;
  				  
 				
 				SET V_TOTAL_PRICE = ((V_PB - V_TOTAL_XITEMS) - V_TOTAL_ZZITEMS);
 				
 				IF V_TOTAL_PRICE <> 0
 				THEN
 					SET V_CALCULATED_PERCENT = (V_TOTAL_CREDIT / V_TOTAL_PRICE) * 100 ;
 				END IF;	
 				
 				IF V_CALCULATED_PERCENT >= V_PERCENT_REQUIREDTO_PASS
 				THEN
 					SET V_PARM_STATUS = V_PASSED_STATUS;
 				ELSE
 					SET V_PARM_STATUS = V_FAILED_STATUS;
 					SET V_BPID_ERRORS = TRIM(V_BPID_ERRORS) || V_PC_BUS_PARTNER_ID || ',';
 				END IF;	 	   				
   			  
   			  SET V_ERRLOC = 'D150';	
   			  SET V_GENNED_ITEM_NUM = V_GENNED_ITEM_NUM + 1;
			  INSERT INTO AC_ITEM       
			  ( ECMS_PROJECT_NUM,       
			    BID_PACKAGE_NUM,        
			    BUS_PARTNER_ID,         
			    AC_ITEM_NUM,            
			    AC_ITEM_CAT_CODE,       
			    AC_ITEM_TYPE_CODE,      
			    AC_ITEM_SUBMIT_TS,      
			    AC_ITEM_STATUS_TS,      
			    AC_ITEM_STATUS_CD,      
			    AC_ITEM_STATUS_BY,      
			    AC_ITEM_BP_ID,          
			    AC_ITEM_DEFLT_IND,      
			    CREATED_BY,             
			    CREATED_BY_TS,          
			    LAST_MODIFIED_BY,       
			    LAST_MODIFIED_TS,       
			    EDMS_DOC_LINK,          
			    AC_ITEM_TITLE,          
			    AC_ITEM_COMMENT )  
			   VALUES                  
			( P_PROJNUM,          
			  P_BIDPKGNUM,        
			  V_PRIME_BPID,          
			  V_GENNED_ITEM_NUM,  
			  V_AUTOMATIC_SUBTYPE,   
			  V_TYPE_CODE_FIFTYWCC,  
			  NULL,                 
			  CURRENT_TIMESTAMP,    
			  V_PARM_STATUS,         
			  V_SYSTEM_USERID,       
			  V_ACITEM_BPID,         
			  'Y',                  
			  V_SYSTEM_USERID,       
			  CURRENT_TIMESTAMP,    
			  V_SYSTEM_USERID,       
			  CURRENT_TIMESTAMP,    
			  NULL,                 
			  V_GEN_CODE_VALUE150,
			  NULL )   ;
  						
 			END IF;
                
    END IF;
   	END WHILE;  

SET V_ERRLOC = 'D160';   	
UPDATE CONTR_ECMS_BID_OPEN                                     
SET BID_STATUS_CODE = V_VERIFIED_APPARENT_LOW      
WHERE ECMS_PROJECT_NUM 	= P_PROJNUM                
  AND BID_PACKAGE_NUM 	= P_BIDPKGNUM               
  AND BUS_PARTNER_ID 	= V_PRIME_BPID                  
  AND 0 =                                           
  (SELECT COUNT(*) FROM AC_ITEM WHERE           
     AC_ITEM_TYPE_CODE 	= V_TYPE_CODE_FINCAP      
     AND ECMS_PROJECT_NUM 	= P_PROJNUM         
     AND BID_PACKAGE_NUM 	= P_BIDPKGNUM        
     AND BUS_PARTNER_ID 	= V_PRIME_BPID           
     AND AC_ITEM_STATUS_CD <> V_PASSED_STATUS )  
	 AND EXISTS                                        
       (SELECT ECMS_PROJECT_NUM FROM AC_ITEM WHERE   
          AC_ITEM_TYPE_CODE 	= V_TYPE_CODE_FINCAP      
          AND ECMS_PROJECT_NUM 	= P_PROJNUM         
          AND BID_PACKAGE_NUM 	= P_BIDPKGNUM        
          AND BUS_PARTNER_ID 	= V_PRIME_BPID)  ;        

END IF;

IF V_PRJ_PREQ_REQD_IND = 'N'
THEN
	SET V_ERRLOC = 'D170';
	SELECT A.BUS_PARTNER_ID                 
  	INTO V_PRIME_BPID                      
  	FROM PROJ_CONTRACTOR A                
 	WHERE A.ECMS_PROJECT_NUM = P_PROJNUM 
   	AND A.PROJ_CONTR_TYPE = 'P' ; 
      	
   	SET V_ERRLOC = 'D180';
  	UPDATE CONTR_ECMS_BID_OPEN                               
    SET BID_STATUS_CODE 	= V_VERIFIED_APPARENT_LOW
 	WHERE ECMS_PROJECT_NUM 	= P_PROJNUM          
   	  AND BID_PACKAGE_NUM 	= P_BIDPKGNUM         
   	  AND BUS_PARTNER_ID 	= V_PRIME_BPID ;            
END IF;
        
OPEN SINGLE_PARM_CURSOR;




END P1
