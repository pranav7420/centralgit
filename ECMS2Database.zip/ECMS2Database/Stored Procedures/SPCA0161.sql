CREATE PROCEDURE ECMSXADM.SPCA0161 (IN P_PROJNUM  INTEGER , OUT P_SQLCODE INTEGER)
	VERSION V1
	ISOLATION LEVEL CS
	RESULT SETS 1
	LANGUAGE SQL
	ALLOW DEBUG MODE
	WLM ENVIRONMENT FOR DEBUG MODE DSNDWLM2
	P1: BEGIN

DECLARE V_SQLCODE                		INT     		DEFAULT 0;      
DECLARE V_SQLSTATE               		CHAR(5) 		DEFAULT '00000';
DECLARE SQLCODE                  		INT     		DEFAULT 0;      
DECLARE SQLSTATE                 		CHAR(5) 		DEFAULT '00000';
DECLARE V_TABLEID                  		CHAR(12)    	DEFAULT '$ECMSRETURN$';
DECLARE V_ERRCD                         SMALLINT    	DEFAULT 0;
DECLARE V_ERRLOC                        CHAR(5)     	DEFAULT '     ';
DECLARE V_END_OF_CURSOR                 CHAR(1)      	DEFAULT 'N';
DECLARE V_END_OF_BID_CURSOR				CHAR(1)			DEFAULT 'N';

DECLARE V_GPC_CLOSED					CHAR(1)			DEFAULT 'T';
DECLARE V_BID_CLOSED					CHAR(1)			DEFAULT 'T';

DECLARE V_GEN_CODE						CHAR(5)			DEFAULT ' ';						
DECLARE V_GEN_CODE_VALUE				VARCHAR(255) 	DEFAULT ' ';
DECLARE V_MIN_PCT_DIFF_MIN_AMT			INTEGER			DEFAULT 0;
DECLARE V_MIN_PCT_DIFF_MIN_LOW			DECIMAL(5,2)	DEFAULT 1;
DECLARE V_MIN_PCT_DIFF_MIN_HI			DECIMAL(5,2)    DEFAULT 0.5;
DECLARE V_NBR_OF_BIDDERS				SMALLINT		DEFAULT 3;
DECLARE V_BID_PACKAGE_NUM				SMALLINT		DEFAULT 0;
DECLARE V_AC_ITEM_NUM					SMALLINT 		DEFAULT 0;
DECLARE V_CONT_BID_TOT_AMT				DECIMAL(15,2)	DEFAULT 0;
DECLARE V_BUS_PARTNER_ID				CHAR(6)			DEFAULT ' ';
DECLARE V_EST_PROJ_AMT					DECIMAL(15,2)	DEFAULT 0;
DECLARE V_MIN_PCT_WRT_PROJ				DECIMAL(5,2)	DEFAULT 0;
DECLARE V_SAVE_LINE_ITEM_NUM			SMALLINT		DEFAULT 0;
DECLARE V_LINE_ITEM_NUM					SMALLINT		DEFAULT 0;
DECLARE V_DSGN_ITEM_AMT                 DECIMAL(15,2) 	DEFAULT 0;
DECLARE V_WRK_PCT_DIFF					DECIMAL(15,2)	DEFAULT 0;
DECLARE V_ITEM_PCT_DIFF					DECIMAL(5,2)	DEFAULT 0;
DECLARE V_BID_ITEM_AMT 					DECIMAL(15,2)	DEFAULT 0;
DECLARE V_DESIGN_ITEM_COUNT				SMALLINT		DEFAULT 0;	
DECLARE V_LI_STATUS_CODE				CHAR(1)			DEFAULT ' ';	
DECLARE V_BID_RANKING					SMALLINT		DEFAULT 0;	
DECLARE V_BID_BPID						CHAR(6)			DEFAULT '  ';
DECLARE V_BID_TOTAL_AMT					DECIMAL(15,2) 	DEFAULT 0;
DECLARE V_BID_PRICE						DECIMAL(15,4)	DEFAULT 0;
DECLARE V_BID_QTY						DECIMAL(15,3)	DEFAULT 0;
DECLARE V_ITEM_NUMBER					CHAR(8)			DEFAULT ' ';
DECLARE V_DSGN_PRICE					DECIMAL(15,4)	DEFAULT 0;
DECLARE V_DSGN_QTY						DECIMAL(15,3)	DEFAULT 0;
DECLARE V_ITEM_UNIT_MEASURE				CHAR(5)			DEFAULT ' ';
DECLARE V_ITEM_DESC						VARCHAR(255)	DEFAULT ' ';
DECLARE V_ITEM_MOD_DESC					VARCHAR(100)	DEFAULT ' ';
DECLARE V_PCT_DIFF_EST_LOW				DECIMAL(5,2)	DEFAULT 0;
DECLARE V_PROJ_PCT_DIFF					DECIMAL(5,2)	DEFAULT 0;
DECLARE V_USER_ID						VARCHAR(80)		DEFAULT 'Ecms System/PennDOT';








DECLARE SINGLE_PARM_CURSOR CURSOR WITH RETURN
   FOR                                        
   SELECT                         
          V_SQLCODE,                          
          V_ERRCD,                          
          V_ERRLOC                         
                              
     FROM SYSIBM.SYSDUMMY1    ;
     
     
     
DECLARE GPC_CURSOR CURSOR FOR
	SELECT GEN_CODE, GEN_CODE_VALUE
	FROM COM_GENERAL_CODE   
	WHERE GEN_CODE_TYPE = 99
	ORDER BY GEN_CODE ;
	

DECLARE BID_CURSOR CURSOR FOR 
  SELECT                      
      A.BID_RANKING,          
      A.BUS_PARTNER_ID,       
      A.CONT_BID_TOT_AMT,     
                          
      B.ITEM_UNIT_PRICE,      
      B.BID_ITEM_PRICE,       
      B.ITEM_QTY,             
                              
      C.LINE_ITEM_NUM,        
      C.ITEM_NUMBER,          
      C.ITEM_UNIT_PRICE,      
      C.ITEM_QTY,             
      C.TOTAL_ITEM_AMT,       
      C.ITEM_UNIT_MEASURE,    
      C.ITEM_DESC,            
      C.ITEM_MOD_DESC    
          
  FROM CONTR_ECMS_BID_OPEN A,     
     CONTR_ECMS_BID_ITEM_OPEN B,
     DESIGN_ITEM C   
     
  WHERE A.ECMS_PROJECT_NUM = P_PROJNUM  
	AND B.ECMS_PROJECT_NUM = A.ECMS_PROJECT_NUM 
	AND C.ECMS_PROJECT_NUM = A.ECMS_PROJECT_NUM 
	AND A.BID_PACKAGE_NUM  = V_BID_PACKAGE_NUM
	AND A.BID_PACKAGE_NUM = B.BID_PACKAGE_NUM   
	AND NOT A.BID_RANKING > V_NBR_OF_BIDDERS  
	AND A.BUS_PARTNER_ID = B.BUS_PARTNER_ID     
	AND B.LINE_ITEM_NUM = C.LINE_ITEM_NUM       
	AND COALESCE(C.IB_ITEM_TYPE_CODE,'') NOT IN 
		(SELECT GEN_CODE FROM COM_GENERAL_CODE 
		 WHERE GEN_CODE_TYPE = 119)  
		 
ORDER BY C.LINE_ITEM_NUM, A.BID_RANKING ;                                        	
	


	
DECLARE EXIT HANDLER FOR SQLEXCEPTION

-- declare continue handler for SQLEXCEPTION

	BEGIN
	
       
       SET V_SQLCODE = SQLCODE   ;
       SET V_ERRCD = -1;
       OPEN SINGLE_PARM_CURSOR;
       
	END;
		

	  
SET V_ERRLOC = 'D010';
OPEN GPC_CURSOR;
WHILE V_END_OF_CURSOR = 'N'
 DO
  FETCH FROM GPC_CURSOR
  INTO   V_GEN_CODE, V_GEN_CODE_VALUE;
  IF SQLCODE = 100
  THEN 
      CLOSE GPC_CURSOR;  
      SET V_END_OF_CURSOR = 'Y';
  ELSE
  	  IF V_GEN_CODE = '01'
      THEN
          SET V_MIN_PCT_DIFF_MIN_AMT = CAST(TRIM(SUBSTR(V_GEN_CODE_VALUE, 1, 9)) AS INTEGER);
      ELSE
      	  IF V_GEN_CODE = '02'
      	  THEN
      	      SET V_MIN_PCT_DIFF_MIN_LOW = CAST(TRIM(SUBSTR(V_GEN_CODE_VALUE, 1, 4)) / 100 AS DECIMAL(5,2) ) ;
      	  ELSE
      	  	  IF  V_GEN_CODE = '03'
      	  	  THEN
      	  	  	  SET V_MIN_PCT_DIFF_MIN_HI = CAST(TRIM(SUBSTR(V_GEN_CODE_VALUE, 1, 4)) / 100 AS DECIMAL(5,2) ) ;
      	  	  ELSE
      	  	  	  IF V_GEN_CODE = '04'
      	  	  	  THEN
      	  	  	  	  SET V_NBR_OF_BIDDERS = CAST(TRIM(SUBSTR(V_GEN_CODE_VALUE, 1, 2)) AS SMALLINT );
      	  	  	  END IF;
      	  	  END IF;
      	  END IF;	   	  	  
      END IF;	

  END IF;
  
END WHILE; 
                  
SET V_ERRLOC = 'D020';
SELECT                                          
     A.CURR_BID_PKG_NUM,                        
     B.AC_ITEM_NUM,                             
     CONT_BID_TOT_AMT,                          
     C.BUS_PARTNER_ID,                          
     FLOAT(A.EST_PROJECT_AMT) AS EST_PROJECT_AMT
     
INTO V_BID_PACKAGE_NUM, V_AC_ITEM_NUM, V_CONT_BID_TOT_AMT, 
  	   V_BUS_PARTNER_ID, V_EST_PROJ_AMT
  	   
FROM PROJECT A, AC_ITEM B, CONTR_ECMS_BID_OPEN C
  
WHERE A.ECMS_PROJECT_NUM  = P_PROJNUM  
    AND   A.ECMS_PROJECT_NUM  = B.ECMS_PROJECT_NUM
	AND   A.ECMS_PROJECT_NUM  = C.ECMS_PROJECT_NUM
	AND   A.CURR_BID_PKG_NUM  = B.BID_PACKAGE_NUM 
	AND   A.CURR_BID_PKG_NUM  = C.BID_PACKAGE_NUM 
	AND   C.BUS_PARTNER_ID    = B.BUS_PARTNER_ID  
	AND   B.AC_ITEM_TYPE_CODE = '120'             
	AND   C.BID_RANKING       = 1
	    
GROUP BY A.ECMS_PROJECT_NUM,           
		A.CURR_BID_PKG_NUM,                
		B.AC_ITEM_NUM,                     
		CONT_BID_TOT_AMT,                  
		C.BUS_PARTNER_ID, A.EST_PROJECT_AMT	   ;  
 			
 			        	      
  -- TEST FOR MISSING DATA	                  
IF V_EST_PROJ_AMT 	IS NULL  OR
     V_CONT_BID_TOT_AMT IS NULL 
THEN    
     SET V_ERRLOC = 'A011';
     SET V_ERRCD  = -1;
     OPEN SINGLE_PARM_CURSOR;
     RETURN -200;
END IF;
  
  -- DETERMINE MINIMUM PERCENT DIFFERENCE
  -- WITH RESPECT TO PROJECT %
IF V_EST_PROJ_AMT < V_MIN_PCT_DIFF_MIN_AMT
THEN
  	  SET V_MIN_PCT_WRT_PROJ = V_MIN_PCT_DIFF_MIN_LOW;
ELSE
  	  SET V_MIN_PCT_WRT_PROJ = V_MIN_PCT_DIFF_MIN_HI;
END IF;	  	  
     
  -- CALCULATE PERCENT DIFFERENCE FROM LOW BIDDER
SET V_PCT_DIFF_EST_LOW = ((V_CONT_BID_TOT_AMT - V_EST_PROJ_AMT) * 100.00) / V_EST_PROJ_AMT;

--SET V_PCT_DIFF_EST_LOW =  CAST ( ROUND (FLOAT((V_CONT_BID_TOT_AMT - V_EST_PROJ_AMT) * 100) /
--						FLOAT(V_EST_PROJ_AMT), 2) AS DECIMAL (5,2) );

  
  SET V_ERRLOC = 'D030';              
  INSERT INTO AC_LI_PROFILE                 
  (ECMS_PROJECT_NUM,                  
   BID_PACKAGE_NUM,                   
   BUS_PARTNER_ID,                    
   AC_ITEM_NUM,                       
   MIN_PCT_WRT_PROJ,                  
   PCT_DIFF_EST_LOW,                  
   EST_PROJECT_AMT,                   
   CREATED_BY, CREATED_BY_TS,         
   LAST_MODIFIED_BY, LAST_MODIFIED_TS,
   DESIGN_ITEM_COUNT)                 
  VALUES                                    
  (P_PROJNUM,                   
   V_BID_PACKAGE_NUM,               
   V_BUS_PARTNER_ID,                
   V_AC_ITEM_NUM,                   
   V_MIN_PCT_WRT_PROJ,              
   V_PCT_DIFF_EST_LOW,              
   V_EST_PROJ_AMT,                  
   V_USER_ID, CURRENT_TIMESTAMP,    
   V_USER_ID, CURRENT_TIMESTAMP,    
   0)    ;                                         
  
  
SET V_ERRLOC = 'D040';
OPEN BID_CURSOR;
SET V_END_OF_BID_CURSOR = 'N' ;
WHILE V_END_OF_BID_CURSOR = 'N'
DO
  FETCH FROM BID_CURSOR                          
  INTO	V_BID_RANKING,                     
	     		V_BID_BPID,                        
			    V_BID_TOTAL_AMT,                   
			                                          
			    V_BID_PRICE,                       
			    V_BID_ITEM_AMT,                    
			    V_BID_QTY,                         
			                                         
			    V_LINE_ITEM_NUM,                   
			    V_ITEM_NUMBER,                     
			    V_DSGN_PRICE,                      
			    V_DSGN_QTY,                        
			    V_DSGN_ITEM_AMT,
			    V_ITEM_UNIT_MEASURE,               
			    V_ITEM_DESC,                       
			    V_ITEM_MOD_DESC ;
		
 IF SQLCODE = 100
 THEN 
 	CLOSE BID_CURSOR;  
 	SET V_END_OF_BID_CURSOR = 'Y';
 ELSE
      IF V_LINE_ITEM_NUM <> V_SAVE_LINE_ITEM_NUM 
      THEN
   		  SET V_DESIGN_ITEM_COUNT = V_DESIGN_ITEM_COUNT + 1;   
		  SET V_ERRLOC = 'D050';
          INSERT INTO AC_LI_PROFILE_ITEM              
		    (ECMS_PROJECT_NUM,                         
		     BID_PACKAGE_NUM,                          
		     BUS_PARTNER_ID,  
		                      
		     AC_ITEM_NUM,                              
		     LINE_ITEM_NUM,                            
		     ITEM_NUMBER,                              
		     ITEM_QTY,                                 
		     ITEM_UNIT_MEASURE,                        
		     BID_JUST_SEL_IND,                         
		     ITEM_DESC,                                
		     ITEM_MOD_DESC)                            
		 VALUES                                      
		 (P_PROJNUM,                          
		  V_BID_PACKAGE_NUM,                      
		  V_BUS_PARTNER_ID,  
		  V_AC_ITEM_NUM,                          
		  V_LINE_ITEM_NUM,                        
		  V_ITEM_NUMBER,                          
		  V_DSGN_QTY,                             
		  V_ITEM_UNIT_MEASURE,                    
		  NULL,                                     
		  V_ITEM_DESC,                            
		  V_ITEM_MOD_DESC); 
					        
		SET V_SAVE_LINE_ITEM_NUM = V_LINE_ITEM_NUM ;
	 END IF;		    
	
	-- COMPUTE ITEM PERCENTAGE DIFFERENCE AMOUNT
	IF V_DSGN_ITEM_AMT IS NULL  OR
   		V_DSGN_ITEM_AMT = 0
	THEN
		SET V_ITEM_PCT_DIFF = 100;
	ELSE
		SET V_WRK_PCT_DIFF = ((V_BID_ITEM_AMT - V_DSGN_ITEM_AMT) * 100.00) / V_DSGN_ITEM_AMT ;
	--	SET V_WRK_PCT_DIFF = CAST ( ROUND (FLOAT ((V_BID_ITEM_AMT - V_DSGN_ITEM_AMT) * 100) / FLOAT(V_DSGN_ITEM_AMT) , 2) AS DECIMAL (15,2) );
	
      
	    IF V_WRK_PCT_DIFF > 999.99 
	    THEN
	    	SET V_ITEM_PCT_DIFF = 999.99  ;           
	    ELSE                                                
	         IF V_WRK_PCT_DIFF  <   -999.99
	         THEN
	         	SET V_ITEM_PCT_DIFF = -999.99  ;            
	         ELSE 
	         	SET V_ITEM_PCT_DIFF = V_WRK_PCT_DIFF;
	         END IF;  
	    END IF;                                         
	END IF;	
    
	SET V_PROJ_PCT_DIFF = ((V_BID_ITEM_AMT - V_DSGN_ITEM_AMT) * 100.00) / V_EST_PROJ_AMT;
	--SET V_PROJ_PCT_DIFF = CAST ( ROUND( FLOAT((V_BID_ITEM_AMT - V_DSGN_ITEM_AMT) * 100) / FLOAT(V_EST_PROJ_AMT), 2) AS DECIMAL (15,2) ); 
	
    
	 SET V_ERRLOC = 'D060';
	 INSERT INTO AC_LI_PROFILE_BID
	  (ECMS_PROJECT_NUM,          
	   BID_PACKAGE_NUM,           
	   BUS_PARTNER_ID,            
	   AC_ITEM_NUM,               
	   LINE_ITEM_NUM,             
	   BID_BP_ID,                 
	   ITEM_TOTAL_AMT,            
	   ITEM_UNIT_PRICE,           
	   ITEM_PCT_DIFF,             
	   PROJ_PCT_DIFF,             
	   BID_RANKING,               
	   ITEM_QTY)                  
	 VALUES                       
	  (P_PROJNUM,           
	   V_BID_PACKAGE_NUM,       
	   V_BUS_PARTNER_ID,        
	   V_AC_ITEM_NUM,           
	   V_LINE_ITEM_NUM,         
	   V_BID_BPID,              
	   V_BID_ITEM_AMT,          
	   V_BID_PRICE,             
	   V_ITEM_PCT_DIFF,         
	   V_PROJ_PCT_DIFF,         
	   V_BID_RANKING,           
	   V_BID_QTY)  ;     
		 
	SET V_ERRLOC = 'D070';  
	UPDATE AC_LI_PROFILE                             
	 SET DESIGN_ITEM_COUNT 		= V_DESIGN_ITEM_COUNT
	 WHERE ECMS_PROJECT_NUM   	= P_PROJNUM         
	   AND BID_PACKAGE_NUM    	= V_BID_PACKAGE_NUM     
	   AND BUS_PARTNER_ID     	= V_BUS_PARTNER_ID      
	   AND AC_ITEM_NUM        	= V_AC_ITEM_NUM     ;  
			   
	SET V_LI_STATUS_CODE = '6';        
	 
	SET V_ERRLOC = 'D080';	 
	UPDATE AC_BID_JUST                            
	   SET AC_LI_STATUS_CODE 	= V_LI_STATUS_CODE
	WHERE ECMS_PROJECT_NUM  = P_PROJNUM       
	  AND BID_PACKAGE_NUM   = V_BID_PACKAGE_NUM   
	  AND BUS_PARTNER_ID    = V_BUS_PARTNER_ID    
	  AND AC_ITEM_NUM       = V_AC_ITEM_NUM ;
             
    

  END IF;
       
END WHILE;                  



OPEN SINGLE_PARM_CURSOR;



END P1
