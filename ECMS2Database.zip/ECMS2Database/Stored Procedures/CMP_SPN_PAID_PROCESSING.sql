CREATE PROCEDURE CMP_SPN_PAID_PROCESSING (
		OUT OUT_SQLSTATE CHAR(5),
		OUT OUT_SQLCODE INTEGER,
		OUT OUT_ERRORLOC VARCHAR(80),
		OUT OUT_ERRCODE INTEGER
	)

	RESULT SETS 1
	LANGUAGE SQL
	QUALIFIER ECMSXADM
	VALIDATE BIND
	ISOLATION LEVEL CS
	PACKAGE OWNER HWYDEV
	ALLOW DEBUG MODE
	ASUTIME LIMIT 120000
	WLM ENVIRONMENT FOR DEBUG MODE DSNDWLM2	
	
P1: BEGIN
    
/*************************/
/* VARIABLE DECLARATIONS */
/*************************/
DECLARE HOLD_SPN_SAP_AGREEMENT_AMT              DECIMAL(13, 2);
DECLARE HOLD_SPN_SAP_LOCAL_PORTION_AMT          DECIMAL(13, 2);
DECLARE HOLD_SPN_SAP_PROJECT_AMT                DECIMAL(13, 2);
DECLARE HOLD_ZERO_VALUE                         DECIMAL(13, 2) DEFAULT 0.00;
DECLARE HOLD_STATE_PROJECT_NUMBER               CHAR(18);
DECLARE SPN_SAP_AGR_PAID_COMPLETE               SMALLINT    DEFAULT 0;
DECLARE SPN_SAP_PRJ_PAID_COMPLETE               SMALLINT    DEFAULT 0;
DECLARE PAID_LOCAL_AMT_COMPLETE                 SMALLINT    DEFAULT 0;
DECLARE HOLD_LAST_MODIFIED_BY                   CHAR(40) DEFAULT 'ECMS CMP_SPN_PAID_PROCESSING';

/**********************************************************/
/* THESE VARIABLES ARE PASSED BACK TO THE CALLING PROGRAM */
/**********************************************************/
DECLARE SQLSTATE CHAR(5) DEFAULT '00000';
DECLARE SQLCODE  INT     DEFAULT 0;

/********************************************************************/
/* DECLARE A CURSOR TO READ THE INV AMTS FOR SPN IN PAID STATUS   */
/********************************************************************/
DECLARE SPN_INV_PAID_AMTS CURSOR FOR

 SELECT SD.STATE_PROJECT_NBR,
        SUM(COALESCE(SD.INVOICED_AMT,0)) AS SPN_AGREEMENT_AMT
        
   FROM INV_HIERARCHY I
                                                            
  INNER JOIN INV_WRAPPER W
     ON W.AGR = I.AGR 
    AND W.INV_ID = I.PRIME_INV_ID 
                                                            
  INNER JOIN SAP_TRANSACTION S
     ON S.ECMS_TRANSACTION_ID = W.ECMS_TRANSACTION_ID
    AND S.SAP_TRANSACTION_TYPE_CODE = '01'  --<== SAP transaction type 'Payment'
    --11-Paid, 99-Bypassed, 04-Pending Transmission to Treasury, 05-Treasury Review/Pending Payment
    --AND S.SAP_TRANSACTION_STATUS_CODE IN ('11', '99', '04', '05') 
  INNER JOIN INV_SPN_DETAIL SD
     ON SD.AGR = I.AGR
    AND SD.INV_ID = I.INV_ID

  WHERE I.INV_STATUS_CODE = '20' --<== Invoice status 'Approved'
    AND SD.STATE_PROJECT_NBR IS NOT NULL
    AND SD.INVOICED_AMT <> 0
    AND ((S.SAP_TRANSACTION_STATUS_CODE IN ('11', '99', '04', '05'))
     OR (S.SAP_TRANSACTION_STATUS_CODE = '02' AND TIMESTAMP(DATE(TRANSACTION_STATUS_TS) + 1 DAY) + 90 MINUTES < CURRENT TIMESTAMP)) 
    
 GROUP BY SD.STATE_PROJECT_NBR 
 ORDER BY SD.STATE_PROJECT_NBR;

/********************************************************************/
/* DECLARE A CURSOR TO READ THE EST AMTS FOR SPN IN PAID STATUS   */
/********************************************************************/
DECLARE SPN_EST_PAID_AMTS CURSOR FOR

 SELECT SD.STATE_PROJECT_NBR,
        SUM(COALESCE(SD.ESTIMATE_AMT,0)) AS SPN_PROJECT_AMT
        
   FROM ESTIMATE E
                                                            
  INNER JOIN SAP_TRANSACTION S
     ON S.ECMS_TRANSACTION_ID = E.ECMS_TRANSACTION_ID
    AND S.SAP_TRANSACTION_TYPE_CODE = '01' --<== SAP transaction type 'Payment'
    --11-Paid, 99-Bypassed, 04-Pending Transmission to Treasury, 05-Treasury Review/Pending Payment 
    --AND S.SAP_TRANSACTION_STATUS_CODE IN ('11', '99', '04', '05')

  INNER JOIN EST_SPN_DETAIL SD
     ON SD.ECMS_PROJECT_NUM = E.ECMS_PROJECT_NUM
    AND SD.ESTIMATE_NUM = E.ESTIMATE_NUM

  WHERE E.EST_STATUS_CODE = '30' --<== Estimate status 'Approved'
    AND SD.STATE_PROJECT_NBR IS NOT NULL
    AND SD.ESTIMATE_AMT <> 0
    AND ((S.SAP_TRANSACTION_STATUS_CODE IN ('11', '99', '04', '05'))
     OR (S.SAP_TRANSACTION_STATUS_CODE = '02' AND TIMESTAMP(DATE(TRANSACTION_STATUS_TS) + 1 DAY) + 90 MINUTES < CURRENT TIMESTAMP)) 
    
 GROUP BY SD.STATE_PROJECT_NBR 
 ORDER BY SD.STATE_PROJECT_NBR;

/******************************************************************************/
/*DECLARE A CURSOR TO READ INV AND EST LOCAL AMOUNTS FOR SPN IN PAID STATUS */
/******************************************************************************/
DECLARE PAID_LOCAL_AMT CURSOR FOR

SELECT TEMP.STATE_PROJECT_NBR, 
       SUM(TEMP.LOCAL_AMT) AS SAP_LOCAL_PORTION_AMT 
       
  FROM (SELECT SD.STATE_PROJECT_NBR, SD.LOCAL_AMT

        FROM   INV_HIERARCHY I 
        
        INNER JOIN INV_WRAPPER W 
           ON W.AGR = I.AGR 
          AND W.INV_ID = I.PRIME_INV_ID 
               
        INNER JOIN SAP_TRANSACTION S 
           ON S.ECMS_TRANSACTION_ID = W.ECMS_TRANSACTION_ID 
          AND S.SAP_TRANSACTION_TYPE_CODE = '01' --<== SAP transaction type 'Payment'
          --11-Paid, 99-Bypassed, 04-Pending Transmission to Treasury, 05-Treasury Review/Pending Payment 
          --AND S.SAP_TRANSACTION_STATUS_CODE IN ( '11', '99', '04', '05')  
               
        INNER JOIN INV_SPN_DETAIL SD 
           ON SD.AGR = I.AGR 
          AND SD.INV_ID = I.INV_ID 
               
        WHERE  I.INV_STATUS_CODE = '20' --<== Invoice status 'Approved' 
          AND SD.STATE_PROJECT_NBR IS NOT NULL 
          AND SD.LOCAL_AMT <> 0 
          AND ((S.SAP_TRANSACTION_STATUS_CODE IN ('11', '99', '04', '05'))
           OR (S.SAP_TRANSACTION_STATUS_CODE = '02' AND TIMESTAMP(DATE(TRANSACTION_STATUS_TS) + 1 DAY) + 90 MINUTES < CURRENT TIMESTAMP))
               
        UNION ALL
        
        SELECT SD.STATE_PROJECT_NBR, SD.LOCAL_AMT
                
        FROM   ESTIMATE E 
        
        INNER JOIN SAP_TRANSACTION S 
           ON S.ECMS_TRANSACTION_ID = E.ECMS_TRANSACTION_ID 
          AND S.SAP_TRANSACTION_TYPE_CODE = '01' --<== SAP transaction type 'Payment'
         --11-Paid, 99-Bypassed, 04-Pending Transmission to Treasury, 05-Treasury Review/Pending Payment
          --AND S.SAP_TRANSACTION_STATUS_CODE IN ( '11', '99', '04', '05' )   
          
        INNER JOIN EST_SPN_DETAIL SD 
           ON SD.ECMS_PROJECT_NUM = E.ECMS_PROJECT_NUM 
          AND SD.ESTIMATE_NUM = E.ESTIMATE_NUM 
          
        WHERE E.EST_STATUS_CODE = '30' --<== Estimate status 'Approved'
          AND SD.STATE_PROJECT_NBR IS NOT NULL 
          AND SD.LOCAL_AMT <> 0
          AND ((S.SAP_TRANSACTION_STATUS_CODE IN ('11', '99', '04', '05'))
           OR (S.SAP_TRANSACTION_STATUS_CODE = '02' AND TIMESTAMP(DATE(TRANSACTION_STATUS_TS) + 1 DAY) + 90 MINUTES < CURRENT TIMESTAMP))) TEMP 
GROUP  BY TEMP.STATE_PROJECT_NBR 
ORDER  BY TEMP.STATE_PROJECT_NBR; 

/*******************/
/* DECLARE HANDLER */
/*******************/
DECLARE EXIT HANDLER FOR SQLEXCEPTION

/************************************/
/* INITIALIZE THE RETURN PARAMETERS.*/
/************************************/
SET OUT_SQLSTATE = SQLSTATE;
SET OUT_SQLCODE = SQLCODE;
SET OUT_ERRORLOC = '0001';
SET OUT_ERRCODE = -1;

/**************************************/
/* OPEN THE SPN_INV_PAID_AMTS CURSOR  */
/**************************************/
OPEN SPN_INV_PAID_AMTS;

/**********************************************/
/* LOOP THROUGHT THE LIST AND UPDATE THE TABLE*/
/**********************************************/
SET OUT_ERRORLOC = '0002';

WHILE SPN_SAP_AGR_PAID_COMPLETE = 0 DO

    FETCH
        SPN_INV_PAID_AMTS
    INTO
        HOLD_STATE_PROJECT_NUMBER,
       HOLD_SPN_SAP_AGREEMENT_AMT               
        ;       

/*******************************************/
/* SQLCODE 100 SIGNIFIES NO RECORD FETCHED */
/*******************************************/        
    IF SQLCODE = 100 THEN
        SET SPN_SAP_AGR_PAID_COMPLETE = 1;
   
/*******************************************/
/* IF NO RECORDS FOUND, CLOSE THE CURSOR   */
/*******************************************/    
        CLOSE SPN_INV_PAID_AMTS;

        ELSE

        SET OUT_ERRORLOC = '0003'||','||'ERROR IN UPDATING SPN'||','||HOLD_STATE_PROJECT_NUMBER;

/*************************************************************/
/* UPDATE THE RECORD INTO THE SPN_COMSUMPTION TABLE          */
/*************************************************************/
        UPDATE SPN_CONSUMPTION
        SET SPN_TOTAL_SPENT_AMT = COALESCE(SAP_TOTAL_SPENT_AMT,0) + HOLD_ZERO_VALUE + COALESCE(INV_PROJECT_AMT,0),
            SPN_STATE_INCUR_COST = COALESCE(SAP_TOTAL_SPENT_AMT,0) - (HOLD_SPN_SAP_AGREEMENT_AMT + COALESCE(SAP_PROJECT_AMT,0)),                          
            SPN_AGREEMENT_AMT = HOLD_SPN_SAP_AGREEMENT_AMT+ HOLD_ZERO_VALUE,
            SAP_AGREEMENT_AMT = HOLD_SPN_SAP_AGREEMENT_AMT,
            INV_AGREEMENT_AMT = HOLD_ZERO_VALUE,
            LAST_MODIFIED_BY = HOLD_LAST_MODIFIED_BY,
            LAST_MODIFIED_TS = CURRENT TIMESTAMP 
         WHERE STATE_PROJECT_NBR = HOLD_STATE_PROJECT_NUMBER
         AND COALESCE(SAP_AGREEMENT_AMT,0) <> HOLD_SPN_SAP_AGREEMENT_AMT
         ;  
  
        SET OUT_SQLSTATE = SQLSTATE;
        SET OUT_SQLCODE = SQLCODE;
  
    END IF;             
END WHILE;

/***************************************/
/* OPEN THE SPN_EST_PAID_AMTS CURSOR   */
/***************************************/
SET OUT_ERRORLOC = '0004';

OPEN SPN_EST_PAID_AMTS;

/**********************************************/
/* LOOP THROUGHT THE LIST AND UPDATE THE TABLE*/
/**********************************************/
SET OUT_ERRORLOC = '0005';

WHILE SPN_SAP_PRJ_PAID_COMPLETE = 0 DO

    FETCH
      SPN_EST_PAID_AMTS
    INTO
       HOLD_STATE_PROJECT_NUMBER,
       HOLD_SPN_SAP_PROJECT_AMT                
       ;       

/*******************************************/
/* SQLCODE 100 SIGNIFIES NO RECORD FETCHED */
/*******************************************/        
    IF SQLCODE = 100 THEN
        SET SPN_SAP_PRJ_PAID_COMPLETE = 1;

/*******************************************/
/* IF NO RECORDS FOUND, CLOSE THE CURSOR   */
/*******************************************/    
        CLOSE SPN_EST_PAID_AMTS;

        ELSE

        SET OUT_ERRORLOC = '0006'||','||'ERROR IN UPDATING SPN'||','||HOLD_STATE_PROJECT_NUMBER;

/*************************************************************/
/* UPDATE THE RECORD INTO THE SPN_COMSUMPTION TABLE          */
/*************************************************************/
        UPDATE SPN_CONSUMPTION
        SET SPN_TOTAL_SPENT_AMT = COALESCE(SAP_TOTAL_SPENT_AMT,0) + COALESCE(INV_AGREEMENT_AMT,0) + HOLD_ZERO_VALUE,
            SPN_STATE_INCUR_COST = COALESCE(SAP_TOTAL_SPENT_AMT,0) - (COALESCE(SAP_AGREEMENT_AMT,0) + HOLD_SPN_SAP_PROJECT_AMT),                          
            SPN_PROJECT_AMT = HOLD_SPN_SAP_PROJECT_AMT+ HOLD_ZERO_VALUE,
            SAP_PROJECT_AMT = HOLD_SPN_SAP_PROJECT_AMT,
            INV_PROJECT_AMT = HOLD_ZERO_VALUE,
            LAST_MODIFIED_BY = HOLD_LAST_MODIFIED_BY,
            LAST_MODIFIED_TS = CURRENT TIMESTAMP 
        WHERE STATE_PROJECT_NBR = HOLD_STATE_PROJECT_NUMBER
        AND COALESCE(SAP_PROJECT_AMT,0) <> HOLD_SPN_SAP_PROJECT_AMT
        ;
  
        SET OUT_SQLSTATE = SQLSTATE;
        SET OUT_SQLCODE = SQLCODE;
  
    END IF;
END WHILE;

/***************************************/
/* OPEN THE PAID_LOCAL_AMT CURSOR   */
/***************************************/
SET OUT_ERRORLOC = '0007';

OPEN PAID_LOCAL_AMT;

/**********************************************/
/* LOOP THROUGHT THE LIST AND UPDATE THE TABLE*/
/**********************************************/
SET OUT_ERRORLOC = '0008';

WHILE PAID_LOCAL_AMT_COMPLETE = 0 DO

    FETCH 
       PAID_LOCAL_AMT
    INTO
       HOLD_STATE_PROJECT_NUMBER,
      HOLD_SPN_SAP_LOCAL_PORTION_AMT
     ; 

/*******************************************/
/* SQLCODE 100 SIGNIFIES NO RECORD FETCHED */
/*******************************************/        
    IF SQLCODE = 100 THEN
        SET PAID_LOCAL_AMT_COMPLETE = 1;

/*******************************************/
/* IF NO RECORDS FOUND, CLOSE THE CURSOR   */
/*******************************************/
        CLOSE PAID_LOCAL_AMT;

        ELSE

        SET OUT_ERRORLOC = '0009'||','||'ERROR IN UPDATING SAP LOCAL AMOUNT FOR SPN'||','||HOLD_STATE_PROJECT_NUMBER;

/*************************************************************/
/* UPDATE THE RECORD INTO THE SPN_COMSUMPTION TABLE          */
/*************************************************************/  
        UPDATE SPN_CONSUMPTION
        SET SAP_LOCAL_PORTION_AMT = HOLD_SPN_SAP_LOCAL_PORTION_AMT,
            INV_LOCAL_PORTION_AMT = HOLD_ZERO_VALUE,
            LOCAL_PORTION_AMT = HOLD_SPN_SAP_LOCAL_PORTION_AMT + HOLD_ZERO_VALUE,
            LAST_MODIFIED_BY = HOLD_LAST_MODIFIED_BY,
            LAST_MODIFIED_TS = CURRENT TIMESTAMP   
        WHERE STATE_PROJECT_NBR = HOLD_STATE_PROJECT_NUMBER
        AND COALESCE(SAP_LOCAL_PORTION_AMT,0) <> HOLD_SPN_SAP_LOCAL_PORTION_AMT
        ; 
    
        SET OUT_SQLSTATE = SQLSTATE;
        SET OUT_SQLCODE = SQLCODE;
    
    END IF;            
END WHILE;

IF (SQLCODE = 0 AND SQLSTATE = '00000')THEN
    SET OUT_ERRORLOC = '0000'||','||'SUCCESSFUL';
    SET OUT_ERRCODE = 0;
END IF;
        
END P1