CREATE PROCEDURE ECMSXADM.SPCA0039 (IN P_PROJNUM INTEGER , IN P_BIDPKGNUM SMALLINT , IN P_BPID	CHAR(6) , OUT P_SQLCODE INTEGER)
	VERSION V1
	ISOLATION LEVEL CS
	RESULT SETS 1
	LANGUAGE SQL
	ALLOW DEBUG MODE
	WLM ENVIRONMENT FOR DEBUG MODE DSNDWLM2
	P1: BEGIN
       

DECLARE V_SQLCODE                		INT     DEFAULT 0;      
DECLARE V_SQLSTATE               		CHAR(5) DEFAULT '00000';
DECLARE SQLCODE                  		INT     DEFAULT 0;      
DECLARE SQLSTATE                 		CHAR(5) DEFAULT '00000';
DECLARE V_PRJ_PREQ_REQD_IND      		CHAR(1) DEFAULT ' ';  
DECLARE V_GP_GEN_CODE_VALUE             VARCHAR(255);
DECLARE V_PARM_GEN_CODE_TYPE     		SMALLINT DEFAULT 79;
DECLARE V_TYPE_CODE_FINCAP       		CHAR(3)      DEFAULT '100';
DECLARE V_PROCESS_PRIME                 CHAR(1) DEFAULT 'Y';
DECLARE V_END_OF_CURSOR                 CHAR(1)      DEFAULT 'N';
DECLARE V_PC_BUS_PARTNER_ID             CHAR(6) DEFAULT '      ';
DECLARE V_PC_PROJ_CONTR_AMT             DECIMAL(15,2) DEFAULT 0;
DECLARE V_PRIME_BPID                    CHAR(6);
DECLARE V_PARENT_BPID                   CHAR(6);
DECLARE V_GENNED_ITEM_NUM        		SMALLINT DEFAULT 0;
DECLARE V_PARM_ITEMBPID                 CHAR(6);
DECLARE V_AUTOMATIC_SUBTYPE             CHAR(1) DEFAULT '1';
DECLARE V_PARM_STATUS                   CHAR(1);
DECLARE V_SYSTEM_USERID                 CHAR(19) DEFAULT 'ECMS System/PennDOT';
DECLARE V_GEN_CODE_VALUE150             CHAR(150);
DECLARE V_STRNEWTOPADOT                 DECIMAL(3,2); -- different from cobol due to overflow issues in native sp
DECLARE V_STRNEWTOPADOTCAP       		DECIMAL(11,2);
DECLARE V_FIN_CAP                       DECIMAL(15,2);
DECLARE V_TEMP_AVAIL_CAP         		DECIMAL(15,2);
DECLARE V_AVAIL_CAP                     DECIMAL(15,2);
DECLARE V_THRESHOLD_AVAIL_CAP    		DECIMAL(15,2);
DECLARE V_THRESHOLD                     DECIMAL(11,2);
DECLARE V_SUBCONTRACTOR_AMOUNT   		DECIMAL(15,2);
DECLARE V_CONTRACT_AMOUNT        		DECIMAL(15,2);
DECLARE V_TEST_PASS                     CHAR(1) DEFAULT '1';  
-- 1 = ALL PASSED,  2 = ONE FAILED, 0 = NO PASSED STATE
DECLARE V_NEW_AVAIL                      DECIMAL(15,2);
DECLARE V_E_BPID                        CHAR(6);
DECLARE V_EMAIL_INDEX                   SMALLINT DEFAULT 0;
DECLARE V_EMAIL_SEPARATOR        		CHAR(1);
DECLARE V_VERIFIED_APPARENT_LOW  		CHAR(2) DEFAULT '02';
DECLARE V_TYPE_CODE_FIFTYWCC     		CHAR(3) DEFAULT '110';
DECLARE V_PASSED_STATUS                 CHAR(1) DEFAULT '1';
DECLARE V_FAILED_STATUS                 CHAR(1) DEFAULT '2';
DECLARE V_CONTRACTOR_TYPE        		CHAR(1) DEFAULT ' ';
DECLARE V_PREQ_CONTR                    CHAR(1) DEFAULT '1';
DECLARE V_PREQ_EXEMPT_CONTR             CHAR(1) DEFAULT '2';
DECLARE V_PDOTWORK_UPDATE        		CHAR(1) DEFAULT 'Y';
DECLARE V_CURRENT_PDOT_WORK             DECIMAL (15,2) DEFAULT 0;
DECLARE V_TABLEID                  		CHAR(12)     DEFAULT '$ECMSRETURN$';
DECLARE V_ERRCD                         SMALLINT     DEFAULT 0;
DECLARE V_ERRLOC                        CHAR(5)             DEFAULT '     ';
DECLARE V_EMAIL_BPID               		CHAR(35);
DECLARE V_AVAIL_CAPACITY_CHECK_IND      CHAR(1) DEFAULT ' ';
DECLARE V_BPID_ERRORS					CHAR(34) DEFAULT ' ';
DECLARE V_LENGTH						SMALLINT DEFAULT 0;



DECLARE SINGLE_PARM_CURSOR CURSOR WITH RETURN
   FOR                                        
   SELECT V_TABLEID,                        
          V_SQLCODE,                          
          V_ERRCD,                          
          V_ERRLOC,
          V_BPID_ERRORS                         
                              
     FROM SYSIBM.SYSDUMMY1    ;
     
     
 

DECLARE BID_CONTRACTOR CURSOR FOR                 
--  SELECT A.BUS_PARTNER_ID,      
SELECT A.PARTNER_BP_ID,             
         VALUE(PROJ_CONTR_TOT_AMT,0)             
    FROM ECMSXADM.CONTR_ECMS_BID_PARTNER_WORK A 
    	 
   WHERE A.ECMS_PROJECT_NUM = P_PROJNUM    
     AND A.PROJ_CONTR_TYPE IN ( 'P', 'J')    
     
     AND A.BID_PACKAGE_NUM = P_BIDPKGNUM 
     AND A.BUS_PARTNER_ID = P_BPID
   ORDER BY A.PROJ_CONTR_TYPE DESC  ;
            
             


            
DECLARE EXIT HANDLER FOR SQLEXCEPTION

	BEGIN
	
       
       SET V_SQLCODE = SQLCODE   ;
       SET V_ERRCD = -1;
       OPEN SINGLE_PARM_CURSOR;
       
	END;


       
SET V_SQLCODE = SQLCODE;
SET V_ERRCD = 0;
SET V_ERRLOC =  SPACE(4);        
                   
  
SET V_ERRLOC = 'D010';    
SELECT PREQ_REQD_IND                        
INTO V_PRJ_PREQ_REQD_IND
FROM ECMSXADM.PROJECT                              
WHERE ECMS_PROJECT_NUM = P_PROJNUM  ;

IF V_PRJ_PREQ_REQD_IND IS NULL
THEN
    SET V_PRJ_PREQ_REQD_IND = 'N';
END IF;     

SET V_ERRLOC = 'D020';    
SELECT GEN_CODE_VALUE                      
INTO V_GP_GEN_CODE_VALUE                  
FROM ECMSXADM.COM_GENERAL_CODE                    
WHERE GEN_CODE_TYPE = V_PARM_GEN_CODE_TYPE 
  AND GEN_CODE = V_TYPE_CODE_FINCAP ;

SET V_GEN_CODE_VALUE150 = SPACE(150);
SET V_GEN_CODE_VALUE150 = SUBSTR(V_GP_GEN_CODE_VALUE, 1, 150); 

IF V_PRJ_PREQ_REQD_IND = 'Y'
THEN
    OPEN BID_CONTRACTOR;
       
    SET V_PROCESS_PRIME       =  'Y';
    SET V_END_OF_CURSOR       =  'N';
              
    WHILE V_END_OF_CURSOR = 'N'
    DO FETCH FROM BID_CONTRACTOR
       INTO   V_PC_BUS_PARTNER_ID, V_PC_PROJ_CONTR_AMT;
       IF SQLCODE = 100
       THEN 
           CLOSE BID_CONTRACTOR;  
           SET V_END_OF_CURSOR = 'Y';
       ELSE
       		
                  SET V_PRIME_BPID = V_PC_BUS_PARTNER_ID;
                     
                  SET V_ERRLOC = 'D040';
                  SELECT PARENT_BP_ID                 
                  INTO V_PARENT_BPID                 
                  FROM ECMSXADM.CONTRACTOR                   
                  WHERE BUS_PARTNER_ID      = V_PRIME_BPID;
                  
                  SET V_PARM_ITEMBPID = V_PC_BUS_PARTNER_ID;
                    
                                   
                  -- CHECK PRIME AND EACH JOINT VENTURES  --
                  -- GET NEW TO PENNDOT PERCENTAGE TO MULTIPLY BY
                  SET V_ERRLOC = 'D050';
                  SELECT DEC(GEN_CODE_VALUE,3,2)        -- let's retrieve GPC values as 1 decimal instead of 2.        
                  INTO V_STRNEWTOPADOT                  -- different from cobol version because this one has just 1 decimal       
            	  FROM ECMSXADM.COM_GENERAL_CODE        -- reason to change is due to the overflow issue we encountered in native stored proc               
                  WHERE GEN_CODE_TYPE = 921 AND GEN_CODE = '08';
                    
                  -- GET THE CAP FINANCIAL CAPACITY AMOUNT
                  SELECT DEC(GEN_CODE_VALUE,11,2)             
                  INTO V_STRNEWTOPADOTCAP                    
              	  FROM ECMSXADM.COM_GENERAL_CODE                     
                  WHERE GEN_CODE_TYPE = 921 AND GEN_CODE = '09';
                     
                  -- GET AVAILABLE CAPACITY THRESHOLD
                  SELECT DEC(GEN_CODE_VALUE,3,2)               
                  INTO V_THRESHOLD                         
              	  FROM ECMSXADM.COM_GENERAL_CODE                      
                  WHERE GEN_CODE_TYPE = 921 AND GEN_CODE = '10';
                     
                     
                  -- DETERMINE THE FINANCIAL CAPACITY OF THE BUSINESS PARTNER
                  -- THIS MUST BE DETERMINED BEFORE AVAILABLE CAPACITY IS
                  -- DETERMINED BECAUSE IT IS INPUT TO THE AVAILABLE
                  -- CAPACITY FORMULA
                     
                                        
                  SET V_ERRLOC = 'D060';
                  
                  SET V_FIN_CAP =
                  (
                   SELECT CASE  WHEN NEW_TO_PADOT_IND = 'Y'                   
                   THEN                                          
                       CASE   WHEN COALESCE(PERF_FACTOR, 1) *             
                                  CAST( COALESCE(WORKING_CAPITAL, 0) *         
                               	   V_STRNEWTOPADOT AS DECIMAL(15,2)  )   > V_STRNEWTOPADOTCAP 
              		   THEN V_STRNEWTOPADOTCAP                      
                       ELSE   
                    	   COALESCE(PERF_FACTOR, 1) *             
                           CAST(COALESCE(WORKING_CAPITAL, 0) *         
                           V_STRNEWTOPADOT AS DECIMAL(15,2) )
                       END                                         
                   ELSE                                          
                   	   CAST(COALESCE(PERF_FACTOR, 1) *                 
                       WORKING_CAPITAL AS DECIMAL(15,2) )                         
                   END                                           
                   FROM ECMSXADM.PREQ_CONTRACTOR
                   WHERE BUS_PARTNER_ID =                               
                         (SELECT PARENT_BP_ID                            
                          FROM ECMSXADM.CONTRACTOR
                          WHERE BUS_PARTNER_ID = V_PC_BUS_PARTNER_ID)     
                   AND PREQ_CONTR_TYPE = '12'                            
                                                     
                   UNION 
                         
                   SELECT CASE  WHEN NEW_TO_PADOT_IND = 'Y'
                   THEN                                            
                   		CASE   WHEN COALESCE(PERF_FACTOR, 1) *              
                               		CAST((COALESCE(WORKING_CAPITAL, 0) +          
                               	CAST(COALESCE(LOC_AMOUNT, 0) * .5 AS DOUBLE) +         
                               	CAST(COALESCE(EQUIP_BOOK_VALUE, 0) * .5 AS DOUBLE)) *  
                           			 V_STRNEWTOPADOT AS DECIMAL(15,2) )   > V_STRNEWTOPADOTCAP   
                   		THEN V_STRNEWTOPADOTCAP                       
                    	ELSE                                         
                        	COALESCE(PERF_FACTOR, 1) *              
                        CAST((COALESCE(WORKING_CAPITAL, 0) +          
                            CAST(COALESCE(LOC_AMOUNT, 0) * .5 AS DOUBLE )  +         
                        	CAST(COALESCE(EQUIP_BOOK_VALUE, 0) * .5 AS DOUBLE))  *  
                        	V_STRNEWTOPADOT   AS DECIMAL(15,2) )                        
                    	END                                          
                    ELSE                                            
                    	CAST(COALESCE(PERF_FACTOR, 1) *                   
                    	(COALESCE(WORKING_CAPITAL, 0) +               
                    	CAST(COALESCE(LOC_AMOUNT, 0) * .5 AS DOUBLE)  +              
                    	CAST(COALESCE(EQUIP_BOOK_VALUE, 0) * .5 AS DOUBLE)) AS DECIMAL(15,2) )
                    END                                             
                    --INTO V_FIN_CAP                                          
                    FROM ECMSXADM.PREQ_CONTRACTOR 
                    WHERE BUS_PARTNER_ID =                                 
                           (SELECT PARENT_BP_ID                              
                            FROM ECMSXADM.CONTRACTOR
                            WHERE BUS_PARTNER_ID = V_PC_BUS_PARTNER_ID)       
                    AND PREQ_CONTR_TYPE = '11'    );
                    

                                     
                    -- DETERMINE AVAILABLE CAPACITY SIDE OF THE FORMULA 
                    SET V_ERRLOC = 'D070';
                    SELECT (COALESCE(SUM(PC.PRIME_CONTR_AMT), 0.0) +
                           COALESCE(SUM(PC.PRIME_WO_AMT), 0.0) -   
                           COALESCE(SUM(PC.PRIME_PAID_AMT), 0.0)) -
                           COALESCE(SUM(PC.NON_PD_WORK_AMT), 0.0) -
                           COALESCE(SUM(PC.SUB_WORK_AMT), 0.0) +   
                           COALESCE(SUM(PC.WORK_SUB_AMT), 0.0)     
                    INTO V_TEMP_AVAIL_CAP                          
                    FROM ECMSXADM.PREQ_CONTRACTOR PC,                      
                    ECMSXADM.CONTRACTOR CR                            
                    WHERE CR.PARENT_BP_ID =                       
                           (SELECT PARENT_BP_ID                         
                            FROM ECMSXADM.CONTRACTOR
                            WHERE BUS_PARTNER_ID = V_PC_BUS_PARTNER_ID)  
                    AND CR.BUS_PARTNER_ID = PC.BUS_PARTNER_ID;
                    
                    IF V_TEMP_AVAIL_CAP < 0.0
                    THEN
                        SET V_TEMP_AVAIL_CAP = 0.0;
                    END IF;
                    
                    SET V_AVAIL_CAP = (V_FIN_CAP - V_TEMP_AVAIL_CAP);
                    
                    -- CONTRACTORS BID CAN ONLY TAKE UP TO 90% OF HIS 
                    -- AVAILABLE CAPACITY (90% IS ACTUALLY A PERCENT STORED
                    -- IN THE SYSTEM CODE TABLE
                    SET V_THRESHOLD_AVAIL_CAP = (V_AVAIL_CAP * V_THRESHOLD);
                    
                    -- DETERMINE CONTRACT AMOUNT
                    -- IF THE BID IS A JOINT VENTURE, WE MUST SUM THE CONTRACTOR
                    -- AMOUNT FOR ALL THE SUBS AND SUBTRACT THAT AMOUNT FROM
                    -- THE CONTRACT AMOUNT
                    SET V_SUBCONTRACTOR_AMOUNT = 0.0;
                    
                    SET V_ERRLOC = 'D080';
                    SELECT VALUE (SUM(PROJ_CONTR_TOT_AMT),0.0)     
                    INTO V_SUBCONTRACTOR_AMOUNT                   
                    FROM ECMSXADM.CONTR_ECMS_BID_WORK A, 
                    	 ECMSXADM.CONTR_ECMS_BID_PARTNER_WORK B
                    WHERE A.ECMS_PROJECT_NUM = P_PROJNUM       
                    AND A.BID_PACKAGE_NUM      = P_BIDPKGNUM      
                    AND A.BUS_PARTNER_ID       = P_BPID 
                    AND B.PARTNER_BP_ID 	   = V_PRIME_BPID        
                    AND A.ECMS_PROJECT_NUM     = B.ECMS_PROJECT_NUM
                    AND A.BID_PACKAGE_NUM      = B.BID_PACKAGE_NUM  
                    AND A.BUS_PARTNER_ID       = B.BUS_PARTNER_ID  
                    AND B.PROJ_CONTR_TYPE      = 'S';
                                    
                   -- SET V_CONTRACT_AMOUNT = ( V_PC_PROJ_CONTR_AMT - V_SUBCONTRACTOR_AMOUNT );
                    
                    -- IF THE BUSINESS PARTNER IS ASSIGNED TO MORE ITEMS THAN THEY HAVE
                    -- FINANCIAL CAPACITY TO DO, 
                    -- CHECK CONTRACT AMOUNT TO 90% OF THE CONTRACTORS AVAILABLE CAPACITY RATHER
                    -- THAN TOTAL AVAILABLE CAPACITY
                    IF V_PC_PROJ_CONTR_AMT > V_THRESHOLD_AVAIL_CAP
                    THEN
                        SET V_PARM_STATUS = '2';  -- FAILED STATUS
                        SET V_TEST_PASS   = '2';  -- ONE FAILED 
                        
                        SET V_BPID_ERRORS = TRIM(V_BPID_ERRORS) || V_PC_BUS_PARTNER_ID || ',';
                        			       	
                    ELSE                                       
                        SET V_PARM_STATUS = '1';  -- PASSED STATUS    
                                                     
                    END IF;
                    
                                                               
                     
                    
            --  END IF;                    
       END IF;                           
       END WHILE;

       
       -- IF ALL THE ITEMS ON THIS PROJECT HAVE PASSED FIN CAPACITY
       -- THIS STORED PROCEDURE CANNOT COMMIT SO IT MUST KEEP TRACK
       -- OF WHETHER WE ARE PASSING ALL THE ITEMS
       
       IF V_TEST_PASS = '1'  -- ALL PASSED
       THEN
       		SET V_AVAIL_CAPACITY_CHECK_IND = 'P';
       		SET V_BPID_ERRORS = NULL;
       ELSE
       		SET V_AVAIL_CAPACITY_CHECK_IND = 'F';
       END IF;  
       			
          SET V_ERRLOC = 'D110';
          UPDATE ECMSXADM.CONTR_ECMS_BID_WORK                                   
             SET AVAIL_CAPACITY_CHECK_IND = V_AVAIL_CAPACITY_CHECK_IND       
          WHERE ECMS_PROJECT_NUM 	= P_PROJNUM               
            AND BID_PACKAGE_NUM 	= P_BIDPKGNUM                
            AND BUS_PARTNER_ID 		= P_BPID ; 
                           
      
          

                    
END IF;

                                                                
OPEN SINGLE_PARM_CURSOR;

       
       
END P1
