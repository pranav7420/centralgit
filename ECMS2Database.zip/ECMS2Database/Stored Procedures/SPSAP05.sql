CREATE PROCEDURE ECMSXADM.SPSAP05 (
		IN In_ECMS_Transaction_Id Integer
	)
	
	RESULT SETS 1
	LANGUAGE SQL
	QUALIFIER ECMSXADM
	ISOLATION LEVEL CS
	VALIDATE BIND
	WLM ENVIRONMENT FOR DEBUG MODE DSNDWLM2
	PACKAGE OWNER HWYDEV
	ALLOW DEBUG MODE
	ASUTIME LIMIT 120000
	
P1: Begin

/*************************/
/* Variable Declarations */
/*************************/

DECLARE Hold_ECMS_Transaction_Type_Code     CHAR(2);
DECLARE Hold_Agr                            CHAR(6);
DECLARE Hold_Internal_Order                 CHAR(5);
DECLARE Hold_WBS_Element                    CHAR(24);
DECLARE Hold_General_Ledger_Acct            CHAR(7);
DECLARE No_Funding_Records                  CHAR(1)     DEFAULT 'N';
DECLARE No_Bgt_Funding_Records              CHAR(1)     DEFAULT 'N';
DECLARE No_Part_Funding_Records             CHAR(1)     DEFAULT 'N';
DECLARE Hold_Inv_Id                         INTEGER;
DECLARE Hold_Total_Funding_Amount           DECIMAL(13, 2);
DECLARE Hold_Funding_Id                     INTEGER     DEFAULT 0;
DECLARE Hold_ECMS_Project_Num               INTEGER;
DECLARE Staged_Funding_Complete             SMALLINT    DEFAULT 0;
DECLARE Staged_Bgt_Funding_Complete         SMALLINT    DEFAULT 0;
DECLARE Agr_Funding_Complete                SMALLINT    DEFAULT 0;
DECLARE Bgt_Funding_Complete                SMALLINT    DEFAULT 0;
DECLARE Phases_Complete                     SMALLINT    DEFAULT 0;
DECLARE Hold_Part_Id                        SMALLINT;
DECLARE	Hold_Agr_Funding_Alloc_Id           SMALLINT;
DECLARE Hold_Max_Agr_Funding_Alloc_Id       SMALLINT;
DECLARE	Hold_Bgt_Funding_Alloc_Id           SMALLINT;
DECLARE Hold_Max_Bgt_Funding_Alloc_Id       SMALLINT;
DECLARE Hold_Line_Item_Nbr                  SMALLINT;
DECLARE Hold_Total_Payment_Amt              DECIMAL(13, 2);
DECLARE Hold_Inv_Pct                        DECIMAL(5, 4);
DECLARE Hold_Line_Item_Amount               DECIMAL(13, 2);
DECLARE Hold_Amount_Allocated               DECIMAL(13, 2);
DECLARE Hold_Item_Total_Amt                 DECIMAL(15, 2);
DECLARE Hold_Phase_Id                       CHAR(2);
DECLARE Hold_Internal_Order_Phase_Id        CHAR(2);
DECLARE Out_Gen_Code_Value_Bgt              CHAR(3);

DECLARE Hold_Est_Int_Internal_Order         CHAR(5)     DEFAULT '89802';
DECLARE Hold_Est_Int_WBS_Element            CHAR(24);
DECLARE Estimate_Interest_Complete          SMALLINT    DEFAULT 0;
DECLARE Estimate_Complete                   SMALLINT    DEFAULT 0;
DECLARE Hold_Sum_Est_Int_Amt                DECIMAL(13, 2);
DECLARE Hold_Estimate_Num                   CHAR(3);

/************************************************/
/* These are the various transaction type coded */
/************************************************/
DECLARE C_Transaction_Type_Code_Estimate    CHAR(2) DEFAULT '01';
DECLARE C_Transaction_Type_Code_Est_Adj     CHAR(2) DEFAULT '02';
DECLARE C_Transaction_Type_Code_Invoice     CHAR(2) DEFAULT '03';
DECLARE C_Transaction_Type_Code_Est_Int     CHAR(2) DEFAULT '04';

/**********************************************************/
/* These variables are passed back to the calling program */
/**********************************************************/
DECLARE SQLSTATE CHAR(5) DEFAULT '00000';
DECLARE SQLCODE  INTEGER     DEFAULT 0;
DECLARE ERRLOC   CHAR(40);
DECLARE ERRCODE  INTEGER;

/********************************************************************/
/* We retrieve the agreement funding allocation from either         */
/* Bgt_Funding_Allocation or Agr_Part_Funding_Allocation            */
/********************************************************************/
DECLARE Part_Agr_Funding Cursor For
    SELECT
        WBS_Element,
        General_Ledger_Acct,
        Inv_Pct,
        Agr_Funding_Alloc_Id
    FROM
        ECMSXADM.Agr_Part_Funding_Allocation
    WHERE
        Agr = Hold_Agr
        And Part_Id = Hold_Part_Id
        And Inv_Pct > 0
    ORDER BY
        Agr_Funding_Alloc_Id;
        
DECLARE Bgt_Budget_Funding Cursor For
      SELECT
        Phase_Id,
        WBS_Element,
        General_Ledger_Acct,
        Inv_Pct,		
        Bgt_Funding_Alloc_Id
    FROM
        ECMSXADM.Bgt_Funding_Allocation
    WHERE
       Agr =  Hold_Agr
       And Phase_Id = Hold_Internal_Order_Phase_Id 
       And Inv_Pct > 0
   ORDER BY
        Bgt_Funding_Alloc_Id;

/**************************************************/
/* Get the invoice internal order funding records */
/**************************************************/
DECLARE Staged_Funding Cursor For
    SELECT
        Internal_Order,
        Sum(Funding_Amt) As Total_Funding_Amount
    FROM
        ECMSXADM.Inv_Internal_Order_Funding
    WHERE
        Agr = Hold_Agr
        And Inv_Id = Hold_Inv_Id
        And Left(Internal_Order,3) <> Out_Gen_Code_Value_Bgt
    GROUP BY
        Internal_Order
    ORDER BY
        Internal_Order;
        
DECLARE Staged_Funding_Bgt Cursor For
    SELECT
        Internal_Order,
        Sum(Funding_Amt) As Total_Funding_Amount,
        Right(Internal_Order,2) As Internal_Oreder_Phase_Id
    FROM
        ECMSXADM.Inv_Internal_Order_Funding
    WHERE
        Agr = Hold_Agr
        And Inv_Id = Hold_Inv_Id
        And Left(Internal_Order,3) = Out_Gen_Code_Value_Bgt
    GROUP BY
        Internal_Order
    ORDER BY
        Internal_Order
        ;

/********************************/
/* Retrieve the funding records */
/********************************/
DECLARE Estimate_Interest Cursor For
    SELECT
        PF.WBS_Element,
        PF.Internal_Order,
        Sum(Value(EI.Est_Int_Amt, 0)) As Sum_Est_Int_Amt
    FROM
        ECMSXADM.Proj_Funding PF Inner Join ECMSXADM.Est_Interest EI
            On PF.ECMS_Project_Num = EI.ECMS_Project_Num
            And PF.Fund_Code = EI.Fund_Code
    WHERE
        PF.ECMS_Project_Num = Hold_ECMS_Project_Num
        And (EI.Est_Int_Status_Cd = '2' OR EI.Est_Int_Status_Cd = '4')
    GROUP BY
        PF.WBS_Element,
        PF.Internal_Order
    ORDER BY
        PF.WBS_Element,
        PF.Internal_Order;

/********************************/
/* Retrieve the funding records */
/********************************/
DECLARE Estimate_Funding Cursor For
    SELECT
	    EstAndAdj.WBS_Element,
	    EstAndAdj.Internal_Order,
	    Sum(EstAndAdj.Amt) As Amt
    FROM
    (
    SELECT
	    PF.WBS_Element,
	    PF.Internal_Order,
	    Sum(EIF.Item_Total_Amt) As Amt
    FROM
	    ECMSXADM.Proj_Funding PF Inner Join ECMSXADM.Est_Item_Funding EIF
		    On PF.ECMS_Project_Num = EIF.ECMS_Project_Num
		    And PF.Fund_Code = EIF.Fund_Code
    WHERE
	    PF.ECMS_Project_Num = Hold_ECMS_Project_Num
	    And EIF.Estimate_Num = Hold_Estimate_Num
    GROUP BY
	    PF.WBS_Element,
	    PF.Internal_Order
    UNION All
    SELECT
	    PF.WBS_Element,
	    PF.Internal_Order,
	    Sum(EA.Est_Adj_Appl_Amt) As Amt
    FROM
	    ECMSXADM.Proj_Funding PF Inner Join ECMSXADM.Est_Adjustment EA
		    On PF.ECMS_Project_Num = EA.ECMS_Project_Num
		    And PF.Fund_Code = EA.Fund_Code
    WHERE
	    PF.ECMS_Project_Num = Hold_ECMS_Project_Num
	    And EA.Estimate_Num = Hold_Estimate_Num
    GROUP BY
	    PF.WBS_Element,
	    PF.Internal_Order
    ) EstAndAdj
    GROUP BY
	    EstAndAdj.WBS_Element,
	    EstAndAdj.Internal_Order
;
/*************************/
/* DECLARE return cursor */
/*************************/
DECLARE SINGLE_PARM_CURSOR CURSOR WITH RETURN FOR
    SELECT
        SQLCODE,
        SQLSTATE,
        ERRLOC,
        ERRCODE
    FROM
        SYSIBM.SYSDUMMY1;

/*******************/
/* DECLARE handler */
/*******************/
DECLARE EXIT HANDLER FOR SQLEXCEPTION
    OPEN SINGLE_PARM_CURSOR;

/***********************************/
/* Initialize the error variables. */
/***********************************/
SET ERRLOC = '0001';
SET ERRCODE = -1;

/****************************************************/
/* Get the GPC code for the Budget Internal_Orders. */
/****************************************************/
SET ERRLOC = '0002';
 SELECT Left(Gen_Code_Value,3)
       INTO Out_Gen_Code_Value_Bgt
       FROM Com_General_Code
        WHERE Gen_Code_Type = 906
        AND Gen_Code = '05';

/*******************************************/
/* Retrieve the ECMS Transaction Type Code */
/*******************************************/

SELECT
    ECMS_Transaction_Type_Code
INTO
    Hold_ECMS_Transaction_Type_Code
FROM
    ECMSXADM.SAP_ECMS_Transaction
WHERE
    ECMS_Transaction_Id = In_ECMS_Transaction_Id;

DELETE FROM
	ECMSXADM.SAP_ECMS_Payment_Funding
WHERE
	ECMS_Transaction_Id = In_ECMS_Transaction_Id;

SET ERRLOC = '0003';

If Hold_ECMS_Transaction_Type_Code = C_Transaction_Type_Code_Invoice THEN
    /************************************************/
    /* Retrieve the Agreement Number and Invoice Id */
    /************************************************/

    SELECT
        Agr,
        Inv_Id
    INTO
        Hold_Agr,
        Hold_Inv_Id
    FROM
        ECMSXADM.SAP_ECMS_Transaction
    WHERE
        ECMS_Transaction_Id = In_ECMS_Transaction_Id;

    SET ERRLOC = '0004';

    /******************************************/
    /* Create the funding allocation records. */
    /******************************************/
    Call SPSAP05A(In_ECMS_Transaction_Id);

    /************************************************/
    /* Retrieve the Agreement Number and Invoice Id */
    /************************************************/
    SELECT
        Part_Id
    INTO
        Hold_Part_Id
    FROM
        ECMSXADM.Inv_Hierarchy
    WHERE
        Agr = Hold_Agr
        And Inv_Id = Hold_Inv_Id;

    SET ERRLOC = '0005';

    /********************************/
    /* Get the total payment amount */
    /********************************/
    SELECT
        Total_Payment_Amt
    INTO
        Hold_Total_Payment_Amt
    FROM
        ECMSXADM.Inv_Wrapper
    WHERE
        Agr = Hold_Agr
        And Inv_Id = Hold_Inv_Id;

    SET ERRLOC = '0006';

/***************************************************************/
    /* Open the invoice internal order funding records and get the */
    /* first record                                                */
    /***************************************************************/
    Open Staged_Funding;

    FETCH
        Staged_Funding
    INTO
        Hold_Internal_Order,
        Hold_Total_Funding_Amount;


    /*******************************************/
    /* SQLCODE 100 signifies no record fetched */
    /*******************************************/
    If SQLCODE = 100 THEN
        SET Staged_Funding_Complete = 1;
        SET No_Part_Funding_Records = 'Y';
    END If;

    SET ERRLOC = '0007';

    While Staged_Funding_Complete = 0 Do
        SET Hold_Amount_Allocated = 0;
        
         /*************************************************************/
        /* Open the agreement funding allocation records and get the */
        /* first record.  If the work order id is null, get the      */
        /* funding from the part funding table.  Otherwise, get      */
        /* the funding from the work order funding table.            */
        /*************************************************************/
     
            OPEN Part_Agr_Funding;

            FETCH
                Part_Agr_Funding
            INTO
                Hold_WBS_Element,
                Hold_General_Ledger_Acct,
                Hold_Inv_Pct,
                Hold_Agr_Funding_Alloc_Id;

            /*******************************************/
            /* SQLCODE 100 signifies no record fetched */
            /*******************************************/
            If SQLCODE = 100 THEN
                SET Agr_Funding_Complete = 1;
            END If;

            SET ERRLOC = '0008';

            /************************************************************/
            /* We need this so we can tell if we are on the last record */
            /* in the cursor                                            */
            /************************************************************/
            SELECT
                Max(Agr_Funding_Alloc_Id)
            INTO
                Hold_Max_Agr_Funding_Alloc_Id
            FROM
                ECMSXADM.Agr_Part_Funding_Allocation
            WHERE
                Agr = Hold_Agr
                And Part_Id = Hold_Part_Id;
       
        SET ERRLOC = '0009';

        WHILE Agr_Funding_Complete = 0 Do

            SET ERRLOC = '0010';

            /**************************************************************/
            /* Check to see if this is the last funding allocation record */
            /**************************************************************/
            If Hold_Agr_Funding_Alloc_Id = Hold_Max_Agr_Funding_Alloc_Id THEN
                SET Hold_Line_Item_Amount = Hold_Total_Funding_Amount - Hold_Amount_Allocated;
            Else
                SET Hold_Line_Item_Amount = Hold_Total_Funding_Amount * Hold_Inv_Pct;
                SET Hold_Amount_Allocated = Hold_Amount_Allocated + Hold_Line_Item_Amount;
            END If;

            SET ERRLOC = '0011';

            /*************************************************************/
            /* INSERT the record into the SAP_ECMS_Payment_Funding table */
            /*************************************************************/
            IF Hold_Funding_Id = 0 THEN
                SELECT Funding_Id INTO Hold_Funding_Id FROM Final Table (
                INSERT INTO
                    ECMSXADM.SAP_ECMS_Payment_Funding
                (
                    Funding_Id,
                    Line_Item_Nbr,
                    WBS_Element,
                    General_Ledger_Acct,
                    Internal_Order,
                    Line_Item_Amt,
                    ECMS_Transaction_Id
                ) VALUES (
                    (SELECT Coalesce(Max(Funding_Id), 0) + 1 FROM ECMSXADM.SAP_ECMS_Payment_Funding),
                    1,
                    Coalesce(Hold_WBS_Element,'0-00000000000-0000-000'),
                    Coalesce(Hold_General_Ledger_Acct,'0000000'),
                    Coalesce(Hold_Internal_Order,'00000'),
                    Coalesce(Hold_Line_Item_Amount,0),
                    In_ECMS_Transaction_Id));

                SET Hold_Line_Item_Nbr = 1;
            ELSE
                SELECT Line_Item_Nbr INTO Hold_Line_Item_Nbr FROM Final Table (
                INSERT INTO
                    ECMSXADM.SAP_ECMS_Payment_Funding
                (
                    Funding_Id,
                    Line_Item_Nbr,
                    WBS_Element,
                    General_Ledger_Acct,
                    Internal_Order,
                    Line_Item_Amt,
                    ECMS_Transaction_Id
                ) VALUES (
                    Hold_Funding_Id,
                    (SELECT Coalesce(Max(Line_Item_Nbr), 0) + 1 FROM ECMSXADM.SAP_ECMS_Payment_Funding WHERE Funding_Id = Hold_Funding_Id),
                    Coalesce(Hold_WBS_Element,'0-00000000000-0000-000'),
                    Coalesce(Hold_General_Ledger_Acct,'0000000'),
                    Coalesce(Hold_Internal_Order,'00000'),
                    Coalesce(Hold_Line_Item_Amount,0),
                    In_ECMS_Transaction_Id));
            END If;

            SET ERRLOC = '0012';

            /*************************************************************/
            /* Open the agreement funding allocation records and get the */
            /* first record.  If the work order id is null, get the      */
            /* funding from the part funding table.  Otherwise, get      */
            /* the funding from the work order funding table.            */
            /*************************************************************/
          
                FETCH
                    Part_Agr_Funding
                INTO
                    Hold_WBS_Element,
                    Hold_General_Ledger_Acct,
                    Hold_Inv_Pct,
                    Hold_Agr_Funding_Alloc_Id;
           

            /*******************************************/
            /* SQLCODE 100 signifies no record fetched */
            /*******************************************/
            If SQLCODE = 100 THEN
                SET Agr_Funding_Complete = 1;
            END If;

            SET ERRLOC = '0013';
        END While;

        SET ERRLOC = '0014';
         /******************************************************/
        /* Get the next invoice internal order funding record */
        /******************************************************/
        FETCH
            Staged_Funding
        INTO
            Hold_Internal_Order,
            Hold_Total_Funding_Amount;


        /*******************************************/
        /* SQLCODE 100 signifies no record fetched */
        /*******************************************/
       If SQLCODE = 100 THEN
            SET Staged_Funding_Complete = 1;
        END If;

        SET ERRLOC = '0015';

          
           Close Part_Agr_Funding;

        SET Agr_Funding_Complete = 0;
      
    END While;
    
Close Staged_Funding;
    SET ERRLOC = '0016';
    /***************************************************************/
    /* Open the invoice internal order funding records and get the */
    /* first record                                                */
    /***************************************************************/
    Open Staged_Funding_Bgt;

    FETCH
        Staged_Funding_Bgt
    INTO
        Hold_Internal_Order,
        Hold_Total_Funding_Amount,
        Hold_Internal_Order_Phase_Id;


    /*******************************************/
    /* SQLCODE 100 signifies no record fetched */
    /*******************************************/
    If SQLCODE = 100 THEN
        SET Staged_Funding_Complete = 1;
        SET No_Bgt_Funding_Records = 'Y';
    END If;

    SET ERRLOC = '0017';

    While Staged_Bgt_Funding_Complete = 0 Do
        SET Hold_Amount_Allocated = 0;
        /*************************************************************/
        /* Open the Budget funding allocation records and get the    */
        /* first record.                                             */
        /*************************************************************/
     
            OPEN Bgt_Budget_Funding;
        
            FETCH
                Bgt_Budget_Funding
            INTO
                Hold_Phase_Id,
                Hold_WBS_Element,
                Hold_General_Ledger_Acct,
                Hold_Inv_Pct,
                Hold_Bgt_Funding_Alloc_Id;


            /*******************************************/
            /* SQLCODE 100 signifies no record fetched */
            /*******************************************/
            If SQLCODE = 100 THEN
                SET Bgt_Funding_Complete = 1;
            END If;

            SET ERRLOC = '0018';

            /************************************************************/
            /* We need this so we can tell if we are on the last record */
            /* in the cursor                                            */
            /************************************************************/
            SELECT
                Max(Bgt_Funding_Alloc_Id)
            INTO
                Hold_Max_Bgt_Funding_Alloc_Id
            FROM
                ECMSXADM.Bgt_Funding_Allocation
            WHERE
                Agr = Hold_Agr
                And Phase_Id = Hold_Phase_Id;
    
        SET ERRLOC = '0019';

        While Bgt_Funding_Complete = 0 Do

            SET ERRLOC = '0020';

            /**************************************************************/
            /* Check to see if this is the last funding allocation record */
            /**************************************************************/
            If Hold_Bgt_Funding_Alloc_Id = Hold_Max_Bgt_Funding_Alloc_Id THEN
                SET Hold_Line_Item_Amount = Hold_Total_Funding_Amount - Hold_Amount_Allocated;
            Else
                SET Hold_Line_Item_Amount = Hold_Total_Funding_Amount * Hold_Inv_Pct;
                SET Hold_Amount_Allocated = Hold_Amount_Allocated + Hold_Line_Item_Amount;
            END If;

            SET ERRLOC = '0021';

            /*************************************************************/
            /* INSERT the record into the SAP_ECMS_Payment_Funding table */
            /*************************************************************/
            If Hold_Funding_Id = 0 THEN
                SELECT Funding_Id INTO Hold_Funding_Id FROM Final Table (
                INSERT INTO
                    ECMSXADM.SAP_ECMS_Payment_Funding
                (
                    Funding_Id,
                    Line_Item_Nbr,
                    WBS_Element,
                    General_Ledger_Acct,
                    Internal_Order,
                    Line_Item_Amt,
                    ECMS_Transaction_Id
                ) VALUES (
                    (SELECT Coalesce(Max(Funding_Id), 0) + 1 FROM ECMSXADM.SAP_ECMS_Payment_Funding),
                    1,
                    Coalesce(Hold_WBS_Element,'0-00000000000-0000-000'),
                    Coalesce(Hold_General_Ledger_Acct,'0000000'),
                    Coalesce(Hold_Internal_Order,'00000'),
                    Coalesce(Hold_Line_Item_Amount,0),
                    In_ECMS_Transaction_Id));

                SET Hold_Line_Item_Nbr = 1;
            Else
                SELECT Line_Item_Nbr INTO Hold_Line_Item_Nbr FROM Final Table (
                INSERT INTO
                    ECMSXADM.SAP_ECMS_Payment_Funding
                (
                    Funding_Id,
                    Line_Item_Nbr,
                    WBS_Element,
                    General_Ledger_Acct,
                    Internal_Order,
                    Line_Item_Amt,
                    ECMS_Transaction_Id
                ) VALUES (
                    Hold_Funding_Id,
                    (SELECT Coalesce(Max(Line_Item_Nbr), 0) + 1 FROM ECMSXADM.SAP_ECMS_Payment_Funding WHERE Funding_Id = Hold_Funding_Id),
                    Coalesce(Hold_WBS_Element,'0-00000000000-0000-000'),
                    Coalesce(Hold_General_Ledger_Acct,'0000000'),
                    Coalesce(Hold_Internal_Order,'00000'),
                    Coalesce(Hold_Line_Item_Amount,0),
                    In_ECMS_Transaction_Id));
            END If;

            SET ERRLOC = '0022';

            /************************************************/
            /* Get the next Budget Funding Allocation row   */
            /************************************************/
          
               FETCH
                Bgt_Budget_Funding
            INTO
                Hold_Phase_Id,
                Hold_WBS_Element,
                Hold_General_Ledger_Acct,
                Hold_Inv_Pct,
                Hold_Bgt_Funding_Alloc_Id;
           
            /*******************************************/
            /* SQLCODE 100 signifies no record fetched */
            /*******************************************/
            If SQLCODE = 100 THEN
                SET Bgt_Funding_Complete = 1;
            END If;

            SET ERRLOC = '0023';
        END While;

        SET ERRLOC = '0024';
 
        /******************************************************/
        /* Get the next invoice internal order funding record */
        /******************************************************/
        FETCH
            Staged_Funding_Bgt
        INTO
            Hold_Internal_Order,
            Hold_Total_Funding_Amount,
            Hold_Internal_Order_Phase_Id;


        /*******************************************/
        /* SQLCODE 100 signifies no record fetched */
        /*******************************************/
        If SQLCODE = 100 THEN
            SET Staged_Bgt_Funding_Complete = 1;
        END If;

        SET ERRLOC = '0025';

           Close Bgt_Budget_Funding;

        SET Bgt_Funding_Complete = 0;
      
    END While;
Close Staged_Funding_Bgt;


Else
    If Hold_ECMS_Transaction_Type_Code = C_Transaction_Type_Code_Est_Int THEN
        SET ERRLOC = '0026';

        /********************************************************/
        /* Get the project number for this SAP ECMS Transaction */
        /********************************************************/
        SELECT
            ECMS_Project_Num
        INTO
            Hold_ECMS_Project_Num
        FROM
            ECMSXADM.SAP_ECMS_Transaction
        WHERE
            ECMS_Transaction_Id = In_ECMS_Transaction_Id;

        SET ERRLOC = '0027';

        /***************************************************************/
        /* Open the estimate interest records and get the first record */
        /***************************************************************/
        Open Estimate_Interest;

        FETCH
            Estimate_Interest
        INTO
            Hold_WBS_Element,
            Hold_Internal_Order,
            Hold_Sum_Est_Int_Amt;

        /*******************************************/
        /* SQLCODE 100 signifies no record fetched */
        /*******************************************/
        If SQLCODE = 100 THEN
            SET Estimate_Interest_Complete = 1;
        END If;

        SET ERRLOC = '0028';

        While Estimate_Interest_Complete = 0 Do

            SET ERRLOC = '0029';

            SET Hold_Est_Int_WBS_Element = CONCAT(LEFT(Hold_WBS_Element, LENGTH(Hold_WBS_Element) - 1), '2');

            /*************************************************************/
            /* INSERT the record into the SAP_ECMS_Payment_Funding table */
            /**************************************************************************************/
            /* Removed the code for inserting GL_ACCOUNT for Municipal and Local partial Estimates*/
            /**************************************************************************************/
            If Hold_Funding_Id = 0 THEN
                SELECT Funding_Id INTO Hold_Funding_Id FROM Final Table (
                INSERT INTO
                    ECMSXADM.SAP_ECMS_Payment_Funding
                (
                    Funding_Id,
                    Line_Item_Nbr,
                    WBS_Element,
                    Internal_Order,
                    Line_Item_Amt,
                    ECMS_Transaction_Id
                ) VALUES (
                    (SELECT Coalesce(Max(Funding_Id), 0) + 1 FROM ECMSXADM.SAP_ECMS_Payment_Funding),
                    1,
                    Coalesce(Hold_Est_Int_WBS_Element,'0-00000000000-0000-000'),
                    Coalesce(Hold_Est_Int_Internal_Order,'00000'),
                    Coalesce(Hold_Sum_Est_Int_Amt,0),
                    In_ECMS_Transaction_Id));
            Else
                INSERT INTO
                    ECMSXADM.SAP_ECMS_Payment_Funding
                (
                    Funding_Id,
                    Line_Item_Nbr,
                    WBS_Element,
                    Internal_Order,
                    Line_Item_Amt,
                    ECMS_Transaction_Id
                ) VALUES (
                    Hold_Funding_Id,
                    (SELECT Coalesce(Max(Line_Item_Nbr), 0) + 1 FROM ECMSXADM.SAP_ECMS_Payment_Funding WHERE Funding_Id = Hold_Funding_Id),
                    Coalesce(Hold_Est_Int_WBS_Element,'0-00000000000-0000-000'),
                    Coalesce(Hold_Est_Int_Internal_Order,'00000'),
                    Coalesce(Hold_Sum_Est_Int_Amt,0),
                    In_ECMS_Transaction_Id);
            END If;

            SET ERRLOC = '0030';

            /***********************/
            /* Get the next record */
            /***********************/
            FETCH
                Estimate_Interest
            INTO
                Hold_WBS_Element,
                Hold_Internal_Order,
                Hold_Sum_Est_Int_Amt;

            /*******************************************/
            /* SQLCODE 100 signifies no record fetched */
            /*******************************************/
            If SQLCODE = 100 THEN
                SET Estimate_Interest_Complete = 1;
            END If;

            SET ERRLOC = '0031';
        END While;

        SET ERRLOC = '0032';

        /***********************************************/
        /* UPDATE the estimate interest status to Paid */
        /***********************************************/
        UPDATE
            ECMSXADM.Est_Interest
        SET
            Est_Int_Status_Cd = '4'
        WHERE
            ECMS_Project_Num = Hold_ECMS_Project_Num
            And Est_Int_Status_Cd = '2';
 Else
        If Hold_ECMS_Transaction_Type_Code = C_Transaction_Type_Code_Estimate Or Hold_ECMS_Transaction_Type_Code = C_Transaction_Type_Code_Est_Adj THEN

            SET ERRLOC = '0033';

            /**********************************************/
            /* Get the project number and estimate number */
            /**********************************************/
            SELECT
                ECMS_Project_Num,
                Estimate_Num
            INTO
                Hold_ECMS_Project_Num,
                Hold_Estimate_Num
            FROM
                ECMSXADM.SAP_ECMS_Transaction
            WHERE
                ECMS_Transaction_Id = In_ECMS_Transaction_Id;

            SET ERRLOC = '0034';

            /***************************************************************/
            /* Open the estimate funding records and get the first record */
            /***************************************************************/
            Open Estimate_Funding;

            FETCH
                Estimate_Funding
            INTO
                Hold_WBS_Element,
                Hold_Internal_Order,
                Hold_Item_Total_Amt;

            /*******************************************/
            /* SQLCODE 100 signifies no record fetched */
            /*******************************************/
            If SQLCODE = 100 THEN
                SET Estimate_Complete = 1;
            END If;

            SET ERRLOC = '0035';

            While Estimate_Complete = 0 Do

                SET ERRLOC = '0036';

                /*************************************************************/
                /* INSERT the record into the SAP_ECMS_Payment_Funding table */
                /**************************************************************************************/
                /* Removed the code for inserting GL_ACCOUNT for Municipal and Local partial Estimates*/
                /**************************************************************************************/
                if Hold_Funding_Id = 0 THEN
                    SELECT Funding_Id INTO Hold_Funding_Id FROM Final Table (
                    INSERT INTO
                        ECMSXADM.SAP_ECMS_Payment_Funding
                    (
                        Funding_Id,
                        Line_Item_Nbr,
                        WBS_Element,
                        Internal_Order,
                        Line_Item_Amt,
                        ECMS_Transaction_Id
                    ) VALUES (
                        (SELECT Coalesce(Max(Funding_Id), 0) + 1 FROM ECMSXADM.SAP_ECMS_Payment_Funding),
                        1,
                        Coalesce(Hold_WBS_Element,'0-00000000000-0000-000'),
                        Coalesce(Hold_Internal_Order,'00000'),
                        Coalesce(Hold_Item_Total_Amt,0),
                        In_ECMS_Transaction_Id));
                Else
                    INSERT INTO
                        ECMSXADM.SAP_ECMS_Payment_Funding
                    (
                        Funding_Id,
                        Line_Item_Nbr,
                        WBS_Element,
                        Internal_Order,
                        Line_Item_Amt,
                        ECMS_Transaction_Id
                    ) VALUES (
                        Hold_Funding_Id,
                        (SELECT Coalesce(Max(Line_Item_Nbr), 0) + 1 FROM ECMSXADM.SAP_ECMS_Payment_Funding WHERE Funding_Id = Hold_Funding_Id),
                        Coalesce(Hold_WBS_Element,'0-00000000000-0000-000'),
                        Coalesce(Hold_Internal_Order,'00000'),
                        Coalesce(Hold_Item_Total_Amt,0),
                        In_ECMS_Transaction_Id);
                END If;

                SET ERRLOC = '0037';

                /***************************************************************/
                /* Get the next record */
                /***************************************************************/
                FETCH
                    Estimate_Funding
                INTO
                    Hold_WBS_Element,
                    Hold_Internal_Order,
                    Hold_Item_Total_Amt;

                /*******************************************/
                /* SQLCODE 100 signifies no record fetched */
                /*******************************************/
                If SQLCODE = 100 THEN
                    SET Estimate_Complete = 1;
                END If;

                SET ERRLOC = '0038';
            END While;
        END If;
   END If;
END If;

SET ERRLOC = '0039';

If No_Part_Funding_Records = 'Y' AND No_Bgt_Funding_Records = 'Y'
THEN 
SET No_Funding_Records = 'Y';
END If;





If No_Funding_Records = 'Y' THEN
    SET ERRLOC = '0040'||','||'No records found.';
    SET ERRCODE = -1;
Else
    /**************************************************************/
    /* UPDATE the ECMS Transaction with the funding code created. */
    /**************************************************************/
    UPDATE
        ECMSXADM.SAP_ECMS_Transaction
    SET
        Funding_Id = Hold_Funding_Id
    WHERE
        ECMS_Transaction_Id = In_ECMS_Transaction_Id;

    /*******************************************/
    /* Cursor left open for client application */
    /*******************************************/
    SET ERRLOC = '0000';
    SET ERRCODE = 0;
END If;

OPEN SINGLE_PARM_CURSOR;

END P1
