CREATE PROCEDURE ECMSXADM.SPCA0171 (IN P_PROJNUM INTEGER , OUT P_SQLCODE INTEGER)
	VERSION V1
	ISOLATION LEVEL CS
	RESULT SETS 1
	LANGUAGE SQL
	ALLOW DEBUG MODE
	WLM ENVIRONMENT FOR DEBUG MODE DSNDWLM2
	P1: BEGIN




DECLARE V_SQLCODE                		INT     DEFAULT 0;      
DECLARE V_SQLSTATE               		CHAR(5) DEFAULT '00000';
DECLARE SQLCODE                  		INT     DEFAULT 0;      
DECLARE SQLSTATE                 		CHAR(5) DEFAULT '00000';
DECLARE V_END_OF_CURSOR                 CHAR(1) DEFAULT 'N';
DECLARE V_ERRCD                         SMALLINT     DEFAULT 0;
DECLARE V_ERRLOC                        CHAR(5)      DEFAULT '     ';
DECLARE V_TABLEID                  		CHAR(12)     DEFAULT '$ECMSRETURN$';
DECLARE V_USER_ID						CHAR(80) DEFAULT 'Ecms system/PennDOT';
DECLARE V_GEN_CODE 						CHAR(5)	DEFAULT ' ';						
DECLARE V_GPC_VALUE						VARCHAR(255) DEFAULT ' ';
DECLARE V_GPC_VALUE_X					VARCHAR(255) DEFAULT ' ';
DECLARE V_GPC_PCT						SMALLINT DEFAULT 0;
DECLARE V_GPC_CNT						SMALLINT DEFAULT 0;
DECLARE V_GPC_AMT						INTEGER DEFAULT 0;
DECLARE V_FED_OVER_PCT				DECIMAL(4,1) DEFAULT 10;      
DECLARE V_FED_UNDER_PCT    			DECIMAL(4,1) DEFAULT 10;     
DECLARE V_STATE_OVER_PCT   			DECIMAL(4,1) DEFAULT 15;      
DECLARE V_STATE_UNDER_PCT  			DECIMAL(4,1) DEFAULT 10;      
DECLARE V_PRCS_BIDS_MAX    			DECIMAL(4,1) DEFAULT 5;       
DECLARE V_LRG_OVER_PCT              DECIMAL(4,1) DEFAULT 5;       
DECLARE V_LRG_UNDER_PCT             DECIMAL(4,1) DEFAULT 10;      
DECLARE V_MED_OVER_PCT              DECIMAL(4,1) DEFAULT 10;      
DECLARE V_MED_UNDER_PCT             DECIMAL(4,1) DEFAULT 20;      
DECLARE V_SM_OVER_PCT      			DECIMAL(4,1) DEFAULT 15;      
DECLARE V_SM_UNDER_PCT              DECIMAL(4,1) DEFAULT 25;      
DECLARE V_LRG_MIN_AMT               INTEGER DEFAULT 5000000; 
DECLARE V_MED_MIN_AMT      			INTEGER DEFAULT 500000;  
DECLARE V_DEFAULT_SCORE    			SMALLINT DEFAULT 25;      
DECLARE V_IX1						SMALLINT DEFAULT 0;
DECLARE V_BID_PACKAGE_NUM			SMALLINT DEFAULT 0;
DECLARE V_WT_BIDS_MAX				SMALLINT DEFAULT 25;
DECLARE V_MAX_DSGN_EST_BIDS			SMALLINT DEFAULT 12;
DECLARE V_MAX_COMP_DELTA			SMALLINT DEFAULT 20;
DECLARE V_MAX_OVERRUN_PCT			SMALLINT DEFAULT 20;
DECLARE V_MAX_OVERBID_PCT			SMALLINT DEFAULT 4;
DECLARE V_FED_PROJ_STAT_CD			CHAR(1)	DEFAULT ' ';  

DECLARE V_AC_ITEM_NUM				SMALLINT DEFAULT 120;     
DECLARE V_BUS_PARTNER_ID			CHAR(6) DEFAULT ' ';  
DECLARE V_EST_PROJ_AMT				DECIMAL(15,2) DEFAULT 0; 

DECLARE V_ECMS_PROJECT_NUM			INTEGER DEFAULT 0;                   
               
DECLARE V_BID_BPID					CHAR(6) DEFAULT ' ';                           
DECLARE V_BID_TOTAL_AMT 			DECIMAL(15,2) DEFAULT 0;		  
DECLARE V_BID_STATUS_CODE			CHAR(1) DEFAULT ' ';
DECLARE V_BID_RANKING 				SMALLINT DEFAULT 0; 

DECLARE V_TOT_NUM_BIDS				SMALLINT DEFAULT 0;  
DECLARE V_DSGN_EST_RANK_9			SMALLINT DEFAULT 0;
DECLARE V_DSGN_EST_RANK				SMALLINT DEFAULT 0;
DECLARE V_DSGN_EST_RANK_X			CHAR(2) DEFAULT ' ';
DECLARE V_DSGN_EST_RANK_H			CHAR(2) DEFAULT ' ';
DECLARE V_OVER_MAX 					DECIMAL(5,2) DEFAULT 0;
DECLARE V_UNDER_MAX					DECIMAL(5,2) DEFAULT 0;
DECLARE V_MAX_PCT_PROJ				DECIMAL(5,2) DEFAULT 0;				
DECLARE  V_MIN_PCT_PROJ				DECIMAL(5,2) DEFAULT 0;
DECLARE V_PCT_VARIANCE				DECIMAL(7,2) DEFAULT 0;
DECLARE V_BID_JUST_IND				CHAR(1) DEFAULT ' ';
DECLARE V_LOW_BID_VARIANCE			DECIMAL(5,2) DEFAULT 0;
DECLARE V_COMP_NUM_BIDS				SMALLINT	DEFAULT 0;

DECLARE V_BID_TOTAL_AMT_1ST_ROW		DECIMAL(15,2)	DEFAULT 0;
DECLARE V_BID_TOTAL_AMT_2ND_ROW		DECIMAL(15,2)	DEFAULT 0;	
DECLARE V_BID_SCORE_COMP			SMALLINT	DEFAULT 0;
DECLARE V_BID_SCORE_ESTLOW			SMALLINT 	DEFAULT 0;
DECLARE V_DELTA_VARIANCE			DECIMAL(4,1) DEFAULT 0;
DECLARE V_BID_SCORE_OVER			SMALLINT	DEFAULT 0;
DECLARE V_BID_SCORE_POS_U			SMALLINT	DEFAULT 0;
DECLARE V_WRK_BIDS					SMALLINT	DEFAULT 0;
DECLARE V_BID_SCORE_POS_O			SMALLINT	DEFAULT 0;

DECLARE V_FIRST_TIME_SW				CHAR(1)		DEFAULT 'Y';
DECLARE V_BID_SCORE_CON_1			SMALLINT	DEFAULT 0;
DECLARE V_BID_SCORE_TOTAL			SMALLINT	DEFAULT 0;
DECLARE V_JS_STATUS_CODE			CHAR(1)		DEFAULT ' ';
DECLARE V_NUM_BIDS					SMALLINT	DEFAULT 0;





DECLARE SINGLE_PARM_CURSOR CURSOR WITH RETURN
   FOR                                        
   SELECT V_TABLEID,                        
          V_SQLCODE,                          
          V_ERRCD,                          
          V_ERRLOC
                           
     FROM SYSIBM.SYSDUMMY1    ;


DECLARE GPC_CURSOR CURSOR 
	FOR
    SELECT GEN_CODE, GEN_CODE_VALUE   
    FROM COM_GENERAL_CODE             
    WHERE GEN_CODE_TYPE = 98          
    ORDER BY GEN_CODE ;                


DECLARE BID_CURSOR CURSOR FOR 
  SELECT ECMS_PROJECT_NUM,    
           BID_PACKAGE_NUM,   
           BUS_PARTNER_ID,    
           CONT_BID_TOT_AMT,  
           BID_STATUS_CODE,   
           BID_RANKING        
  FROM CONTR_ECMS_BID_OPEN 
  WHERE   ECMS_PROJECT_NUM = P_PROJNUM      
	AND     BID_PACKAGE_NUM    = V_BID_PACKAGE_NUM
	AND     BID_STATUS_CODE    <> '04'              
	AND     BID_STATUS_CODE    <> '05'              
	AND     CONT_BID_TOT_AMT    > 0                 
	AND NOT BID_RANKING        IS NULL              
	ORDER BY BID_RANKING   ;                            


DECLARE TEMP_CURSOR CURSOR FOR
SELECT *
FROM SESSION.G_TEMP;



DECLARE EXIT HANDLER FOR SQLEXCEPTION

	BEGIN
	
	   SET V_SQLCODE = SQLCODE   ;
       SET V_ERRCD = -1;
       OPEN SINGLE_PARM_CURSOR;
       
   END;





DECLARE CONTINUE HANDLER FOR SQLSTATE '42704'
	
	BEGIN
	
		SET V_SQLSTATE = SQLSTATE;
  
	END;


DROP TABLE SESSION.G_TEMP;	


DECLARE GLOBAL TEMPORARY TABLE SESSION.G_TEMP
 (  
 	G_BID_BPID				CHAR(6),                                              
    G_BID_TOTAL_AMT 		DECIMAL(15,2),
    G_BID_RANKING   		SMALLINT,
    G_PCT_VARIANCE			DECIMAL(4,2)                   
 )
 ON COMMIT PRESERVE ROWS            
;


SET V_DSGN_EST_RANK_9 = 99;
SET V_DSGN_EST_RANK   = 99;
SET V_DSGN_EST_RANK_X = V_DSGN_EST_RANK_9;

   
   
SET V_ERRLOC = 'D010';
OPEN GPC_CURSOR;

SET V_END_OF_CURSOR       =  'N';
SET V_ERRLOC = 'D020';              
WHILE V_END_OF_CURSOR = 'N'
DO FETCH GPC_CURSOR   
 	INTO V_GEN_CODE,
      	 V_GPC_VALUE;
  IF SQLCODE = 100
  THEN 
       CLOSE GPC_CURSOR;  
       SET V_END_OF_CURSOR = 'Y';
  ELSE
  	    IF V_GEN_CODE = '01'
   	    THEN
   	  	  SET V_FED_UNDER_PCT = CAST(TRIM(SUBSTR(V_GPC_VALUE, 1, 2)) AS DECIMAL(4,1) ) ;
   	    ELSE
   	  		IF V_GEN_CODE = '02'
   	  		THEN
   	  			SET V_FED_OVER_PCT = CAST(TRIM(SUBSTR(V_GPC_VALUE, 1, 2)) AS DECIMAL(4,1) ) ;
   	  		ELSE
   	  			IF V_GEN_CODE = '03'
   	  			THEN
   	  				SET V_STATE_UNDER_PCT = CAST(TRIM(SUBSTR(V_GPC_VALUE, 1, 2)) AS DECIMAL(4,1) ) ;
   	  			ELSE
   	  				IF V_GEN_CODE = '04'
   	  				THEN
   	  					SET V_STATE_OVER_PCT = CAST(TRIM(SUBSTR(V_GPC_VALUE, 1, 2)) AS DECIMAL(4,1) ) ;
   	  				ELSE
   	  					IF V_GEN_CODE = '05'
   	  					THEN
   	  						SET V_PRCS_BIDS_MAX = CAST(TRIM(SUBSTR(V_GPC_VALUE, 1, 2)) AS DECIMAL(4,1) ) ;
   	  						IF V_PRCS_BIDS_MAX > V_WT_BIDS_MAX
   	  						THEN
   	  							 SET V_ERRLOC = 'A011';
							     SET V_ERRCD  = -1;
							     OPEN SINGLE_PARM_CURSOR;
							     RETURN -200;
							END IF;
						ELSE
							IF V_GEN_CODE = '06'
							THEN
								SET V_LRG_OVER_PCT = CAST(TRIM(SUBSTR(V_GPC_VALUE, 1, 2)) AS DECIMAL(4,1) ) ;
							ELSE
								IF V_GEN_CODE = '07'
								THEN
									SET V_LRG_UNDER_PCT = CAST(TRIM(SUBSTR(V_GPC_VALUE, 1, 2)) AS DECIMAL(4,1) ) ;
								ELSE
									IF V_GEN_CODE = '08'
									THEN
										SET V_MED_OVER_PCT = CAST(TRIM(SUBSTR(V_GPC_VALUE, 1, 2)) AS DECIMAL(4,1) ) ;
									ELSE
										IF V_GEN_CODE = '09'
										THEN
											SET V_MED_UNDER_PCT = CAST(TRIM(SUBSTR(V_GPC_VALUE, 1, 2)) AS DECIMAL(4,1) ) ;
										ELSE
										 	IF V_GEN_CODE = '10'
											THEN
												SET V_SM_OVER_PCT = CAST(TRIM(SUBSTR(V_GPC_VALUE, 1, 2)) AS DECIMAL(4,1) ) ;
											ELSE
												IF V_GEN_CODE = '11'
												THEN
													SET V_SM_UNDER_PCT = CAST(TRIM(SUBSTR(V_GPC_VALUE, 1, 2)) AS DECIMAL(4,1) ) ;
												ELSE
													IF V_GEN_CODE = '12'
													THEN
														SET V_LRG_MIN_AMT = CAST(TRIM(SUBSTR(V_GPC_VALUE, 1, 9)) AS INTEGER);
													ELSE
														IF V_GEN_CODE = '13'
														THEN
															SET V_MED_MIN_AMT = CAST(TRIM(SUBSTR(V_GPC_VALUE, 1, 9)) AS INTEGER);
														ELSE
															IF V_GEN_CODE = '14'
															THEN
																SET V_DEFAULT_SCORE = CAST(TRIM(SUBSTR(V_GPC_VALUE, 1, 2)) AS SMALLINT);
															ELSE
																IF  V_GEN_CODE = '15'
																THEN
																	SET V_MAX_DSGN_EST_BIDS = CAST(TRIM(SUBSTR(V_GPC_VALUE, 1, 2)) AS SMALLINT) ;	
																ELSE
																	IF V_GEN_CODE = '16'
																	THEN
																		SET V_MAX_COMP_DELTA = 	CAST(TRIM(SUBSTR(V_GPC_VALUE, 1, 2)) AS SMALLINT) ;
																	ELSE
																		IF V_GEN_CODE = '17'
																		THEN
																			SET V_MAX_OVERRUN_PCT = CAST(TRIM(SUBSTR(V_GPC_VALUE, 1, 2)) AS DECIMAL(4,1) ) ;
																		ELSE
																			IF V_GEN_CODE = '18'
																			THEN
																				SET V_MAX_OVERBID_PCT = CAST(TRIM(SUBSTR(V_GPC_VALUE, 1, 2)) AS DECIMAL(4,1) ) ;
																			END IF;
																		END IF;
																	END IF;
																END IF;			
															END IF;
														END IF;
													END IF;			
												END IF;
											END IF;
										END IF;			
									END IF;	
								END IF;
							END IF;
						END IF;
					END IF;
				END IF;
			END IF;
		END IF;						
  END IF;
END WHILE;   	  

SET V_ERRLOC = 'D030';  
SELECT A.FED_PROJ_STAT_CD,                      
     A.CURR_BID_PKG_NUM,                        
     B.AC_ITEM_NUM,                             
     C.BUS_PARTNER_ID ,                         
     FLOAT(A.EST_PROJECT_AMT) AS EST_PROJECT_AMT

INTO V_FED_PROJ_STAT_CD,
     V_BID_PACKAGE_NUM, 
     V_AC_ITEM_NUM,     
     V_BUS_PARTNER_ID,  
     V_EST_PROJ_AMT   
       
FROM PROJECT A, AC_ITEM B, CONTR_ECMS_BID_OPEN C
 
WHERE A.ECMS_PROJECT_NUM  = P_PROJNUM    
AND   A.ECMS_PROJECT_NUM  = B.ECMS_PROJECT_NUM 
AND   A.ECMS_PROJECT_NUM  = C.ECMS_PROJECT_NUM 
AND   A.CURR_BID_PKG_NUM  = B.BID_PACKAGE_NUM  
AND   A.CURR_BID_PKG_NUM  = C.BID_PACKAGE_NUM  
AND   C.BUS_PARTNER_ID    = B.BUS_PARTNER_ID   
AND   B.AC_ITEM_TYPE_CODE = '120'              
AND   C.BID_RANKING       = 1                  
                                               
GROUP BY A.ECMS_PROJECT_NUM,                   
    A.FED_PROJ_STAT_CD,
	A.CURR_BID_PKG_NUM,
	B.AC_ITEM_NUM,
	C.BUS_PARTNER_ID, 
	A.EST_PROJECT_AMT    ; 


SET V_ERRLOC = 'D040';             	
OPEN BID_CURSOR;
SET V_END_OF_CURSOR       =  'N';
SET V_ERRLOC = 'D050';  
SET V_TOT_NUM_BIDS = 0;
SET V_IX1 = 0;            
WHILE V_END_OF_CURSOR = 'N'
DO FETCH BID_CURSOR                              
 	INTO V_ECMS_PROJECT_NUM,                   
      	 V_BID_PACKAGE_NUM,                    
      	 V_BID_BPID,                           
      	 V_BID_TOTAL_AMT ,  
      	 V_BID_STATUS_CODE ,
      	 V_BID_RANKING ;                        
  IF SQLCODE = 100
  THEN 
       CLOSE BID_CURSOR;  
       SET V_END_OF_CURSOR = 'Y';
  ELSE
  	  SET V_TOT_NUM_BIDS = V_TOT_NUM_BIDS + 1;
	  SET V_NUM_BIDS = V_TOT_NUM_BIDS;	
	  
	  IF V_DSGN_EST_RANK_9 = 99
  	  THEN
  	  		IF  V_BID_TOTAL_AMT > V_EST_PROJ_AMT  AND
  	  		    V_BID_RANKING < 100
  	  		THEN
  	  			SET V_DSGN_EST_RANK_9 = V_BID_RANKING;
  	  			SET V_DSGN_EST_RANK = V_DSGN_EST_RANK_9  ;  
  	  			SET V_DSGN_EST_RANK_X = V_DSGN_EST_RANK_9;
  	  		END IF;
  	  END IF;
  	  
  	  
  	  SET V_IX1 = V_IX1 + 1;	-- NUMBER OF INSERTED ROWS


	  IF V_EST_PROJ_AMT <= 0
  	  THEN
  	  		SET V_ERRLOC = 'A021';
     		SET V_ERRCD  = -1;
     		OPEN SINGLE_PARM_CURSOR;
     		RETURN -200;	
      END IF;



	  IF V_IX1 = 1
      THEN
      		SET V_BID_TOTAL_AMT_1ST_ROW = V_BID_TOTAL_AMT;  -- SAVED HERE BECAUSE I DON'T HAVE INTERNAL TABLE 
      	
      	  IF V_FED_PROJ_STAT_CD = '4'  -- FEDERAL PROJECT STATUS CODE IS 100% STATE
      	  THEN
      	  	  SET V_OVER_MAX  = V_STATE_OVER_PCT;
      	  	  SET V_UNDER_MAX = V_STATE_UNDER_PCT;
      	  ELSE
      	  	  SET V_OVER_MAX  = V_FED_OVER_PCT;
      	  	  SET V_UNDER_MAX = V_FED_UNDER_PCT;
      	  END IF;
      	  
      	  IF V_EST_PROJ_AMT > V_LRG_MIN_AMT
      	  THEN
      	  	  SET V_MAX_PCT_PROJ = V_LRG_OVER_PCT;
      	  	  SET V_MIN_PCT_PROJ = V_LRG_UNDER_PCT;
      	  ELSE
      	  	  IF V_EST_PROJ_AMT > V_MED_MIN_AMT  OR
      	  	     V_EST_PROJ_AMT < V_LRG_MIN_AMT
      	  	  THEN
      	  	  		SET V_MAX_PCT_PROJ = V_MED_OVER_PCT;
      	  	  		SET V_MIN_PCT_PROJ = V_MED_UNDER_PCT;
      	  	  ELSE
      	  	  		SET V_MAX_PCT_PROJ = V_SM_OVER_PCT;
      	  	  		SET V_MIN_PCT_PROJ = V_MED_UNDER_PCT;
      	  	  END IF;
      	  END IF;
      	  
      	  IF V_BID_TOTAL_AMT >= V_EST_PROJ_AMT
      	  THEN
      	  	  SET V_PCT_VARIANCE = (V_BID_TOTAL_AMT * 100 / V_EST_PROJ_AMT) - 100;
      	  	  IF V_PCT_VARIANCE > V_OVER_MAX  OR
      	  	     V_PCT_VARIANCE > V_MAX_PCT_PROJ
      	  	  THEN
      	  	  		SET V_BID_JUST_IND = 'Y';
      	  	  END IF;
      	  ELSE
      	  	  SET V_PCT_VARIANCE = 100 - (V_BID_TOTAL_AMT * 100 / V_EST_PROJ_AMT)	;
      	  	  
      	  	  IF V_PCT_VARIANCE > V_UNDER_MAX  OR
      	  	     V_PCT_VARIANCE > V_MIN_PCT_PROJ
      	  	  THEN
      	  	  	  SET V_BID_JUST_IND = 'Y';
      	  	  END IF;
      	  END IF;
      	  
      	  SET V_LOW_BID_VARIANCE = V_PCT_VARIANCE;
      	  	  	  	   	   		   
      	  SET V_PCT_VARIANCE = 0;
      ELSE
      		IF V_IX1 = 2
      		THEN
      			SET V_BID_TOTAL_AMT_2ND_ROW = V_BID_TOTAL_AMT;  -- SAVED HERE BECAUSE I DON'T HAVE INTERNAL TABLE 
      		END IF;	
      	  SET V_PCT_VARIANCE = (V_BID_TOTAL_AMT * 100 / V_BID_TOTAL_AMT_1ST_ROW) - 100 ;
      	  IF V_PCT_VARIANCE > 99.99
      	  THEN
      	  	  SET V_PCT_VARIANCE  = 99.99;
      	  END IF;
      END IF;	  	  	  		
      
      IF V_IX1 <= V_PRCS_BIDS_MAX
      THEN	   	  		
	      INSERT INTO SESSION.G_TEMP
	  	  (G_BID_BPID, G_BID_TOTAL_AMT, G_BID_RANKING, G_PCT_VARIANCE)
	  	  VALUES
	  	  (V_BID_BPID, V_BID_TOTAL_AMT, V_BID_RANKING, V_PCT_VARIANCE); 
      
	      IF V_PCT_VARIANCE < V_MAX_COMP_DELTA
	      THEN
	      	  SET V_COMP_NUM_BIDS = V_TOT_NUM_BIDS;
	      END IF;	  
  	  END IF;			
  END IF;		
END WHILE;	


IF V_DSGN_EST_RANK_9 = 99
THEN
	SET V_DSGN_EST_RANK_9 	= V_TOT_NUM_BIDS + 1;
	SET V_DSGN_EST_RANK 	= V_DSGN_EST_RANK_9;
	SET V_DSGN_EST_RANK_X 	= V_DSGN_EST_RANK_9;
END IF;

SET V_ERRLOC = 'D060';     	
SELECT BID_SCORE                   
INTO   V_BID_SCORE_COMP          
FROM   BID_COMPETITION             
WHERE  NUM_BIDS = V_COMP_NUM_BIDS;

SET V_DELTA_VARIANCE = V_LOW_BID_VARIANCE;
IF V_DELTA_VARIANCE < 0
THEN
	SET V_DELTA_VARIANCE = V_DELTA_VARIANCE * -1;
END IF;

IF V_BID_TOTAL_AMT_1ST_ROW >= V_EST_PROJ_AMT
THEN
	SET V_ERRLOC = 'D070';
	 SELECT BID_SCORE                          
	INTO   V_BID_SCORE_ESTLOW               
	FROM   BID_EST_DIFF_OVER                  
	WHERE  NUM_BIDS      = V_COMP_NUM_BIDS  
	AND    BID_PCT_LOW  <= V_DELTA_VARIANCE 
	AND    BID_PCT_HIGH >= V_DELTA_VARIANCE ;
ELSE
	SET V_ERRLOC = 'D080';
	SELECT BID_SCORE                         
	INTO   V_BID_SCORE_ESTLOW              
	FROM   BID_EST_DIFF_UNDER                
	WHERE  NUM_BIDS      = V_COMP_NUM_BIDS 
	AND    BID_PCT_LOW  <= V_DELTA_VARIANCE
	AND    BID_PCT_HIGH >= V_DELTA_VARIANCE ;
END IF;

IF V_BID_TOTAL_AMT_1ST_ROW > 0
THEN
	SET V_PCT_VARIANCE = (V_BID_TOTAL_AMT_2ND_ROW * 100 / V_BID_TOTAL_AMT_1ST_ROW) - 100;
ELSE
	SET V_ERRLOC = 'A031';
     SET V_ERRCD  = -1;
     OPEN SINGLE_PARM_CURSOR;
     RETURN -200;
END IF;     	

SET V_ERRLOC = 'D090';
SELECT BID_SCORE                       
INTO   V_BID_SCORE_OVER              
FROM   BID_OVERRUN                     
WHERE  BID_PCT_LOW  <= V_PCT_VARIANCE
  AND    BID_PCT_HIGH > V_PCT_VARIANCE ;

IF V_PCT_VARIANCE > V_MAX_OVERRUN_PCT
THEN
	SET V_BID_JUST_IND = 'Y';
END IF;

IF V_TOT_NUM_BIDS > V_MAX_DSGN_EST_BIDS
THEN
	SET V_WRK_BIDS = V_MAX_DSGN_EST_BIDS;
ELSE
	SET V_WRK_BIDS = V_TOT_NUM_BIDS;
END IF;


IF V_DSGN_EST_RANK_X = '1' OR
   V_DSGN_EST_RANK_X = '2' OR
   V_DSGN_EST_RANK_X = '3' OR
   V_DSGN_EST_RANK_X = '4' OR
   V_DSGN_EST_RANK_X = '5' OR
   V_DSGN_EST_RANK_X = '6' OR
   V_DSGN_EST_RANK_X = '7' OR
   V_DSGN_EST_RANK_X = '8' OR
   V_DSGN_EST_RANK_X = '9'
THEN
	SET V_DSGN_EST_RANK_H = '0' || TRIM(V_DSGN_EST_RANK_X);    
   	SET V_DSGN_EST_RANK_X = V_DSGN_EST_RANK_H;
END IF;   	

SET V_ERRLOC = 'D100';
SELECT BID_SCORE                              
INTO   V_BID_SCORE_POS_U                    
FROM   BID_EST_POS_UNDER                      
WHERE  NUM_BIDS         = V_WRK_BIDS        
AND    DESIGN_EST_RANK  = V_DSGN_EST_RANK_X ;

IF SQLCODE = 100
THEN
	SET V_BID_SCORE_POS_U = 0;
END IF;		

IF V_BID_TOTAL_AMT_1ST_ROW > V_EST_PROJ_AMT
THEN
    SET V_BID_SCORE_POS_O = 0;
    SET V_ERRLOC = 'D110';  
    OPEN TEMP_CURSOR; 
    SET V_IX1 = 0;          	
	SET V_END_OF_CURSOR   =  'N';
	WHILE V_END_OF_CURSOR = 'N'
	DO FETCH TEMP_CURSOR                              
	 	INTO V_BID_BPID,                                              
    		V_BID_TOTAL_AMT,
    		V_BID_RANKING,
    		V_PCT_VARIANCE;	                        
	  IF SQLCODE = 100
	  THEN 
	       CLOSE TEMP_CURSOR;  
	       SET V_END_OF_CURSOR = 'Y';
	  ELSE
	  		SET V_IX1 = V_IX1 + 1;
	  		IF V_FIRST_TIME_SW = 'Y'
	  		THEN
	  			SET V_FIRST_TIME_SW = 'N';
	  		ELSE
	  			IF V_TOT_NUM_BIDS > V_MAX_OVERBID_PCT
	  			THEN
	  				SET V_WRK_BIDS = V_MAX_OVERBID_PCT;
	  			ELSE			
	  	  			SET V_WRK_BIDS = V_TOT_NUM_BIDS;
	  	  		END IF;	
	  	  		
	  	  			  	  		
	  	  		SET V_ERRLOC = 'D120';
	  	  		SELECT BID_SCORE                         
				INTO   V_BID_SCORE_CON_1               
				FROM   BID_EST_POS_OVER                  
				WHERE  NUM_BIDS       = V_WRK_BIDS     
				AND    BID_RANKING    = V_IX1          
				AND    BID_PCT_LOW   <= V_PCT_VARIANCE 
				AND    BID_PCT_HIGH  >= V_PCT_VARIANCE ;
				
				SET V_BID_SCORE_POS_O = V_BID_SCORE_POS_O + V_BID_SCORE_CON_1;
	  	  		
	  	  	END IF;	
	  	  
	  	  	IF V_IX1 > V_WRK_BIDS
	  	  	THEN
	  	  		CLOSE TEMP_CURSOR;
	  	  		SET V_END_OF_CURSOR = 'Y';
	  	  	END IF;
	  	  		
	  END IF;	  		
    END WHILE;
    
END IF;   

SET V_BID_SCORE_TOTAL = V_BID_SCORE_COMP + 
						V_BID_SCORE_ESTLOW + 
						V_BID_SCORE_OVER +
						V_BID_SCORE_POS_U + 
						V_BID_SCORE_POS_O;
						
IF V_TOT_NUM_BIDS > V_PRCS_BIDS_MAX
THEN
	SET V_WRK_BIDS = V_PRCS_BIDS_MAX;
ELSE
	SET V_WRK_BIDS = V_TOT_NUM_BIDS;
END IF;
		
SET V_DSGN_EST_RANK_X = V_DSGN_EST_RANK;
SET V_ERRLOC = 'D130';
INSERT INTO AC_JSHEET 
    (ECMS_PROJECT_NUM,
     BID_PACKAGE_NUM, 
     BUS_PARTNER_ID,  
     AC_ITEM_NUM,     
     EST_PROJECT_AMT, 
     NUM_BIDS,        
     DESIGN_EST_RANK, 
     BID_LEVEL_COMP,  
     BID_EST_LOW,     
     BID_OVERRUN,     
     BID_UNDERBID,    
     BID_OVERBID,     
     BID_SCORE_TOTAL, 
     BID_JUST_IND,    
     CREATED_BY,      
     CREATED_BY_TS)   
VALUES
	(V_ECMS_PROJECT_NUM, 
	 V_BID_PACKAGE_NUM,  
	 V_BUS_PARTNER_ID,   
	 V_AC_ITEM_NUM,      
	 V_EST_PROJ_AMT,     
	 V_WRK_BIDS,         
	 V_DSGN_EST_RANK_X,  
	 V_BID_SCORE_COMP,   
	 V_BID_SCORE_ESTLOW, 
	 V_BID_SCORE_OVER,   
	 V_BID_SCORE_POS_U,  
	 V_BID_SCORE_POS_O,  
	 V_BID_SCORE_TOTAL,  
	 V_BID_JUST_IND,     
	 V_USER_ID,          
	 CURRENT_TIMESTAMP)  ;       


SET V_ERRLOC = 'D140';  
OPEN TEMP_CURSOR; 
SET V_IX1 = 0;          	
SET V_END_OF_CURSOR   =  'N';
WHILE V_END_OF_CURSOR = 'N'
DO FETCH TEMP_CURSOR                              
 	INTO V_BID_BPID,                                              
		V_BID_TOTAL_AMT,
		V_BID_RANKING,
		V_PCT_VARIANCE;	                        
  IF SQLCODE = 100
  THEN 
       CLOSE TEMP_CURSOR;  
       SET V_END_OF_CURSOR = 'Y';
  ELSE
  		SET V_ERRLOC = 'D150'; 
  		INSERT INTO AC_JSHEET_BID_COMP 
	    (ECMS_PROJECT_NUM,         
	     BID_PACKAGE_NUM,          
	     BUS_PARTNER_ID,           
	     AC_ITEM_NUM,              
	     BID_RANKING,              
	     BID_TOTAL_AMT,            
	     BID_PCT_DIFF_LOW)         
		VALUES                         
	    (V_ECMS_PROJECT_NUM,     
	     V_BID_PACKAGE_NUM,      
	     V_BUS_PARTNER_ID,       
	     V_AC_ITEM_NUM,          
	     V_BID_RANKING,          
	     V_BID_TOTAL_AMT,        
	     V_PCT_VARIANCE) ;        
  		
  END IF;	  		
END WHILE;

IF V_BID_JUST_IND = 'Y'
THEN
	SET V_JS_STATUS_CODE = '2';
ELSE
	SET V_JS_STATUS_CODE = '1';
END IF;

SET V_ERRLOC = 'D160'; 
UPDATE AC_BID_JUST                             
    SET AC_JS_STATUS_CODE = V_JS_STATUS_CODE 
WHERE                                          
    ECMS_PROJECT_NUM  = V_ECMS_PROJECT_NUM   
AND BID_PACKAGE_NUM   = V_BID_PACKAGE_NUM    
AND BUS_PARTNER_ID    = V_BUS_PARTNER_ID     
AND AC_ITEM_NUM       = V_AC_ITEM_NUM  ;      				


	
OPEN SINGLE_PARM_CURSOR;	
	
	
END P1
