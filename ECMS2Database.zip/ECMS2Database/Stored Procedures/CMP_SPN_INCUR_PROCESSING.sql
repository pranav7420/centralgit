CREATE PROCEDURE CMP_SPN_INCUR_PROCESSING (
     	OUT OUT_SQLSTATE CHAR(5),
		OUT OUT_SQLCODE INTEGER,
		OUT OUT_ERRORLOC VARCHAR(80),
		OUT OUT_ERRCODE INTEGER
	)

	RESULT SETS 1
	LANGUAGE SQL
	QUALIFIER ECMSXADM
	VALIDATE BIND
	ISOLATION LEVEL CS
	PACKAGE OWNER HWYDEV
	ALLOW DEBUG MODE
	ASUTIME LIMIT 120000
	WLM ENVIRONMENT FOR DEBUG MODE DSNDWLM2  

P1: BEGIN

/*************************/
/* VARIABLE DECLARATIONS */
/*************************/
DECLARE HOLD_SPN_SAP_TOTAL_SPENT_AMT            DECIMAL(13, 2);
DECLARE HOLD_STATE_PROJECT_NUMBER               CHAR(18);
DECLARE SPN_STATE_INCUR_UPDATE_COMPLETE         SMALLINT    DEFAULT 0;
DECLARE HOLD_LAST_MODIFIED_BY                   CHAR(40) DEFAULT 'ECMS CMP_SPN_STATE_INCUR_PROCESSING';

/**********************************************************/
/* THESE VARIABLES ARE PASSED BACK TO THE CALLING PROGRAM */
/**********************************************************/
DECLARE SQLSTATE CHAR(5) DEFAULT '00000';
DECLARE SQLCODE  INT     DEFAULT 0;

/********************************************************************/
/* DECLARE A CURSOR TO READ THE INV AMTS FOR SPN IN PAID STATUS   */
/********************************************************************/
DECLARE SPN_SAP_TOTAL_SPENT CURSOR FOR

SELECT STATE_PROJECT_NBR,
       COALESCE(SAP_TOTAL_SPENT_AMT,0) AS SAP_TOTAL_SPENT_AMT
  FROM ECMSXADM.SPN_CONSUMPTION  
WHERE STATE_PROJECT_NBR IS NOT NULL
AND COALESCE(SAP_TOTAL_SPENT_AMT,0) > 0
; 

/*******************/
/* DECLARE HANDLER */
/*******************/
DECLARE EXIT HANDLER FOR SQLEXCEPTION

/************************************/
/* INITIALIZE THE RETURN PARAMETERS.*/
/************************************/
SET OUT_SQLSTATE = SQLSTATE;
SET OUT_SQLCODE = SQLCODE;
SET OUT_ERRORLOC = '0001';
SET OUT_ERRCODE = -1;

/**************************************/
/* OPEN THE SPN_INV_PAID_AMTS CURSOR  */
/**************************************/
OPEN SPN_SAP_TOTAL_SPENT;

/**********************************************/
/* LOOP THROUGHT THE LIST AND UPDATE THE TABLE*/
/**********************************************/
SET OUT_ERRORLOC = '0002';

WHILE SPN_STATE_INCUR_UPDATE_COMPLETE = 0 DO

    FETCH
       SPN_SAP_TOTAL_SPENT
    INTO
        HOLD_STATE_PROJECT_NUMBER,
        HOLD_SPN_SAP_TOTAL_SPENT_AMT               
        ;      

/*******************************************/
/* SQLCODE 100 SIGNIFIES NO RECORD FETCHED */
/*******************************************/        
    IF SQLCODE = 100 THEN
        SET SPN_STATE_INCUR_UPDATE_COMPLETE = 1;
   
/*******************************************/
/* IF NO RECORDS FOUND, CLOSE THE CURSOR   */
/*******************************************/    
        CLOSE SPN_SAP_TOTAL_SPENT;

        ELSE

        SET OUT_ERRORLOC = '0003'||','||'ERROR IN UPDATING SPN'||','||HOLD_STATE_PROJECT_NUMBER;

/*************************************************************/
/* UPDATE THE RECORD INTO THE SPN_COMSUMPTION TABLE          */
/*************************************************************/
        UPDATE SPN_CONSUMPTION
        SET SPN_TOTAL_SPENT_AMT = HOLD_SPN_SAP_TOTAL_SPENT_AMT + COALESCE(INV_AGREEMENT_AMT,0) + COALESCE(INV_PROJECT_AMT,0),
            SPN_STATE_INCUR_COST = HOLD_SPN_SAP_TOTAL_SPENT_AMT - (COALESCE(SAP_AGREEMENT_AMT,0) + COALESCE(SAP_PROJECT_AMT,0)),                          
            LAST_MODIFIED_BY = HOLD_LAST_MODIFIED_BY,
            LAST_MODIFIED_TS = CURRENT TIMESTAMP 
         WHERE STATE_PROJECT_NBR = HOLD_STATE_PROJECT_NUMBER
         AND COALESCE(SPN_TOTAL_SPENT_AMT,0) <> HOLD_SPN_SAP_TOTAL_SPENT_AMT
         ;  
  
        SET OUT_SQLSTATE = SQLSTATE;
        SET OUT_SQLCODE = SQLCODE;
  
    END IF;             
END WHILE;

IF (SQLCODE = 0 AND SQLSTATE = '00000')THEN
    SET OUT_ERRORLOC = '0000'||','||'SUCCESSFUL';
    SET OUT_ERRCODE = 0;
END IF;

END P1