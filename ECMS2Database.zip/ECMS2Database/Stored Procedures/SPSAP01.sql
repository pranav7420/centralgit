CREATE PROCEDURE ECMSXADM.SPSAP01 (IN In_ECMS_Transaction_Id Integer)

 LANGUAGE SQL
 FENCED
 RESULT SETS 1
 NOT DETERMINISTIC
 EXTERNAL NAME SPSAP01
 MODIFIES SQL DATA
 NO DBINFO
 COLLID ECMSODBC
 WLM ENVIRONMENT DSNDWLM2
 ASUTIME LIMIT 10000
 STAY RESIDENT NO
 PROGRAM TYPE MAIN
 SECURITY DB2
 COMMIT ON RETURN NO
 RUN OPTIONS 'NOTEST(ALL,*,,VADTCPIP&10.27.80.85:*)'
 
------------------------------------------------------------------------
-- SQL Stored Procedure
------------------------------------------------------------------------
P1: Begin

/*************************/
/* Variable Declarations */
/*************************/

DECLARE Hold_ECMS_Transaction_Type_Code     Char(2);
DECLARE Hold_Agr                            Char(6);
DECLARE Hold_Internal_Order                 Char(5);
DECLARE Hold_WBS_Element                    Char(24);
DECLARE Hold_General_Ledger_Acct            Char(7);
DECLARE Hold_Estimate_Num                   Char(3);
DECLARE No_Funding_Records                  Char(1)     Default 'N';
DECLARE Hold_Est_Int_Internal_Order         Char(5)     Default '89802';
DECLARE Hold_Est_Int_GL_Account             Char(7)     Default '6391130';
DECLARE Hold_Est_Int_WBS_Element            Char(24);
DECLARE Hold_Inv_Id                         Integer;
DECLARE Hold_Total_Funding_Amount           Decimal(13, 2);
DECLARE Hold_Funding_Id                     Integer     Default 0;
DECLARE Hold_ECMS_Project_Num               Integer;
DECLARE Staged_Funding_Complete             SmallInt    Default 0;
DECLARE Agr_Funding_Complete                SmallInt    Default 0;
DECLARE Estimate_Interest_Complete          SmallInt    Default 0;
DECLARE Estimate_Complete                   SmallInt    Default 0;
DECLARE Hold_WO_Id                          SmallInt;
DECLARE Hold_Part_Id                        SmallInt;
DECLARE Hold_Agr_Funding_Alloc_Id           SmallInt;
DECLARE Hold_Max_Agr_Funding_Alloc_Id       SmallInt;
DECLARE Hold_Line_Item_Nbr                  SmallInt;
DECLARE Hold_Total_Payment_Amt              Decimal(13, 2);
DECLARE Hold_Inv_Pct                        Decimal(5, 4);
DECLARE Hold_Line_Item_Amount               Decimal(13, 2);
DECLARE Hold_Amount_Allocated               Decimal(13, 2);
DECLARE Hold_Sum_Est_Int_Amt                Decimal(13, 2);
DECLARE Hold_Item_Total_Amt                 Decimal(15, 2);

/************************************************/
/* These are the various transaction type coded */
/************************************************/
DECLARE C_Transaction_Type_Code_Estimate    Char(2) Default '01';
DECLARE C_Transaction_Type_Code_Est_Adj     Char(2) Default '02';
DECLARE C_Transaction_Type_Code_Invoice     Char(2) Default '03';
DECLARE C_Transaction_Type_Code_Est_Int     Char(2) Default '04';
DECLARE C_Transaction_Type_Code_WO          Char(2) Default '05';

/**********************************************************/
/* These variables are passed back to the calling program */
/**********************************************************/
DECLARE SQLSTATE Char(5) Default '00000';
DECLARE SQLCODE  Int     Default 0;
DECLARE ERRLOC   Char(4);
DECLARE ERRCODE  Integer;

/********************************************************************/
/* We retrieve the agreement funding allocation from either         */
/* Agr_Work_Order_Funding_Allocation or Agr_Part_Funding_Allocation */
/* depending on whether or not the work order id was null           */
/********************************************************************/
DECLARE WO_Agr_Funding Cursor For
    SELECT
        WBS_Element,
        General_Ledger_Acct,
        Inv_Pct,
        Agr_Funding_Alloc_Id
    FROM
        ECMSXADM.Agr_Work_Order_Funding_Allocation
    WHERE
        Agr = Hold_Agr
        And WO_Id = Hold_WO_Id
        And Inv_Pct > 0
    ORDER BY
        Agr_Funding_Alloc_Id;

DECLARE Part_Agr_Funding Cursor For
    SELECT
        WBS_Element,
        General_Ledger_Acct,
        Inv_Pct,
        Agr_Funding_Alloc_Id
    FROM
        ECMSXADM.Agr_Part_Funding_Allocation
    WHERE
        Agr = Hold_Agr
        And Part_Id = Hold_Part_Id
        And Inv_Pct > 0
    ORDER BY
        Agr_Funding_Alloc_Id;

/**************************************************/
/* Get the invoice internal order funding records */
/**************************************************/
DECLARE Staged_Funding Cursor For
    SELECT
        Internal_Order,
        Sum(Funding_Amt) As Total_Funding_Amount
    FROM
        ECMSXADM.Inv_Internal_Order_Funding
    WHERE
        Agr = Hold_Agr
        And Inv_Id = Hold_Inv_Id
    GROUP BY
        Internal_Order
    ORDER BY
        Internal_Order;

/********************************/
/* Retrieve the funding records */
/********************************/
DECLARE Estimate_Interest Cursor For
    SELECT
        PF.WBS_Element,
        PF.General_Ledger_Acct,
        PF.Internal_Order,
        Sum(Value(EI.Est_Int_Amt, 0)) As Sum_Est_Int_Amt
    FROM
        ECMSXADM.Proj_Funding PF Inner Join ECMSXADM.Est_Interest EI
            On PF.ECMS_Project_Num = EI.ECMS_Project_Num
            And PF.Fund_Code = EI.Fund_Code
    WHERE
        PF.ECMS_Project_Num = Hold_ECMS_Project_Num
        And (EI.Est_Int_Status_Cd = '2' OR EI.Est_Int_Status_Cd = '4')
    GROUP BY
        PF.WBS_Element,
        PF.General_Ledger_Acct,
        PF.Internal_Order
    ORDER BY
        PF.WBS_Element,
        PF.General_Ledger_Acct,
        PF.Internal_Order;

/********************************/
/* Retrieve the funding records */
/********************************/
DECLARE Estimate_Funding Cursor For
    SELECT
        EstAndAdj.WBS_Element,
        EstAndAdj.General_Ledger_Acct,
        EstAndAdj.Internal_Order,
        Sum(EstAndAdj.Amt) As Amt
    FROM
    (
    SELECT
        PF.WBS_Element,
        PF.General_Ledger_Acct,
        PF.Internal_Order,
        Sum(EIF.Item_Total_Amt) As Amt
    FROM
        ECMSXADM.Proj_Funding PF Inner Join ECMSXADM.Est_Item_Funding EIF
            On PF.ECMS_Project_Num = EIF.ECMS_Project_Num
            And PF.Fund_Code = EIF.Fund_Code
    WHERE
        PF.ECMS_Project_Num = Hold_ECMS_Project_Num
        And EIF.Estimate_Num = Hold_Estimate_Num
    GROUP BY
        PF.WBS_Element,
        PF.General_Ledger_Acct,
        PF.Internal_Order
    UNION All
    SELECT
        PF.WBS_Element,
        PF.General_Ledger_Acct,
        PF.Internal_Order,
        Sum(EA.Est_Adj_Appl_Amt) As Amt
    FROM
        ECMSXADM.Proj_Funding PF Inner Join ECMSXADM.Est_Adjustment EA
            On PF.ECMS_Project_Num = EA.ECMS_Project_Num
            And PF.Fund_Code = EA.Fund_Code
    WHERE
        PF.ECMS_Project_Num = Hold_ECMS_Project_Num
        And EA.Estimate_Num = Hold_Estimate_Num
    GROUP BY
        PF.WBS_Element,
        PF.General_Ledger_Acct,
        PF.Internal_Order
    ) EstAndAdj
    GROUP BY
        EstAndAdj.WBS_Element,
        EstAndAdj.General_Ledger_Acct,
        EstAndAdj.Internal_Order
;

/*************************/
/* Declare return cursor */
/*************************/
DECLARE SINGLE_PARM_CURSOR CURSOR WITH RETURN FOR
    SELECT
        SQLCODE,
        SQLSTATE,
        ERRLOC,
        ERRCODE
    FROM
        SYSIBM.SYSDUMMY1;

/*******************/
/* Declare handler */
/*******************/
DECLARE EXIT HANDLER FOR SQLEXCEPTION
    OPEN SINGLE_PARM_CURSOR;

/***********************************/
/* Initialize the error variables. */
/***********************************/
SET ERRLOC = '0001';
SET ERRCODE = -1;

/*******************************************/
/* Retrieve the ECMS Transaction Type Code */
/*******************************************/

SELECT
    ECMS_Transaction_Type_Code
INTO
    Hold_ECMS_Transaction_Type_Code
FROM
    ECMSXADM.SAP_ECMS_Transaction
WHERE
    ECMS_Transaction_Id = In_ECMS_Transaction_Id;

DELETE FROM
    ECMSXADM.SAP_ECMS_Payment_Funding
WHERE
    ECMS_Transaction_Id = In_ECMS_Transaction_Id;

SET ERRLOC = '0002';

IF Hold_ECMS_Transaction_Type_Code = C_Transaction_Type_Code_Invoice THEN
    /************************************************/
    /* Retrieve the Agreement Number and Invoice Id */
    /************************************************/

    SELECT
        Agr,
        Inv_Id
    INTO
        Hold_Agr,
        Hold_Inv_Id
    FROM
        ECMSXADM.SAP_ECMS_Transaction
    WHERE
        ECMS_Transaction_Id = In_ECMS_Transaction_Id;

    SET ERRLOC = '0003';

    /******************************************/
    /* Create the funding allocation records. */
    /******************************************/
    CALL ECMSXADM.SPSAP01A(In_ECMS_Transaction_Id);

    /************************************************/
    /* Retrieve the Agreement Number and Invoice Id */
    /************************************************/
    SELECT
        WO_Id,
        Part_Id
    INTO
        Hold_WO_Id,
        Hold_Part_Id
    FROM
        ECMSXADM.Inv_Hierarchy
    WHERE
        Agr = Hold_Agr
        And Inv_Id = Hold_Inv_Id;

    SET ERRLOC = '0004';

    /********************************/
    /* Get the total payment amount */
    /********************************/
    SELECT
        Total_Payment_Amt
    INTO
        Hold_Total_Payment_Amt
    FROM
        ECMSXADM.Inv_Wrapper
    WHERE
        Agr = Hold_Agr
        And Inv_Id = Hold_Inv_Id;

    SET ERRLOC = '0005';

    /***************************************************************/
    /* Open the invoice internal order funding records and get the */
    /* first record                                                */
    /***************************************************************/
    Open Staged_Funding;

    FETCH
        Staged_Funding
    INTO
        Hold_Internal_Order,
        Hold_Total_Funding_Amount;

    /*******************************************/
    /* SQLCODE 100 signifies no record fetched */
    /*******************************************/
    IF SQLCODE = 100 THEN
        SET Staged_Funding_Complete = 1;
        SET No_Funding_Records = 'Y';
    END IF;

    SET ERRLOC = '0006';

    WHILE Staged_Funding_Complete = 0 Do
        SET Hold_Amount_Allocated = 0;

        /*************************************************************/
        /* Open the agreement funding allocation records and get the */
        /* first record.  IF the work order id is null, get the      */
        /* funding from the part funding table.  Otherwise, get      */
        /* the funding from the work order funding table.            */
        /*************************************************************/
        IF Hold_WO_Id Is Null THEN
            Open Part_Agr_Funding;

            FETCH
                Part_Agr_Funding
            INTO
                Hold_WBS_Element,
                Hold_General_Ledger_Acct,
                Hold_Inv_Pct,
                Hold_Agr_Funding_Alloc_Id;

            /*******************************************/
            /* SQLCODE 100 signifies no record fetched */
            /*******************************************/
            IF SQLCODE = 100 THEN
                SET Agr_Funding_Complete = 1;
            END IF;

            SET ERRLOC = '0007';

            /************************************************************/
            /* We need this so we can tell if we are on the last record */
            /* in the cursor                                            */
            /************************************************************/
            SELECT
                Max(Agr_Funding_Alloc_Id)
            INTO
                Hold_Max_Agr_Funding_Alloc_Id
            FROM
                ECMSXADM.Agr_Part_Funding_Allocation
            WHERE
                Agr = Hold_Agr
                And Part_Id = Hold_Part_Id;
        ELSE
            OPEN WO_Agr_Funding;

            FETCH
                WO_Agr_Funding
            INTO
                Hold_WBS_Element,
                Hold_General_Ledger_Acct,
                Hold_Inv_Pct,
                Hold_Agr_Funding_Alloc_Id;

            /*******************************************/
            /* SQLCODE 100 signifies no record fetched */
            /*******************************************/
            IF SQLCODE = 100 THEN
                SET Agr_Funding_Complete = 1;
            END IF;

            SET ERRLOC = '0008';

            /************************************************************/
            /* We need this so we can tell if we are on the last record */
            /* in the cursor                                            */
            /************************************************************/
            SELECT
                Max(Agr_Funding_Alloc_Id)
            INTO
                Hold_Max_Agr_Funding_Alloc_Id
            FROM
                ECMSXADM.Agr_Work_Order_Funding_Allocation
            WHERE
                Agr = Hold_Agr
                And WO_Id = Hold_WO_Id;
        END IF;

        SET ERRLOC = '0009';

        WHILE Agr_Funding_Complete = 0 DO

            SET ERRLOC = '0010';

            /**************************************************************/
            /* Check to see if this is the last funding allocation record */
            /**************************************************************/
            IF Hold_Agr_Funding_Alloc_Id = Hold_Max_Agr_Funding_Alloc_Id THEN
                SET Hold_Line_Item_Amount = Hold_Total_Funding_Amount - Hold_Amount_Allocated;
            ELSE
                SET Hold_Line_Item_Amount = Hold_Total_Funding_Amount * Hold_Inv_Pct;
                SET Hold_Amount_Allocated = Hold_Amount_Allocated + Hold_Line_Item_Amount;
            END IF;

            SET ERRLOC = '0011';

            /*************************************************************/
            /* Insert the record into the SAP_ECMS_Payment_Funding table */
            /*************************************************************/
            IF Hold_Funding_Id = 0 THEN
                SELECT Funding_Id INTO Hold_Funding_Id FROM Final Table (
                INSERT INTO
                    ECMSXADM.SAP_ECMS_Payment_Funding
                (
                    Funding_Id,
                    Line_Item_Nbr,
                    WBS_Element,
                    General_Ledger_Acct,
                    Internal_Order,
                    Line_Item_Amt,
                    ECMS_Transaction_Id
                ) VALUES (
                    (SELECT Coalesce(Max(Funding_Id), 0) + 1 FROM ECMSXADM.SAP_ECMS_Payment_Funding),
                    1,
                    Coalesce(Hold_WBS_Element,'0-00000000000-0000-000'),
                    Coalesce(Hold_General_Ledger_Acct,'0000000'),
                    Coalesce(Hold_Internal_Order,'00000'),
                    Coalesce(Hold_Line_Item_Amount,0),
                    In_ECMS_Transaction_Id));

                SET Hold_Line_Item_Nbr = 1;
            ELSE
                SELECT Line_Item_Nbr INTO Hold_Line_Item_Nbr FROM Final Table (
                INSERT INTO
                    ECMSXADM.SAP_ECMS_Payment_Funding
                (
                    Funding_Id,
                    Line_Item_Nbr,
                    WBS_Element,
                    General_Ledger_Acct,
                    Internal_Order,
                    Line_Item_Amt,
                    ECMS_Transaction_Id
                ) VALUES (
                    Hold_Funding_Id,
                    (SELECT Coalesce(Max(Line_Item_Nbr), 0) + 1 FROM ECMSXADM.SAP_ECMS_Payment_Funding WHERE Funding_Id = Hold_Funding_Id),
                    Coalesce(Hold_WBS_Element,'0-00000000000-0000-000'),
                    Coalesce(Hold_General_Ledger_Acct,'0000000'),
                    Coalesce(Hold_Internal_Order,'00000'),
                    Coalesce(Hold_Line_Item_Amount,0),
                    In_ECMS_Transaction_Id));
            END IF;

            SET ERRLOC = '0012';

            /*************************************************************/
            /* Open the agreement funding allocation records and get the */
            /* first record.  If the work order id is null, get the      */
            /* funding from the part funding table.  Otherwise, get      */
            /* the funding from the work order funding table.            */
            /*************************************************************/
            IF Hold_WO_Id Is Null THEN
                FETCH
                    Part_Agr_Funding
                INTO
                    Hold_WBS_Element,
                    Hold_General_Ledger_Acct,
                    Hold_Inv_Pct,
                    Hold_Agr_Funding_Alloc_Id;
            ELSE
                FETCH
                    WO_Agr_Funding
                INTO
                    Hold_WBS_Element,
                    Hold_General_Ledger_Acct,
                    Hold_Inv_Pct,
                    Hold_Agr_Funding_Alloc_Id;
            END IF;

            /*******************************************/
            /* SQLCODE 100 signifies no record fetched */
            /*******************************************/
            IF SQLCODE = 100 THEN
                SET Agr_Funding_Complete = 1;
            END IF;

            SET ERRLOC = '0013';
        END WHILE;

        SET ERRLOC = '0014';

        /******************************************************/
        /* Get the next invoice internal order funding record */
        /******************************************************/
        FETCH
            Staged_Funding
        INTO
            Hold_Internal_Order,
            Hold_Total_Funding_Amount;

        /*******************************************/
        /* SQLCODE 100 signifies no record fetched */
        /*******************************************/
        IF SQLCODE = 100 THEN
            SET Staged_Funding_Complete = 1;
        END IF;

        SET ERRLOC = '0016';

        IF Hold_WO_Id Is Null THEN
            Close Part_Agr_Funding;
        ELSE
            Close WO_Agr_Funding;
        END IF;

        SET Agr_Funding_Complete = 0;
    END WHILE;

ELSE
    IF Hold_ECMS_Transaction_Type_Code = C_Transaction_Type_Code_Est_Int THEN
        SET ERRLOC = '0017';

        /********************************************************/
        /* Get the project number for this SAP ECMS Transaction */
        /********************************************************/
        SELECT
            ECMS_Project_Num
        INTO
            Hold_ECMS_Project_Num
        FROM
            ECMSXADM.SAP_ECMS_Transaction
        WHERE
            ECMS_Transaction_Id = In_ECMS_Transaction_Id;

        SET ERRLOC = '0018';

        /***************************************************************/
        /* Open the estimate interest records and get the first record */
        /***************************************************************/
        Open Estimate_Interest;

        FETCH
            Estimate_Interest
        INTO
            Hold_WBS_Element,
            Hold_General_Ledger_Acct,
            Hold_Internal_Order,
            Hold_Sum_Est_Int_Amt;

        /*******************************************/
        /* SQLCODE 100 signifies no record fetched */
        /*******************************************/
        IF SQLCODE = 100 THEN
            SET Estimate_Interest_Complete = 1;
        END IF;

        SET ERRLOC = '0019';

        WHILE Estimate_Interest_Complete = 0 Do

            SET ERRLOC = '0020';

            SET Hold_Est_Int_WBS_Element = CONCAT(LEFT(Hold_WBS_Element, LENGTH(Hold_WBS_Element) - 1), '2');

            /*************************************************************/
            /* Insert the record into the SAP_ECMS_Payment_Funding table */
            /*************************************************************/
            IF Hold_Funding_Id = 0 THEN
                SELECT Funding_Id INTO Hold_Funding_Id FROM Final Table (
                INSERT INTO
                    ECMSXADM.SAP_ECMS_Payment_Funding
                (
                    Funding_Id,
                    Line_Item_Nbr,
                    WBS_Element,
                    General_Ledger_Acct,
                    Internal_Order,
                    Line_Item_Amt,
                    ECMS_Transaction_Id
                ) VALUES (
                    (SELECT Coalesce(Max(Funding_Id), 0) + 1 FROM ECMSXADM.SAP_ECMS_Payment_Funding),
                    1,
                    Coalesce(Hold_Est_Int_WBS_Element,'0-00000000000-0000-000'),
                    Coalesce(Hold_Est_Int_GL_Account,'0000000'),
                    Coalesce(Hold_Est_Int_Internal_Order,'00000'),
                    Coalesce(Hold_Sum_Est_Int_Amt,0),
                    In_ECMS_Transaction_Id));
            ELSE
                INSERT INTO
                    ECMSXADM.SAP_ECMS_Payment_Funding
                (
                    Funding_Id,
                    Line_Item_Nbr,
                    WBS_Element,
                    General_Ledger_Acct,
                    Internal_Order,
                    Line_Item_Amt,
                    ECMS_Transaction_Id
                ) VALUES (
                    Hold_Funding_Id,
                    (SELECT Coalesce(Max(Line_Item_Nbr), 0) + 1 FROM ECMSXADM.SAP_ECMS_Payment_Funding WHERE Funding_Id = Hold_Funding_Id),
                    Coalesce(Hold_Est_Int_WBS_Element,'0-00000000000-0000-000'),
                    Coalesce(Hold_Est_Int_GL_Account,'0000000'),
                    Coalesce(Hold_Est_Int_Internal_Order,'00000'),
                    Coalesce(Hold_Sum_Est_Int_Amt,0),
                    In_ECMS_Transaction_Id);
            END IF;

            SET ERRLOC = '0021';

            /***********************/
            /* Get the next record */
            /***********************/
            FETCH
                Estimate_Interest
            INTO
                Hold_WBS_Element,
                Hold_General_Ledger_Acct,
                Hold_Internal_Order,
                Hold_Sum_Est_Int_Amt;

            /*******************************************/
            /* SQLCODE 100 signifies no record fetched */
            /*******************************************/
            IF SQLCODE = 100 THEN
                SET Estimate_Interest_Complete = 1;
            END IF;

            SET ERRLOC = '0022';
        END WHILE;

        SET ERRLOC = '0023';

        /***********************************************/
        /* Update the estimate interest status to Paid */
        /***********************************************/
        UPDATE
            ECMSXADM.Est_Interest
        SET
            Est_Int_Status_Cd = '4'
        WHERE
            ECMS_Project_Num = Hold_ECMS_Project_Num
            And Est_Int_Status_Cd = '2';
    ELSE
        IF Hold_ECMS_Transaction_Type_Code = C_Transaction_Type_Code_Estimate Or Hold_ECMS_Transaction_Type_Code = C_Transaction_Type_Code_Est_Adj THEN

            SET ERRLOC = '0024';

            /**********************************************/
            /* Get the project number and estimate number */
            /**********************************************/
            SELECT
                ECMS_Project_Num,
                Estimate_Num
            INTO
                Hold_ECMS_Project_Num,
                Hold_Estimate_Num
            FROM
                ECMSXADM.SAP_ECMS_Transaction
            WHERE
                ECMS_Transaction_Id = In_ECMS_Transaction_Id;

            SET ERRLOC = '0025';

            /***************************************************************/
            /* Open the estimate funding records and get the first record */
            /***************************************************************/
            OPEN Estimate_Funding;

            FETCH
                Estimate_Funding
            INTO
                Hold_WBS_Element,
                Hold_General_Ledger_Acct,
                Hold_Internal_Order,
                Hold_Item_Total_Amt;

            /*******************************************/
            /* SQLCODE 100 signifies no record fetched */
            /*******************************************/
            IF SQLCODE = 100 THEN
                SET Estimate_Complete = 1;
            END IF;

            SET ERRLOC = '0026';

            WHILE Estimate_Complete = 0 Do

                SET ERRLOC = '0027';

                /*************************************************************/
                /* Insert the record into the SAP_ECMS_Payment_Funding table */
                /*************************************************************/
                if Hold_Funding_Id = 0 THEN
                    SELECT Funding_Id INTO Hold_Funding_Id FROM Final Table (
                    INSERT INTO
                        ECMSXADM.SAP_ECMS_Payment_Funding
                    (
                        Funding_Id,
                        Line_Item_Nbr,
                        WBS_Element,
                        General_Ledger_Acct,
                        Internal_Order,
                        Line_Item_Amt,
                        ECMS_Transaction_Id
                    ) VALUES (
                        (SELECT Coalesce(Max(Funding_Id), 0) + 1 FROM ECMSXADM.SAP_ECMS_Payment_Funding),
                        1,
                        Coalesce(Hold_WBS_Element,'0-00000000000-0000-000'),
                        Coalesce(Hold_General_Ledger_Acct,'0000000'),
                        Coalesce(Hold_Internal_Order,'00000'),
                        Coalesce(Hold_Item_Total_Amt,0),
                        In_ECMS_Transaction_Id));
                ELSE
                    INSERT INTO
                        ECMSXADM.SAP_ECMS_Payment_Funding
                    (
                        Funding_Id,
                        Line_Item_Nbr,
                        WBS_Element,
                        General_Ledger_Acct,
                        Internal_Order,
                        Line_Item_Amt,
                        ECMS_Transaction_Id
                    ) VALUES (
                        Hold_Funding_Id,
                        (SELECT Coalesce(Max(Line_Item_Nbr), 0) + 1 FROM ECMSXADM.SAP_ECMS_Payment_Funding WHERE Funding_Id = Hold_Funding_Id),
                        Coalesce(Hold_WBS_Element,'0-00000000000-0000-000'),
                        Coalesce(Hold_General_Ledger_Acct,'0000000'),
                        Coalesce(Hold_Internal_Order,'00000'),
                        Coalesce(Hold_Item_Total_Amt,0),
                        In_ECMS_Transaction_Id);
                END IF;

                SET ERRLOC = '0028';

                /***************************************************************/
                /* Get the next record */
                /***************************************************************/
                FETCH
                    Estimate_Funding
                INTO
                    Hold_WBS_Element,
                    Hold_General_Ledger_Acct,
                    Hold_Internal_Order,
                    Hold_Item_Total_Amt;

                /*******************************************/
                /* SQLCODE 100 signifies no record fetched */
                /*******************************************/
                IF SQLCODE = 100 THEN
                    SET Estimate_Complete = 1;
                END IF;

                SET ERRLOC = '0029';
            END WHILE;
        END IF;
    END IF;
END IF;

SET ERRLOC = '0030';

IF No_Funding_Records = 'Y' THEN
    SET ERRLOC = '0031';
    SET ERRCODE = -1;
ELSE
    /**************************************************************/
    /* Update the ECMS Transaction with the funding code created. */
    /**************************************************************/
    UPDATE
        ECMSXADM.SAP_ECMS_Transaction
    SET
        Funding_Id = Hold_Funding_Id
    WHERE
        ECMS_Transaction_Id = In_ECMS_Transaction_Id;

    /*******************************************/
    /* Cursor left open for client application */
    /*******************************************/
    SET ERRLOC = '0000';
    SET ERRCODE = 0;
END IF;

OPEN SINGLE_PARM_CURSOR;

END P1