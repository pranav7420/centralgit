CREATE PROCEDURE CMP_FPN_INCUR_PROCESSING (
		OUT OUT_SQLSTATE CHAR(5),
		OUT OUT_SQLCODE INTEGER,
		OUT OUT_ERRORLOC VARCHAR(80),
		OUT OUT_ERRCODE INTEGER
	)

	RESULT SETS 1
	LANGUAGE SQL
	QUALIFIER ECMSXADM
	VALIDATE BIND
	ISOLATION LEVEL CS
	WLM ENVIRONMENT FOR DEBUG MODE DSNDWLM2
	PACKAGE OWNER HWYDEV
	ALLOW DEBUG MODE
	ASUTIME LIMIT 120000
	
--**** VERSION 1.2 ****--   
P1: BEGIN

/*************************/
/* VARIABLE DECLARATIONS */
/*************************/
DECLARE HOLD_FPN_STATE_INCUR_AMT 		DECIMAL(13, 2);
DECLARE HOLD_FEDERAL_PROJECT_NUMBER		CHAR(11);
DECLARE FPN_STATE_INCUR_UPDATE_COMPLETE	SMALLINT  DEFAULT 0;
DECLARE HOLD_LAST_MODIFIED_BY			CHAR(40) DEFAULT 'ECMS CMP_FPN_STATE_INCUR_PROCESSING';

/**********************************************************/
/* THESE VARIABLES ARE PASSED BACK TO THE CALLING PROGRAM */
/**********************************************************/
DECLARE SQLSTATE CHAR(5) DEFAULT '00000';
DECLARE SQLCODE  INT     DEFAULT 0;

/********************************************************************/
/* DECLARE A CURSOR TO READ THE SAP TOTAL SPENT AMT FROM AMP TABLE  */
/********************************************************************/
DECLARE FPN_SAP_TOTAL_SPENT CURSOR FOR

SELECT FEDERAL_PROJECT_NBR,
       COALESCE(SAP_TOTAL_SPENT_AMT,0)-(COALESCE(SAP_AGREEMENT_AMT,0)+COALESCE(SAP_PROJECT_AMT,0)) AS FPN_STATE_INCUR_AMT
  FROM ECMSXADM.FPN_CONSUMPTION  
 WHERE FEDERAL_PROJECT_NBR IS NOT NULL
   AND COALESCE(SAP_TOTAL_SPENT_AMT,0)-(COALESCE(SAP_AGREEMENT_AMT,0)+COALESCE(SAP_PROJECT_AMT,0)) <> 0
;

/*******************/
/* DECLARE HANDLER */
/*******************/
DECLARE EXIT HANDLER FOR SQLEXCEPTION

/************************************/
/* INITIALIZE THE RETURN PARAMETERS.*/
/************************************/
SET OUT_SQLSTATE = SQLSTATE;
SET OUT_SQLCODE = SQLCODE;
SET OUT_ERRORLOC = '0001';
SET OUT_ERRCODE = -1;

/*************************/
/* COM_SYSTEM_LOG BEGIN  */
/*************************/
 INSERT INTO COM_SYSTEM_LOG
      ( LOG_ID,
         LOG_TYPE,
         USER_ID,
         LOG_TS,
         CLASS_NAME)
VALUES ((SELECT COALESCE(MAX(LOG_ID), 0) + 1 FROM COM_SYSTEM_LOG),
        'BEGIN',
        'ECMSLP System',
        CURRENT TIMESTAMP,
        'CMP_FPN_INCUR_PROCESSING');
             
/**************************************/
/* OPEN THE FPN_SAP_TOTAL_SPENT CURSOR*/
/**************************************/
SET OUT_ERRORLOC = '0002';

OPEN FPN_SAP_TOTAL_SPENT;

/**********************************************/
/* LOOP THROUGHT THE LIST AND UPDATE THE TABLE*/
/**********************************************/
SET OUT_ERRORLOC = '0003';

WHILE FPN_STATE_INCUR_UPDATE_COMPLETE = 0 DO

    FETCH FPN_SAP_TOTAL_SPENT
     INTO
          HOLD_FEDERAL_PROJECT_NUMBER,
          HOLD_FPN_STATE_INCUR_AMT               
        ;
     
/*******************************************/
/* SQLCODE 100 SIGNIFIES NO RECORD FETCHED */
/*******************************************/        
    IF SQLCODE = 100 THEN
        SET FPN_STATE_INCUR_UPDATE_COMPLETE = 1;

/*******************************************/
/* IF NO RECORDS FOUND, CLOSE THE CURSOR   */
/*******************************************/   
        CLOSE FPN_SAP_TOTAL_SPENT;

        ELSE

        SET OUT_ERRORLOC = '0004'||','||'ERROR IN UPDATING FPN'||','||HOLD_FEDERAL_PROJECT_NUMBER;

/*************************************************************/
/* UPDATE THE RECORD INTO THE FPN_COMSUMPTION TABLE          */
/*************************************************************/
        UPDATE FPN_CONSUMPTION
           SET FPN_TOTAL_SPENT_AMT = COALESCE(SAP_TOTAL_SPENT_AMT,0) + COALESCE(INV_AGREEMENT_AMT,0) + COALESCE(INV_PROJECT_AMT,0),
               FPN_STATE_INCUR_COST = COALESCE(SAP_TOTAL_SPENT_AMT,0) - (COALESCE(SAP_AGREEMENT_AMT,0) + COALESCE(SAP_PROJECT_AMT,0)), 
               LAST_MODIFIED_BY = HOLD_LAST_MODIFIED_BY,
               LAST_MODIFIED_TS = CURRENT TIMESTAMP  
         WHERE FEDERAL_PROJECT_NBR = HOLD_FEDERAL_PROJECT_NUMBER
           AND COALESCE(FPN_STATE_INCUR_COST,0) <> HOLD_FPN_STATE_INCUR_AMT
         ;          

        SET OUT_SQLSTATE = SQLSTATE;
        SET OUT_SQLCODE = SQLCODE;

    END IF;
END WHILE;

IF (SQLCODE = 0 AND SQLSTATE = '00000')THEN
    SET OUT_ERRORLOC = '0000'||','||'SUCCESSFUL';
    SET OUT_ERRCODE = 0;
END IF ;    

/*************************/
/* COM_SYSTEM_LOG END    */
/*************************/
INSERT INTO COM_SYSTEM_LOG
       (LOG_ID,
       LOG_TYPE,
       USER_ID,
       LOG_TS,
       CLASS_NAME
       )
VALUES ((SELECT COALESCE(MAX(LOG_ID), 0) + 1 FROM COM_SYSTEM_LOG),
       'END',
       'ECMSLP System',
       CURRENT TIMESTAMP,
       'CMP_FPN_INCUR_PROCESSING'
       ); 
    
END P1