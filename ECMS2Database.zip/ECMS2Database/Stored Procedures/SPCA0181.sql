CREATE PROCEDURE ECMSXADM.SPCA0181 (IN P_PROJNUM  INTEGER , IN P_BIDPKGNUM SMALLINT , OUT P_SQLCODE INTEGER)
	VERSION V1
	ISOLATION LEVEL CS
	RESULT SETS 1
	LANGUAGE SQL
	ALLOW DEBUG MODE
	WLM ENVIRONMENT FOR DEBUG MODE DSNDWLM2
	P1: BEGIN

DECLARE V_SQLCODE                		INT     		DEFAULT 0;      
DECLARE V_SQLSTATE               		CHAR(5) 		DEFAULT '00000';
DECLARE SQLCODE                  		INT     		DEFAULT 0;      
DECLARE SQLSTATE                 		CHAR(5) 		DEFAULT '00000';
DECLARE V_TABLEID                  		CHAR(12)    	DEFAULT '$ECMSRETURN$';
DECLARE V_ERRCD                         SMALLINT    	DEFAULT 0;
DECLARE V_ERRLOC                        CHAR(5)     	DEFAULT '     ';
DECLARE V_END_OF_CURSOR                 CHAR(1)      	DEFAULT 'N';
DECLARE V_END_OF_BID_CURSOR				CHAR(1)			DEFAULT 'N';
DECLARE V_USER_ID						VARCHAR(80)		DEFAULT 'Ecms System/PennDOT';

DECLARE V_BUS_PARTNER_ID				CHAR(6)			DEFAULT ' ';
DECLARE V_BPID							CHAR(6)			DEFAULT ' ';
DECLARE V_SAVE_ITEM_NUM					CHAR(8)			DEFAULT ' ';
DECLARE V_ALT_AND_ITEM					CHAR(1)			DEFAULT 'N';

DECLARE V_ECMS_PROJECT_NUM				INTEGER 		DEFAULT '0';
DECLARE V_BID_PACKAGE_NUM  				SMALLINT		DEFAULT '0';
DECLARE V_LINE_ITEM_NUM  				SMALLINT		DEFAULT '0';  
DECLARE V_ITEM_UNIT_PRICE				DECIMAL(13,4)	DEFAULT '0';  
DECLARE V_ITEM_QTY						DECIMAL(15,3)	DEFAULT '0';												         
DECLARE V_ITEM_NUMBER					CHAR(8)			DEFAULT ' ';       
DECLARE V_ITEM_UNIT_MEASURE				CHAR(5)			DEFAULT ' '; 
DECLARE V_ASPHALT_IND 					CHAR(1)			DEFAULT ' ';      
DECLARE V_DIESEL_FUEL_IND				CHAR(1)			DEFAULT ' ';   
DECLARE V_ST_MATL_IND					CHAR(1)			DEFAULT ' ';       
DECLARE V_PREDET_PRICE_IND				CHAR(1)			DEFAULT ' ';  
DECLARE V_ITEM_DESC 					VARCHAR(255)	DEFAULT ' ';        
DECLARE V_ITEM_MOD_DESC					VARCHAR(100)	DEFAULT ' ';     
DECLARE V_COMP_ITEM_REQD_IND			CHAR(1)			DEFAULT ' ';			
DECLARE V_MASTER_ITEM_TYPE				CHAR(1)			DEFAULT ' ';				  
DECLARE V_ALT_GROUP_NUM					SMALLINT		DEFAULT '0';		     
DECLARE V_ALT_SUB_GROUP_NUM				SMALLINT		DEFAULT '0'; 
DECLARE V_ALT_ITEM_CODE					CHAR(1)			DEFAULT ' ';     
DECLARE V_DEPTH							DECIMAL(6,2)	DEFAULT '0';             
DECLARE V_ASPHALT_TYPE_CODE				CHAR(2)			DEFAULT ' '; 
DECLARE V_DIESEL_CATEGORY_CODE			CHAR(2)			DEFAULT ' ';
DECLARE V_FUND_CODE						CHAR(2)			DEFAULT ' ';         
DECLARE V_FUND_QTY						DECIMAL(15,3)	DEFAULT '0';	          
DECLARE V_COST_FUNCTION_CODE			CHAR(4)			DEFAULT ' ';			
DECLARE V_INTERNAL_ORDER				CHAR(5)			DEFAULT ' ';    
DECLARE V_WORK_CLASS_CODE				CHAR(2)			DEFAULT ' ';  
DECLARE V_AC_CI_CNT						SMALLINT		DEFAULT '0';
DECLARE V_ITEM_SORT_SEQ					CHAR(8)			DEFAULT ' ';
DECLARE V_ITEMS_FOUND					CHAR(1)			DEFAULT 'N';
DECLARE V_AC_CI_FOUND_SW				CHAR(1)			DEFAULT '1';
DECLARE V_AND_ITEM						CHAR(1)			DEFAULT 'A';
DECLARE V_CAT_CODE_E					CHAR(1)			DEFAULT 'E';						
DECLARE V_EITHER_LINEITEMNUM			SMALLINT		DEFAULT 0;
DECLARE V_EITHER_ITEMNUMBER				CHAR(8)			DEFAULT ' ';
DECLARE V_PS_COUNT						SMALLINT		DEFAULT 0;
DECLARE V_DPS_FUND_CODE					CHAR(2)			DEFAULT ' ';
DECLARE V_DPS_STATE_ROUTE_ID			CHAR(4)			DEFAULT ' ';  
DECLARE V_DPS_SECTION_GEN				CHAR(3)			DEFAULT ' ';     
DECLARE V_DPS_PLAN_STN_QTY				DECIMAL(18,6)	DEFAULT 0;    
DECLARE V_DPS_PLAN_STN_START			CHAR(13)		DEFAULT ' ';  
DECLARE V_DPS_LANE_START				CHAR(2)			DEFAULT ' ';      
DECLARE V_DPS_SIDE_START				CHAR(8)			DEFAULT ' ';      
DECLARE V_DPS_PLAN_STN_END				CHAR(13)		DEFAULT ' ';    
DECLARE V_DPS_LANE_END					CHAR(2)			DEFAULT ' ';        
DECLARE V_DPS_SIDE_END					CHAR(8)			DEFAULT ' ';        
DECLARE V_DPS_SIDE_ROAD					CHAR(30)		DEFAULT ' ';	       
DECLARE V_DPS_RAMP						CHAR(6)			DEFAULT ' ';            
DECLARE V_DPS_PLAN_STN_ID				CHAR(15)		DEFAULT ' ';     
DECLARE V_DPS_ENTIRE_PROJ_IND			CHAR(1)			DEFAULT ' '; 
DECLARE V_DPS_PLAN_STN_COMMENT			VARCHAR(255)	DEFAULT ' ';
DECLARE V_COUNT							SMALLINT		DEFAULT 0;
DECLARE V_FOUND_8000_ITEM				CHAR(1)			DEFAULT 'N';
DECLARE V_IS_ALT_AND_ITEM				CHAR(1)			DEFAULT 'N';
DECLARE V_1ST_FUND_SW					CHAR(1)			DEFAULT 'N';
DECLARE V_SAVE_WCC						CHAR(2)			DEFAULT ' ';
DECLARE V_PARM_PS_LINE_NUM				SMALLINT		DEFAULT 0;
DECLARE V_DESIGNPS_LINEITEMNUM			SMALLINT		DEFAULT 0;
DECLARE V_END_OF_DESIGNPS				CHAR(1)			DEFAULT '5';
DECLARE V_PARM_PSQTY					DECIMAL(18,6) 	DEFAULT 0;
DECLARE V_LI_MAX						SMALLINT		DEFAULT 0;
DECLARE V_LIB_SUB						SMALLINT		DEFAULT 0;
DECLARE V_SAVE_FUND_CODE				CHAR(2)			DEFAULT ' ';
DECLARE V_FUND_LI_TBL					SMALLINT		DEFAULT 0;
DECLARE V_ITEM_TYPE_CODE				CHAR(2)			DEFAULT '0 ';
DECLARE V_SPECIAL_PROV_NUM				SMALLINT		DEFAULT 0;				
DECLARE V_SPECIAL_PROV_REV				CHAR(1)			DEFAULT ' ';
DECLARE V_SP_CL_LINE_NUM				SMALLINT		DEFAULT 0;
DECLARE V_SP_ITEM_NUM					CHAR(8)			DEFAULT ' ';
DECLARE V_SP_NAME						VARCHAR(100)	DEFAULT ' ';
DECLARE V_SP_BODY 						CLOB(409600);
DECLARE V_SP_EDIT_IND					CHAR(1)			DEFAULT ' ';
DECLARE V_SP_AFTER_EDIT_IND				CHAR(1)			DEFAULT ' ';
DECLARE V_SP_BEFORE_EDIT_IND			CHAR(1)			DEFAULT ' ';
DECLARE V_SP_BEFORE_PARA				CLOB(20480);
DECLARE V_SP_AFTER_PARA					CLOB(32768);
DECLARE V_DI_ALT_GROUP_NUM				SMALLINT		DEFAULT 0;
DECLARE V_DI_ITEM_NUMBER				CHAR(8)			DEFAULT ' ';
DECLARE V_PF_FUND_CODE					CHAR(2)			DEFAULT '  ';
DECLARE V_PF_COST_FUNCTION_CODE			CHAR(4)			DEFAULT ' ';
DECLARE V_PF_INTERNAL_ORDER				CHAR(5)			DEFAULT ' ';
DECLARE V_SAVED_CL_LINE_NUM				SMALLINT		DEFAULT 0;
DECLARE V_ONE_ALTGROUP_FOUND			CHAR(1)			DEFAULT 'N';  
DECLARE V_HOLD_ALT_GROUP_NUM			SMALLINT		DEFAULT 0;
DECLARE V_CINDEX						SMALLINT 		DEFAULT 0;
DECLARE V_SPLIT_ITEMNUM					CHAR(10)		DEFAULT ' ';
DECLARE V_ADJUSTMENT_NUM_X				CHAR(3)			DEFAULT ' ';
DECLARE V_COMMENT250					VARCHAR(250)	DEFAULT ' ';
DECLARE V_COMMENT_ITEM					CHAR(9);
DECLARE V_ITEMNUM_POOL_ENTRY			CHAR(9);			
DECLARE V_END_OF_ITEMSPOOL_CSR			CHAR(1)			DEFAULT 'N';
DECLARE V_END_OF_ITEMSPOOL				CHAR(1)			DEFAULT 'N';
DECLARE V_ITEM1							CHAR(9);			
DECLARE V_ITEM2							CHAR(9);			
DECLARE V_ITEM3							CHAR(9);
DECLARE V_ITEM4							CHAR(9);
DECLARE V_ITEM5							CHAR(9);
DECLARE V_ITEM6							CHAR(9);
DECLARE V_ITEM7							CHAR(9);
DECLARE V_ITEM8							CHAR(9);
DECLARE V_ITEM9							CHAR(9);
DECLARE V_ITEM10						CHAR(9);
DECLARE V_ADJUSTMENT_NUM				SMALLINT	DEFAULT 0;
DECLARE V_ADJUSTMENT_NUM_9				SMALLINT	DEFAULT 0;
			




DECLARE SINGLE_PARM_CURSOR CURSOR WITH RETURN
   FOR                                        
   SELECT                         
          V_SQLCODE,                          
          V_ERRCD,                          
          V_ERRLOC                         
                              
     FROM SYSIBM.SYSDUMMY1    ;
     
     
     
DECLARE ITEM_JOIN CURSOR FOR

SELECT A.ECMS_PROJECT_NUM, A.BID_PACKAGE_NUM,             
       A.BUS_PARTNER_ID, A.LINE_ITEM_NUM,                 
       A.ITEM_UNIT_PRICE, A.ITEM_QTY,                     
   B.ITEM_NUMBER, B.ITEM_UNIT_MEASURE, B.ASPHALT_IND,     
           B.DIESEL_FUEL_IND, B.ST_MATL_IND,              
           B.PREDET_PRICE_IND, B.ITEM_DESC,               
           B.ITEM_MOD_DESC, B.COMP_ITEM_REQD_IND,         
           B.MASTER_ITEM_TYPE,                            
           B.ALT_GROUP_NUM, B.ALT_SUB_GROUP_NUM,          
           B.ALT_ITEM_CODE, B.DEPTH, B.ASPHALT_TYPE_CODE, 
           B.DIESEL_CATEGORY_CODE,                        
   B1.FUND_CODE, B1.FUND_CODE_QTY,                        
   B1.COST_FUNCTION_CODE,                                 
   B1.INTERNAL_ORDER,                                     
   E.WORK_CLASS_CODE,                                     
   F.AC_CI_CNT                                            
                                                          
FROM CONTR_ECMS_BID_ITEM_OPEN A,                          
     DESIGN_ITEM B LEFT OUTER JOIN (                       
        SELECT A.ECMS_PROJECT_NUM, A.LINE_ITEM_NUM,       
               A.FUND_CODE, A.FUND_CODE_QTY,              
               B.COST_FUNCTION_CODE,                      
               B.INTERNAL_ORDER                           
            FROM DESIGN_ITEM_FUND A, PROJ_FUNDING B       
            WHERE A.ECMS_PROJECT_NUM = P_PROJNUM 
            AND A.ECMS_PROJECT_NUM = B.ECMS_PROJECT_NUM   
            AND A.FUND_CODE = B.FUND_CODE                 
        ) B1 ON B.ECMS_PROJECT_NUM = B1.ECMS_PROJECT_NUM  
            AND  B.LINE_ITEM_NUM = B1.LINE_ITEM_NUM,      
   DESIGN_ITEM_WCC E,                                     
   (SELECT COUNT(*) AS AC_CI_CNT                          
       FROM AC_ITEM                                       
       WHERE ECMS_PROJECT_NUM = P_PROJNUM         
       AND BID_PACKAGE_NUM = P_BIDPKGNUM           
       AND BUS_PARTNER_ID = V_BPID  
	   AND AC_ITEM_TYPE_CODE = '210'  
	   AND AC_ITEM_STATUS_CD = '4') F 
WHERE A.ECMS_PROJECT_NUM = P_PROJNUM
AND B.ECMS_PROJECT_NUM = A.ECMS_PROJECT_NUM  
AND E.ECMS_PROJECT_NUM = A.ECMS_PROJECT_NUM  
AND A.BID_PACKAGE_NUM  = P_BIDPKGNUM  
AND A.BUS_PARTNER_ID   = V_BPID            
AND A.LINE_ITEM_NUM    = B.LINE_ITEM_NUM     
AND B.LINE_ITEM_NUM    = E.LINE_ITEM_NUM     
AND COALESCE(B.ALT_SUB_GROUP_NUM,0) = 0      
                                             
AND COALESCE(IB_ITEM_TYPE_CODE,'') NOT IN    
   (SELECT GEN_CODE                          
      FROM COM_GENERAL_CODE                  
     WHERE GEN_CODE_TYPE = 119)              
                                             
UNION                                            	   

SELECT A.ECMS_PROJECT_NUM, A.BID_PACKAGE_NUM,            
       A.BUS_PARTNER_ID, A.LINE_ITEM_NUM,                
       A.ITEM_UNIT_PRICE, A.ITEM_QTY,                    
   B.ITEM_NUMBER, B.ITEM_UNIT_MEASURE, B.ASPHALT_IND,    
           B.DIESEL_FUEL_IND, B.ST_MATL_IND,             
           B.PREDET_PRICE_IND, B.ITEM_DESC,              
           B.ITEM_MOD_DESC, B.COMP_ITEM_REQD_IND,        
           B.MASTER_ITEM_TYPE,                           
           B.ALT_GROUP_NUM, B.ALT_SUB_GROUP_NUM,         
           B.ALT_ITEM_CODE, B.DEPTH, B.ASPHALT_TYPE_CODE,
           B.DIESEL_CATEGORY_CODE,                       
   B1.FUND_CODE, B1.FUND_CODE_QTY,                       
   B1.COST_FUNCTION_CODE,                                
   B1.INTERNAL_ORDER,                                    
   E.WORK_CLASS_CODE,                                    
   F.AC_CI_CNT                                           
                                                         
FROM CONTR_ECMS_BID_ITEM_OPEN A,                         
    DESIGN_ITEM B LEFT OUTER JOIN (                      
     SELECT A.ECMS_PROJECT_NUM, A.LINE_ITEM_NUM,         
     A.FUND_CODE, A.FUND_CODE_QTY, C.ALT_GROUP_NUM,      
     B.COST_FUNCTION_CODE,                               
     B.INTERNAL_ORDER                                    
     FROM DESIGN_ITEM_FUND A, PROJ_FUNDING B,            
     DESIGN_ITEM C                                       
     WHERE A.ECMS_PROJECT_NUM = P_PROJNUM       
     AND A.ECMS_PROJECT_NUM = B.ECMS_PROJECT_NUM         
     AND A.FUND_CODE = B.FUND_CODE                       
     AND C.ADDENDA_PEND_IND = 'C'                        
     AND COALESCE(C.ADDENDUM_ACT_CODE,'') <> 'D'         
     AND A.LINE_ITEM_NUM = C.LINE_ITEM_NUM               
     AND A.ECMS_PROJECT_NUM = C.ECMS_PROJECT_NUM         
     ) B1 ON B.ECMS_PROJECT_NUM = B1.ECMS_PROJECT_NUM    
      AND  B.ALT_GROUP_NUM = B1.ALT_GROUP_NUM            
      AND  B.LINE_ITEM_NUM = B1.LINE_ITEM_NUM            
  ,DESIGN_ITEM_WCC E,                                    
 	(SELECT COUNT(*) AS AC_CI_CNT                 
    FROM AC_ITEM                              
    WHERE ECMS_PROJECT_NUM = P_PROJNUM
    AND BID_PACKAGE_NUM = P_BIDPKGNUM  
    AND BUS_PARTNER_ID = V_BPID             
    AND AC_ITEM_TYPE_CODE = '210'             
    AND AC_ITEM_STATUS_CD = '4') F            
WHERE A.ECMS_PROJECT_NUM = P_PROJNUM
AND B.ECMS_PROJECT_NUM = A.ECMS_PROJECT_NUM  
AND E.ECMS_PROJECT_NUM = A.ECMS_PROJECT_NUM  
AND A.BID_PACKAGE_NUM  = P_BIDPKGNUM  
AND A.BUS_PARTNER_ID   = V_BPID            
AND A.LINE_ITEM_NUM    = B.LINE_ITEM_NUM     
AND B.LINE_ITEM_NUM    = E.LINE_ITEM_NUM     
AND COALESCE(B.ALT_SUB_GROUP_NUM,0) > 0      
                                             
AND COALESCE(IB_ITEM_TYPE_CODE,'') NOT IN    
   (SELECT GEN_CODE                          
      FROM COM_GENERAL_CODE                  
     WHERE GEN_CODE_TYPE = 119)              

--ORDER BY 7, 23, 26;
ORDER BY 7,23,27; -- this change modified in expedite 2019 release to make the wcc_code as the order by          	

DECLARE DESIGNPS CURSOR FOR                   
  SELECT                                      
    FUND_CODE,                                
    STATE_ROUTE_ID,                           
    SECTION,                                  
    VALUE(PLAN_STN_QTY,0),                    
    PLAN_STN_START,                           
    LANE_START,                               
    SIDE_START,                               
    PLAN_STN_END,                             
    LANE_END,                                 
    SIDE_END,                                 
    SIDE_ROAD,                                
    RAMP,                                     
    PLAN_STN_ID,                              
    ENTIRE_PROJ_IND,                          
    PLAN_STN_COMMENT                          
                                              
   FROM DESIGN_ITEM_PS                        
  WHERE ECMS_PROJECT_NUM = P_PROJNUM 
    AND LINE_ITEM_NUM = V_DESIGNPS_LINEITEMNUM  ;                       	
	
	
DECLARE DESIGNSPECIAL CURSOR FOR                           
SELECT                                                     
 SPECIAL_PROV_NUM,                                         
 COALESCE(SPECIAL_PROV_REV,' ') AS SPECIAL_PROV_REV,       
 SP.CL_LINE_NUM,                                           
 ITEM_NUMBER,                                              
 SP_NAME,                                                  
 SP_BODY,                                                  
 COALESCE(SP_EDIT_IND,'N') AS SP_EDIT_IND,                 
 COALESCE(SP_AFTER_EDIT_IND,'N') AS SP_AFTER_EDIT_IND,     
 COALESCE(SP_BEFORE_EDIT_IND,'N') AS SP_BEFORE_EDIT_IND,   
 SP_BEFORE_PARA,                                           
 SP_AFTER_PARA                                             
 FROM PDC_SP_PROV SP, PDC_ITEM ITEM                        
 LEFT OUTER JOIN (SELECT DISTINCT CL_LINE_NUM, ITEM_NUMBER 
 FROM DESIGN_ITEM_PDC_SP D                                 
 WHERE D.ECMS_PROJECT_NUM = P_PROJNUM) DSP        
 ON DSP.CL_LINE_NUM = ITEM.CL_LINE_NUM                     
    WHERE ITEM.ECMS_PROJECT_NUM = P_PROJNUM       
      AND ITEM.CL_ITEM_NUM = 144                           
      AND ITEM.ADDENDA_PEND_IND = 'C'                      
      AND COALESCE(ITEM.DELETE_IND, 'N') = 'N'             
      AND  COALESCE(ITEM.ADDENDUM_ACT_CODE, '') <> 'D'     
      AND ITEM.ECMS_PROJECT_NUM = SP.ECMS_PROJECT_NUM      
      AND ITEM.CL_LINE_NUM = SP.CL_LINE_NUM                
      AND                                                  
          (DSP.ITEM_NUMBER IS NULL                         
           OR                                              
          (DSP.ITEM_NUMBER IS NOT NULL                     
          AND DSP.ITEM_NUMBER IN (SELECT ITEM_NUMBER       
              FROM  CONST_ITEM                             
              WHERE ECMS_PROJECT_NUM = P_PROJNUM) 
          )                                                
          )                                                
 ORDER BY CL_LINE_NUM   ;    
 
 
DECLARE ALTGROUPS CURSOR FOR 
  SELECT DI.ALT_GROUP_NUM,   
         DI.ITEM_NUMBER      
   FROM CONTR_ECMS_BID_ITEM_OPEN CBI,
   		CONTR_ECMS_BID_OPEN CB, 
		PROJECT PR,             
		DESIGN_ITEM DI  
  WHERE DI.ECMS_PROJECT_NUM = P_PROJNUM
  AND CBI.ECMS_PROJECT_NUM = DI.ECMS_PROJECT_NUM
  AND CB.ECMS_PROJECT_NUM = DI.ECMS_PROJECT_NUM 
  AND PR.ECMS_PROJECT_NUM = DI.ECMS_PROJECT_NUM
  AND CB.BID_PACKAGE_NUM = PR.CURR_BID_PKG_NUM 
	AND CBI.BID_PACKAGE_NUM = PR.CURR_BID_PKG_NUM
	AND CB.BID_PACKAGE_NUM = CBI.BID_PACKAGE_NUM 
	AND CB.BUS_PARTNER_ID = CBI.BUS_PARTNER_ID
AND CB.BID_RANKING = 1                   
                                         
AND DI.ALT_SUB_GROUP_NUM > 0             
AND LEFT(DI.ITEM_NUMBER,1) = '8'         
AND DI.LINE_ITEM_NUM = CBI.LINE_ITEM_NUM 
AND COALESCE(IB_ITEM_TYPE_CODE,'') NOT IN
	(SELECT GEN_CODE	
	FROM COM_GENERAL_CODE 
	WHERE GEN_CODE_TYPE = 119)
ORDER BY DI.ALT_GROUP_NUM, CBI.ITEM_NUMBER ;	
  			                                               
 
DECLARE ADJFUNDCODE CURSOR FOR                
  SELECT VALUE(FUND_CODE, ' '),               
         VALUE(COST_FUNCTION_CODE, ' '),      
         VALUE(INTERNAL_ORDER, ' ')           
    FROM PROJ_FUNDING                         
   WHERE ECMS_PROJECT_NUM = P_PROJNUM
   ORDER BY FUND_CODE  ;                       

      
DECLARE ITEMSPOOL_CURSOR CURSOR FOR
	SELECT G_ITEMNUM_POOL_ENTRY
	FROM SESSION.G_ITEMNUM_POOL;

	
DECLARE EXIT HANDLER FOR SQLEXCEPTION

	BEGIN
	
       
       SET V_SQLCODE = SQLCODE   ;
       SET V_ERRCD = -1;
       OPEN SINGLE_PARM_CURSOR;
       
	END;


BEGIN

DECLARE CONTINUE HANDLER FOR SQLSTATE '42704'
	SET V_SQLSTATE = SQLSTATE;
	
	DROP TABLE SESSION.G_ITEMNUM_POOL;	
	DROP TABLE SESSION.G_ITEM_LI_TABLE;
	DROP TABLE SESSION.G_FUND_LI_TABLE;
		
END;




DECLARE GLOBAL TEMPORARY TABLE SESSION.G_ITEMNUM_POOL
	(
	 G_ITEMNUM_POOL_ENTRY CHAR(9) 
	)
	ON COMMIT PRESERVE ROWS
;	


DECLARE GLOBAL TEMPORARY TABLE SESSION.G_ITEM_LI_TABLE
 (  
 	G_ITEM_LI_TBL 		SMALLINT                                              
  )
 ON COMMIT PRESERVE ROWS            
;


DECLARE GLOBAL TEMPORARY TABLE SESSION.G_FUND_LI_TABLE
 (  
 	G_FUND_LI_TBL 		SMALLINT                                              
  )
 ON COMMIT PRESERVE ROWS            
;



SET V_ERRLOC = 'D010';
SELECT BUS_PARTNER_ID                                          
INTO V_BPID 
FROM CONTR_ECMS_BID_OPEN
	  
WHERE ECMS_PROJECT_NUM = P_PROJNUM
  AND BID_PACKAGE_NUM  = P_BIDPKGNUM 
  AND BID_RANKING      = 1   ;              	


SET V_ERRLOC = 'D020';
OPEN ITEM_JOIN;

WHILE V_END_OF_CURSOR = 'N'
 DO
   FETCH ITEM_JOIN             
   INTO V_ECMS_PROJECT_NUM, 
        V_BID_PACKAGE_NUM,  
        V_BUS_PARTNER_ID,   
        V_LINE_ITEM_NUM,    
        V_ITEM_UNIT_PRICE,  
        V_ITEM_QTY,          
        V_ITEM_NUMBER,       
        V_ITEM_UNIT_MEASURE, 
        V_ASPHALT_IND,       
        V_DIESEL_FUEL_IND,   
        V_ST_MATL_IND,       
        V_PREDET_PRICE_IND,  
        V_ITEM_DESC,         
        V_ITEM_MOD_DESC,     
        V_COMP_ITEM_REQD_IND,
        V_MASTER_ITEM_TYPE,  
        V_ALT_GROUP_NUM,     
        V_ALT_SUB_GROUP_NUM, 
        V_ALT_ITEM_CODE,     
        V_DEPTH ,            
        V_ASPHALT_TYPE_CODE, 
        V_DIESEL_CATEGORY_CODE,
        V_FUND_CODE,         
        V_FUND_QTY,          
        V_COST_FUNCTION_CODE,
        V_INTERNAL_ORDER ,   
        V_WORK_CLASS_CODE,  
        V_AC_CI_CNT ;
               
  IF SQLCODE = 100
  THEN 
      CLOSE ITEM_JOIN;  
      SET V_END_OF_CURSOR = 'Y';
  ELSE
  	  IF V_DIESEL_CATEGORY_CODE IS NULL
  	  THEN
  	  	  SET V_DIESEL_CATEGORY_CODE = ' ';
  	  END IF;
  	  IF V_ITEM_QTY IS NULL
  	  THEN
  	  	  SET V_ERRCD = -1;
  	  END IF;
  	  IF V_ITEM_NUMBER IS NULL
  	  THEN
  	  	  SET V_ERRCD = -2;
  	  END IF;	  
  	  IF V_ITEM_UNIT_MEASURE IS NULL
  	  THEN
  	      SET V_ERRCD = -3;
  	  END IF;  
  	  IF V_ITEM_DESC IS NULL
  	  THEN
  	      SET V_ERRCD = -4;
  	  END IF;
  	  IF V_MASTER_ITEM_TYPE IS NULL
  	  THEN
  	      SET V_ERRCD = -5;
  	  END IF;  
  	  IF V_ITEM_NUMBER IS NULL
  	  THEN
  	      SET V_ERRCD = -6;
  	  END IF;  
  	  IF V_FUND_CODE IS NULL
  	  THEN
  	      SET V_FUND_CODE = ' ';
  	  END IF;  
  	  IF V_ALT_GROUP_NUM IS NULL
  	  THEN
  	      SET V_ALT_GROUP_NUM = 0;
  	  END IF;  
  	  IF V_ALT_SUB_GROUP_NUM IS NULL
  	  THEN
  	      SET V_ALT_SUB_GROUP_NUM = 0;
  	  END IF;  
  	  IF V_ALT_ITEM_CODE IS NULL
  	  THEN
  	      SET V_ALT_ITEM_CODE = ' ';
  	  END IF;  
  	  IF V_FUND_QTY IS NULL
  	  THEN
  	  	  SET V_FUND_QTY = 0;
  	  END IF;
  	  IF V_DEPTH IS NULL
  	  THEN
  	      SET V_DEPTH = 0;
  	  END IF;  	  
  	  IF  V_ERRCD <> 0
  	  THEN
  	  	 SET V_ERRLOC = 'C012';
         --SET V_ERRCD  = -1;
         OPEN SINGLE_PARM_CURSOR;
         RETURN -200;
  	  END IF; 
  	  IF V_ASPHALT_IND IS NULL   OR
  	  	 V_ASPHALT_IND = ' '
  	  THEN
  	  	  SET V_ASPHALT_IND = 'N';
  	  END IF;	  
  	  IF V_DIESEL_FUEL_IND IS NULL  OR
  	     V_DIESEL_FUEL_IND = ' '
  	  THEN
  	  	  SET V_DIESEL_FUEL_IND = 'N';
  	  END IF;	    
  	  IF V_ST_MATL_IND IS NULL  OR
  	  	 V_ST_MATL_IND = ' '
  	  THEN
  	  	  SET V_ST_MATL_IND = 'N';
  	  END IF;	
  	  IF V_PREDET_PRICE_IND IS NULL  OR
  	  	 V_PREDET_PRICE_IND = ' '
  	  THEN
  	  	  SET V_PREDET_PRICE_IND = 'N';
  	  END IF;	  	  	     
  	  IF V_COMP_ITEM_REQD_IND IS NULL  OR
  	  	 V_COMP_ITEM_REQD_IND = ' '
  	  THEN
  	  	 SET V_COMP_ITEM_REQD_IND = 'N';
  	  END IF;
  	  
  	  
  	  IF V_SAVE_ITEM_NUM = ' '
  	  THEN
  	  	  SET V_ITEMS_FOUND = 'Y';
  	  	  IF V_AC_CI_CNT > 0
  	  	  THEN
  	  	      SET V_AC_CI_FOUND_SW = '0';
  	  	  END IF;    
  	  	  IF V_ALT_ITEM_CODE = V_AND_ITEM
  	  	  THEN
  	  	      SET V_FOUND_8000_ITEM = 'N';
  	  	  	  SET V_ERRLOC = 'D030';
  	  	  	  SELECT ITEM_SORT_SEQ
			  INTO V_ITEM_SORT_SEQ
			  FROM DESIGN_ITEM A                            
			  WHERE ECMS_PROJECT_NUM = P_PROJNUM    
			    AND LINE_ITEM_NUM = V_LINE_ITEM_NUM        
				AND ITEM_NUMBER = V_ITEM_NUMBER            
				AND ALT_GROUP_NUM = V_ALT_GROUP_NUM        
				AND ALT_SUB_GROUP_NUM = V_ALT_SUB_GROUP_NUM;
			 	    
			  IF V_ITEM_SORT_SEQ >= '80000000'  AND
			     V_ITEM_SORT_SEQ <= '89999999'
			  THEN
			      SET V_FOUND_8000_ITEM = 'Y';
			  END IF;	
			  IF V_FOUND_8000_ITEM = 'Y'
			  THEN
			      SET V_ALT_AND_ITEM = 'Y';
			  ELSE
			      SET V_ALT_AND_ITEM = 'N';
			  END IF;			    
		  ELSE
				SET V_ALT_AND_ITEM = 'N';
		  END IF;
	  END IF;						   	 	 
	  			
  	  
  	  IF V_ITEM_NUMBER <> V_SAVE_ITEM_NUM
  	  THEN
	  	  	  IF V_ALT_ITEM_CODE = V_AND_ITEM
	  	  	  THEN
	  	  	  	  SET V_FOUND_8000_ITEM = 'N';
	  	  	  	  SET V_ERRLOC = 'D040';
	  	  	  	  SELECT ITEM_SORT_SEQ
				  INTO V_ITEM_SORT_SEQ
				  FROM DESIGN_ITEM A                            
				  WHERE ECMS_PROJECT_NUM = P_PROJNUM    
				    AND LINE_ITEM_NUM = V_LINE_ITEM_NUM        
				    AND ITEM_NUMBER = V_ITEM_NUMBER            
				    AND ALT_GROUP_NUM = V_ALT_GROUP_NUM        
				    AND ALT_SUB_GROUP_NUM = V_ALT_SUB_GROUP_NUM;
	  	  	  	  
	  	  	  	  IF V_ITEM_SORT_SEQ >= '80000000'  AND
					 V_ITEM_SORT_SEQ <= '89999999'
				  THEN
					  SET V_FOUND_8000_ITEM = 'Y';
				  END IF;	
				  IF V_FOUND_8000_ITEM = 'Y'
				  THEN
					  SET V_ALT_AND_ITEM = 'Y';
				  ELSE
					  SET V_ALT_AND_ITEM = 'N';
				  END IF;			    
			  ELSE
				  SET V_ALT_AND_ITEM = 'N';
			  END IF;	
		  
	  	  	  IF V_ITEM_NUMBER >= '80000000'  AND
	  	  	     V_ITEM_NUMBER <= '89999999'
	  	  	  THEN   
	  	  	     IF  V_DIESEL_CATEGORY_CODE <> '  '
	  	  	     THEN
	  	  	     	 SET V_DIESEL_FUEL_IND = 'Y';
	  	  	     ELSE
	  	  	     	 SET V_DIESEL_CATEGORY_CODE = V_CAT_CODE_E;
	  	  	     	 SET V_DIESEL_FUEL_IND = 'Y';
	  	  	     END IF;	 	 	
	  	  	  ELSE
	  	  	  	  IF  (V_ITEM_NUMBER >= '90000000'  AND
	  	  	  	  	   V_ITEM_NUMBER <= '99999999')
	  	  	  	  THEN
	  	  	  	  	  IF V_DIESEL_CATEGORY_CODE <> '  '
	  	  	  	  	  THEN
	  	  	  	  	  	  SET V_DIESEL_FUEL_IND = 'Y';
	  	  	  	  	  END IF;
	  	  	  	  ELSE
	  	  	  	  	  IF  V_IS_ALT_AND_ITEM = 'Y'
	  	  	  	  	  THEN
	  	  	  	  	  	  SET V_DIESEL_CATEGORY_CODE = V_CAT_CODE_E;
	  	  	  	  	  	  SET V_DIESEL_FUEL_IND = 'Y';
	  	  	  	  	  ELSE
	  	  	  	  	  	  SET V_DIESEL_CATEGORY_CODE = ' ';
	  	  	  	  	  END IF;
	  	  	  	  END IF;
	  	  	  END IF;
  	  	  
	  	  	  SET V_ERRLOC = 'D050';
			  INSERT INTO CONST_ITEM       
			      ( ECMS_PROJECT_NUM,    
			        ITEM_NUMBER,         
			        ITEM_TYPE_CODE,      
			        ITEM_ORIG_QTY,       
			        ITEM_USED_QTY,       
			        ITEM_WO_ADD_QTY,     
			        ITEM_WO_SUB_QTY,     
			        ITEM_WO_PEND_QTY,    
			        ITEM_UNIT_PRICE,     
			        ITEM_UNIT_MEASURE,   
			        PREDET_PRICE_IND,    
			        ST_MATL_IND,         
			        ASPHALT_IND,         
			        DIESEL_FUEL_IND,     
			        MASTER_ITEM_TYPE,    
			        CREATED_BY,          
			        CREATED_BY_TS,       
			        LAST_MODIFIED_BY,    
			        LAST_MODIFIED_TS,    
			        ITEM_DESC,           
			        ITEM_MOD_DESC,       
			        ASPHALT_MIX_PCT,     
			        DEPTH,               
			        ASPHALT_TYPE_CODE,   
			        DIESEL_CATEGORY_CODE)
			  VALUES                       	  	  	  	  	  			  	  			 				 	 	   	
	  	  		(V_ECMS_PROJECT_NUM,               
				 V_ITEM_NUMBER,                    
				 V_ITEM_TYPE_CODE,                 
				 V_ITEM_QTY,                       
				 0,                                  
				 0,                                  
				 0,                                  
				 0,                                  
				 V_ITEM_UNIT_PRICE,                
				 V_ITEM_UNIT_MEASURE,              
				 V_PREDET_PRICE_IND,               
				 V_ST_MATL_IND,                    
				 V_ASPHALT_IND,                    
				 V_DIESEL_FUEL_IND,                
				 V_MASTER_ITEM_TYPE,               
				 V_USER_ID,                        
				 CURRENT_TIMESTAMP,                  
				 V_USER_ID,                        
				 CURRENT_TIMESTAMP,                  
				 V_ITEM_DESC,                      
				 V_ITEM_MOD_DESC,
				 0,                                  
				 V_DEPTH,                          
				 V_ASPHALT_TYPE_CODE,              
				 V_DIESEL_CATEGORY_CODE)  ;         
  	  	

	
	  	  	  SET V_ALT_AND_ITEM = 'N';
	  	  	  SET V_SAVE_ITEM_NUM = V_ITEM_NUMBER;
	  	  	  SET V_SAVE_FUND_CODE = '##';
	  	  	  SET V_1ST_FUND_SW = 'Y';
  	  	  
	  	  	  SET V_SAVE_WCC = ' ';
	  	  	  INSERT INTO SESSION.G_ITEM_LI_TABLE
	  	  	  	(G_ITEM_LI_TBL)
	  	  	  VALUES
	  	  	  	(V_LINE_ITEM_NUM);	
	  	  	  	
	  	  	  SET V_PARM_PS_LINE_NUM = 0;
  	  	  
	  	  	  IF V_ALT_GROUP_NUM = 0
	  	  	  THEN
	  	  	  	SET V_DESIGNPS_LINEITEMNUM = V_LINE_ITEM_NUM;
	  	  	  ELSE
	  	  	  	IF V_ALT_GROUP_NUM > 0
	  	  	  	THEN
	  	  	  		SET V_ERRLOC = 'D060';
	  	  	  		SELECT LINE_ITEM_NUM,                          
	       					ITEM_NUMBER                             
					  INTO V_EITHER_LINEITEMNUM,                 
					       V_EITHER_ITEMNUMBER                   
					  FROM DESIGN_ITEM                             
					 WHERE ECMS_PROJECT_NUM = P_PROJNUM   
					   AND ALT_ITEM_CODE = 'E'                     
					   AND ALT_GROUP_NUM = V_ALT_GROUP_NUM       
					   AND ADDENDA_PEND_IND = 'C'                  
					   AND (ADDENDUM_ACT_CODE <> 'D'               
					        OR ADDENDUM_ACT_CODE IS NULL)          
	                                               
					   AND COALESCE(IB_ITEM_TYPE_CODE,'') NOT IN   
					      (SELECT GEN_CODE                         
					       FROM COM_GENERAL_CODE                 
					        WHERE GEN_CODE_TYPE = 119)   ;          
	  	  	  		
	  	  	  		SET V_DESIGNPS_LINEITEMNUM = V_EITHER_LINEITEMNUM;
	  	  	  	ELSE
	  	  	  		SET V_ERRCD = -1;
	  	  	  		SET V_ERRLOC = 'C019';
	  	  	  		RETURN -300;
	  	  	  	END IF;	
	  	  	  END IF;			
	  	  	  SET V_ERRLOC = 'D070';
	  	  	  SELECT COUNT(*)                            
	   		  INTO V_PS_COUNT                           
	  		  FROM DESIGN_ITEM_PS                       
	 		  WHERE ECMS_PROJECT_NUM 	= P_PROJNUM
	   		    AND LINE_ITEM_NUM 	= V_DESIGNPS_LINEITEMNUM ;
   		    
	   		  SET V_ERRLOC = 'D080';  
	   		  OPEN DESIGNPS;
   		  
	   		  SET V_END_OF_DESIGNPS = 'N';
	   		  WHILE V_END_OF_DESIGNPS = 'N'
	   		  DO	FETCH DESIGNPS 
	   		  		INTO                             
					  V_DPS_FUND_CODE ,              
					  V_DPS_STATE_ROUTE_ID ,    
					  V_DPS_SECTION_GEN ,          
					  V_DPS_PLAN_STN_QTY,                            
					  V_DPS_PLAN_STN_START ,    
					  V_DPS_LANE_START ,            
					  V_DPS_SIDE_START ,            
					  V_DPS_PLAN_STN_END ,        
					  V_DPS_LANE_END ,                
					  V_DPS_SIDE_END ,                
					  V_DPS_SIDE_ROAD ,              
					  V_DPS_RAMP ,                        
					  V_DPS_PLAN_STN_ID ,          
					  V_DPS_ENTIRE_PROJ_IND ,  
					  V_DPS_PLAN_STN_COMMENT   ;
					  
					 IF SQLCODE = 100
					 THEN
					 	SET V_END_OF_DESIGNPS = 'Y';
					 	CLOSE DESIGNPS;
					 ELSE
					 	
		   		  		SET V_PARM_PS_LINE_NUM = V_PARM_PS_LINE_NUM + 1;
		   		  		IF V_ALT_ITEM_CODE = 'A'  OR
		   		  		   V_ALT_ITEM_CODE = 'O'
		   		  		THEN
		   		  			IF V_PS_COUNT = 1
		   		  			THEN
		   		  				SET V_PARM_PSQTY = V_ITEM_QTY;
		   		  			ELSE
		   		  				IF V_PS_COUNT > 1
		   		  				THEN
		   		  					SET V_PARM_PSQTY = 0;
		   		  				END IF;
		   		  			END IF;
		   		  		ELSE
		   		  			SET V_PARM_PSQTY = V_DPS_PLAN_STN_QTY;
		   		  		END IF;				   
		   		  		
		   		  		SET V_ERRLOC = 'D090';
		   		  		INSERT INTO CONST_ITEM_PS
						(  ECMS_PROJECT_NUM,     
						   ITEM_NUMBER,          
						   ITEM_TYPE_CODE,       
						   PLAN_STN_LINE_NUM,    
						   FUND_CODE,            
						   STATE_ROUTE_ID,       
						   SECTION,              
						   PLAN_STN_QTY,         
						   PLAN_STN_START,       
						   LANE_START,           
						   SIDE_START,           
						   PLAN_STN_END,         
						   LANE_END,             
						   SIDE_END,             
						   SIDE_ROAD,            
						   RAMP,                 
						   PLAN_STN_ID,          
						   ENTIRE_PROJ_IND,      
						   PLAN_STN_COMMENT,     
						   CREATED_BY,           
						   CREATED_BY_TS,        
						   LAST_MODIFIED_BY,     
						   LAST_MODIFIED_TS,     
						   STATUS_CODE           
						)                        
						VALUES  
						( P_PROJNUM,                           
						  V_ITEM_NUMBER,                              
						  '0 ',                                         
						  V_PARM_PS_LINE_NUM,                            
						  V_DPS_FUND_CODE ,              
						  V_DPS_STATE_ROUTE_ID ,    
						  V_DPS_SECTION_GEN ,          
						  V_PARM_PSQTY,                                  
						  V_DPS_PLAN_STN_START ,    
						  V_DPS_LANE_START ,            
						  V_DPS_SIDE_START ,            
						  V_DPS_PLAN_STN_END ,        
						  V_DPS_LANE_END ,                
						  V_DPS_SIDE_END ,                
						  V_DPS_SIDE_ROAD ,              
						  V_DPS_RAMP ,                        
						  V_DPS_PLAN_STN_ID ,          
						  V_DPS_ENTIRE_PROJ_IND ,  
						  V_DPS_PLAN_STN_COMMENT ,
						  V_USER_ID,                                  
						  CURRENT TIMESTAMP,                            
						  V_USER_ID,                                  
						  CURRENT TIMESTAMP,                            
						  '01'                                          
						)   ;                                            
				
					 END IF;                
	   		  END WHILE;
  	  ELSE
  	  		SET V_ERRLOC = 'D100';
  	  		SELECT COUNT(*)
  	  		INTO V_COUNT
  	  		FROM SESSION.G_ITEM_LI_TABLE
  	  		WHERE G_ITEM_LI_TBL = V_LINE_ITEM_NUM;
  	  		IF V_COUNT = 0
  	  		THEN
  	  			SET V_ERRLOC = 'D102';
  	  			INSERT INTO SESSION.G_ITEM_LI_TABLE
  	  				(G_ITEM_LI_TBL)
  	  			VALUES
  	  				(V_LINE_ITEM_NUM);
  	  			SET V_ERRLOC = 'D104';	
  	  			UPDATE CONST_ITEM
  	  				SET ITEM_ORIG_QTY = ITEM_ORIG_QTY + V_ITEM_QTY
  	  			WHERE ECMS_PROJECT_NUM 	= 	P_PROJNUM
  	  			  AND ITEM_NUMBER 		=	V_ITEM_NUMBER;
  	  			  
  	  			 
  	  			IF V_ALT_GROUP_NUM = 0
  	  	  		THEN
  	  	  			SET V_DESIGNPS_LINEITEMNUM = V_LINE_ITEM_NUM;
  	  	  		ELSE
  	  	  			IF V_ALT_GROUP_NUM > 0
  	  	  			THEN
  	  	  				SET V_ERRLOC = 'D110';
		  	  	  		SELECT LINE_ITEM_NUM,                          
		       					ITEM_NUMBER                             
						  INTO V_EITHER_LINEITEMNUM,                 
						       V_EITHER_ITEMNUMBER                   
						  FROM DESIGN_ITEM                             
						 WHERE ECMS_PROJECT_NUM = P_PROJNUM   
						   AND ALT_ITEM_CODE = 'E'                     
						   AND ALT_GROUP_NUM = V_ALT_GROUP_NUM       
						   AND ADDENDA_PEND_IND = 'C'                  
						   AND (ADDENDUM_ACT_CODE <> 'D'               
						        OR ADDENDUM_ACT_CODE IS NULL)          
		                                               
						   AND COALESCE(IB_ITEM_TYPE_CODE,'') NOT IN   
						      (SELECT GEN_CODE                         
						       FROM COM_GENERAL_CODE                 
						        WHERE GEN_CODE_TYPE = 119)   ;          
		  	  	  		
		  	  	  		SET V_DESIGNPS_LINEITEMNUM = V_EITHER_LINEITEMNUM;
		  	  	  	ELSE
		  	  	  		SET V_ERRCD = -1;
		  	  	  		SET V_ERRLOC = 'C019';
		  	  	  		RETURN -300;
  	  	  			END IF;	
  	  	  		END IF;		
  	  	  			
	  	  	    SET V_ERRLOC = 'D120';
	  	  	    SELECT COUNT(*)                            
	   		    INTO V_PS_COUNT                           
	  		    FROM DESIGN_ITEM_PS                       
	 		    WHERE ECMS_PROJECT_NUM 	= P_PROJNUM
	   		      AND LINE_ITEM_NUM 	= V_DESIGNPS_LINEITEMNUM ;
   		    
	   		    SET V_ERRLOC = 'D130';  
	   		    OPEN DESIGNPS;
   		  
		   		SET V_END_OF_DESIGNPS = 'N';
		   		WHILE V_END_OF_DESIGNPS = 'N'
		   		DO	FETCH DESIGNPS 
		   		  		INTO                             
						  V_DPS_FUND_CODE ,              
						  V_DPS_STATE_ROUTE_ID ,    
						  V_DPS_SECTION_GEN ,          
						  V_DPS_PLAN_STN_QTY,                            
						  V_DPS_PLAN_STN_START ,    
						  V_DPS_LANE_START ,            
						  V_DPS_SIDE_START ,            
						  V_DPS_PLAN_STN_END ,        
						  V_DPS_LANE_END ,                
						  V_DPS_SIDE_END ,                
						  V_DPS_SIDE_ROAD ,              
						  V_DPS_RAMP ,                        
						  V_DPS_PLAN_STN_ID ,          
						  V_DPS_ENTIRE_PROJ_IND ,  
						  V_DPS_PLAN_STN_COMMENT   ;
						  
						 IF SQLCODE = 100
						 THEN
						 	SET V_END_OF_DESIGNPS = 'Y';
						 	CLOSE DESIGNPS;
						 ELSE
						 	
			   		  		SET V_PARM_PS_LINE_NUM = V_PARM_PS_LINE_NUM + 1;
			   		  		IF V_ALT_ITEM_CODE = 'A'  OR
			   		  		   V_ALT_ITEM_CODE = 'O'
			   		  		THEN
			   		  			IF V_PS_COUNT = 1
			   		  			THEN
		   		  					SET V_PARM_PSQTY = V_ITEM_QTY;
		   		  				ELSE
		   		  					IF V_PS_COUNT > 1
		   		  					THEN
		   		  						SET V_PARM_PSQTY = 0;
		   		  					END IF;
		   		  				END IF;
		   		  			ELSE
		   		  				SET V_PARM_PSQTY = V_DPS_PLAN_STN_QTY;
		   		  			END IF;				   
	   		  		
			   		  		SET V_ERRLOC = 'D140';
			   		  		INSERT INTO CONST_ITEM_PS
							(  ECMS_PROJECT_NUM,     
							   ITEM_NUMBER,          
							   ITEM_TYPE_CODE,       
							   PLAN_STN_LINE_NUM,    
							   FUND_CODE,            
							   STATE_ROUTE_ID,       
							   SECTION,              
							   PLAN_STN_QTY,         
							   PLAN_STN_START,       
							   LANE_START,           
							   SIDE_START,           
							   PLAN_STN_END,         
							   LANE_END,             
							   SIDE_END,             
							   SIDE_ROAD,            
							   RAMP,                 
							   PLAN_STN_ID,          
							   ENTIRE_PROJ_IND,      
							   PLAN_STN_COMMENT,     
							   CREATED_BY,           
							   CREATED_BY_TS,        
							   LAST_MODIFIED_BY,     
							   LAST_MODIFIED_TS,     
							   STATUS_CODE           
							)                        
							VALUES  
							( P_PROJNUM,                           
							  V_ITEM_NUMBER,                              
							  '0 ',                                         
							  V_PARM_PS_LINE_NUM,                            
							  V_DPS_FUND_CODE ,              
							  V_DPS_STATE_ROUTE_ID ,    
							  V_DPS_SECTION_GEN ,          
							  V_PARM_PSQTY,                                  
							  V_DPS_PLAN_STN_START ,    
							  V_DPS_LANE_START ,            
							  V_DPS_SIDE_START ,            
							  V_DPS_PLAN_STN_END ,        
							  V_DPS_LANE_END ,                
							  V_DPS_SIDE_END ,                
							  V_DPS_SIDE_ROAD ,              
							  V_DPS_RAMP ,                        
							  V_DPS_PLAN_STN_ID ,          
							  V_DPS_ENTIRE_PROJ_IND ,  
							  V_DPS_PLAN_STN_COMMENT ,
							  V_USER_ID,                                  
							  CURRENT TIMESTAMP,                            
							  V_USER_ID,                                  
							  CURRENT TIMESTAMP,                            
							  '01'                                          
							)   ;                                            
				
				 	END IF;                
   		  		END WHILE;
  	  			
  	  		END IF;			
  	  	
  	  END IF;
  	  
  	  
  	  
  	  IF V_FUND_CODE <> V_SAVE_FUND_CODE AND
  	     V_FUND_CODE <> ' ' 
  	  THEN
  	  		SET V_ERRLOC = 'D150';
  	  		INSERT INTO CONST_ITEM_FUNDING   
		      (ECMS_PROJECT_NUM,         
		       ITEM_NUMBER,              
		       ITEM_TYPE_CODE,           
		       FUND_CODE,                
		       COST_FUNCTION_CODE,       
		       INTERNAL_ORDER,           
		       ITEM_WO_ADD_QTY,          
		       ITEM_WO_PEND_QTY,         
		       ITEM_WO_SUB_QTY,          
		       ITEM_ORIG_QTY,            
		       ITEM_USED_QTY,            
		       ITEM_USED_TOT_AMT,        
		       ITEM_PREV_AUD_IND)        
		VALUES                           
		      (V_ECMS_PROJECT_NUM,     
		       V_ITEM_NUMBER,          
		       V_ITEM_TYPE_CODE,       
		       V_FUND_CODE,            
		       V_COST_FUNCTION_CODE,   
		       V_INTERNAL_ORDER,       
		       0,                        
		       0,                        
		       0,                        
		       V_FUND_QTY,             
		       0,                        
		       0,                        
		       'N')   ;                   
  	  		
  	  		IF V_SAVE_FUND_CODE <> '##'
  	  		THEN
  	  			SET V_1ST_FUND_SW = 'N';
  	  		END IF;
  	  		
  	  		SET V_SAVE_FUND_CODE = V_FUND_CODE;	
  	  		
  	  		INSERT INTO SESSION.G_FUND_LI_TABLE
  	  		(G_FUND_LI_TBL)
  	  		VALUES
  	  		(V_LINE_ITEM_NUM);		
  	  		
  	  ELSE
  	  		SET V_ERRLOC = 'D160';
  	  		SELECT COUNT(*)
  	  		INTO V_COUNT
  	  		FROM SESSION.G_FUND_LI_TABLE
  	  		WHERE G_FUND_LI_TBL = V_LINE_ITEM_NUM;
  	  		IF V_COUNT = 0
  	  		THEN 
  	  			SET V_ERRLOC = 'D165'; 
	  	  		INSERT INTO SESSION.G_FUND_LI_TABLE
	  	  			(G_FUND_LI_TBL)
	  	  		VALUES
	  	  			(V_LINE_ITEM_NUM);
	  	  		SET V_ERRLOC = 'D170';	
	  	  		UPDATE CONST_ITEM_FUNDING                           
	  				SET   ITEM_ORIG_QTY = ITEM_ORIG_QTY + V_FUND_QTY
	                                                    
				WHERE ECMS_PROJECT_NUM = P_PROJNUM       
				AND   ITEM_NUMBER      = V_ITEM_NUMBER            
				AND   FUND_CODE        = V_FUND_CODE;     
			         	
	  		END IF;  	
	  END IF;
	    				
  	  IF V_1ST_FUND_SW = 'Y'
  	  THEN
  	      IF V_WORK_CLASS_CODE <> V_SAVE_WCC
  	  	  THEN
  	  			SET V_ERRLOC = 'D180';
  	  			SET V_SAVE_WCC = V_WORK_CLASS_CODE;
  	  			INSERT INTO CONST_ITEM_WCC  
				      (ECMS_PROJECT_NUM,    
				       ITEM_NUMBER,         
				       ITEM_TYPE_CODE,      
				       WORK_CLASS_CODE)     
				VALUES                      
				      (V_ECMS_PROJECT_NUM,
				       V_ITEM_NUMBER,     
				       V_ITEM_TYPE_CODE,  
				       V_WORK_CLASS_CODE) ;
		  END IF;
	  END IF;	
	  
 
  END IF;	  

END WHILE;

---------------------------------------------------------------------


-- START 3000-COPY-SP HERE 
SET V_ERRLOC = 'D185';
OPEN DESIGNSPECIAL; 

SET V_END_OF_CURSOR = 'N';
WHILE V_END_OF_CURSOR = 'N'
DO	 FETCH DESIGNSPECIAL                                     
	INTO V_SPECIAL_PROV_NUM,                 
     	V_SPECIAL_PROV_REV,                 
     	V_SP_CL_LINE_NUM,                                 
     	V_SP_ITEM_NUM ,                    
     	V_SP_NAME ,              
     	V_SP_BODY ,              
     	V_SP_EDIT_IND,                      
     	V_SP_AFTER_EDIT_IND,                
     	V_SP_BEFORE_EDIT_IND,               
     	V_SP_BEFORE_PARA ,
     	V_SP_AFTER_PARA  ;  	

	IF SQLCODE = 100
	THEN
		SET V_END_OF_CURSOR = 'Y';
		CLOSE DESIGNSPECIAL;
	ELSE
		IF V_SP_CL_LINE_NUM <> V_SAVED_CL_LINE_NUM
		THEN
			SET V_ERRLOC = 'D190';
			SET V_SAVED_CL_LINE_NUM = V_SP_CL_LINE_NUM;
    		INSERT INTO CONST_SP_PROV
			  ( ECMS_PROJECT_NUM,    
			    CL_LINE_NUM,         
			    SPECIAL_PROV_NUM,    
			    SPECIAL_PROV_REV,    
			    SP_NAME,             
			    SP_BODY,             
			    SP_EDIT_IND,         
			    CREATED_BY,          
			    CREATED_BY_TS,       
			    LAST_MODIFIED_BY,    
			    LAST_MODIFIED_TS,    
			    SP_AFTER_EDIT_IND,   
			    SP_BEFORE_EDIT_IND,  
			    SP_BEFORE_PARA,      
			    SP_AFTER_PARA ) 
			VALUES
				(P_PROJNUM,                                
				  V_SP_CL_LINE_NUM,                                 
				  V_SPECIAL_PROV_NUM,                 
				  V_SPECIAL_PROV_REV,                 
				  V_SP_NAME ,              
				  V_SP_BODY ,              
				  V_SP_EDIT_IND,                      
				  V_USER_ID,                                        
				  CURRENT_TIMESTAMP,                                  
				  V_USER_ID,                                        
				  CURRENT_TIMESTAMP,                                  
				  V_SP_AFTER_EDIT_IND,                
				  V_SP_BEFORE_EDIT_IND,               
				  V_SP_BEFORE_PARA ,
				  V_SP_AFTER_PARA ) ;	         
    	END IF;	       		
					
		IF V_SP_ITEM_NUM IS NOT NULL
		THEN
			SET V_ERRLOC = 'D200';	
			INSERT INTO CONST_ITEM_SP_PROV 
			  ( ECMS_PROJECT_NUM,          
			    CL_LINE_NUM,               
			    ITEM_NUMBER,               
			    ITEM_TYPE_CODE,            
			    CREATED_BY,                
			    CREATED_BY_TS,             
			    LAST_MODIFIED_BY,          
			    LAST_MODIFIED_TS)          
			VALUES                         
			  (P_PROJNUM,       
			    V_SP_CL_LINE_NUM,        
			    V_SP_ITEM_NUM,           
			    V_ITEM_TYPE_CODE,        
			    V_USER_ID,               
			    CURRENT_TIMESTAMP,         
			    V_USER_ID,               
			    CURRENT_TIMESTAMP)  ;       
		END IF;		
		
		
	END IF;
END WHILE;
  	  
IF V_AC_CI_FOUND_SW = '0'
THEN
	SET V_ERRLOC = 'D210';
	INSERT INTO CONST_CI (  
	    ECMS_PROJECT_NUM,   
	    ITEM_NUMBER,        
	    ITEM_TYPE_CODE,     
	    COMP_LINE_ITEM_NUM, 
	    COMP_ITEM_SEQ_NUM,  
	    INVOICE_IND,        
	    ITEM_UNIT_MEASURE,  
	    ITEM_UNIT_PRICE,    
	    ITEM_QTY,           
	    COMP_ITEM_NUMBER,   
	    CREATED_BY,         
	    CREATED_BY_TS,      
	    LAST_MODIFIED_BY,   
	    LAST_MODIFIED_TS,   
	    ITEM_DESC,          
	    DI_UNIT_PRICE)      
  	SELECT A.ECMS_PROJECT_NUM, A.LUMP_SUM_ITEM_NUM, '0 ',    
    A.COMP_LINE_ITEM_NUM,                                
    A.COMP_LINE_ITEM_NUM,                                
    'N',                                                 
    A.ITEM_UNIT_MEASURE, A.ITEM_UNIT_PRICE, A.ITEM_QTY,  
    A.ITEM_NUMBER, 'SYSTEM', CURRENT TIMESTAMP, 'SYSTEM',
    CURRENT TIMESTAMP, A.ITEM_DESC, B.ITEM_UNIT_PRICE    
                                                         
	FROM AC_COMP_ITEM A LEFT OUTER JOIN (                    
	    SELECT ECMS_PROJECT_NUM, LINE_ITEM_NUM,              
	            COMP_LINE_ITEM_NUM, ITEM_NUMBER,             
	            ITEM_UNIT_PRICE                              
	        FROM DESIGN_CI                                   
	        WHERE ECMS_PROJECT_NUM = P_PROJNUM    
	     ) B ON A.ECMS_PROJECT_NUM =B.ECMS_PROJECT_NUM       
	         AND A.COMP_LINE_ITEM_NUM = B.COMP_LINE_ITEM_NUM 
	         AND A.LINE_ITEM_NUM = B.LINE_ITEM_NUM           
                                                         
	WHERE A.ECMS_PROJECT_NUM = P_PROJNUM          
	AND A.BID_PACKAGE_NUM  = P_BIDPKGNUM              
	AND A.BUS_PARTNER_ID   = V_BPID                        
	AND A.AC_ITEM_NUM IN (                                   
	    SELECT AC_ITEM_NUM FROM AC_ITEM                      
	        WHERE ECMS_PROJECT_NUM = P_PROJNUM    
	        AND BID_PACKAGE_NUM = P_BIDPKGNUM         
	        AND BUS_PARTNER_ID = V_BPID                    
	        AND AC_ITEM_TYPE_CODE = '210'                    
	        AND AC_ITEM_STATUS_CD = '4')    ;
        
    SET V_ERRLOC = 'D220';    
	INSERT INTO CONST_CI_WCC                               
	     (ECMS_PROJECT_NUM,                                
	      ITEM_NUMBER,                                     
	      ITEM_TYPE_CODE,                                  
	      COMP_LINE_ITEM_NUM,                              
	      WORK_CLASS_CODE)                                 
	                                                       
	SELECT  B.ECMS_PROJECT_NUM, A.LUMP_SUM_ITEM_NUM, '0 ', 
	    B.COMP_LINE_ITEM_NUM, B.WORK_CLASS_CODE            
	                                                       
	FROM AC_COMP_ITEM A, DESIGN_CI_WCC B                   
                                                       
	WHERE A.ECMS_PROJECT_NUM = P_PROJNUM        
	AND A.ECMS_PROJECT_NUM = B.ECMS_PROJECT_NUM            
	AND A.BID_PACKAGE_NUM  = P_BIDPKGNUM            
	AND A.BUS_PARTNER_ID   = V_BPID                      
	AND A.COMP_LINE_ITEM_NUM = B.COMP_LINE_ITEM_NUM        
	AND A.AC_ITEM_NUM IN (                                 
	    SELECT AC_ITEM_NUM FROM AC_ITEM                    
	        WHERE ECMS_PROJECT_NUM = P_PROJNUM  
	        AND BID_PACKAGE_NUM = P_BIDPKGNUM       
	        AND BUS_PARTNER_ID = V_BPID                  
	        AND AC_ITEM_TYPE_CODE = '210'                  
	        AND AC_ITEM_STATUS_CD = '4')                   
	AND A.LINE_ITEM_NUM = B.LINE_ITEM_NUM                  
	AND NOT A.ITEM_NUMBER IS NULL ;                                 
 

END IF;
  	  
-- PERFORM 2400-ADJUSTMENTS

SET V_ERRLOC = 'D230';
OPEN ALTGROUPS;

SET V_ADJUSTMENT_NUM = 0;
SET V_ONE_ALTGROUP_FOUND = 'N';
SET V_END_OF_CURSOR = 'N';
WHILE V_END_OF_CURSOR = 'N'
DO	FETCH ALTGROUPS          
  	INTO V_DI_ALT_GROUP_NUM,
       	 V_DI_ITEM_NUMBER  ;
       	 
    IF SQLCODE = 100
    THEN
    	SET V_END_OF_CURSOR = 'Y';
    	CLOSE ALTGROUPS;
    ELSE
    	SET V_ONE_ALTGROUP_FOUND = 'Y';
    	IF V_HOLD_ALT_GROUP_NUM = 0
    	THEN
    		SET V_HOLD_ALT_GROUP_NUM = V_DI_ALT_GROUP_NUM;
    		--2430 ITEMNUM TOCOMMENT BELOW --
    		SET V_COMMENT_ITEM = SUBSTR(V_DI_ITEM_NUMBER, 1, 4) || '-' || SUBSTR(V_DI_ITEM_NUMBER,5,4);
    		SET V_ERRLOC = 'D235';
    		INSERT INTO SESSION.G_ITEMNUM_POOL
    			(G_ITEMNUM_POOL_ENTRY) 
    		VALUES
    			(V_COMMENT_ITEM);
    	ELSE
    		IF V_DI_ALT_GROUP_NUM <> V_HOLD_ALT_GROUP_NUM
    		THEN
    			SET V_ERRLOC = 'D240';
    			OPEN ADJFUNDCODE;
    			FETCH ADJFUNDCODE             
  				INTO V_PF_FUND_CODE,         
			    	V_PF_COST_FUNCTION_CODE,
			    	V_PF_INTERNAL_ORDER   ;
			    CLOSE ADJFUNDCODE;   		  
    			
    			    			
    			SET V_CINDEX = 0;
    			SET V_ERRLOC = 'D245';
    			OPEN ITEMSPOOL_CURSOR;
    			SET V_END_OF_ITEMSPOOL_CSR = 'N';
    			WHILE V_END_OF_ITEMSPOOL_CSR = 'N'
    			DO FETCH ITEMSPOOL_CURSOR
    			   INTO V_ITEMNUM_POOL_ENTRY;
    				IF SQLCODE = 100
    				THEN
    					SET V_END_OF_ITEMSPOOL_CSR = 'Y';
    					CLOSE ITEMSPOOL_CURSOR;
    				ELSE
    					SET V_CINDEX = V_CINDEX + 1;
    					IF V_CINDEX = 1
    					THEN
    						SET V_ITEM1 = V_ITEMNUM_POOL_ENTRY;
    					ELSE
    						IF V_CINDEX = 2
    						THEN
    							SET V_ITEM2 = V_ITEMNUM_POOL_ENTRY;
    						ELSE
    							IF V_CINDEX = 3
    							THEN
    								SET V_ITEM3 = V_ITEMNUM_POOL_ENTRY;	
    							ELSE
    								IF V_CINDEX = 4
    								THEN
    									SET V_ITEM4 = V_ITEMNUM_POOL_ENTRY;
    								ELSE
    									IF V_CINDEX = 5
    									THEN
    										SET V_ITEM5 = V_ITEMNUM_POOL_ENTRY;
    									ELSE
    										IF V_CINDEX = 6
    										THEN
    											SET V_ITEM6 = V_ITEMNUM_POOL_ENTRY;	
    										ELSE
    											IF V_CINDEX = 7
    											THEN
    												SET V_ITEM7 = V_ITEMNUM_POOL_ENTRY;
    											ELSE
    												IF V_CINDEX = 8
    												THEN
    													SET V_ITEM8 = V_ITEMNUM_POOL_ENTRY;
    												ELSE
    													IF V_CINDEX = 9
    													THEN
    														SET V_ITEM9 = V_ITEMNUM_POOL_ENTRY;	
    													ELSE
    														IF V_CINDEX = 10
    														THEN
    															SET V_ITEM10 = V_ITEMNUM_POOL_ENTRY;
    														END IF;
    													END IF;
    												END IF;
    											END IF;
    										END IF;
    									END IF;
    								END IF;
    							END IF;
    						END IF;
    					END IF;												
    				END IF;
    			  
    			END WHILE; 
    			
    			
    			SET V_COMMENT250= V_ITEM1 || V_ITEM2 || V_ITEM3 || V_ITEM4 || V_ITEM5 || V_ITEM6 || V_ITEM7 ||
    								V_ITEM8 || V_ITEM9 || V_ITEM10;
    			    			
    			SET V_ADJUSTMENT_NUM = V_ADJUSTMENT_NUM + 1;
    			--SET V_ADJUSTMENT_NUM_9 = V_ADJUSTMENT_NUM;
    			SET V_ADJUSTMENT_NUM_X = CHAR(V_ADJUSTMENT_NUM);
    			
    			SET V_ERRLOC = 'D250';
        		INSERT INTO ADJUSTMENT
				  ( ECMS_PROJECT_NUM,         
				    ADJUSTMENT_NUM,           
				    ADJUST_NUM_RVRSD,         
				    ADJUST_TYPE_CODE,         
				    FUND_CODE,                
				    COST_FUNCTION_CODE,       
				    INTERNAL_ORDER,           
				    ADJUST_AMT,               
				    LIQ_DMG_DAYS,             
				    ADJUST_STATUS_CODE,       
				    CREATED_BY,               
				    CREATED_BY_TS,            
				    LAST_MODIFIED_BY,         
				    LAST_MODIFIED_TS,         
				    ADJUST_COMMENT )          
				  VALUES                      
				    ( P_PROJNUM,     
				      V_ADJUSTMENT_NUM_X,   
				      '000',                  
				      '02',                   
				      V_PF_FUND_CODE,          
				      V_PF_COST_FUNCTION_CODE, 
				      V_PF_INTERNAL_ORDER,     
				      0,                      
				      0,                      
				      '30',                   
				      V_USER_ID,            
				      CURRENT_TIMESTAMP,      
				      V_USER_ID,            
				      CURRENT_TIMESTAMP,      
				      V_COMMENT250 )   ;     
    			
    			-- 2440- CLEAR COMMENT SHOULD I DO IT --
    			SET V_ITEM1 = SPACE(9);
    			SET V_ITEM2 = SPACE(9);
    			SET V_ITEM3 = SPACE(9);
    			SET V_ITEM4 = SPACE(9);
    			SET V_ITEM5 = SPACE(9);
    			SET V_ITEM6 = SPACE(9);
    			SET V_ITEM7 = SPACE(9);
    			SET V_ITEM8 = SPACE(9);
    			SET V_ITEM9 = SPACE(9);
    			SET V_ITEM10 = SPACE(9);
    			SET V_ERRLOC = 'D252';
    			DELETE FROM SESSION.G_ITEMNUM_POOL;
    			SET V_HOLD_ALT_GROUP_NUM = V_DI_ALT_GROUP_NUM;
    			-- 2430-ITEMNUM TO COMMENT BELOW --
    			SET V_COMMENT_ITEM = SUBSTR(V_DI_ITEM_NUMBER, 1, 4) || '-' || SUBSTR(V_DI_ITEM_NUMBER,5,4);
    			SET V_ERRLOC = 'D254';
    			INSERT INTO SESSION.G_ITEMNUM_POOL
    				(G_ITEMNUM_POOL_ENTRY)
    			VALUES
    				(V_COMMENT_ITEM);
    		ELSE
    			--2430-ITEMNUM TO COMMENT BELOW --	
    			SET V_COMMENT_ITEM = SUBSTR(V_DI_ITEM_NUMBER, 1, 4) || '-' || SUBSTR(V_DI_ITEM_NUMBER,5,4);
    			SET V_ERRLOC = 'D256';
    			INSERT INTO SESSION.G_ITEMNUM_POOL
    				(G_ITEMNUM_POOL_ENTRY)
    			VALUES
    				(V_COMMENT_ITEM);	
    				
    		END IF;	
    	END IF;	
    END IF;   	 
END WHILE;

IF V_ONE_ALTGROUP_FOUND = 'Y'
THEN
	SET V_ERRLOC = 'D260';
	OPEN ADJFUNDCODE;
    			FETCH ADJFUNDCODE             
  				INTO V_PF_FUND_CODE,         
			    	V_PF_COST_FUNCTION_CODE,
			    	V_PF_INTERNAL_ORDER   ;
			    CLOSE ADJFUNDCODE;   		  
    			
    			SET V_CINDEX = 0;
    			SET V_ERRLOC = 'D262';
    			OPEN ITEMSPOOL_CURSOR;
    			SET V_END_OF_ITEMSPOOL_CSR = 'N';
    			WHILE V_END_OF_ITEMSPOOL_CSR = 'N'
    			DO FETCH ITEMSPOOL_CURSOR
    			   INTO V_ITEMNUM_POOL_ENTRY;
    				IF SQLCODE = 100
    				THEN
    					SET V_END_OF_ITEMSPOOL_CSR = 'Y';
    					CLOSE ITEMSPOOL_CURSOR;
    				ELSE
    					SET V_CINDEX = V_CINDEX + 1;
    					IF V_CINDEX = 1
    					THEN
    						SET V_ITEM1 = V_ITEMNUM_POOL_ENTRY;
    					ELSE
    						IF V_CINDEX = 2
    						THEN
    							SET V_ITEM2 = V_ITEMNUM_POOL_ENTRY;
    						ELSE
    							IF V_CINDEX = 3
    							THEN
    								SET V_ITEM3 = V_ITEMNUM_POOL_ENTRY;	
    							ELSE
    								IF V_CINDEX = 4
    								THEN
    									SET V_ITEM4 = V_ITEMNUM_POOL_ENTRY;
    								ELSE
    									IF V_CINDEX = 5
    									THEN
    										SET V_ITEM5 = V_ITEMNUM_POOL_ENTRY;
    									ELSE
    										IF V_CINDEX = 6
    										THEN
    											SET V_ITEM6 = V_ITEMNUM_POOL_ENTRY;	
    										ELSE
    											IF V_CINDEX = 7
    											THEN
    												SET V_ITEM7 = V_ITEMNUM_POOL_ENTRY;
    											ELSE
    												IF V_CINDEX = 8
    												THEN
    													SET V_ITEM8 = V_ITEMNUM_POOL_ENTRY;
    												ELSE
    													IF V_CINDEX = 9
    													THEN
    														SET V_ITEM9 = V_ITEMNUM_POOL_ENTRY;	
    													ELSE
    														IF V_CINDEX = 10
    														THEN
    															SET V_ITEM10 = V_ITEMNUM_POOL_ENTRY;
    														END IF;
    													END IF;
    												END IF;
    											END IF;
    										END IF;
    									END IF;
    								END IF;
    							END IF;
    						END IF;
    					END IF;												
    				END IF;
    			  
    			END WHILE; 
    			
    			
    			SET V_COMMENT250= V_ITEM1 || V_ITEM2 || V_ITEM3 || V_ITEM4 || V_ITEM5 || V_ITEM6 || V_ITEM7 ||
    								V_ITEM8 || V_ITEM9 || V_ITEM10;
    			    			
    			SET V_ADJUSTMENT_NUM = V_ADJUSTMENT_NUM + 1;
    			SET V_ADJUSTMENT_NUM_9 = V_ADJUSTMENT_NUM;
    			SET V_ADJUSTMENT_NUM_X = V_ADJUSTMENT_NUM_9;
    			
    			SET V_ERRLOC = 'D270';
        		INSERT INTO ADJUSTMENT
				  ( ECMS_PROJECT_NUM,         
				    ADJUSTMENT_NUM,           
				    ADJUST_NUM_RVRSD,         
				    ADJUST_TYPE_CODE,         
				    FUND_CODE,                
				    COST_FUNCTION_CODE,       
				    INTERNAL_ORDER,           
				    ADJUST_AMT,               
				    LIQ_DMG_DAYS,             
				    ADJUST_STATUS_CODE,       
				    CREATED_BY,               
				    CREATED_BY_TS,            
				    LAST_MODIFIED_BY,         
				    LAST_MODIFIED_TS,         
				    ADJUST_COMMENT )          
				  VALUES                      
				    ( P_PROJNUM,     
				      V_ADJUSTMENT_NUM_X,   
				      '000',                  
				      '02',                   
				      V_PF_FUND_CODE,          
				      V_PF_COST_FUNCTION_CODE, 
				      V_PF_INTERNAL_ORDER,     
				      0,                      
				      0,                      
				      '30',                   
				      V_USER_ID,            
				      CURRENT_TIMESTAMP,      
				      V_USER_ID,            
				      CURRENT_TIMESTAMP,      
				      V_COMMENT250 )   ;     
    			
 END IF;	


OPEN SINGLE_PARM_CURSOR;


END P1
