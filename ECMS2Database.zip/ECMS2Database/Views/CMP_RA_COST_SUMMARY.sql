------------------------------------------------------------------------
--     View: CMP_RA_COST_SUMMARY
------------------------------------------------------------------------
  --DROP view ecmsxadm.CMP_RA_COST_SUMMARY;
--CREATE view ecmsxadm.CMP_RA_COST_SUMMARY as

SELECT RA.RA_NUM, 
       SUM(RA.TOTAL_PART_COST) AS TOTAL_PART_AMT, 
       SUM(RA.TOTAL_BUDGET_COST) AS TOTAL_BUDGET_AMT, 
       SUM(RA.TOTAL_PROJECT_BID_ITEM_COST) AS TOTAL_PROJECT_AMT,
       SUM(RA.TOTAL_PART_COST) + 
          SUM(RA.TOTAL_BUDGET_COST) +
          SUM(RA.TOTAL_PROJECT_BID_ITEM_COST) AS TOTAL_COST     
  FROM ( 
        SELECT DISTINCT     -- Get Part costs
               AX.RA_NUM, 
               COALESCE(APS.PART_CURRENT_COST,0) 
               + COALESCE(ASP.SUPPL_PART_COST,0)
                 AS TOTAL_PART_COST, 
               0 as TOTAL_BUDGET_COST, 
               0 AS TOTAL_PROJECT_BID_ITEM_COST
          FROM ECMSXADM.RAS_AGR_PART_XREF AX

         INNER JOIN ECMSXADM.AGR_AGREEMENT A
            ON A.AGR = AX.AGR

         INNER JOIN ECMSXADM.AGR_PART AP
            ON AP.AGR = AX.AGR
           AND AP.PART_ID = AX.PART_ID
           AND AP.PART_STATUS_CODE IN ('20', '25', '30', '35', '40')
                 
         INNER JOIN ECMSXADM.AGR_PART_SUMMARY APS
            ON APS.AGR = AP.AGR
           AND APS.PART_ID = AP.PART_ID  
          
         LEFT OUTER JOIN ECMSXADM.AGR_SUPPLEMENTED_PART ASP
            ON ASP.AGR = AP.AGR
           AND ASP.PART_ID = AP.PART_ID
           AND ASP.SUPPL_PART_STATUS_CODE = '20'  

         WHERE A.AGR_STATUS_CODE IN ('50', '55', '60', '65', '70')
                 
         UNION
        
        SELECT DISTINCT     -- Get Budget costs 
               b.RA_NUM, 
               0 AS TOTAL_PART_COST, 
               COALESCE(BP.PHASE_BUDGET_AMT,0) AS TOTAL_BUDGET_COST,
               0 AS TOTAL_PROJECT_BID_ITEM_COST
          FROM ECMSXADM.BGT_RAS b
               
         INNER JOIN ECMSXADM.AGR_AGREEMENT a
            ON a.AGR = b.AGR
           
         INNER JOIN  --  Get a list of current Budgets   
               (SELECT AGR, MAX(REVISION_ID) AS MAXID                                  
                  FROM ECMSXADM.BGT_BUDGET                                      
                 WHERE BUDGET_STATUS_CODE IN ('05', '09')   
                 GROUP BY AGR
               ) BGT 
            ON BGT.AGR  = B.AGR   
       
         INNER JOIN ECMSXADM.BGT_PHASE BP
            ON BP.AGR = BGT.AGR
           AND BP.REVISION_ID = BGT.MAXID
         
         WHERE a.AGR_STATUS_CODE IN ('60', '65', '70')
           AND b.RA_NUM is not null
           AND b.RA_NUM <> ''
                 
         UNION
         
        SELECT DISTINCT     --  Get Project Bid Item Costs
               PX.RA_NUM, 
               0 AS TOTAL_PART_COST, 
               0 AS TOTAL_BUDGET_COST, 
               COALESCE(CBI.BID_ITEM_PRICE,0)
                 AS TOTAL_PROJECT_BID_ITEM_COST                  
          FROM ECMSXADM.RAS_PROJECT_XREF PX

          LEFT OUTER JOIN ECMSXADM.PROJECT p
            ON p.ECMS_PROJECT_NUM = PX.ECMS_PROJECT_NUM
                  
         INNER JOIN ECMSXADM.CONTR_BID_ITEM CBI
            ON CBI.ECMS_PROJECT_NUM = PX.ECMS_PROJECT_NUM   

         WHERE p.PROJ_STATUS_CODE IN
               ('10', '20', '30', '40', '50', '55', '60') 
   
       ) RA
       
 GROUP BY RA.RA_NUM;
 
 --GRANT SELECT ON ecmsxadm.CMP_RA_COST_SUMMARY to ECMSODBC, HWYDEV;
 
--SELECT * FROM ecmsxadm.CMP_RA_COST_SUMMARY;