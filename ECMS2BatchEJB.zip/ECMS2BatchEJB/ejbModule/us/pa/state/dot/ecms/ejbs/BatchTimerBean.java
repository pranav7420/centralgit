package us.pa.state.dot.ecms.ejbs;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Date;
import java.util.Iterator;

import javax.ejb.SessionBean;
import javax.ejb.TimedObject;
import javax.ejb.Timer;
import javax.ejb.TimerService;

import us.pa.state.dot.ecms.dataobjects.DOCOMBatch;
import us.pa.state.dot.framework.util.PDTime;
import us.pa.state.dot.framework.util.PDTimeStamp;
import us.pa.state.dot.framework.util.PDUtil;

/**
 * Bean implementation class for Enterprise Bean: BatchTimer
 */
public class BatchTimerBean extends us.pa.state.dot.framework.ejb.PDSessionBean
	implements SessionBean, TimedObject {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2903987069196019974L;
	private javax.ejb.SessionContext mySessionCtx;
	/**
	 * getSessionContext
	 */
	public javax.ejb.SessionContext getSessionContext() {
		return mySessionCtx;
	}
	/**
	 * setSessionContext
	 */
	public void setSessionContext(javax.ejb.SessionContext ctx) {
		mySessionCtx = ctx;
	}
	/**
	 * ejbCreate
	 */
	public void ejbCreate() throws javax.ejb.CreateException {
	}
	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
	}
	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() {
	}
	public void ejbTimeout(Timer timer) {
		DOCOMBatch doBatch = (DOCOMBatch) timer.getInfo();
		System.out.println("BathTimerBean - Request Received to ejbTimeout method");
		try {
			String response = "";
			try {
				response = run(doBatch);
			} catch (Exception ex) {
				response = ex.getMessage();
			}
			if (!response.equalsIgnoreCase("SUCCESS")) {
				logError(doBatch);
			}
			if (!doBatch.isInterval()) {
				System.out.println("BathTimerBean -doBatch.isInterval() is not true");
				schedule(doBatch);
			}
		} catch (Exception e) {
			System.out.println("Error in ejbTimeout: " + e.getMessage());
		}
	}
	public void schedule(DOCOMBatch doBatch) throws Exception {
		System.out.println("BathTimerBean - Request Received to schedule method");
		try {
		cancel(doBatch);
		TimerService timerService = getSessionContext().getTimerService();
		if (doBatch.isInterval()) {
			timerService.createTimer(doBatch.getPDNumber(DOCOMBatch.INITIAL_DELAY).longValue()*1000*60, doBatch.getPDNumber(DOCOMBatch.INTERVAL).longValue()*1000*60, doBatch);
		} else {
			Date date = PDUtil.createTSfromDateTime(null, (PDTime)doBatch.getValue(DOCOMBatch.TIME_OF_DAY));
			if (date.before(new Date())) {
				date = new Date(date.getTime() + 1000*60*60*24); //add 24 hours
			}
			System.out.println("BathTimerBean - createTimer");
			timerService.createTimer(date, 1000*60*60*24, doBatch);
		}
		}catch( Exception e) {
			System.out.println("BathTimerBean - Exception log to check on schedule method"+e);
			System.out.println("******BathTimerBean-schedule(doBatch)-Exception printstacktrace******");
			e.printStackTrace(System.out);
		}
	}
	public void cancel(DOCOMBatch doBatch) throws Exception {
		System.out.println("BathTimerBean - Request Received to cancel(doBatch) method");
		try {
		Iterator timers = getSessionContext().getTimerService().getTimers().iterator();
		while (timers.hasNext()) {
			Timer timer = (Timer) timers.next();
			DOCOMBatch info = (DOCOMBatch)timer.getInfo();
			System.out.println("BathTimerBean - batch process id from the timer :"+info.getPDNumber(DOCOMBatch.BATCH_PROCESS_ID));
			System.out.println("BathTimerBean - batch process id from the doBatch :"+doBatch.getPDNumber(DOCOMBatch.BATCH_PROCESS_ID));
			if (info.getPDNumber(DOCOMBatch.BATCH_PROCESS_ID).equals(doBatch.getPDNumber(DOCOMBatch.BATCH_PROCESS_ID))) {
				timer.cancel();
			}
		}
		}catch( Exception e) {
			System.out.println("BathTimerBean - Exception log for Cancel(doBatch) method"+e);
			System.out.println("******BathTimerBean- cancel(boBatch) - Exception printstacktrace******");
			e.printStackTrace(System.out);
		}
	}
	public void cancel() throws Exception {
		System.out.println("BathTimerBean - Request Received to Cancel() method");
		Iterator timers = getSessionContext().getTimerService().getTimers().iterator();
		while (timers.hasNext()) {
			((Timer) timers.next()).cancel();
		}
	}
	public DOCOMBatch setTimerInfo(DOCOMBatch doBatch) throws Exception  {
		System.out.println("BathTimerBean - Request Received to setTimerInfo method");
		doBatch.setValue(DOCOMBatch.STATUS, "Stopped");
		Iterator timers = getSessionContext().getTimerService().getTimers().iterator();
		while (timers.hasNext()) {
			Timer timer = (Timer) timers.next();
			Object o = null;
			try {
				o = timer.getInfo();
			} catch (Exception ex) {
				timer.cancel();
			}
			if (o instanceof DOCOMBatch) {
				DOCOMBatch doBatchTimerInfo = (DOCOMBatch) o;
				if (doBatch.getPDNumber(DOCOMBatch.BATCH_PROCESS_ID).equals(doBatchTimerInfo.getPDNumber(DOCOMBatch.BATCH_PROCESS_ID))) {
					doBatch.setValue(DOCOMBatch.NEXT_RUN_DATE, new PDTimeStamp(timer.getNextTimeout()));
					doBatch.setValue(DOCOMBatch.STATUS, "Scheduled");
				}
			}
		}
		return doBatch;
	}
	public String run(DOCOMBatch doBatch) throws Exception {
		System.out.println("BathTimerBean - Request Received to run method");
		StringBuffer response = null;
		try {
		URL url = new URL(doBatch.getString(DOCOMBatch.WORKER_SERVLET));
		System.out.println("BatchTimerBean - URL:"+url.toString());
		// Set properties on a new HTTP Connection
		HttpURLConnection con = (HttpURLConnection)url.openConnection();
		System.out.println("BatchTimerBean - Connection Open to:"+con.getURL());
		// Don't use cache, must always try to get a fresh copy of the object
		con.setUseCaches(false);
		System.out.println("BatchTimerBean - usecaches set to false");
		//Http redirects should be automatically followed
		HttpURLConnection.setFollowRedirects(true);
		System.out.println("BatchTimerBean - FollwedRedirects set to true");
		// read the response from the URL into a string buffer
		InputStreamReader isr = new InputStreamReader(con.getInputStream());
		System.out.println("BatchTimerBean - Input stream opened from connection");
		BufferedReader b = new BufferedReader(isr); 
		String s = ""; 
		response = new StringBuffer();
		while ( (s = b.readLine()) != null ) {
			response.append(s);  
		}
		isr.close();
		b.close();
		System.out.println("BatchTimerBean - Connection Request Method:"+con.getRequestMethod());
		System.out.println("BatchTimerBean - Connection response code:"+con.getResponseCode());
		System.out.println("BatchTimerBean - RESPONSE:"+response.toString());
		}catch( Exception e) {
			System.out.println("Exception log"+e);
			System.out.println("******Exception printstacktrace******");
			e.printStackTrace(System.out);
		}
		return response.toString();
	}
	private void logError(DOCOMBatch doBatch) {
		
	}
}
