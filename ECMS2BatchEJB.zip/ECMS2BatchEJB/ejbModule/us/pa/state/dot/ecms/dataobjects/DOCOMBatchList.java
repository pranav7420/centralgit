/*
 * Created on Jun 11, 2007
 *
 */
package us.pa.state.dot.ecms.dataobjects;

import us.pa.state.dot.framework.data.PDSortableDataObjectList;
import us.pa.state.dot.framework.interfaces.PDClearable;


/**
 * @author msultza
 *
 */
public class DOCOMBatchList extends PDSortableDataObjectList implements PDClearable {

	private static final long serialVersionUID = -8542254281300936553L;

	/**
	 * @param sortCol
	 * @param ascendingOrder
	 */
	public DOCOMBatchList(String sortCol, boolean ascendingOrder) {
		super(sortCol, ascendingOrder);
	}

}
