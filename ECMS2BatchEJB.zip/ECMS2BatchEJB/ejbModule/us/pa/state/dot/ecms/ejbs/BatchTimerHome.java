package us.pa.state.dot.ecms.ejbs;

/**
 * Home interface for Enterprise Bean: BatchTimer
 */
public interface BatchTimerHome extends javax.ejb.EJBHome {

	/**
	 * Creates a default instance of Session Bean: BatchTimer
	 */
	public us.pa.state.dot.ecms.ejbs.BatchTimer create()
		throws javax.ejb.CreateException,
		java.rmi.RemoteException;
}
