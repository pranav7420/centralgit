package us.pa.state.dot.ecms.ejbs;

import com.ibm.ejs.container.*;

/**
 * EJSStatelessBatchTimerHomeBean_1cb8ea30
 */
public class EJSStatelessBatchTimerHomeBean_1cb8ea30 extends EJSHome {
	static final long serialVersionUID = 61;
	/**
	 * EJSStatelessBatchTimerHomeBean_1cb8ea30
	 */
	public EJSStatelessBatchTimerHomeBean_1cb8ea30() throws java.rmi.RemoteException {
		super();	}
	/**
	 * create
	 */
	public us.pa.state.dot.ecms.ejbs.BatchTimer create() throws javax.ejb.CreateException, java.rmi.RemoteException {
BeanO beanO = null;
us.pa.state.dot.ecms.ejbs.BatchTimer result = null;
boolean createFailed = false;
try {
	result = (us.pa.state.dot.ecms.ejbs.BatchTimer) super.createWrapper(null);
}
catch (javax.ejb.CreateException ex) {
	createFailed = true;
	throw ex;
} catch (java.rmi.RemoteException ex) {
	createFailed = true;
	throw ex;
} catch (Throwable ex) {
	createFailed = true;
	throw new CreateFailureException(ex);
} finally {
	if (createFailed) {
		super.createFailure(beanO);
	}
}
return result;	}
}
