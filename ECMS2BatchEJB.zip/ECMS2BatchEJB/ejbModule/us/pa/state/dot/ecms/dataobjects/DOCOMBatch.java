/*
 * Created on Jun 11, 2007
 *
 */
package us.pa.state.dot.ecms.dataobjects;

import us.pa.state.dot.framework.data.PDDataObject;

/**
 * @author msultza
 *
 */
public class DOCOMBatch extends PDDataObject {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7945538538879621425L;
	public static final String BATCH_PROCESS_ID = "BATCH_PROCESS_ID";
	public static final String BATCH_PROCESS_NAME = "BATCH_PROCESS_NAME";
	public static final String BATCH_PROCESS_DESC = "BATCH_PROCESS_DESC";
	public static final String CLASS_NAME = "CLASS_NAME";
	public static final String METHOD_NAME = "METHOD_NAME";
	public static final String INITIAL_DELAY = "INITIAL_DELAY";
	public static final String INTERVAL = "INTERVAL";
	public static final String TIME_OF_DAY = "TIME_OF_DAY";
	public static final String LAST_EXECUTION_TS = "LAST_EXECUTION_TS";
	public static final String LAST_SCHEDULED_TS = "LAST_SCHEDULED_TS";
	public static final String LAST_EXECUTION_RESULT_CODE = "LAST_EXECUTION_RESULT_CODE";
	public static final String LAST_EXECUTION_RESULT_DESC = "LAST_EXECUTION_RESULT_DESC";
	
	public static final String STATUS = "STATUS";
	public static final String NEXT_RUN_DATE = "NEXT_RUN_DATE";

	public static final String BATCH_SERVLET = "BATCH_SERVLET";
	public static final String WORKER_SERVLET = "WORKER_SERVLET";
	public static final String RESULT_SERVLET = "RESULT_SERVLET";
	
	
	public DOCOMBatch() {
		super();
	}
	public boolean isProcessSheduled() {
		return (getString(STATUS).equalsIgnoreCase("Scheduled"));
	}
	
	public boolean isInterval() {
		return getValue(INTERVAL)!=null;
	}
}
