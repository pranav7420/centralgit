package us.pa.state.dot.ecms.ejbs;

import us.pa.state.dot.ecms.dataobjects.DOCOMBatch;

/**
 * Remote interface for Enterprise Bean: BatchTimer
 */
public interface BatchTimer extends javax.ejb.EJBObject {

	/**
	 * @param doBatch
	 * @throws Exception
	 * @throws java.rmi.RemoteException
	 */
	public void schedule(DOCOMBatch doBatch) throws Exception, java.rmi.RemoteException;

	/**
	 * @param doBatch
	 * @throws Exception
	 * @throws java.rmi.RemoteException
	 */
	public void cancel(DOCOMBatch doBatch) throws Exception, java.rmi.RemoteException;

	/**
	 * @throws Exception
	 * @throws java.rmi.RemoteException
	 */
	public void cancel() throws Exception, java.rmi.RemoteException;

	/**
	 * @param doBatch
	 * @return
	 * @throws Exception
	 * @throws java.rmi.RemoteException
	 */
	public DOCOMBatch setTimerInfo(DOCOMBatch doBatch) throws Exception, java.rmi.RemoteException;

	/**
	 * @param doBatch
	 * @return
	 * @throws Exception
	 * @throws java.rmi.RemoteException
	 */
	public String run(DOCOMBatch doBatch) throws Exception, java.rmi.RemoteException;
}
