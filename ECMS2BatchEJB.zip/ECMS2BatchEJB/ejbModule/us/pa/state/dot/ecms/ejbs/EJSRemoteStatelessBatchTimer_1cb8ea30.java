package us.pa.state.dot.ecms.ejbs;

import com.ibm.ejs.container.*;

/**
 * EJSRemoteStatelessBatchTimer_1cb8ea30
 */
public class EJSRemoteStatelessBatchTimer_1cb8ea30 extends EJSWrapper implements BatchTimer {
	/**
	 * EJSRemoteStatelessBatchTimer_1cb8ea30
	 */
	public EJSRemoteStatelessBatchTimer_1cb8ea30() throws java.rmi.RemoteException {
		super();	}
	/**b
	 * run
	 */
	public java.lang.String run(us.pa.state.dot.ecms.dataobjects.DOCOMBatch doBatch) throws java.lang.Exception, java.rmi.RemoteException {
		System.out.println("request received to run method from EJSRemoteStatelessBatchTimer");
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		Object[] _jacc_parms = null;
		java.lang.String _EJS_result = null;
		try {
			if (container.doesJaccNeedsEJBArguments( this ))
			{
				_jacc_parms = new Object[1];
				_jacc_parms[0] = doBatch;
			}
	us.pa.state.dot.ecms.ejbs.BatchTimerBean beanRef = (us.pa.state.dot.ecms.ejbs.BatchTimerBean)container.preInvoke(this, 0, _EJS_s, _jacc_parms);
			_EJS_result = beanRef.run(doBatch);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (java.lang.RuntimeException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (java.lang.Exception ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try{
				container.postInvoke(this, 0, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return _EJS_result;
	}
	/**
	 * setTimerInfo
	 */
	public us.pa.state.dot.ecms.dataobjects.DOCOMBatch setTimerInfo(us.pa.state.dot.ecms.dataobjects.DOCOMBatch doBatch) throws java.lang.Exception, java.rmi.RemoteException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		Object[] _jacc_parms = null;
		us.pa.state.dot.ecms.dataobjects.DOCOMBatch _EJS_result = null;
		try {
			if (container.doesJaccNeedsEJBArguments( this ))
			{
				_jacc_parms = new Object[1];
				_jacc_parms[0] = doBatch;
			}
	us.pa.state.dot.ecms.ejbs.BatchTimerBean beanRef = (us.pa.state.dot.ecms.ejbs.BatchTimerBean)container.preInvoke(this, 1, _EJS_s, _jacc_parms);
			_EJS_result = beanRef.setTimerInfo(doBatch);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (java.lang.RuntimeException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (java.lang.Exception ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try{
				container.postInvoke(this, 1, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return _EJS_result;
	}
	/**
	 * cancel
	 */
	public void cancel() throws java.lang.Exception, java.rmi.RemoteException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		Object[] _jacc_parms = null;
		
		try {
			if (container.doesJaccNeedsEJBArguments( this ))
			{
				_jacc_parms = new Object[0];
			}
	us.pa.state.dot.ecms.ejbs.BatchTimerBean beanRef = (us.pa.state.dot.ecms.ejbs.BatchTimerBean)container.preInvoke(this, 2, _EJS_s, _jacc_parms);
			beanRef.cancel();
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (java.lang.RuntimeException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (java.lang.Exception ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try{
				container.postInvoke(this, 2, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return ;
	}
	/**
	 * cancel
	 */
	public void cancel(us.pa.state.dot.ecms.dataobjects.DOCOMBatch doBatch) throws java.lang.Exception, java.rmi.RemoteException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		Object[] _jacc_parms = null;
		
		try {
			if (container.doesJaccNeedsEJBArguments( this ))
			{
				_jacc_parms = new Object[1];
				_jacc_parms[0] = doBatch;
			}
	us.pa.state.dot.ecms.ejbs.BatchTimerBean beanRef = (us.pa.state.dot.ecms.ejbs.BatchTimerBean)container.preInvoke(this, 3, _EJS_s, _jacc_parms);
			beanRef.cancel(doBatch);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (java.lang.RuntimeException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (java.lang.Exception ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try{
				container.postInvoke(this, 3, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return ;
	}
	/**
	 * schedule
	 */
	public void schedule(us.pa.state.dot.ecms.dataobjects.DOCOMBatch doBatch) throws java.lang.Exception, java.rmi.RemoteException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		Object[] _jacc_parms = null;
		
		try {
			if (container.doesJaccNeedsEJBArguments( this ))
			{
				_jacc_parms = new Object[1];
				_jacc_parms[0] = doBatch;
			}
	us.pa.state.dot.ecms.ejbs.BatchTimerBean beanRef = (us.pa.state.dot.ecms.ejbs.BatchTimerBean)container.preInvoke(this, 4, _EJS_s, _jacc_parms);
			beanRef.schedule(doBatch);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (java.lang.RuntimeException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (java.lang.Exception ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try{
				container.postInvoke(this, 4, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return ;
	}
}
